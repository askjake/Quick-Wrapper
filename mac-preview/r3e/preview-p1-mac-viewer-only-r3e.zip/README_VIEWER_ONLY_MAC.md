# VIEWER-ONLY macOS PREVIEW PACKAGE  -  README (R3E)

**NOT A QUALIFIED RELEASE  -  ENGINEERING PREVIEW. No window from this package has ever been shown on macOS.**
**Do NOT run this on a managed machine until your employer has confirmed it is permitted.**

## What this is

A tiny package that shows two of the wizard's synthetic preview screens, driven
by the **actual frozen viewer source** and launched by one macOS entry point,
`view_preview_mac.py`. On-screen values are **synthetic placeholders only**; no
gateway is contacted, no SSH/AWS/network call is made.

Which program produces which exit code: exit 4 (package integrity) is returned by this
entry script when EITHER its own early in-process verifier OR the frozen viewer's
`verify_package` refuses the package; exit 5 (viewer integrity) is returned when the
frozen viewer's `run_gui` raises its integrity error; exits 2 and 6 come from the
entry script alone.

## What changed in R3E (read this if you ran R3D)

R3D was run on a real Mac. It verified the package (9 files), accepted the Homebrew
Tk file, and then stopped before any window appeared with
`REFUSED - unexpected import blocked: package_local` (exit code 2).

The cause was found by reading the R3D launcher and replaying its own import checks
against a real module specification for the packaged viewer file: the launcher imports
the frozen viewer file (`preview_viewer.py`) from the verified package folder, but its
rule for modules in the package folder allowed only the six product modules, by name.
The viewer file is not one of them, so the launcher's own import of it was refused as
"package_local". The checker was blocking a file the launcher needs in order to start.

R3E changes exactly that and nothing else:

- The launcher now also accepts the ONE file `preview_viewer.py`, and only when ALL of
  these hold: the package has already been verified; the name is exactly
  `preview_viewer` (a look-alike name or a sub-module name is not accepted); it is a
  plain module loaded by Python's own standard source-file loader (the loader's class
  itself is checked, not only its name); the file is not a link; and its real path is
  exactly the file in the verified package folder. Everything else in the package
  folder is still refused.
  If the viewer file fails one of these checks you will see
  `REFUSED - unexpected import blocked: <word>` (exit code 2), where `<word>` is one of
  `viewer_unverified`, `viewer_loader`, `viewer_not_module`, `viewer_symlink`,
  `viewer_path_mismatch`. These are reason words, not module names. Stop and report
  the line.
- The six product modules, the deny list (network and process modules), the Homebrew
  Tk file checks, the package check, the isolated start-up (`-I -B -S`) and the
  tripwires are unchanged.
- The built-in self-test now checks this with the launcher's real import checker and
  real module specifications. When it is run from the package folder (`--self-test`
  next to the packaged files) it also checks every package-local import found in the
  packaged files, so that this kind of mismatch is reported by the self-test and not
  by the first run.

What R3E does NOT claim: it has not been run on macOS. The R3D run never got past the
viewer import, so nothing after that point (importing the six product modules, starting
Tk, drawing the window, the footer lock, closing) has been run on a Mac with this
package, and the next step may reveal another refusal. That is an acceptable result;
report it exactly as printed. The result that matters from the self-test is the word
`SELFTEST PASS`; the counts differ by situation (on the developer replay, 372 checks and
6 skipped when run from the package folder), so report the line you actually get.

## What changed in R3D (an earlier version, kept for history)

Two earlier runs on a real Mac each stopped at a different point:

1. The first package (R3b) printed `REFUSED - unexpected import blocked: fake_builtin`
   (exit 2). R3c addressed that loader-classification mistake.
2. R3c, run with Homebrew's Python 3.13 (`/opt/homebrew/bin/python3.13`), verified the
   package and then stopped with an uncaught `ModuleNotFoundError: No module named
   '_tkinter'` and exit code 1. Read-only diagnostics on that Mac (not a run of this
   package) showed the cause: Homebrew ships Tk's Python binding as a separate
   package (`python-tk@3.13`); the interpreter normally finds it through its own
   start-up code, which `-S` switches off. So under `-I -B -S` the extension exists
   but is not visible.

R3D changes exactly two things and nothing else:

- **One named Tk extension.** If, and only if, the running interpreter is a Homebrew
  `python@3.13` and its matching `python-tk@3.13` package is installed at the
  expected place, the launcher locates the single file `_tkinter.cpython-313-darwin.so`
  and lets the import system load THAT file for the name `_tkinter` and nothing else.
  Nothing is added to `sys.path`, `site` and `sitecustomize` are not run, and no other
  file or module from that package is trusted. Details and limits are in the section
  "Homebrew Tk extension (R3D)" below.
- **No more tracebacks at start-up.** A start-up import failure (such as a missing
  `_tkinter`) or any other unexpected start-up error now prints ONE sanitised line
  with no path and exits with code 6, instead of an uncaught traceback with exit 1.

Everything else is as in R3c: the deny list, the origin rules, the package check,
the isolated start-up (`-I -B -S`), the tripwires and the R3c loader correction.

What R3D does NOT claim: it has not been run on macOS, so it is not known whether the
window now opens or whether a later check refuses something else (for example a
directory permission on your Homebrew install). Whether a given module is accepted
end-to-end on your interpreter is only learnable by running it. If you see any
`REFUSED` line, stop and send the full output and exit code exactly as printed. The
result that matters is the word `SELFTEST PASS`; the counts differ by version and situation (the R3E
section above gives the current developer-replay figures), so report the line you
actually get.

## Homebrew Tk extension (R3D): what is trusted and what is not

The launcher derives ONE candidate file from the interpreter's own Homebrew layout. It
never reads a path from the environment or from you. It accepts that file only if ALL
of these hold; any failure refuses with one fixed reason word and no path:

- the interpreter lives under `Cellar/python@3.13` and the matching `python-tk@3.13`
  package has the same `3.13.<micro>` version (a Homebrew `_<n>` revision is allowed);
- the file is directly in that package's `libexec` folder, is named for this
  interpreter's ABI (`cpython-313`), is a regular file (not a link), is not larger
  than 64 MiB, begins with the 64-bit Mach-O header for your CPU (arm64 or x86_64),
  is owned by you or root, and is not group- or world-writable;
- EVERY directory on its path, from `libexec` up to and including `/`, is a real
  directory owned by you or root and is never world-writable; group-write is allowed
  only when the group is macOS's `admin` group (group id 80, which is an assumption
  that you can check with `dscl . -read /Groups/admin PrimaryGroupID`).

Reason words you may see after `tk-extension:` are: `not_homebrew`, `keg_absent`,
`keg_location`, `keg_version`, `ext_symlink`, `ext_absent`, `ext_not_regular`,
`ext_owner`, `ext_perms`, `dir_owner`, `dir_perms`, `dir_group`, `abi_name`,
`abi_macho`, `machine_unsupported`, `tk_probe_error`.

When the file is accepted, the launcher prints one line after the banner,
`tk-extension: homebrew python-tk accepted (sha256 <64 hex digits>)`. That hash is
simply the observed value of the file on your machine, for you to record. It is NOT a
pinned hash and NOT proof that the file is authentic.

Honest limits of this trust:

- It is **structural, not cryptographic.** Homebrew's folders normally belong to your
  user, and the rule also accepts folders writable by the macOS `admin` group. So anyone
  who can act as you, **or any member of the `admin` group**, could replace that file or
  a folder on its path. This is similar to the trust the design already places in the
  Python standard library on your machine.
- There is a short gap between the check and the moment the file is loaded.
- Loading `_tkinter` makes the operating system load the Tcl/Tk libraries from
  Homebrew's `tcl-tk` package and makes Tk read its own script files. The import
  checker does not see those loads. `TCL_LIBRARY` and `TK_LIBRARY` must stay unset.
- The `admin` group id 80 is an assumption about macOS and is not checked by this
  package against your machine.

## What this is NOT

- It is **NOT isolated.** It imports the real pinned product source (`wizard.py`,
  `model.py`, `quick_reg.py`, `deploy_lib.py`, `native_gateway.py`,
  `bootstrap_lib.py`) and, during start-up, loads `subprocess` and `sqlite3`
  (module load only -- nothing is spawned, no database is opened). Synthetic
  on-screen values do not make it isolated.
- It is **NOT the standard macOS runner** and **NOT a qualification**.

## Launch command shape (isolated mode is REQUIRED)

```
python3 -I -B -S <pkg-dir>/view_preview_mac.py [--self-test]
```

`-I` (isolated) **and** `-B` (no bytecode) **and** `-S` (no site) are all
required; the launcher refuses otherwise (`sys.flags.isolated` is enforced). It
also refuses if the platform is not macOS, if run as root, or if **any
environment variable whose name starts with `PYTHON` is set** (the value is
never read or printed). The only accepted argument is `--self-test` (anything
else is refused before any file is read).

## Exit codes

| Code | Meaning |
|------|---------|
| 0 | clean Quit |
| 2 | the launcher's own refusals, BEFORE or DURING GUI start-up: bad argument; wrong interpreter / platform / not isolated; root; a `PYTHON*` env var set; path-hygiene; a blocked/denied import; an **ambiguous or untrusted module origin**; a missing `stdlib_module_names`; or any armed tripwire firing. ALSO the two POST-run refusals, after the window closes: a denied name present in `sys.modules`, and a loaded module that is neither standard library nor product. Any code 2 is a launcher refusal; it is not reported as a package-integrity (4) or viewer-integrity (5) failure |
| 4 | package integrity failure (the in-process `trusted_verify` or the frozen `verify_package` refused) |
| 5 | viewer integrity failure (the frozen `run_gui` raised `IntegrityError`) |
| 6 | **GUI or start-up could not proceed**: Tk init / `run_gui` raised a non-refusal exception, a start-up import such as `tkinter` or `_tkinter` failed (R3D prints `REFUSED - GUI start failure: <ErrorClass> <module>`, optionally followed by `(tk-extension: <reason word>)`), or an unexpected start-up error occurred (`REFUSED - startup failure: <ErrorClass>`). One sanitised line, no path. The launcher NEVER retries with relaxed settings |

## Network / origin policy (important)

The **only** network/origin mechanism is a `sys.meta_path` **origin finder**,
armed before any product import. For each new import it (1) refuses any DENY
name **first and independently** (deny wins), then (2) checks the module's
ORIGIN against trusted interpreter/standard-library roots, the product-module
rule and the exact-path rule for the one frozen viewer file **before the module's
code runs**, then (3) defers to the normal machinery.
The delta check after `run_gui` is now **"stdlib or product, deny wins"** -- not
a hand-written list of module names. There is **no runtime socket guard and no
fallback**; the rules are never relaxed on failure. A genuine incompatibility on
a real interpreter is recorded as an **OBSERVED LIMITATION** for a separately
approved correction; it is not worked around here.

## Standard-library rule and its known limitation

A module is accepted only if the running interpreter's own
`sys.stdlib_module_names` classes it as standard library **and** its file
originates under a trusted stdlib root -- or it is one of the six product
modules, or the one frozen viewer file, loaded from the verified package folder. **site-packages and user-site
are NOT trusted roots**, even though they can live under the stdlib directory, so
a stdlib-NAMED file found there is **refused**. APFS is case-insensitive; the
origin comparison is conservative (it may over-refuse, never over-accept).

> **Known limitation:** a legitimately installed but **unexpectedly located**
> stdlib or `_tkinter` module is **REFUSED** (fail closed), except the single
> Homebrew `python-tk` file described above. This is an OBSERVED LIMITATION for a
> separately approved correction.
>
> If this happens the preview will NOT start. You will see a single `REFUSED` line
> and exit code 2 (a launcher refusal). That is the designed fail-closed behaviour,
> not a package defect - report the line and stop.
>
> If the Homebrew `python-tk` file itself fails the rule above, you will instead see the
> exit-6 line with a `tk-extension:` reason word.

## Pre-launch read-only checks (optional; print COUNTS and CLASS words only)

From the extracted package directory, each as a one-liner under isolation; none
of these print any path:

```
python3 -I -B -S -c "import sys;print('isolated',int(sys.flags.isolated),'nosite',int(sys.flags.no_site),'nobytecode',int(sys.flags.dont_write_bytecode))"
python3 -I -B -S -c "import sys;print('stdlib_names_ok',isinstance(getattr(sys,'stdlib_module_names',None),frozenset))"
python3 -I -B -S -c "import os;print('members',len([n for n in os.listdir('.') if not n.startswith('.')]))"
```

## Operator procedure (integrity standpoint)

1. **MANDATORY** -- verify the ZIP SHA-256 **out of band** BEFORE extracting.
2. **MANDATORY** -- extract under your home; do **not** open the folder in Finder
   first (avoids `.DS_Store` / `._*`, which the verifier refuses).
3. **RECOMMENDED** -- `shasum -a 256 view_preview_mac.py` and compare to the
   value in the hand-off before launch (the entry script cannot verify itself
   in-process; the ZIP hash, plus this optional entry-file hash, is its only
   anchor).
4. **MANDATORY** -- launch exactly `python3 -I -B -S <pkg-dir>/view_preview_mac.py`.
5. **MANDATORY** -- the in-process verifier prints the manifest's own SHA-256
   (`PREVIEW_MANIFEST.sha256 digest: ...`); **compare it to the hand-off value**.
6. **MANDATORY** -- on any refusal, stop; do not relax flags or rules.

## What it prints

A `NOT A QUALIFIED RELEASE ...` banner, the printed **manifest digest**, a
verified-file **count**, and -- only on a refusal -- one sanitised `REFUSED` line
naming a class/control word or a module name reduced to letters/digits/
underscore. It prints no file paths and no file contents. On a Homebrew install it
also prints the `tk-extension: ...` line described above, and a start-up failure
prints the single exit-6 line described in the exit-code table.

## What to send back

- The **sanitised terminal lines only** (banner, digest, count, the
  `tk-extension:` line if one is printed, any `REFUSED` line). They carry no path and no
  identity. On a Homebrew install, a missing `tk-extension:` line is itself worth reporting.
- Optionally, a screenshot of the preview window **with the menu bar, clock,
  notifications, username and any home path out of frame**.

### (C5) known_hosts disclosure -- act on this before sharing a screenshot

The step-3 screen has a **"Local known_hosts path"** field seeded at wizard
construction from `os.path.expanduser('~/.ssh/known_hosts')` (a path **string**
only -- no file is opened). On your machine it may show your **real expanded home
path**. **Crop or blank that field**, and crop any username / home path / menu
bar / clock / notification, before sharing.

## Provider-layout notes (NOT VERIFIED)

Homebrew's separate `python-tk` package is handled only by the single-file rule
above, and only for the Homebrew layout described there. `pyenv`, `conda` and any
other layout that places the stdlib or `_tkinter` outside the derived trusted roots
are still **refused** (fail closed). The reported test interpreter is Homebrew's
Python 3.13. **These layouts are NOT VERIFIED on a real run.**

## Honest NOT-VERIFIED list (never run anywhere)

- Aqua / Tk 9.1.0 rendering of either screen.
- The footer re-lock behaviour on Aqua.
- The 75 ms / `after` timers under a real Tk event loop.
- Real-interpreter start-up: whether the origin finder refuses an import some
  stdlib/Tk path needs indirectly (fails **closed**; learnable only by a run).
- Everything after the viewer import: importing the six product modules, starting Tk,
  drawing the window, the footer lock and a clean close have never run on a Mac with
  this package (the R3D run stopped at the viewer import).
- Whether every directory on your Homebrew path passes the permission rule (the
  modes of those directories on your machine have not been read), and whether the
  macOS `admin` group id really is 80 on your machine.
- Any macOS behaviour, the MDM/EDR/VPN/TCC/Gatekeeper layer, and the
  interpreter's own site/startup behaviour under `-I -B -S`. `TCL_LIBRARY` /
  `TK_LIBRARY` are **not** `PYTHON*` and are **not** ignored by `-I`.
- None of this protects against a **compromised interpreter, standard library or
  host**.

## Cleanup

Delete the extracted package folder when done. The viewer is designed not to write
application data and runs in place after verifying itself; the Terminal steps in the
hand-off create small diagnostic output files outside the package folder, which you
delete as described there.

## Where the ZIP hash is

This file does not contain the ZIP's SHA-256 (an archive's own hash cannot be stored
inside it). Take it from the separate hand-off, out of band.
