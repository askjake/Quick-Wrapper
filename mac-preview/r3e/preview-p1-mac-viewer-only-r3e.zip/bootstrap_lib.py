"""Curated, secrets-free gateway runtime bundle for create-only installs.

Every text payload member destined for the Linux gateway (shell scripts, Python
sources, requirements) is normalised CRLF -> LF before it is hashed and placed in
the bundle, so the bundle SHA and each member's bytes are computed over LF content
regardless of whether this repo is checked out with CRLF or LF line endings. This
prevents a CRLF shebang in aq-run.sh ('#!/bin/bash\\r') from reaching the gateway,
and keeps the remote pinned-dependency check (which matches LF-joined bytes) valid.

The curated payload also carries requirements-gateway.lock, a hash-pinned lockfile
(Security H-2). It SHIPS AS A TEMPLATE containing the sentinel REPLACE_WITH_REAL_HASH
until the user regenerates it with tools/make_gateway_lock.py on a connected machine;
the remote agent refuses to install from a template or malformed lock, so fresh-host
bootstrap stays blocked until a real lock is generated.
"""
import base64
import hashlib
import io
import pathlib
import zipfile

HERE = pathlib.Path(__file__).resolve().parent
PAYLOAD = HERE / 'bootstrap_payload'
FILES = ('aq_registry.py', 'aq-run.sh', 'aq_mcp_stdio.py', 'aq_check.py',
         'requirements-gateway.txt', 'requirements-gateway.lock')
# Members that are installed/executed on the Linux gateway and must be LF.
LF_NORMALISE = ('aq_registry.py', 'aq-run.sh', 'aq_mcp_stdio.py', 'aq_check.py',
                'requirements-gateway.txt', 'requirements-gateway.lock')
MAX_SOURCE_BYTES = 100000


def normalise_lf(blob):
    """Convert CRLF and lone CR to LF. Robust to CRLF or LF repo checkouts."""
    return blob.replace(b'\r\n', b'\n').replace(b'\r', b'\n')


def make_bundle():
    """Deterministic in-memory ZIP: no venv, credentials, log files or backups.

    Text/code members are LF-normalised before hashing so no b'\\r' can reach the
    gateway. A defensive assertion guarantees the bundled aq-run.sh begins with an
    exact '#!/bin/bash\\n' shebang and that no normalised member contains a CR byte.
    requirements-gateway.lock travels with the bundle (as a template until the user
    regenerates it); the remote agent validates and enforces it at install time.
    """
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
        for name in FILES:
            src = PAYLOAD / name
            if src.is_symlink() or not src.is_file():
                raise ValueError('Missing/unsafe gateway source: ' + name)
            blob = src.read_bytes()
            if not blob or len(blob) > MAX_SOURCE_BYTES:
                raise ValueError('Invalid gateway source size: ' + name)
            if name in LF_NORMALISE:
                blob = normalise_lf(blob)
                if b'\r' in blob:
                    raise ValueError('Carriage return survived normalisation: ' + name)
            if name == 'aq-run.sh':
                first_line = blob.split(b'\n', 1)[0]
                if first_line != b'#!/bin/bash':
                    raise ValueError('aq-run.sh shebang must be exactly "#!/bin/bash" (LF)')
            info = zipfile.ZipInfo(name, date_time=(2026, 10, 19, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = (0o100600 << 16)
            zf.writestr(info, blob)
    blob = buffer.getvalue()
    if len(blob) > 100000:
        raise ValueError('Installer exceeds size limit')
    return {'bundle_b64': base64.b64encode(blob).decode('ascii'),
            'bundle_sha256': hashlib.sha256(blob).hexdigest()}
