"""Pure input validation and Quick config generation (GUI/deploy side: Python 3.8+).

The Windows GUI/deploy side of the wizard runs on Python 3.8+. The Linux gateway
bootstrap worker (remote_agent.bootstrap) separately requires Python 3.10+; see
remote_agent.py and the README.
"""
import json
import hashlib
import os
import re
import stat
from urllib.parse import urlsplit

TARGET_RE = re.compile(r'^[a-z0-9][a-z0-9-]{0,63}$')
TOOL_RE = re.compile(r'^[A-Za-z0-9_.:/-]{1,128}$')
# Lambda function-URL id: lowercase only, to match remote_agent.URL (the gateway
# is the stricter, authoritative validator). urlsplit lowercases the hostname, so
# the entry URL built below is lowercased on the host portion before this check.
LAMBDA_HOST_RE = re.compile(r'^[a-z0-9]+\.lambda-url\.([a-z0-9-]+)\.on\.aws$')
SSH_HOST_RE = re.compile(r'^[A-Za-z0-9][A-Za-z0-9.:-]{0,252}$')
SSH_USER_RE = re.compile(r'^[A-Za-z_][A-Za-z0-9_.-]{0,63}$')
LOCAL_SERVER = 'aq_build_artifacts_mcp.py'

# Connector timeout (seconds) per backend kind. The live Epg (Lambda) connector
# uses 30; the live GitHub (Git) connector uses 120. Local mirrors Git (120) as
# no MOP/README specifies a different local value.
TIMEOUT_SECONDS = {'lambda': 30, 'git': 120, 'local': 120}

class ValidationError(ValueError):
    pass


def validate_gateway(host, user):
    if not SSH_HOST_RE.fullmatch(host or '') or '..' in host or host.startswith('-'):
        raise ValidationError('Invalid SSH hostname/IP. Use a trusted, resolved server.')
    if not SSH_USER_RE.fullmatch(user or '') or user.startswith('-'):
        raise ValidationError('Invalid SSH username.')


def normalize_tools(tools):
    if not isinstance(tools, list) or not tools:
        raise ValidationError('Select at least one exact tool name; an empty allow-list exposes ALL tools.')
    if len(tools) > 300:
        raise ValidationError('Too many tools selected.')
    if any(not isinstance(t, str) or not TOOL_RE.fullmatch(t) for t in tools):
        raise ValidationError('Invalid tool name in allow-list.')
    if len(set(tools)) != len(tools):
        raise ValidationError('Duplicate tool names.')
    return sorted(tools)


def validate_lambda_url(url):
    try:
        parsed = urlsplit(url)
    except ValueError:
        raise ValidationError('Malformed Lambda URL.')
    if parsed.scheme != 'https' or parsed.port not in (None, 443) or parsed.username or parsed.password:
        raise ValidationError('Only HTTPS Lambda Function URLs are supported.')
    match = LAMBDA_HOST_RE.fullmatch(parsed.hostname or '')
    if not match or parsed.query or parsed.fragment or parsed.path not in ('', '/', '/mcp'):
        raise ValidationError('Expected https://ID.lambda-url.REGION.on.aws[/mcp] only.')
    if parsed.netloc.lower() != (parsed.hostname or '').lower():
        raise ValidationError('Non-standard URL port is not supported.')
    return parsed.hostname, match.group(1)


def validate_spec(spec):
    # v0.4 native-local merge: transport gate runs BEFORE the SSH gateway check so a
    # native-local target (localhost, no SSH login) is not rejected by validate_gateway.
    transport = spec.get('transport', 'linux-ssh')
    if transport not in ('linux-ssh', 'native-local'):
        raise ValidationError('Unsupported gateway transport (Windows remote SSH requires an approved SSH server).')
    if transport == 'native-local':
        if spec.get('host') not in ('127.0.0.1', 'localhost'):
            raise ValidationError('Native-local gateway may only target this computer')
        if spec.get('kind') != 'lambda':
            raise ValidationError('Native-local v0.4 supports Lambda targets; Git and existing local require Linux SSH')
    validate_gateway(spec.get('host', ''), spec.get('user', ''))
    name = spec.get('target', '')
    if not TARGET_RE.fullmatch(name):
        raise ValidationError('Target: lowercase letters, digits, dashes (max 64).')
    kind = spec.get('kind')
    if kind not in ('lambda', 'git', 'local'):
        raise ValidationError('Choose Lambda, Git or Local.')
    if kind == 'lambda':
        validate_lambda_url(spec.get('url', ''))
        normalize_tools(spec.get('allow', []))
    elif kind == 'git':
        if name not in ('github-ghes', 'gitlab'):
            raise ValidationError('MVP Git mode registers only preconfigured github-ghes or gitlab targets.')
    elif kind == 'local':
        if spec.get('server') not in (None, '', LOCAL_SERVER):
            raise ValidationError('Local server must be the gateway-approved Build Artifacts server.')
        # Existing target registration only, avoids accidentally adding a local server with no roots.
    return spec


def make_registry_entry(spec):
    validate_spec(spec)
    if spec['kind'] != 'lambda':
        raise ValidationError('This wizard supports new Lambda targets only.')
    host, region = validate_lambda_url(spec['url'])
    # Rebuild the URL with the urlsplit-normalised (lowercased) host so the entry
    # written to the registry always matches remote_agent.URL (lowercase-only id).
    parsed = urlsplit(spec['url'])
    normalized = '{}://{}{}'.format(parsed.scheme, host, parsed.path)
    entry = {'url': normalized.rstrip('/'), 'region': region,
             'env': 'wizard', 'note': 'Installed by AQ-MCP Connector Wizard',
             'allow': normalize_tools(spec['allow'])}
    return entry


def quick_connector(spec):
    validate_spec(spec)
    if spec.get('transport') == 'native-local':
        # v0.4 native-local branch: no SSH, no remote login. Launch the curated MCP
        # proxy directly through the per-user local Python venv. Returns before the
        # SSH path below. Native-local is Lambda-only (enforced in validate_spec), so
        # the SSH-only Git/Local launchers and the S2 wizard-bootstrap refusal (which
        # only fires for kind in ('git','local')) are never reached on this branch.
        from native_gateway import native_root, local_python
        root = native_root()
        runner = local_python(root)
        if any(char.isspace() for char in str(root)):
            raise ValidationError('Local gateway directory includes spaces; Quick argument parsing must be independently verified')
        return {'id': 'aq-' + spec['target'],
                'name': spec.get('display_name') or 'AQ ' + spec['target'],
                'connection_type': 'Local', 'command': str(runner),
                'arguments': [str(root / 'aq_registry.py'), 'run', spec['target']],
                'timeout_seconds': 120, 'environment_variables': {}}
    root = '/home/{}/aq-mcp'.format(spec['user'])
    name = spec['target']
    if spec['kind'] == 'git':
        arguments = ['-T','-q','{}@{}'.format(spec['user'], spec['host']),
                     '{}/venv/bin/python'.format(root), '{}/aq_git_run.py'.format(root), name]
    else:
        arguments = ['-T','-q','{}@{}'.format(spec['user'], spec['host']),
                     '{}/aq-run.sh'.format(root), name]
    return {'id': 'aq-' + name, 'name': spec.get('display_name') or 'AQ ' + name,
            'connection_type': 'Local', 'command': 'ssh', 'arguments': arguments,
            'timeout_seconds': TIMEOUT_SECONDS[spec['kind']], 'environment_variables': {}}


def config_export(spec):
    c = quick_connector(spec)
    # Export is a guide / not known to be directly importable by Quick.
    return json.dumps({'mcpServers': {c['id']: {'command': c['command'], 'args': c['arguments']}}}, indent=2)


def backend_identity(spec):
    """Fingerprints the inputs that bind a verification to a backend selection."""
    required = ['transport','host','user','kind','target','display_name']
    extra = ['url'] if spec.get('kind') == 'lambda' else ['server'] if spec.get('kind') == 'local' else []
    source = {key: spec.get(key, '') for key in required + extra}
    return hashlib.sha256(json.dumps(source, sort_keys=True, separators=(',', ':')).encode('utf-8')).hexdigest()


def risk_tool_names(names):
    """Advisory name-based classifier, never a proof of read-only behavior."""
    prefixes = ('create_', 'write_', 'delete_', 'remove_', 'update_', 'set_', 'push_',
                'merge_', 'approve_', 'submit_', 'trigger_', 'upload_', 'export_',
                'send_', 'start_', 'run_', 'execute_', 'deploy_', 'publish_')
    keywords = ('_upload', '_write', '_delete', '_submit', '_export', '_trigger',
                '_mutate', 'build_log_capsule', 'grasshopper_plan_profile_upload')
    return sorted(name for name in names if name.lower().startswith(prefixes)
                  or any(token in name.lower() for token in keywords))


def identity_warnings(spec, names):
    """Heuristic mismatch signal; does not determine backend identity."""
    label = (spec.get('target', '') + ' ' + spec.get('display_name', '')).lower()
    n = {name.lower() for name in names}
    notes=[]
    if 'epg' in label and len(n & {'count_alerts','alert_time_series','export_receivers_csv',
                                    'submit_receivers_export','alert_geo_map'}) >= 2:
        notes.append('Possible backend mismatch: this connector is labeled EPG but the endpoint offers RTR Alerts tools. Verify the Lambda URL before approval.')
    if ('rtr' in label or 'alert' in label) and len(n & {'list_programs','get_genres','genre_distribution','top_programs'}) >= 2:
        notes.append('Possible backend mismatch: this connector is labeled Alerts but the endpoint offers EPG tools.')
    return notes


def plan(spec, current_sha):
    entry = make_registry_entry(spec) if spec['kind']=='lambda' else None
    chosen = entry['allow'] if entry else []
    risks = risk_tool_names(chosen)
    steps = (['1. Verify the selected backend and review tool discovery.',
              '2. Compare the live registry SHA-256 to this plan.',
              '3. Back up targets.json without changing other targets.',
              '4. Create exactly one new target with the chosen allow-list.',
              '5. Run MCP initialize/tools/list through the installed target.',
              '6. If health verification fails, attempt checksum-bound rollback.']
             if spec['kind']=='lambda' else
             ['1. Verify the existing launcher and complete an MCP tools/list handshake.',
              '2. Leave Git/local gateway configuration unchanged.'])
    steps += ['7. Register the generated Local SSH connector manually in Amazon Quick.',
              '8. Start a new Quick chat and verify a harmless read.']
    return {'version': 2, 'mode':'plan-only', 'target':spec['target'],
            'kind':spec['kind'], 'backend_identity_sha256':backend_identity(spec),
            'expected_registry_sha256':current_sha,
            'registry_entry':entry, 'tool_count_to_expose':len(chosen) if entry else 'existing policy',
            'potentially_mutating_tools_name_only':risks,
            'warnings':identity_warnings(spec, chosen) +
                       (['Name-based mutator detection is advisory; inspect ALL selected tools and schemas.'] if risks else []),
            'execution_plan':steps,
            'quick_connector':quick_connector(spec),
            'registration':'MANUAL_REQUIRED', 'no_secrets_in_manifest':True}


# ---------------------------------------------------------------------------
# B2a S2: refuse Git / Local on a host THIS wizard bootstrapped (Lambda lane only)
# ---------------------------------------------------------------------------
# A gateway that this wizard bootstrapped carries the Lambda lane only: the
# bootstrap bundle (see bootstrap_lib.FILES) installs aq_registry.py, aq-run.sh,
# aq_mcp_stdio.py and aq_check.py, but NOT aq_git_run.py, aq_git_guard.py,
# git_targets.json, the set_secret helper, or aq_build_artifacts_mcp.py. So the
# Git and Build Artifacts launchers simply do not exist on such a host and must be
# refused rather than producing a connector that cannot launch.
#
# "Bootstrapped by the wizard" is decided ONLY from state the wizard already holds:
# the receipt object returned by ConnectorDeployer.bootstrap / remote_agent.bootstrap
# (status == 'BOOTSTRAPPED'), either produced in this session or read back from a
# receipt file the wizard itself wrote and the user points at. It is NEVER inferred
# from a guess about the remote. When no such receipt is held, behaviour is unchanged:
# Git/Local manifests against an existing full gateway keep working.
LAMBDA_ONLY_REFUSAL = ('This host was bootstrapped by the wizard with the Lambda lane '
                       'only; the Git and Build Artifacts launchers are not installed.')


def host_is_wizard_lambda_only(bootstrap_receipt):
    """True only when the given receipt proves THIS wizard bootstrapped the host.

    Decided purely from wizard-held state (the bootstrap receipt), never from a
    remote guess. Returns False for None, non-dicts, or any receipt that is not an
    unambiguous wizard bootstrap result, so the refusal fails safe (does not fire
    unless we positively know the wizard installed the Lambda-only lane).
    """
    if not isinstance(bootstrap_receipt, dict):
        return False
    # remote_agent.bootstrap returns exactly these on a successful fresh install.
    if bootstrap_receipt.get('status') != 'BOOTSTRAPPED':
        return False
    if bootstrap_receipt.get('state') != 'READY':
        return False
    if bootstrap_receipt.get('gateway_root') != '~/aq-mcp':
        return False
    return True


def validate_spec_for_host(spec, bootstrap_receipt=None):
    """validate_spec plus the S2 refusal when the wizard itself bootstrapped the host.

    With no bootstrap_receipt (the default) this is exactly validate_spec, so every
    existing caller and every manifest against an existing full gateway is unchanged.

    v0.4 native-local note: native-local specs are Lambda-only (validate_spec rejects
    git/local for transport='native-local'), and a native-local gateway is not an SSH
    wizard bootstrap, so host_is_wizard_lambda_only() returns False for it and the S2
    refusal below cannot fire on a native target. The SAFER behaviour is preserved on
    both sides: Git/Local are still refused on an SSH Lambda-only bootstrapped host,
    and native-local never reaches kind in ('git','local') to be wrongly blocked.
    """
    validate_spec(spec)
    if bootstrap_receipt is not None and host_is_wizard_lambda_only(bootstrap_receipt):
        if spec.get('kind') in ('git', 'local'):
            raise ValidationError(LAMBDA_ONLY_REFUSAL)
    return spec


# ---------------------------------------------------------------------------
# B2a S5: plain-language plan summary a non-expert can read before confirming
# ---------------------------------------------------------------------------
def plain_language_summary(spec, prepared, discovered_count=None):
    """Human-readable deploy summary, shown BEFORE the confirm gate (GUI + CLI).

    Grounded only in the spec and the already-computed plan ('prepared'); it adds no
    new gateway calls and asserts no safety it cannot prove. 'discovered_count' is the
    number of tools the backend offered at verification time; when the caller does not
    have it, the summary says the full list is re-discovered and re-checked at deploy.
    """
    kind = spec.get('kind')
    target = spec.get('target', '')
    entry = prepared.get('registry_entry') if isinstance(prepared, dict) else None
    lines = ['PLAIN-LANGUAGE SUMMARY (read this before you approve)',
             '----------------------------------------------------']
    if kind != 'lambda' or not entry:
        # Git / local are existing-launcher registrations; nothing is added to the registry.
        lines.append('What this does: verify the EXISTING "{}" launcher on the gateway and give '
                      'you manual Quick setup steps.'.format(target))
        lines.append('Nothing is added to or changed in the gateway registry.')
        lines.append('How to undo: there is nothing to roll back; no registry entry is written.')
        return '\n'.join(lines)
    region = entry.get('region', '')
    allowed = list(entry.get('allow', []))
    allow_n = len(allowed)
    if discovered_count is None:
        discovered_text = ('out of the tools the backend offers (the full list is re-discovered '
                           'and each name re-checked at deploy time)')
    else:
        discovered_text = 'out of {} tool(s) the backend offered'.format(discovered_count)
    risky = prepared.get('potentially_mutating_tools_name_only', []) or []
    lines.append('What will be added: a new connector target named "{}" in region {}.'.format(target, region))
    lines.append('Tools allowed: {} tool(s) {}.'.format(allow_n, discovered_text))
    if risky:
        lines.append('Tools that LOOK like they can change things (name-based guess, NOT a '
                     'safety verdict - read each one): ' + ', '.join(risky) + '.')
    else:
        lines.append('Tools that look like they can change things: none by name. A name cannot '
                     'prove a tool is read-only - you must still read each tool name yourself.')
    existing = prepared.get('existing_target_count')
    if isinstance(existing, int):
        lines.append('{} existing target(s) will be left unchanged, 1 added.'.format(existing))
    else:
        lines.append('All existing targets will be left unchanged, 1 added.')
    lines.append('Backup: before the change, the gateway writes a timestamped backup of '
                 'targets.json next to it under ~/aq-mcp (create-only, never overwritten).')
    lines.append('How to roll back: save the receipt, then use Rollback (GUI) or '
                 '"cli.py rollback --receipt-file <file> --approve-target {}"; it restores only '
                 'if the registry has not changed since deploy.'.format(target))
    return '\n'.join(lines)


# ---------------------------------------------------------------------------
# B2a S4: shared mutating-tool confirmation text, so the GUI and the CLI apply
# path show IDENTICAL wording (Reviewer S4 parity). Name heuristics are advisory
# only and this text says so; it is NOT a safety verdict.
# ---------------------------------------------------------------------------
def mutating_confirm_text(risky):
    """Exact warning shown before approving a deploy that exposes name-flagged mutators.

    B2b cosmetic: with an empty list the old text printed the 'Potentially MUTATING
    tool names were selected:' header over nothing. For an empty list we now return a
    neutral message instead. The non-empty text is byte-for-byte unchanged (S4 parity).
    """
    risky = list(risky)
    if not risky:
        return ('No tool names were name-flagged as potentially mutating. Name heuristics '
                'are NOT a safety verdict: inspect each selected tool before you approve.')
    return ('Potentially MUTATING tool names were selected:\n'
            + ', '.join(risky[:14])
            + '\n\nName heuristics are NOT a safety verdict. Did you inspect each tool '
              'and intentionally approve exposing these actions?')


# ---------------------------------------------------------------------------
# B2b S7 (Security M-2): redaction of the real login/host/home path for sharing,
# and owner-only (0600) creation of any file the wizard writes for the user.
# ---------------------------------------------------------------------------
# The wizard renders the real SSH login as "<user>@<host>" and the gateway home
# path "/home/<user>/aq-mcp" in Quick setup instructions, JSON exports and deploy
# receipts. Those are internal addresses. For anything the user may SHARE (a Copy
# or an Export) we offer a REDACTED variant by DEFAULT, replacing the real login,
# host/IP and home path with placeholders, and a clearly labelled FULL variant
# only on an explicit second action.
REDACTED_USER = '<user>'
REDACTED_HOST = '<3090-host>'
FULL_VARIANT_WARNING = ('FULL variant - contains your real login and host. Do NOT paste '
                        'into tickets, decks or chat. Use the redacted variant to share.')


class RedactionError(ValueError):
    """Raised when redaction cannot be performed safely (empty/None user or host).

    Callers that produce a SHAREABLE (redacted) artifact must treat this as a hard
    failure and refuse to emit anything, rather than emit unredacted text.
    """


def redact_identity(text, user, host, home_root=None):
    """Replace the real login, host/IP and home path in text with placeholders.

    Returns text in which no occurrence of the real username, the real host/IP,
    the real "user@host" composite, or the real "/home/<user>/aq-mcp" home path
    remains. Used for the DEFAULT (shareable) Copy/Export variants. It is a string
    substitution over known values the wizard already holds; it is best-effort and
    does not attempt to find identities it was not told about.

    E2/LOW-3/N1 fix:
      * the login AND the host are matched CASE-INSENSITIVELY (Linux logins are
        case-sensitive, but a hostname entered in a different case than it appears
        in the text must still be redacted);
      * the function FAILS CLOSED: if user or host is empty/None/whitespace it
        raises RedactionError, so an empty value can never silently disable
        redaction and leak the other identity in shareable text.
    """
    if text is None:
        return text
    user = (user or '').strip()
    host = (host or '').strip()
    if not user or not host:
        raise RedactionError('redact_identity requires a non-empty user and host; '
                             'refusing to emit a half-redacted (shareable) artifact.')
    out = str(text)

    def ci_replace(s, needle, repl):
        # Case-insensitive literal substitution (needle is a fixed, known value).
        return re.sub(re.escape(needle), repl, s, flags=re.IGNORECASE) if needle else s

    # Most-specific first so no original fragment survives a later, broader pass.
    home = home_root or ('/home/' + user + '/aq-mcp')
    out = ci_replace(out, home, '/home/' + REDACTED_USER + '/aq-mcp')
    out = ci_replace(out, '/home/' + user + '/', '/home/' + REDACTED_USER + '/')
    out = ci_replace(out, '/home/' + user, '/home/' + REDACTED_USER)
    out = ci_replace(out, user + '@' + host, REDACTED_USER + '@' + REDACTED_HOST)
    out = ci_replace(out, host, REDACTED_HOST)
    # Remaining standalone user tokens, on word boundaries only so we never chew
    # into an unrelated substring that merely contains the name.
    out = re.sub(r'(?<![A-Za-z0-9_.-])' + re.escape(user) + r'(?![A-Za-z0-9_.-])',
                 REDACTED_USER, out, flags=re.IGNORECASE)
    return out


def _is_windows():
    return os.name == 'nt'


def secure_open(path):
    """Create a NEW file (create-only, never overwrites) with owner-only perms.

    POSIX: os.open(O_CREAT|O_EXCL|O_WRONLY, 0o600) then fchmod(0o600) to defeat a
    permissive umask, and a stat check that REFUSES (removes the file and raises)
    if any group/other bit is set.
    Windows: the Python stdlib cannot set a POSIX ACL, so we create the file
    create-only and then call os.chmod(path, 0o600), which on Windows only toggles
    the read-only attribute - it does NOT restrict group/other. We do NOT claim an
    ACL we did not set; on Windows, rely on the user profile's NTFS inheritance /
    disk encryption for real confidentiality. (See README "File permissions".)
    The O_EXCL create-only behaviour preserves the wizard's never-overwrite rule.
    """
    flags = os.O_CREAT | os.O_EXCL | os.O_WRONLY
    # LOW-4: add O_NOFOLLOW where the platform has it (0 elsewhere), for symmetry
    # with the O_EXCL create-only behaviour and the _read_secret_file/_secure_log_file
    # idiom. O_EXCL already refuses a pre-existing symlink; this is defence-in-depth.
    flags |= getattr(os, 'O_NOFOLLOW', 0)
    if hasattr(os, 'O_BINARY'):
        flags |= os.O_BINARY  # Windows: no CRLF translation on this fd.
    fd = os.open(path, flags, 0o600)
    try:
        if not _is_windows():
            os.fchmod(fd, 0o600)
            mode = stat.S_IMODE(os.fstat(fd).st_mode)
            if mode & (stat.S_IRWXG | stat.S_IRWXO):
                raise OSError('Refusing to leave {} group/world-accessible (mode {:o})'.format(path, mode))
    except Exception:
        try:
            os.close(fd)
        except Exception:
            pass
        try:
            os.unlink(path)
        except Exception:
            pass
        raise
    return fd


def secure_write_text(path, text, newline='\n'):
    """Create-only write of text to path with owner-only permissions (secure_open).

    Raises FileExistsError if path exists (never overwrites). On Windows a final
    os.chmod(path, 0o600) toggles the read-only attribute only (not an ACL).
    """
    data = text if text.endswith(newline) else text + newline
    fd = secure_open(path)
    try:
        os.write(fd, data.encode('utf-8'))
    finally:
        os.close(fd)
    if _is_windows():
        try:
            os.chmod(path, 0o600)  # Windows: read-only attribute only; not an ACL.
        except OSError:
            pass
    return path


def secure_write_json(path, obj):
    """Create-only owner-only write of obj as indented, key-sorted JSON."""
    return secure_write_text(path, json.dumps(obj, indent=2, sort_keys=True))
