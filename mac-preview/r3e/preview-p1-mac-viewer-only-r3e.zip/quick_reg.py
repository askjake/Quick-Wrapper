"""Quick registration export and DIPS read-only inspection.

Direct writes to undocumented Quick SQLite schemas are intentionally prohibited.
A Quick-created connector can have internal cross-table invariants, signing or migrations.
"""
import json
import os
import sqlite3
from model import (quick_connector, config_export, redact_identity, secure_write_text,
                   secure_open, TIMEOUT_SECONDS, FULL_VARIANT_WARNING, RedactionError)

class RegistrationUnsupported(RuntimeError):
    pass


def _spec_identity(spec):
    """The (user, host) this spec renders into instructions/exports, for redaction."""
    return spec.get('user', ''), spec.get('host', '')


def config_export_text(spec, redacted=True):
    """The JSON export string. redacted=True (DEFAULT, shareable) replaces the real
    login, host/IP and home path with placeholders; redacted=False is the FULL variant
    that contains the real values (only for an explicit second user action).

    E2/N1 fail-closed: for the redacted (shareable) variant, redact_identity raises
    RedactionError if user or host is empty; this propagates so a caller NEVER emits a
    half-redacted export. Callers (wizard.py, cli.py) catch it, show the message, and
    refuse the share rather than writing unredacted text."""
    text = config_export(spec)
    if redacted:
        user, host = _spec_identity(spec)
        return redact_identity(text, user, host)
    return text


def write_quick_config(spec, file_path, redacted=True):
    """Create-only, owner-only (0600) write of the Quick config JSON example.

    Default writes the REDACTED (shareable) variant. Pass redacted=False only for a
    deliberate FULL export that carries the real login/host. NEVER overwrites an
    existing file, and NEVER touches the Quick application profile.
    """
    if not str(file_path).lower().endswith('.json'):
        raise ValueError('Configuration export must be .json')
    if os.path.exists(file_path):
        raise FileExistsError('Refusing to overwrite an existing export.')
    # secure_write_text is create-only (O_EXCL) with 0600 perms (POSIX enforced;
    # Windows best-effort read-only attribute only - see model.secure_open).
    secure_write_text(file_path, config_export_text(spec, redacted=redacted))
    return file_path


def inspect_dips_read_only(path):
    """Inventory table/schema NAMES only; no personal connector rows or database writes."""
    if not os.path.isfile(path):
        raise FileNotFoundError(path)
    # URI read-only avoids modifying schema; Quick should be closed for consistent inspection.
    from pathlib import Path
    uri = Path(path).resolve().as_uri() + '?mode=ro'
    cn = sqlite3.connect(uri, uri=True, timeout=1)
    try:
        cn.execute('PRAGMA query_only=ON')
        return [{'name': row[0], 'type': row[1]}
                for row in cn.execute("SELECT name,type FROM sqlite_master WHERE type IN ('table','view') ORDER BY name")]
    finally:
        cn.close()


def register_quick_automatically(*args, **kwargs):
    raise RegistrationUnsupported('No supported Quick connector registration interface verified. Use guided manual entry.')


def quick_copy_fields(connector):
    """Format a validated wizard connector for direct manual Quick GUI entry.

    This is a display/export helper only; it never registers a connector in Quick.
    Both SSH and native-local connectors use a single space-separated Arguments
    field in the observed Quick UI. Paths containing spaces require separate
    validation before use (native-local model rejects such paths).
    """
    if not isinstance(connector, dict):
        raise ValueError('Quick connector configuration is missing')
    command = connector.get('command')
    arguments = connector.get('arguments')
    if not isinstance(command, str) or not command.strip():
        raise ValueError('Missing Quick connector command')
    if not isinstance(arguments, list) or not arguments or any(
            not isinstance(arg, str) or not arg.strip() or any(ch in arg for ch in ('\n', '\r', '\x00'))
            for arg in arguments):
        raise ValueError('Invalid Quick connector arguments')
    if any(any(ch.isspace() for ch in arg) for arg in arguments):
        raise ValueError('Quick Arguments include spaces within an argument; validate UI parsing before copying')
    return {'command': command, 'arguments': ' '.join(arguments),
            'id': connector.get('id', ''), 'name': connector.get('name', ''),
            'timeout_seconds': connector.get('timeout_seconds', 120)}


def quick_instructions(spec, redacted=False):
    """Human-executable setup steps grounded in observed Quick Edit MCP UI.

    This is manual UI registration, not a DIPS mutation or import contract.

    B2b S7: redacted=False (DEFAULT) renders the real login/host so the user can
    actually run the command on their own machine. When the text is to be SHARED
    (Copy/Export), callers pass redacted=True, which replaces the real login,
    host/IP and home path with placeholders (<user>@<3090-host>, /home/<user>/aq-mcp).
    The GUI 'Copy Quick settings' and 'Export' actions default to the redacted text
    and offer the full text only behind an explicit second action.

    v0.4 native-local merge: the Command line is no longer hard-coded to 'ssh'; it
    renders cfg['command'] so a native-local connector (command = the local Python
    interpreter path) shows the correct launcher. For SSH specs cfg['command'] is
    'ssh', so SSH wording is unchanged.
    """
    cfg=quick_connector(spec)
    args=' '.join(cfg['arguments'])
    chips='\n'.join('    {}. {}'.format(i+1, value) for i,value in enumerate(cfg['arguments']))
    text=("AMAZON QUICK \u2014 MANUAL LOCAL MCP CONNECTOR SETUP\n"
            "================================================\n"
            "Prerequisite: gateway was inspected and backend passed MCP tools/list.\n"
            "The gateway write and Quick registration are TWO separate operations.\n\n"
            "1. Open Amazon Quick Desktop. Go to Customize > Connectors.\n"
            "2. Open Create/Add MCP (exact label may vary by Quick version).\n"
            "3. Set these fields in the Edit MCP form:\n"
            "   Connection type : Local\n"
            "   ID              : {id}\n"
            "   Name            : {name}\n"
            "   Command         : {command}\n"
            "   Arguments       : {args}\n"
            "   Environment variables : EMPTY \u2014 never enter AWS credentials/PATs.\n"
            "   Timeout (seconds)     : {timeout} (adjust for the tool family)\n\n"
            "   The Arguments field is ONE input; Quick displays parsed chips.\n"
            "   Expected {count} argument chips:\n{chips}\n\n"
            "4. Click Test connection (if offered). Diagnose any failure before saving.\n"
            "5. Click Save changes. If updating a connector, Edit > Save relaunches\n"
            "   its process in the observed Quick build; a toggle alone may not.\n"
            "6. Open a NEW Quick chat so that the model sees the refreshed tool list.\n"
            "7. Request a safe read-only tool or inspect tools/list. Check it returns\n"
            "   data from the intended backend; a different tool family is a red flag.\n"
            "8. Review per-tool Quick permissions: keep mutations Ask each time\n"
            "   or Always deny unless explicitly approved. The gateway allow-list\n"
            "   is a separate permission layer.\n\n"
            "   Example prompt: Using the {name} connector, list your available\n"
            "   tools and perform one harmless read-only query. Do not modify data.\n\n"
            "NOTICE: This wizard does not modify Quick's undocumented DIPS DB,\n"
            "register a connector, grant permissions, or prove tool execution\n"
            "inside Quick. Exported JSON is a reference example, NOT a verified\n"
            "import format. Capture the test result and mark registration verified\n"
            "only after a real Quick chat call succeeds.\n").format(
                id=cfg['id'],name=cfg['name'],command=cfg['command'],args=args,
                timeout=cfg['timeout_seconds'],count=len(cfg['arguments']),chips=chips)
    if redacted:
        user, host = _spec_identity(spec)
        return redact_identity(text, user, host)
    return text


def quick_instructions_variants(spec):
    """Both variants for the GUI: the DEFAULT redacted (shareable) text and the FULL
    text with its warning banner. The GUI shows the full text only on an explicit
    'Show full (real login/host)' action."""
    full=quick_instructions(spec, redacted=False)
    return {'redacted': quick_instructions(spec, redacted=True),
            'full': full,
            'full_labeled': FULL_VARIANT_WARNING + '\n\n' + full}
# ===========================================================================
# v0.4 Import-phase additions (stage 1 of 3): Quick "Import" workflow helpers.
#
# These functions ADD a *generate-an-import-file / read-only-verify* path on top
# of the existing manual-registration helpers above. They never write to Quick's
# own store (mcp_config.json / DIPS); emit_quick_import_file writes an import file
# ELSEWHERE, and the discovery/collision/verify helpers only READ Quick's
# mcp_config.json. Every existing name and behaviour above is preserved.
#
# Observed facts these are built on (executed on the user's machine, 2026-10-20):
#   * Quick's Add-MCP dialog has an Import mode that reads a standard mcpServers
#     JSON file by path.
#   * A file with ONE server {command, args} (no env, no _quick) imported and
#     worked. Quick stored it under a key = <name>-<random 8 hex> with fields
#     command, args and a Quick-added _quick object
#     {name: <source name>, source: <import file path>, upstream_id: <source name>};
#     NO startupTimeout was recorded. Deleting the connector restored the file.
#   * In a LATER executed read of the real profile mcp_config.json (2026-10-20),
#     11 of 19 entries carried startupTimeout, name and autoDisabled INSIDE the
#     per-entry _quick object (not at the entry top level). So the verifier reads
#     startupTimeout from _quick first and falls back to a top-level value, and
#     reports which location it used (startup_timeout_location).
#
# NOT observed (so NOTHING below claims it): whether Quick shows a command-
# confirmation prompt, the default timeout value, duplicate-import behaviour.
# ===========================================================================

import re as _re
import hashlib as _hashlib

# Connector key / import-file server name: lowercase, digit/hyphen, 1..64 chars,
# must start with [a-z0-9]. This is the charset the observed import used.
QUICK_IMPORT_NAME_RE = _re.compile(r'^[a-z0-9][a-z0-9-]{0,63}$')

# Windows reserved device names (compared case-insensitively, with or without an
# extension). These can never be a safe connector/server name.
_WINDOWS_RESERVED_NAMES = frozenset(
    ['con', 'prn', 'aux', 'nul']
    + ['com%d' % n for n in range(1, 10)]
    + ['lpt%d' % n for n in range(1, 10)])

# Cloud-sync folder markers; an import file dropped inside one of these would be
# copied off the machine by the sync client (the file carries the real login/host),
# so emit refuses such a destination unless allow_synced=True.
#
# F-2 / Tester D-1 single-source: this is the ONE authoritative marker list.
# cli.py's advisory pre-check imports the public helper path_looks_synced (below)
# instead of carrying its own copy, so the CLI message and the emitter refusal can
# never diverge. SYNCED_PATH_MARKERS is the public alias of this same object.
_SYNCED_PATH_MARKERS = ('onedrive', 'dropbox', 'google drive', 'googledrive',
                        'icloud', 'icloud drive', 'icloudrive')
# Public alias (same object) so callers can reference the markers without reaching
# for the underscore-prefixed name. Do NOT redefine this list elsewhere.
SYNCED_PATH_MARKERS = _SYNCED_PATH_MARKERS

# Hard cap for reading Quick's mcp_config.json read-only (defensive; the real file
# is a few KB). Anything larger is treated as UNREADABLE rather than parsed.
_QUICK_CONFIG_MAX_BYTES = 5 * 1024 * 1024


class ImportFileError(ValueError):
    """Raised when an import file cannot be emitted safely. Its message NEVER
    contains the file content or any argument/command value - only the reason."""
    pass


def _is_windows_reserved_name(name):
    """True if name is a Windows reserved device name, with or without an
    extension and regardless of case (e.g. 'CON', 'con.json', 'COM1.txt')."""
    stem = str(name).split('.', 1)[0].strip().lower()
    return stem in _WINDOWS_RESERVED_NAMES


def _validate_import_name(name):
    """Validate the single mcpServers key. Returns the name on success, else
    raises ImportFileError with a reason that never echoes other content."""
    if not isinstance(name, str) or not name:
        raise ImportFileError('Import connector name must be a non-empty string.')
    if not QUICK_IMPORT_NAME_RE.match(name):
        raise ImportFileError(
            "Import connector name must match ^[a-z0-9][a-z0-9-]{0,63}$ "
            "(lowercase letters, digits, hyphen; 1-64 chars; no leading hyphen).")
    if _is_windows_reserved_name(name):
        raise ImportFileError('Import connector name must not be a Windows reserved device name.')
    return name


def _coerce_import_server(settings):
    """Validate the wizard settings into exactly {command, args}.

    'settings' is the existing quick_copy_fields / quick_connector output: it
    carries a string 'command' and an arguments list (key 'args' or 'arguments')
    plus a display name ('name' or 'id'). We take those VERBATIM; we do not
    re-derive the command or args. Returns (name, command, args_list).

    Enforces: exactly one server (settings is a single connector dict), command a
    non-empty str, args a list of non-empty strs without control chars/newlines,
    NO 'env', NO '_quick', NO unknown keys beyond the known wizard field set.
    """
    if not isinstance(settings, dict):
        raise ImportFileError('Connector settings must be a dict (one server).')
    # Explicitly refuse metadata that must never reach an import file.
    if 'env' in settings and settings.get('env') not in (None, {}):
        raise ImportFileError("Import file must not carry an 'env' block.")
    if '_quick' in settings:
        raise ImportFileError("Import file must not carry a '_quick' block (Quick adds it).")
    # Known wizard field set (quick_copy_fields / quick_connector). Anything else
    # is an unknown key and is refused so we never silently pass a surprise field
    # into the import file.
    known = {'command', 'arguments', 'args', 'id', 'name', 'timeout_seconds',
             'connection_type', 'environment_variables'}
    unknown = set(settings) - known
    if unknown:
        raise ImportFileError('Unknown connector settings key(s) present; refusing to emit.')
    command = settings.get('command')
    if not isinstance(command, str) or not command.strip():
        raise ImportFileError('Connector command must be a non-empty string.')
    args = settings.get('args', settings.get('arguments'))
    if not isinstance(args, list) or not args:
        raise ImportFileError('Connector args must be a non-empty list.')
    for a in args:
        if not isinstance(a, str) or not a:
            raise ImportFileError('Each connector arg must be a non-empty string.')
        if any((ord(ch) < 0x20 or ord(ch) == 0x7f) for ch in a):
            raise ImportFileError('Connector args must not contain control characters or newlines.')
    name = settings.get('name') or settings.get('id') or ''
    return name, command, list(args)


def _build_import_payload(name, command, args):
    """The exact bytes written to an import file: UTF-8, no BOM, LF, indent 2,
    key order {command, args}. Pure; returns a bytes object. Never logged."""
    body = ('{\n'
            '  "mcpServers": {\n'
            '    ' + json.dumps(name) + ': {\n'
            '      "command": ' + json.dumps(command) + ',\n'
            '      "args": [\n'
            + ''.join('        ' + json.dumps(a) + (',' if i < len(args) - 1 else '') + '\n'
                      for i, a in enumerate(args))
            + '      ]\n'
            '    }\n'
            '  }\n'
            '}\n')
    return body.encode('utf-8')  # no BOM, LF only


def _path_is_synced(dest_dir):
    """True if dest_dir sits inside a known cloud-sync folder (name match on any
    path component, case-insensitive). Uses the single authoritative marker list
    _SYNCED_PATH_MARKERS; see path_looks_synced for the public entry point."""
    norm = str(dest_dir).replace('\\', '/').lower()
    parts = [p for p in norm.split('/') if p]
    for p in parts:
        if p in _SYNCED_PATH_MARKERS:
            return True
    return False


def path_looks_synced(path):
    """Public, single-source synced-folder check (F-2 / Tester D-1).

    Returns True if `path` sits inside a known cloud-sync folder. This is the ONE
    implementation; cli.py imports and calls it so the CLI advisory pre-check and
    the emitter refusal share the exact same markers (including 'icloud drive')
    and can never drift apart. Behaviour is identical to _path_is_synced; this is
    the name external callers should use.
    """
    return _path_is_synced(path)


def emit_quick_import_file(settings, dest_dir, *, filename=None, allow_synced=False,
                           allow_inside_repo=False):
    """Write a minimal, Quick-importable mcpServers JSON file for ONE server.

    settings: the existing quick_copy_fields / quick_connector output (command +
        args list + display name). command and args are used VERBATIM.
    dest_dir: a directory to write into (NOT Quick's profile dir). Create-only.
    filename: optional base filename (no path separators). On collision a numbered
        new filename is chosen; an existing file is NEVER overwritten.
    allow_synced: must be True to permit a dest_dir inside a OneDrive/Dropbox/
        Google Drive/iCloud-named path (the file carries the real login/host).
    allow_inside_repo: TEST-ONLY override. When False (the default, and the only
        value the CLI ever uses) the destination is REFUSED if it lies inside a
        git work tree (a .git directory OR file found by walking up from dest_dir)
        or inside the folder that contains this module (the project's own
        repo/work copy). The import file carries the real login/host and must
        never be committed or published, so it must not land in a repo.

    Writes {"mcpServers": {name: {"command":..., "args":[...]}}} as UTF-8 without
    BOM, LF, indent 2. Owner-only (0600) where the OS supports it; refuses a
    symlink destination (O_NOFOLLOW/O_EXCL via model.secure_open).

    Returns {path, name, sha256, bytes, contains_identity_warning: True}. The file
    CONTENT is NEVER included in the result or in any exception message.
    """
    name, command, args = _coerce_import_server(settings)
    name = _validate_import_name(name)
    payload = _build_import_payload(name, command, args)

    if not isinstance(dest_dir, str) or not dest_dir:
        raise ImportFileError('Destination directory must be a non-empty path string.')
    if not allow_synced and _path_is_synced(dest_dir):
        raise ImportFileError(
            'Destination is inside a cloud-sync folder; the import file carries your '
            'login/host. Pass allow_synced=True only if you accept that it will sync.')
    if not os.path.isdir(dest_dir):
        raise ImportFileError('Destination directory does not exist.')
    if not allow_inside_repo and _dest_inside_repo(dest_dir):
        raise ImportFileError(
            'Destination is inside a git work tree or this project folder; the import '
            'file contains your login and host and must never be committed or published. '
            'Choose a directory outside any repository.')

    # Filename: default is the connector name; reject any path separators so the
    # file can only land inside dest_dir.
    base = filename if filename else (name + '.json')
    if not isinstance(base, str) or not base:
        raise ImportFileError('Filename must be a non-empty string.')
    if ('/' in base) or ('\\' in base) or (os.sep in base) or (os.altsep and os.altsep in base):
        raise ImportFileError('Filename must not contain a path separator.')
    if not base.lower().endswith('.json'):
        base = base + '.json'
    stem = base[:-len('.json')]

    # Create-only: on collision pick a numbered new filename, never overwrite.
    candidate = base
    n = 1
    last_err = None
    path = None
    while n <= 1000:
        full = os.path.join(dest_dir, candidate)
        try:
            # secure_open is O_CREAT|O_EXCL|O_WRONLY|O_NOFOLLOW, 0600: it refuses an
            # existing file AND a symlink at the path. We write payload bytes as-is
            # (no newline translation: O_BINARY on Windows).
            # F-8 (informational): on Windows O_NOFOLLOW is defined as 0, so there
            # the symlink refusal rests on O_EXCL (which refuses an existing reparse
            # point) together with the realpath-based checks in _dest_inside_repo /
            # _is_within below. This note documents existing behaviour; nothing here
            # changes on either platform.
            fd = secure_open(full)
            try:
                os.write(fd, payload)
            finally:
                os.close(fd)
            if os.name == 'nt':
                try:
                    os.chmod(full, 0o600)  # Windows: read-only attribute only.
                except OSError:
                    pass
            path = full
            break
        except FileExistsError as e:
            last_err = e
            candidate = '%s-%d.json' % (stem, n)
            n += 1
            continue
    if path is None:
        # Exhausted numbered candidates; reason only, never content.
        raise ImportFileError('Could not create a new import file (too many name collisions).')

    return {'path': path,
            'name': name,
            'sha256': _hashlib.sha256(payload).hexdigest(),
            'bytes': len(payload),
            'contains_identity_warning': True}


def _dest_inside_repo(dest_dir):
    """True if dest_dir lies inside a git work tree or inside the folder that
    contains this module (the project's own repo/work copy).

    A git work tree is detected by walking UP from dest_dir looking for a `.git`
    entry that exists as either a directory (normal clone) OR a file (worktree/
    submodule gitlink). The project-folder check refuses a destination at or
    under the directory that holds quick_reg.py itself.

    F-3 hardening:
      * Every path (the destination, the project folder and each ancestor in the
        git walk) is resolved with os.path.realpath - NOT os.path.abspath - so
        junctions / 8.3 short names / symlinked ancestors collapse to their real
        location before the comparison.
      * The project-folder guard must not silently vanish. If __file__ is
        unavailable we fall back to the current working directory (realpath'd);
        if NEITHER the module path nor the cwd can be resolved we FAIL CLOSED
        (return True, refusing the destination) rather than dropping the guard.
      * An unresolvable destination also fails closed.
    """
    try:
        dest = os.path.realpath(dest_dir)
    except OSError:
        return True  # fail closed: cannot resolve the destination
    # Determine the project's own folder. Prefer __file__; if it is unavailable
    # (frozen/exec'd module) fall back to the current working directory; if
    # NEITHER resolves, fail closed rather than skip the guard.
    module_dir = None
    try:
        module_dir = os.path.realpath(os.path.dirname(__file__))
    except (NameError, OSError):
        module_dir = None
    if module_dir is None:
        try:
            module_dir = os.path.realpath(os.getcwd())
        except OSError:
            module_dir = None
    if module_dir is None:
        return True  # fail closed: project root undeterminable
    if _is_within(dest, module_dir):
        return True
    # Walk up looking for a .git entry (directory OR file), on realpath'd paths.
    cur = dest
    while True:
        git_marker = os.path.join(cur, '.git')
        if os.path.isdir(git_marker) or os.path.isfile(git_marker):
            return True
        parent = os.path.realpath(os.path.dirname(cur))
        if parent == cur:
            break
        cur = parent
    return False


def _is_within(child, parent):
    """True if `child` is `parent` or a path under it.

    F-3: both ends are resolved with os.path.realpath (collapsing symlinks, 8.3
    short names and junctions) before the normcase prefix comparison, so a
    symlinked ancestor cannot slip a destination past the project-folder guard.

    Follow-up (Security cond D / Tester D-1): on an OSError from os.path.realpath
    this now FAILS CLOSED (returns True, i.e. "treat as inside/refuse") to match
    _dest_inside_repo's posture. _is_within has exactly one caller - the
    project-folder guard in _dest_inside_repo, where True means "inside -> refuse"
    - so returning True on an unresolvable path refuses rather than silently
    skipping the guard. This matters for the work copy, which has NO .git tree, so
    the .git walk is NOT a backstop for the project-folder guard.
    """
    try:
        child_n = os.path.normcase(os.path.realpath(child))
        parent_n = os.path.normcase(os.path.realpath(parent))
    except OSError:
        return True  # fail closed: an unresolvable path is treated as "inside"
    if child_n == parent_n:
        return True
    prefix = parent_n if parent_n.endswith(os.sep) else parent_n + os.sep
    return child_n.startswith(prefix)


def find_quick_profile_configs(quick_home=None):
    """Read-only discovery of Quick's mcp_config.json files.

    Looks under <quick_home>/profiles/*/mcp_config.json plus the root-level
    <quick_home>/mcp_config.json. quick_home defaults to ~/.quickwork. Returns a
    list of existing file PATHS only - never any file content. Never writes.
    """
    home = quick_home if quick_home else os.path.join(os.path.expanduser('~'), '.quickwork')
    found = []
    root_cfg = os.path.join(home, 'mcp_config.json')
    if os.path.isfile(root_cfg):
        found.append(root_cfg)
    profiles_dir = os.path.join(home, 'profiles')
    if os.path.isdir(profiles_dir):
        try:
            entries = sorted(os.listdir(profiles_dir))
        except OSError:
            entries = []
        for entry in entries:
            cfg = os.path.join(profiles_dir, entry, 'mcp_config.json')
            if os.path.isfile(cfg):
                found.append(cfg)
    return found


_KEY_SUFFIX_RE = _re.compile(r'-[0-9a-f]{8}$')


def _strip_key_suffix(key):
    """Remove a trailing -<8 hex> suffix Quick appends to the stored key."""
    return _KEY_SUFFIX_RE.sub('', str(key))


def _load_quick_config_servers(config_path):
    """Read-only load of mcp_config.json -> the mcpServers dict, or a sentinel.

    Returns (servers_dict, None) on success, or (None, 'UNREADABLE') for a
    missing/corrupt/oversized file, a non-object top level, a missing/!object
    'mcpServers', or a BOM-but-otherwise-valid file (BOM tolerated). NEVER raises
    on bad content and NEVER includes content in anything it returns.

    F-7: the 5 MB size cap is enforced via os.fstat on the OPEN handle rather than
    a separate os.stat/os.path.getsize before the open, closing the stat-then-open
    (TOCTOU) window. Every UNREADABLE outcome (missing, oversized, corrupt,
    non-dict, missing mcpServers, OS error) is preserved exactly, and content is
    never returned.
    """
    try:
        if not os.path.isfile(config_path):
            return None, 'UNREADABLE'
        with open(config_path, 'rb') as fh:
            # Size-cap from the already-open handle (fstat), not a pre-open stat,
            # so the file we measure is the file we read. Oversized -> UNREADABLE
            # without reading the body.
            if os.fstat(fh.fileno()).st_size > _QUICK_CONFIG_MAX_BYTES:
                return None, 'UNREADABLE'
            # Follow-up (Security cond B / F-7): bound the read itself to cap+1
            # bytes so the cap governs the bytes actually pulled into memory, not
            # just the pre-read fstat size. If the file grew between fstat and the
            # read, len(raw) > cap -> UNREADABLE, and we never return its content.
            raw = fh.read(_QUICK_CONFIG_MAX_BYTES + 1)
            if len(raw) > _QUICK_CONFIG_MAX_BYTES:
                return None, 'UNREADABLE'
    except OSError:
        return None, 'UNREADABLE'
    # Tolerate a UTF-8 BOM.
    if raw[:3] == b'\xef\xbb\xbf':
        raw = raw[3:]
    try:
        obj = json.loads(raw.decode('utf-8'))
    except (ValueError, UnicodeDecodeError):
        return None, 'UNREADABLE'
    if not isinstance(obj, dict):
        return None, 'UNREADABLE'
    servers = obj.get('mcpServers')
    if not isinstance(servers, dict):
        return None, 'UNREADABLE'
    return servers, None


def check_name_collision(name, config_path):
    """Read-only: does `name` already name a connector in config_path?

    Compares `name` against each entry's _quick.name, _quick.upstream_id, and the
    stored key with a trailing -<8hex> removed. Returns {collides: bool, count:
    int}. NEVER returns any other entry's name, args, env, or source path. A
    missing/unreadable file yields {collides: False, count: 0}.
    """
    servers, err = _load_quick_config_servers(config_path)
    if err is not None or servers is None:
        return {'collides': False, 'count': 0}
    count = 0
    for key, entry in servers.items():
        matched = False
        if _strip_key_suffix(key) == name:
            matched = True
        if not matched and isinstance(entry, dict):
            q = entry.get('_quick')
            if isinstance(q, dict):
                if q.get('name') == name or q.get('upstream_id') == name:
                    matched = True
        if matched:
            count += 1
    return {'collides': count > 0, 'count': count}


def _read_startup_timeout(entry):
    """Resolve the connector's startupTimeout from an entry, honouring the REAL
    observed storage shape where it lives inside the per-entry _quick object.

    Executed observation (2026-10-20): 11/19 real entries carried startupTimeout
    inside _quick. Older/other builds may put it at the entry top level, so we
    accept a top-level value as a fallback.

    Returns (has_startup_timeout: bool, value_or_None, location) where location is
    '_quick' when read from entry['_quick']['startupTimeout'], 'top-level' when
    read from entry['startupTimeout'], or None when absent/invalid. A valid
    timeout is a real number (int or float, NOT bool) that is strictly positive;
    a non-numeric, bool, negative or zero value is treated as 'no usable timeout'.
    """
    def _valid(v):
        return isinstance(v, (int, float)) and not isinstance(v, bool) and v > 0

    q = entry.get('_quick') if isinstance(entry.get('_quick'), dict) else None
    if q is not None and 'startupTimeout' in q:
        v = q.get('startupTimeout')
        if _valid(v):
            return True, v, '_quick'
        return False, None, None
    if 'startupTimeout' in entry:
        v = entry.get('startupTimeout')
        if _valid(v):
            return True, v, 'top-level'
        return False, None, None
    return False, None, None


def _read_auto_disabled(entry):
    """Return the boolean _quick.autoDisabled when present as a real bool, else
    None. Only this one field is read out of _quick (never any other _quick
    value). autoDisabled True means Quick itself disabled the connector."""
    q = entry.get('_quick') if isinstance(entry.get('_quick'), dict) else None
    if q is not None and isinstance(q.get('autoDisabled'), bool):
        return q.get('autoDisabled')
    return None


def verify_quick_import(name, expected_command, expected_args, config_path):
    """Read-only verification that Quick imported the connector as expected.

    Locates the entry by _quick.name == name OR _quick.upstream_id == name OR
    (stored key == name OR key matches name-<8hex>). Compares command and args
    EXACTLY against expected_command / expected_args.

    Returns a dict {status, ...flags} where status is one of:
      NOT_FOUND            - no matching entry
      FOUND_MATCH          - exactly one match, command and args both equal
      FOUND_MISMATCH_COMMAND - one match, command differs
      FOUND_MISMATCH_ARGS  - one match, command equal but args differ
      MULTIPLE_MATCHES     - more than one entry matches (count only)
      UNREADABLE           - missing/corrupt/oversized file or unexpected shape

    For a single match it also reports BOOLEAN flags {disabled, has_env,
    has_startup_timeout}. startupTimeout is read from the entry's _quick object
    first (the REAL observed location) and from a top-level startupTimeout only as
    a fallback; when present (and a positive number) the NUMBER 'startup_timeout'
    and a 'startup_timeout_location' of '_quick' or 'top-level' are included (a
    number/location is not a secret). When _quick.autoDisabled is present as a
    bool it is reported as 'auto_disabled'. NOTHING else is ever read out of
    _quick, and the function NEVER returns the stored args, env, source path, or
    any other entry's name.
    """
    servers, err = _load_quick_config_servers(config_path)
    if err is not None or servers is None:
        return {'status': 'UNREADABLE'}

    matches = []
    for key, entry in servers.items():
        if not isinstance(entry, dict):
            # A non-object entry can still match by key; keep it so we count it,
            # but comparisons below guard on isinstance.
            if _strip_key_suffix(key) == name or key == name:
                matches.append((key, entry))
            continue
        q = entry.get('_quick') if isinstance(entry.get('_quick'), dict) else {}
        if (q.get('name') == name or q.get('upstream_id') == name
                or key == name or _strip_key_suffix(key) == name):
            matches.append((key, entry))

    if not matches:
        return {'status': 'NOT_FOUND'}
    if len(matches) > 1:
        return {'status': 'MULTIPLE_MATCHES', 'count': len(matches)}

    _key, entry = matches[0]
    if not isinstance(entry, dict):
        return {'status': 'UNREADABLE'}

    stored_command = entry.get('command')
    stored_args = entry.get('args')

    disabled = bool(entry.get('disabled', False))
    has_env = isinstance(entry.get('env'), dict) and len(entry.get('env')) > 0
    has_startup_timeout, st_value, st_location = _read_startup_timeout(entry)
    auto_disabled = _read_auto_disabled(entry)

    flags = {'disabled': disabled, 'has_env': has_env,
             'has_startup_timeout': has_startup_timeout}
    if has_startup_timeout:
        flags['startup_timeout'] = st_value  # a number, not a secret
        flags['startup_timeout_location'] = st_location  # '_quick' or 'top-level'
    if auto_disabled is not None:
        flags['auto_disabled'] = auto_disabled

    # Exact comparison. command first, then args. Never echo the stored values.
    if stored_command != expected_command:
        result = {'status': 'FOUND_MISMATCH_COMMAND'}
        result.update(flags)
        return result
    if (not isinstance(stored_args, list)) or stored_args != list(expected_args):
        result = {'status': 'FOUND_MISMATCH_ARGS'}
        result.update(flags)
        return result
    result = {'status': 'FOUND_MATCH'}
    result.update(flags)
    return result


def import_instructions(settings, kind, *, import_path):
    """Plain-language numbered steps for a non-expert to import `import_path`
    into Quick, verify the connector, and set the timeout by hand.

    Grounded ONLY in what was observed. It does NOT assert that a confirmation
    prompt appears, nor a default timeout; it says 'if a confirmation prompt
    appears, read the command and confirm it matches'. The manual-registration
    fallback (quick_instructions) remains available and is referenced.

    `kind` selects the by-hand timeout the user should set after import, because
    an import file carries no timeout: lambda -> 30 s, git -> 120 s, local -> 120 s.
    """
    try:
        timeout = TIMEOUT_SECONDS.get(kind, 120)
    except Exception:
        timeout = 120
    name = ''
    if isinstance(settings, dict):
        name = settings.get('name') or settings.get('id') or ''
    lines = [
        'AMAZON QUICK \u2014 IMPORT AN MCP CONNECTOR FROM A FILE',
        '==================================================',
        'This uses Quick\'s documented Import mode. The wizard has written an import',
        'file for you; Quick reads it and creates the connector. Quick\'s own files are',
        'never written by the wizard.',
        '',
        '1. Open Amazon Quick Desktop.',
        '2. Go to Customize > Connectors.',
        '3. Click Create > Create local connector.',
        '4. Choose the Import type.',
        '5. In the Config file path field, paste or pick this path:',
        '       {}'.format(import_path),
        '6. Let Quick scan the file. BEFORE you confirm or save, take a screenshot of',
        '   what Quick shows (the command and arguments it parsed).',
        '7. If a confirmation prompt appears, read the command it shows and confirm it',
        '   matches the command you expect. (We do not know whether this build shows',
        '   such a prompt; if it does, this is your chance to check it.)',
        '8. Click Save.',
        '9. Open a NEW Quick chat and ask the connector for one harmless, read-only',
        '   action (for example: list your available tools). Confirm it responds from',
        '   the intended backend.',
        '',
        'SET THE TIMEOUT BY HAND (an import file carries no timeout):',
        '10. Open the connector you just created and edit it. Set the Timeout to',
        '    {} seconds for this connector ({} connectors: Lambda 30, Git 120,'.format(timeout, 'these'),
        '    local 120). Save.',
        '',
        'AFTER IMPORT:',
        '11. Delete the import file as soon as Quick has created the connector. It',
        '    contains your login and the gateway address. On Windows it is NOT',
        '    permission-protected - it inherits the containing folder\'s access rules,',
        '    so create it only in a PRIVATE folder, OUTSIDE any synced, shared,',
        '    cloud-backed-up or git folder, and never commit or publish it.',
        '    (The synced-folder check is a NAME-BASED heuristic: it cannot see'
        ' OneDrive Known Folder Move redirection, network shares, mapped drives'
        ' or cloud-synced folders with unusual names, so you must choose a'
        ' private local folder yourself.)',
        '',
        'If Import does not work on your build, the manual-registration steps',
        '(quick_instructions) remain available as a fallback: enter the Command,',
        'Arguments and Timeout by hand in the Local connector form.',
    ]
    if name:
        lines.insert(7, '   (The connector will be named "{}".)'.format(name))
    return '\n'.join(lines) + '\n'
