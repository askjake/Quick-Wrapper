"""AQ-MCP Wizard ENGINEERING PREVIEW P1 - viewer-only macOS entry point (R3).

NOT A QUALIFIED RELEASE - ENGINEERING PREVIEW. Nothing has ever run on macOS.

This is the ONE new Mac launcher for the viewer-only package. It does NOT call
the frozen viewer's main() (whose USERNAME/Windows-Sandbox guard and exit-3 path
are Windows-only and meaningless on macOS). Instead it performs its own
argv/interpreter/platform checks under STRICT isolation (-I -B -S), computes a
set of TRUSTED stdlib roots from the running interpreter BEFORE the package
folder is on sys.path, verifies the package in-process with a stdlib-only
trusted verifier, arms fail-closed tripwires and a sys.meta_path ORIGIN finder,
warms the stdlib import closure from the trusted roots, appends (never inserts)
the verified package folder to sys.path, imports the frozen preview_viewer whose
own verify_package runs as an independent second check, and runs the frozen
run_gui. It reuses the frozen viewer UNCHANGED.

Governing documents (round 3): p1mac_viewer_only_r3_brief_addendum2.md (wins),
p1mac_viewer_only_r3_brief.md, p1mac_viewer_only_correction_proposal_r3.md,
security_engineer_p1mac_viewer_only_trust_boundary.md.

EXIT CODES (addendum2 S8; new 6):
  0  clean Quit
  2  this launcher's OWN refusals: argv, interpreter/platform/isolated, a
     PYTHON* env var, path hygiene, a blocked/denied import, an ambiguous or
     untrusted module ORIGIN, the post-run sys.modules deny check, the
     stdlib-or-product delta check, a missing stdlib_module_names, and any
     armed tripwire firing
  4  package integrity failure (trusted_verify or the frozen verify_package)
  5  viewer integrity failure (the frozen run_gui raised IntegrityError)
  6  GUI could not start (Tk init / run_gui raised a non-refusal exception);
     NEVER retried with relaxed settings

NETWORK/ORIGIN POLICY (addendum2 S1-S7): the sys.meta_path finder is the DEFAULT
and ONLY network/origin mechanism. It (a) refuses any DENY name first (deny wins,
checked independently of everything), then (b) for a NEWLY resolved module checks
the module ORIGIN against the trusted roots and the product-module rule BEFORE
the module's code executes, and (c) otherwise defers to the real finders. The
post-run checks (deny over all of sys.modules; stdlib-or-product delta) are a
BACKSTOP. There is NO runtime socket guard and NO fallback. On any refusal the
launcher prints exactly one fixed sanitized line and exits non-zero. It NEVER
relaxes or widens the rules on failure.

HONEST LIMITS (addendum2 DISCLOSE; see README): the entry script cannot verify
itself in-process (only the external ZIP SHA-256 and the optional entry-file
hash anchor it); the post-run checks cannot PREVENT execution; APFS is
case-insensitive so the origin comparison is conservative (may over-refuse,
never over-accept); provider layouts (Homebrew/pyenv/conda, python-tk) may place
a legitimate module outside the derived trusted roots and it will be REFUSED
(fail closed) and recorded as an OBSERVED LIMITATION; none of this protects
against a compromised interpreter, standard library or host.

HARD RULES honoured: standard library only (tkinter allowed; no network, no
subprocess, no os.system, no eval/exec, no ctypes, no file writes by this
launcher). No secret / real login / surname / device name / host / IP / account
id appears anywhere in this file (synthetic + documentation values only).
"""
import os
import sys


# --------------------------------------------------------------------------- #
# Fixed strings (no identity; documentation/synthetic only).
# --------------------------------------------------------------------------- #
BANNER = 'NOT A QUALIFIED RELEASE - ENGINEERING PREVIEW (viewer-only macOS)'
ARGV_ALLOW = frozenset({'--self-test'})

# addendum2 S3/S8 / A2: the single fixed sanitized refusal template for a
# blocked/unexpected/ambiguous import. <name> is the top-level module name OR a
# class-word reason reduced to the token class and clipped; nothing else (no
# path, no traceback, no message text, never the module's origin path).
REFUSE_IMPORT_TEMPLATE = 'REFUSED - unexpected import blocked: %s'

# addendum2 S8: exit codes (0 clean / 2 own refusal / 4 package integrity /
# 5 viewer integrity / 6 GUI start failure).
EXIT_CLEAN = 0
EXIT_OWN_REFUSAL = 2
EXIT_PACKAGE_INTEGRITY = 4
EXIT_VIEWER_INTEGRITY = 5
EXIT_GUI_START = 6


# --------------------------------------------------------------------------- #
# Embedded 3-line manifest header contract (M3/M5).
#
# Line 1 MUST equal the frozen viewer's MANIFEST_LINE1 constant (a build-time
# self-test asserts equality against the real viewer source and the builder's
# build_manifest_text output). Line 2 is the identity-scan line with N digits.
# Line 3 is the exact format line emitted by the builder.
# --------------------------------------------------------------------------- #
MANIFEST_LINE1 = '# AQ-MCP Wizard ENGINEERING PREVIEW P1 - NOT A QUALIFIED RELEASE'
MANIFEST_LINE3 = '# format: <sha256-hex>  <posix-relative-path>'
# Line-2 shape, validated by code (N = one-or-more digits):
#   '# identity-scan: SCANNED (private terms: N)'
_MAN_L2_PREFIX = '# identity-scan: SCANNED (private terms: '
_MAN_L2_SUFFIX = ')'

# The EXACTLY-ten package members (M3). Sorted here for readability only; the
# verifier compares as a set and also enforces the count.
EXPECTED_MEMBERS = (
    'README_VIEWER_ONLY_MAC.md', 'PREVIEW_MANIFEST.sha256',
    'preview_viewer.py', 'view_preview_mac.py',
    'wizard.py', 'model.py', 'quick_reg.py', 'deploy_lib.py',
    'native_gateway.py', 'bootstrap_lib.py',
)
MANIFEST_NAME = 'PREVIEW_MANIFEST.sha256'

# Per-member streaming hash size cap (M3). A member larger than this is a
# refusal (the real members are well under this; the frozen viewer is ~119 KB).
_MEMBER_SIZE_CAP = 4 * 1024 * 1024  # 4 MiB


# --------------------------------------------------------------------------- #
# Product modules (A1) and the stdlib import closure to WARM (M4).
#
# The six PRODUCT modules are the ONLY non-stdlib names the delta check and the
# origin finder may ALLOW, and only after trusted_verify has succeeded AND the
# module's realpath equals pkg_dir/<name>.py EXACTLY (addendum2 S4).
# --------------------------------------------------------------------------- #
_PRODUCT_MODULES = frozenset({
    'wizard', 'model', 'quick_reg', 'deploy_lib', 'native_gateway',
    'bootstrap_lib',
})

# R3E: the ONE additional package-local module the launcher itself imports
# (`_run` imports the frozen viewer from the verified package folder). It is NOT
# a product module: the six-name product allow-list above is unchanged, and the
# viewer is accepted only by the exact-path rule in classify_origin.
_VIEWER_MODULE = 'preview_viewer'

# The stdlib top-level names imported at MODULE LEVEL by the frozen viewer and
# the six product modules, DERIVED BY AST from those files (not guessed):
#   preview_viewer: argparse ast hashlib os sys
#   wizard:         json os threading tkinter (+ product)
#   model:          hashlib json os re stat urllib.parse
#   quick_reg:      hashlib json os re sqlite3 (+ product)
#   deploy_lib:     base64 json os pathlib threading (+ product)
#   native_gateway: base64 contextlib hashlib json os pathlib platform re
#                   shutil struct subprocess sys tempfile time (+ product)
#   bootstrap_lib:  base64 hashlib io pathlib zipfile
# os/sys are start-up / already loaded. urllib.parse is warmed as urllib.parse
# (full name) so the submodule is present before the append.
_WARM_TOPLEVEL = (
    'argparse', 'ast', 'base64', 'contextlib', 'hashlib', 'io', 'json',
    'pathlib', 'platform', 're', 'shutil', 'sqlite3', 'stat', 'struct',
    'subprocess', 'tempfile', 'threading', 'time', 'tkinter', 'zipfile',
)
_WARM_DOTTED = ('urllib.parse',)


# --------------------------------------------------------------------------- #
# DENY set (A2) - BYTE-IDENTICAL to r2. Checked INDEPENDENTLY of and BEFORE the
# stdlib/origin rule; DENY wins over everything (addendum2 S7).
# --------------------------------------------------------------------------- #
DENY_PREFIXES = (
    'socket', '_socket', 'ssl', '_ssl', 'http', 'urllib.request',
    'urllib.error', 'paramiko', 'botocore', 'boto3', 'mcp', 'requests',
    'ftplib', 'smtplib', 'telnetlib', 'poplib', 'imaplib', 'xmlrpc', 'ctypes',
)
# Names in the deny set that must stay OUT of sys.modules after the product
# import (post-run deny check over ALL of sys.modules; exit 2 on any present).
DENY_POSTCHECK = (
    'socket', '_socket', 'ssl', '_ssl', 'paramiko', 'botocore', 'boto3',
    'mcp', 'requests',
)


# --------------------------------------------------------------------------- #
# Sanitisation helpers (pure).
# --------------------------------------------------------------------------- #
def _sanitize_modname(name):
    """Reduce a module name / reason word to [A-Za-z0-9_], TOP-LEVEL token,
    clip to 40 chars. Pure; never returns a path, message or origin."""
    top = (name or '').split('.', 1)[0]
    cleaned = ''.join(c for c in top if (c.isalnum() and c.isascii()) or c == '_')
    return cleaned[:40]


def _is_denied(fullname):
    """True iff the dotted import name is in the deny set (top-level or any
    submodule). Pure. Checked FIRST and independently of the stdlib/origin
    rule (addendum2 S7; deny wins)."""
    for pref in DENY_PREFIXES:
        if fullname == pref or fullname.startswith(pref + '.'):
            return True
    return False


class _RefusedImport(BaseException):
    """Raised by a tripwire / the origin finder to refuse. Subclasses
    BaseException so a product ``except Exception`` cannot swallow it. Carries
    a sanitized token only (name or reason class word)."""
    def __init__(self, sanitized_name):
        self.sanitized_name = sanitized_name
        super().__init__(sanitized_name)


# --------------------------------------------------------------------------- #
# Trusted roots (addendum2 S4). Computed ONCE, from the running interpreter,
# BEFORE the package folder is appended and before any non-startup import, using
# only os + sys. The real directory of os.__file__ is the stdlib directory; its
# lib-dynload sibling holds C-extension stdlib modules. site-packages and
# user-site are NOT trusted roots (a stdlib-NAMED module found there is refused).
# We deliberately do NOT import sysconfig before verification (S4); the derived
# roots are the os-module directory, its parent-derived lib-dynload sibling, and
# (best-effort, os/sys only) the real sys.prefix/lib tree if different.
# --------------------------------------------------------------------------- #
def compute_trusted_roots(os_file_path, prefix, base_prefix):
    """Pure given its inputs. Return a tuple of realpath'd trusted-root
    directories derived from the running interpreter using os/sys only.

    os_file_path : os.__file__ (the stdlib directory holds os.py)
    prefix       : sys.prefix
    base_prefix  : sys.base_prefix

    Caller resolves os.__file__/sys.prefix on the REAL interpreter BEFORE the
    package folder is on sys.path; this function only derives + realpath-
    normalises, so it is unit-testable with synthetic inputs."""
    roots = []

    def _add(p):
        if not p:
            return
        try:
            rp = os.path.realpath(p)
        except (OSError, ValueError):
            return
        if rp and rp not in roots:
            roots.append(rp)

    if os_file_path:
        stdlib_dir = os.path.dirname(os.path.realpath(os_file_path))
        _add(stdlib_dir)
        # lib-dynload sibling (C-extension stdlib modules live here on POSIX).
        _add(os.path.join(stdlib_dir, 'lib-dynload'))
    # Platform stdlib under sys.prefix / sys.base_prefix, os/sys-only derivation
    # (no sysconfig). CPython POSIX layout: <prefix>/lib/pythonX.Y and its
    # lib-dynload. We derive the 'pythonX.Y' leaf from the stdlib_dir basename.
    leaf = os.path.basename(os.path.dirname(os.path.realpath(os_file_path))) if os_file_path else ''
    for base in (prefix, base_prefix):
        if base and leaf:
            cand = os.path.join(base, 'lib', leaf)
            _add(cand)
            _add(os.path.join(cand, 'lib-dynload'))
    return tuple(roots)


def _sep_aware_under(child_real, root_real):
    """Pure. True iff child_real is root_real itself OR strictly under it by a
    SEPARATOR-AWARE prefix test (so '/usr/lib/python3.13-evil/x.py' is NOT
    under '/usr/lib/python3.13'). Both inputs must already be realpath'd and
    absolute. APFS note: the comparison is case-SENSITIVE string-wise, which is
    CONSERVATIVE on a case-insensitive FS (it can over-refuse, never
    over-accept)."""
    if not child_real or not root_real:
        return False
    if child_real == root_real:
        return True
    return child_real.startswith(root_real + os.sep)


# --------------------------------------------------------------------------- #
# ORIGIN classification (addendum2 S1/S2/S3/S4). Pure decision function over a
# module's resolved (name, spec-origin, loader-kind, is-builtin, is-frozen)
# facts plus the trusted roots, the product-set, pkg_dir, and the interpreter's
# own stdlib_module_names. Returns (ok, reason_classword).
#
# This is the heart of round 3 and is intentionally a PURE function so the
# sys.meta_path finder (pre-exec) and the self-tests drive the SAME logic.
# --------------------------------------------------------------------------- #
# Loader kinds we accept, matched by CLASS NAME (string) so the function stays
# pure and importlib need not be imported before verification. These are the
# standard CPython loader class names (THIRD-PARTY: documented importlib
# machinery). Anything else fails closed.
_OK_SOURCE_LOADERS = frozenset({'SourceFileLoader'})
_OK_EXT_LOADERS = frozenset({'ExtensionFileLoader'})
_OK_BUILTIN_LOADERS = frozenset({'BuiltinImporter'})
_OK_FROZEN_LOADERS = frozenset({'FrozenImporter'})


# --------------------------------------------------------------------------- #
# Loader-name classification (R3c defect fix). A genuine CPython BuiltinImporter
# / FrozenImporter spec.loader is the IMPORTER CLASS ITSELF, not an instance, so
# type(loader).__name__ is the metatype name 'type' and classify_origin would
# wrongly reject every real built-in / frozen module as fake. This PURE helper
# returns the loader class-name used by classify_origin:
#   * INSTANCE loader  -> type(loader).__name__  (UNCHANGED prior behaviour,
#     covers SourceFileLoader / ExtensionFileLoader instances);
#   * None             -> '' (UNCHANGED);
#   * CLASS loader     -> its __name__ ONLY IF it is IDENTITY-EQUAL (`is`) to the
#     running interpreter's genuine _frozen_importlib.BuiltinImporter or
#     .FrozenImporter; ANY other class (incl. a counterfeit class that merely
#     has the right __name__) yields the metatype name 'type', so classify_origin
#     still refuses it (fail-closed).
# The genuine classes are obtained via a FUNCTION-LEVEL `import _frozen_importlib`
# (no new module-level import, no importlib.util): the frozen bootstrap module is
# ALWAYS already loaded, and by the time this helper runs the origin finder is
# already armed, so re-importing an already-present module defers through the
# finder without re-executing code. If the genuine classes cannot be obtained
# (import fails / attribute missing / injected None), class loaders FAIL CLOSED
# (keep yielding 'type'). `genuine` may be injected by tests as a 2-tuple
# (BuiltinImporter, FrozenImporter); default None means derive it here.
def _genuine_import_classes():
    """Return (BuiltinImporter, FrozenImporter) genuine classes, or (None, None)
    if they cannot be obtained. Never raises."""
    try:
        import _frozen_importlib as _fi
        return (getattr(_fi, 'BuiltinImporter', None),
                getattr(_fi, 'FrozenImporter', None))
    except BaseException:
        return (None, None)


def loader_class_name(loader, genuine=None):
    """Pure given its inputs. Classify a spec.loader into the class-name string
    classify_origin expects. See the block comment above for the rules. `genuine`
    is an optional (BuiltinImporter, FrozenImporter) tuple for test injection; if
    None it is derived from _frozen_importlib (fail-closed on any failure)."""
    if loader is None:
        return ''
    # Instance loader: unchanged behaviour.
    if not isinstance(loader, type):
        return type(loader).__name__
    # Class loader: accept the name ONLY on genuine-class identity; else 'type'.
    if genuine is None:
        gen_builtin, gen_frozen = _genuine_import_classes()
    else:
        try:
            gen_builtin, gen_frozen = genuine
        except BaseException:
            gen_builtin, gen_frozen = None, None
    if gen_builtin is not None and loader is gen_builtin:
        return 'BuiltinImporter'
    if gen_frozen is not None and loader is gen_frozen:
        return 'FrozenImporter'
    # Any other class object (counterfeit, or genuine classes unavailable) ->
    # fail closed: yield the metatype name so classify_origin rejects it.
    return 'type'


# Path segments that mark an UNTRUSTED location even when nested under a trusted
# root (site-packages and user-site live under <prefix>/lib/pythonX.Y on POSIX,
# which is itself a trusted root; they must NOT be trusted). addendum2 S4.
_UNTRUSTED_SEGMENTS = ('site-packages', 'dist-packages', '.local')


def _is_untrusted_location(origin_real):
    """Pure. True iff the realpath contains a site-packages / dist-packages /
    user-site ('.local') path segment (separator-bounded)."""
    parts = origin_real.split(os.sep)
    return any(seg in parts for seg in _UNTRUSTED_SEGMENTS)


def _genuine_source_loader(loader, genuine=None):
    """R3E. True iff ``loader`` is an INSTANCE of exactly the interpreter's own
    importlib SourceFileLoader class (class IDENTITY, not just the class name).
    ``genuine`` may be injected (tests); otherwise it is read from the frozen
    ``_frozen_importlib_external``. Fail closed: any problem -> False."""
    try:
        if genuine is None:
            import _frozen_importlib_external as _fe
            genuine = _fe.SourceFileLoader
        return type(loader) is genuine
    except BaseException:
        return False


def classify_origin(name, origin, loader_classname, submodule_search_locations,
                     has_spec, trusted_roots, pkg_dir_real, product_set,
                     stdlib_names, builtin_names):
    """Pure. Decide whether a module with these resolved facts may load.

    Returns (ok: bool, reason: str). reason is a CLASS WORD only on refusal
    (e.g. 'origin_ambiguous', 'untrusted_origin', 'shadowed_stdlib',
    'fake_builtin', 'product_unverified', 'not_product', 'no_stdlib_names').
    Deny is handled by the caller BEFORE this function (deny wins).

    name                : full dotted name
    origin              : spec.origin (str | None)
    loader_classname    : type(spec.loader).__name__ or '' 
    submodule_search_locations : spec.submodule_search_locations or None
    has_spec            : whether __spec__/spec exists at all
    trusted_roots       : tuple of realpath'd trusted dirs
    pkg_dir_real        : realpath of the verified package dir (or None if
                          verification has NOT succeeded yet)
    product_set         : frozenset of the six product names
    stdlib_names        : the interpreter's sys.stdlib_module_names (set/frozenset
                          of str) or None -> fail closed
    builtin_names       : sys.builtin_module_names (tuple of str)
    """
    top = (name or '').split('.', 1)[0]

    # S3: no spec at all -> fail closed.
    if not has_spec:
        return False, 'no_spec'

    # S1 fail-closed precondition: the interpreter must expose its own stdlib
    # classification as a set/frozenset of str; otherwise we cannot apply the
    # stdlib rule and refuse everything (addendum2 S1 / A1).
    if not isinstance(stdlib_names, (set, frozenset)):
        return False, 'no_stdlib_names'

    # ---- Built-in / frozen: classify by origin, accept WITHOUT a path check,
    #      but only if genuinely so (S2). A fake 'built-in'/'frozen' is refused.
    if origin == 'built-in':
        if loader_classname in _OK_BUILTIN_LOADERS and name in builtin_names:
            return True, 'builtin'
        return False, 'fake_builtin'
    if origin == 'frozen':
        # Accept only an expected frozen/stdlib name with the frozen loader.
        if loader_classname in _OK_FROZEN_LOADERS and (
                name in stdlib_names or top in stdlib_names
                or name.startswith('importlib')
                or name.startswith('_frozen_importlib')):
            return True, 'frozen'
        return False, 'fake_frozen'

    # ---- From here a path origin is required. S3: ambiguous origins fail
    #      closed BEFORE any trust decision.
    if origin is None or not isinstance(origin, str) or origin == '':
        return False, 'origin_ambiguous'
    # Namespace package: no real origin, submodule_search_locations only.
    if origin == 'namespace' or (submodule_search_locations is not None
                                 and origin in (None, '', 'namespace')):
        return False, 'namespace_origin'
    # zip / egg origins are refused (S3).
    low = origin.lower()
    if ('.zip' + os.sep) in (low + os.sep) or low.endswith('.zip') \
            or '.egg' in low:
        return False, 'zip_origin'
    # Relative origin -> ambiguous (S3).
    if not os.path.isabs(origin):
        return False, 'origin_relative'
    # Loader must be one of the expected path-based kinds (S3).
    if loader_classname not in (_OK_SOURCE_LOADERS | _OK_EXT_LOADERS):
        return False, 'unexpected_loader'

    # Realpath the origin; a symlink escaping the trusted roots is caught by
    # realpath + the separator-aware test (S3).
    try:
        origin_real = os.path.realpath(origin)
    except (OSError, ValueError):
        return False, 'origin_unresolvable'
    if not os.path.isabs(origin_real):
        return False, 'origin_ambiguous'

    under_pkg = pkg_dir_real is not None and _sep_aware_under(origin_real, pkg_dir_real)

    # ---- PRODUCT modules (S4): accepted ONLY if (a) verification has
    #      succeeded (pkg_dir_real is not None), (b) the name is one of the six,
    #      and (c) realpath(origin) == pkg_dir/<name>.py EXACTLY.
    if name in product_set:
        if pkg_dir_real is None:
            return False, 'product_unverified'
        expected = os.path.join(pkg_dir_real, name + '.py')
        if origin_real == os.path.realpath(expected):
            return True, 'product'
        return False, 'product_path_mismatch'

    # ---- R3E: the ONE frozen viewer module (exact name). `_run` imports
    #      preview_viewer from the verified package folder, so the origin policy
    #      must accept exactly that module and nothing else that is package-local.
    #      It is NOT a product module (the six-name allow-list is unchanged).
    #      Accepted ONLY if (a) verification has succeeded (pkg_dir_real is not
    #      None), (b) the name is EXACTLY the viewer name (a submodule or a
    #      look-alike name is not), (c) the spec is a plain module with a SOURCE
    #      file loader (not an extension, package or namespace), (d) the expected
    #      file is not itself a symlink, and (e) realpath(origin) ==
    #      pkg_dir/preview_viewer.py EXACTLY. The finder additionally requires the
    #      loader's class IDENTITY to be the genuine SourceFileLoader.
    if name == _VIEWER_MODULE:
        if pkg_dir_real is None:
            return False, 'viewer_unverified'
        if loader_classname not in _OK_SOURCE_LOADERS:
            return False, 'viewer_loader'
        if submodule_search_locations is not None:
            return False, 'viewer_not_module'
        expected = os.path.join(pkg_dir_real, name + '.py')
        if os.path.islink(expected):
            return False, 'viewer_symlink'
        if origin_real == os.path.realpath(expected):
            return True, 'viewer'
        return False, 'viewer_path_mismatch'

    # ---- Any OTHER module whose origin is under pkg_dir is REFUSED (S4),
    #      including a file named like a stdlib module (shadowed stdlib).
    if under_pkg:
        return False, 'shadowed_stdlib' if (top in stdlib_names) else 'package_local'

    # ---- Standard-library rule (S1 + A1): a module classed as stdlib by the
    #      interpreter's own list is accepted ONLY if its origin is under a
    #      TRUSTED root (origin check). site-packages / user-site are NOT
    #      trusted roots even though they commonly live UNDER the stdlib dir, so
    #      a stdlib-NAMED module found there is refused (addendum2 S4). This
    #      guard runs regardless of the separator-aware root test below.
    if top in stdlib_names or name in stdlib_names:
        if _is_untrusted_location(origin_real):
            return False, 'untrusted_origin'
        for root in trusted_roots:
            if _sep_aware_under(origin_real, root):
                return True, 'stdlib'
        return False, 'untrusted_origin'

    # ---- Neither product nor stdlib: third-party / unknown -> refuse (A3).
    return False, 'not_stdlib_not_product'


# --------------------------------------------------------------------------- #
# Tripwire 1a: the sys.meta_path ORIGIN finder (addendum2 S1-S7; S6 pre-exec).
#
# DEFAULT and ONLY network/origin mechanism. For each find_spec:
#   1. DENY check FIRST and independently (deny wins; raise exit-2 refusal).
#   2. If the name is already in sys.modules, defer (already-decided).
#   3. Otherwise ask the OTHER real finders for a spec (without recursing into
#      ourselves), inspect name+origin+loader, and raise the refusal BEFORE the
#      loader runs if classify_origin rejects it. If accepted, return None so
#      the normal machinery loads it (we do not load it ourselves).
#
# S6: this enforces the rule BEFORE module code executes. If, on a given
# interpreter, obtaining a spec without loading is not feasible with the stdlib
# alone, the design still keeps the post-run delta check as a backstop; see the
# report's S6 feasibility statement. (THIRD-PARTY: importlib.util.find_spec and
# the meta_path protocol are documented CPython machinery; NOT executed here.)
# --------------------------------------------------------------------------- #
class _OriginFinder:
    def __init__(self, trusted_roots, pkg_dir_real_holder, product_set,
                 stdlib_names, builtin_names, meta_path=None, tk_ext_real=None):
        self._roots = trusted_roots
        # R3d: optional absolute path of the validated Homebrew python-tk
        # _tkinter extension. None (default) => byte-for-byte R3C behaviour.
        self._tk_ext_real = tk_ext_real
        # pkg_dir_real_holder is a 1-element list so the caller can flip it from
        # None to the verified realpath AFTER trusted_verify succeeds, without
        # replacing the finder instance.
        self._pkg_holder = pkg_dir_real_holder
        self._products = product_set
        self._stdlib = stdlib_names
        self._builtins = builtin_names
        self._in_find = False  # re-entrancy guard
        # The finder list to delegate to. Default None -> the live sys.meta_path
        # (read lazily). Tests inject an explicit list so they never touch the
        # sandbox-blocked global.
        self._meta_path = meta_path

    def _spec_without_self(self, fullname, path):
        """Ask every OTHER meta_path finder for a spec, skipping ourselves.
        Returns a spec or None. Does NOT execute the module (find_spec only)."""
        mp = self._meta_path if self._meta_path is not None else sys.meta_path
        for finder in list(mp):
            if finder is self:
                continue
            fs = getattr(finder, 'find_spec', None)
            if fs is None:
                continue
            spec = fs(fullname, path, None)
            if spec is not None:
                return spec
        return None

    def find_spec(self, fullname, path=None, target=None):
        # 1. DENY wins, checked first and independently (S7).
        if _is_denied(fullname):
            raise _RefusedImport(_sanitize_modname(fullname))
        # 2. Already imported -> not our business (decided earlier). Tests may
        #    inject a loaded-name set via self._loaded; default is sys.modules.
        loaded = getattr(self, '_loaded', None)
        loaded = loaded if loaded is not None else sys.modules
        if fullname in loaded:
            return None
        # Re-entrancy: while we query other finders, defer.
        if self._in_find:
            return None
        self._in_find = True
        try:
            spec = self._spec_without_self(fullname, path)
        except _RefusedImport:
            raise
        except BaseException:
            # Could not obtain a spec without loading -> fail closed.
            raise _RefusedImport(_sanitize_modname('spec_unavailable'))
        finally:
            self._in_find = False
        if fullname == '_tkinter' and self._tk_ext_real is not None:
            F = self._tk_ext_real
            if spec is None:
                # (i) No standard finder knows '_tkinter'; SUPPLY one spec for
                #     exactly F (and nothing else). Any failure -> no spec.
                try:
                    import _frozen_importlib_external as _fe
                    _ldr = _fe.ExtensionFileLoader('_tkinter', F)
                    _sup = _fe.spec_from_file_location(
                        '_tkinter', F, loader=_ldr)
                except BaseException:
                    _sup = None
                if _sup is None:
                    return None
                try:
                    _o = os.path.realpath(getattr(_sup, 'origin', None) or '')
                except BaseException:
                    return None
                if _o == F and loader_class_name(
                        getattr(_sup, 'loader', None)) == 'ExtensionFileLoader':
                    # (ii) accepted from a SUPPLIED spec -> RETURN it so the
                    #      import machinery loads exactly this file.
                    return _sup
                return None
            # A standard finder DID return a spec for '_tkinter'. Accept it
            # WITHOUT change only when it points at exactly F with the right
            # loader; otherwise fall through to classify_origin (unchanged).
            try:
                _so = os.path.realpath(getattr(spec, 'origin', None) or '')
            except BaseException:
                _so = ''
            if _so == F and loader_class_name(
                    getattr(spec, 'loader', None)) == 'ExtensionFileLoader':
                return None
        if spec is None:
            # No real finder claims it; let the normal machinery raise
            # ModuleNotFoundError (defer).
            return None
        loader_cn = loader_class_name(getattr(spec, 'loader', None))
        ok, reason = classify_origin(
            fullname,
            getattr(spec, 'origin', None),
            loader_cn,
            getattr(spec, 'submodule_search_locations', None),
            True,
            self._roots,
            self._pkg_holder[0],
            self._products,
            self._stdlib,
            self._builtins,
        )
        if not ok:
            raise _RefusedImport(_sanitize_modname(reason))
        # R3E: the viewer is accepted only with the GENUINE SourceFileLoader class
        # (identity, not a class NAME), so a counterfeit loader that merely
        # carries the right name cannot load it.
        if reason == 'viewer' and not _genuine_source_loader(
                getattr(spec, 'loader', None)):
            raise _RefusedImport(_sanitize_modname('viewer_loader'))
        # Accepted: defer to the real machinery to actually load it.
        return None

    # Legacy API (harmless).
    def find_module(self, fullname, path=None):
        if _is_denied(fullname):
            raise _RefusedImport(_sanitize_modname(fullname))
        return None


def arm_origin_finder(meta_path, trusted_roots, pkg_dir_real_holder,
                      product_set, stdlib_names, builtin_names,
                      tk_ext_real=None):
    """Insert a fresh _OriginFinder at the FRONT of meta_path. Returns it."""
    f = _OriginFinder(trusted_roots, pkg_dir_real_holder, product_set,
                      stdlib_names, builtin_names, tk_ext_real=tk_ext_real)
    meta_path.insert(0, f)
    return f


# --------------------------------------------------------------------------- #
# Tripwire 2: subprocess + os exec/spawn/system/popen refusers (unchanged r2).
# --------------------------------------------------------------------------- #
_OS_PROC_NAMES = (
    'system', 'popen', 'execl', 'execle', 'execlp', 'execlpe', 'execv',
    'execve', 'execvp', 'execvpe', 'spawnl', 'spawnle', 'spawnlp', 'spawnlpe',
    'spawnv', 'spawnve', 'spawnvp', 'spawnvpe', 'posix_spawn', 'posix_spawnp',
    'fork', 'forkpty',
)


def _make_proc_refuser(label):
    def _refuse(*_a, **_k):
        raise _RefusedImport(_sanitize_modname(label))
    return _refuse


def arm_subprocess_tripwire(subprocess_module, os_module):
    """Replace subprocess.Popen (the module attribute) and the os process-
    creation entry points with refusers. Returns a dict of the originals."""
    saved = {}
    saved['subprocess.Popen'] = getattr(subprocess_module, 'Popen', None)
    subprocess_module.Popen = _make_proc_refuser('subprocess_Popen')
    for nm in _OS_PROC_NAMES:
        if hasattr(os_module, nm):
            saved['os.' + nm] = getattr(os_module, nm)
            setattr(os_module, nm, _make_proc_refuser('os_' + nm))
    return saved


# --------------------------------------------------------------------------- #
# Tripwire 3: write-mode file/dir/sqlite guards (unchanged r2).
# --------------------------------------------------------------------------- #
_WRITE_MODE_CHARS = ('w', 'a', 'x', '+')


def _mode_is_write(mode):
    m = str(mode)
    return any(c in m for c in _WRITE_MODE_CHARS)


def arm_write_tripwire(builtins_module, io_module, os_module, shutil_module,
                       tempfile_module, sqlite3_module):
    """Install write-mode guards. Returns a dict of originals. Read preserved."""
    saved = {}

    _orig_builtins_open = builtins_module.open

    def _guard_open(file, mode='r', *a, **k):
        if _mode_is_write(mode):
            raise _RefusedImport(_sanitize_modname('open_write'))
        return _orig_builtins_open(file, mode, *a, **k)
    saved['builtins.open'] = _orig_builtins_open
    builtins_module.open = _guard_open

    _orig_io_open = io_module.open

    def _guard_io_open(file, mode='r', *a, **k):
        if _mode_is_write(mode):
            raise _RefusedImport(_sanitize_modname('io_open_write'))
        return _orig_io_open(file, mode, *a, **k)
    saved['io.open'] = _orig_io_open
    io_module.open = _guard_io_open

    _orig_os_open = os_module.open
    _wflags = 0
    for fl in ('O_WRONLY', 'O_RDWR', 'O_APPEND', 'O_CREAT', 'O_TRUNC', 'O_EXCL'):
        _wflags |= getattr(os_module, fl, 0)

    def _guard_os_open(path, flags, *a, **k):
        if flags & _wflags:
            raise _RefusedImport(_sanitize_modname('os_open_write'))
        return _orig_os_open(path, flags, *a, **k)
    saved['os.open'] = _orig_os_open
    os_module.open = _guard_os_open

    for nm in ('mkdir', 'makedirs', 'remove', 'unlink', 'rename', 'replace',
               'rmdir'):
        if hasattr(os_module, nm):
            saved['os.' + nm] = getattr(os_module, nm)
            setattr(os_module, nm, _make_proc_refuser('os_' + nm))
    for nm in ('rmtree', 'copy', 'copy2', 'copyfile', 'copytree', 'move'):
        if hasattr(shutil_module, nm):
            saved['shutil.' + nm] = getattr(shutil_module, nm)
            setattr(shutil_module, nm, _make_proc_refuser('shutil_' + nm))
    for nm in ('mkstemp', 'mkdtemp', 'NamedTemporaryFile', 'TemporaryDirectory',
               'TemporaryFile'):
        if hasattr(tempfile_module, nm):
            saved['tempfile.' + nm] = getattr(tempfile_module, nm)
            setattr(tempfile_module, nm, _make_proc_refuser('tempfile_' + nm))

    _orig_sqlite_connect = sqlite3_module.connect

    def _guard_sqlite(database, *a, **k):
        if str(database) != ':memory:':
            raise _RefusedImport(_sanitize_modname('sqlite3_connect'))
        return _orig_sqlite_connect(database, *a, **k)
    saved['sqlite3.connect'] = _orig_sqlite_connect
    sqlite3_module.connect = _guard_sqlite

    return saved


# --------------------------------------------------------------------------- #
# Interpreter / platform / argv / environment checks (pure where possible).
# --------------------------------------------------------------------------- #
def argv_ok(argv_tail):
    """Pure: True iff argv_tail is empty or exactly ['--self-test']. (I9)"""
    if not argv_tail:
        return True
    return all(tok in ARGV_ALLOW for tok in argv_tail) and len(argv_tail) <= 1


def interpreter_ok(platform_str, flags, geteuid_fn):
    """Pure: (ok, reason). darwin + isolated (-I) + -S (no_site) + -B
    (dont_write_bytecode) + not root. reason is a CLASS name only (M1)."""
    if platform_str != 'darwin':
        return False, 'platform-not-darwin'
    if not getattr(flags, 'isolated', 0):
        return False, 'missing-I-isolated'
    if not getattr(flags, 'no_site', 0):
        return False, 'missing-S-no-site'
    if not getattr(flags, 'dont_write_bytecode', 0):
        return False, 'missing-B-no-bytecode'
    try:
        if geteuid_fn is not None and geteuid_fn() == 0:
            return False, 'running-as-root'
    except Exception:
        return False, 'euid-unavailable'
    return True, 'ok'


def any_python_env_set(environ_keys):
    """Pure (C-8): True iff any env var name starts with 'PYTHON'. Never reads
    or returns the value."""
    for k in environ_keys:
        if k.startswith('PYTHON'):
            return True
    return False


def scrub_sys_path(path_list, script_dir_real, cwd_real):
    """Pure (M2/C-1): return a new sys.path list with '', '.', the script
    directory and the cwd removed (separator-aware, realpath-compared). Defence
    in depth when -I is absent from a hand-typed command."""
    out = []
    for entry in path_list:
        if entry in ('', '.'):
            continue
        try:
            er = os.path.realpath(entry)
        except (OSError, ValueError):
            out.append(entry)
            continue
        if er == script_dir_real or er == cwd_real:
            continue
        out.append(entry)
    return out


# --------------------------------------------------------------------------- #
# Trusted in-process verifier (M3, addendum2). stdlib-only (hashlib+os+sys).
# Raises _PackageIntegrity on any failure; caller maps to exit 4.
# --------------------------------------------------------------------------- #
class _PackageIntegrity(Exception):
    """Trusted-verify refusal (maps to exit 4). Message is a CLASS WORD only."""


def _manifest_header_ok(lines):
    """Pure. Validate the embedded 3-line header. Returns True/False."""
    if len(lines) < 3:
        return False
    l1, l2, l3 = lines[0], lines[1], lines[2]
    if l1 != MANIFEST_LINE1 or l3 != MANIFEST_LINE3:
        return False
    if not (l2.startswith(_MAN_L2_PREFIX) and l2.endswith(_MAN_L2_SUFFIX)):
        return False
    mid = l2[len(_MAN_L2_PREFIX):-len(_MAN_L2_SUFFIX)]
    return mid.isdigit() and len(mid) >= 1


def parse_manifest_bytes(raw):
    """Pure. Parse PREVIEW_MANIFEST.sha256 BYTES. Refuse BOM/NUL/CR. Enforce the
    embedded 3-line header, lowercase hex, two-space separator, sorted posix
    paths, no traversal, no duplicates. Returns {posix_path: hexdigest}. Raises
    _PackageIntegrity('<class>')."""
    if raw[:3] == b'\xef\xbb\xbf':
        raise _PackageIntegrity('manifest_bom')
    if b'\x00' in raw:
        raise _PackageIntegrity('manifest_nul')
    if b'\r' in raw:
        raise _PackageIntegrity('manifest_cr')
    try:
        text = raw.decode('utf-8')
    except UnicodeDecodeError:
        raise _PackageIntegrity('manifest_not_utf8')
    lines = text.split('\n')
    if lines and lines[-1] == '':
        lines = lines[:-1]
    if not _manifest_header_ok(lines):
        raise _PackageIntegrity('manifest_header')
    entries = {}
    order = []
    for ln in lines[3:]:
        if ln == '':
            continue
        if ln.startswith('#'):
            raise _PackageIntegrity('manifest_extra_comment')
        if len(ln) < 67 or ln[64:66] != '  ':
            raise _PackageIntegrity('manifest_line_shape')
        digest, rel = ln[:64], ln[66:]
        if len(digest) != 64 or any(c not in '0123456789abcdef' for c in digest):
            raise _PackageIntegrity('manifest_digest')
        if '\\' in rel or rel.startswith('/') or '..' in rel.split('/') \
                or rel.startswith('./'):
            raise _PackageIntegrity('manifest_traversal')
        if rel in entries:
            raise _PackageIntegrity('manifest_duplicate')
        entries[rel] = digest
        order.append(rel)
    if not entries:
        raise _PackageIntegrity('manifest_empty')
    if order != sorted(order):
        raise _PackageIntegrity('manifest_unsorted')
    return entries


def _stream_sha256(hashlib_module, abspath):
    """Streaming SHA-256 with a size cap. Read-only open. Raises
    _PackageIntegrity on an oversize member."""
    h = hashlib_module.sha256()
    total = 0
    with open(abspath, 'rb') as fh:
        while True:
            chunk = fh.read(65536)
            if not chunk:
                break
            total += len(chunk)
            if total > _MEMBER_SIZE_CAP:
                raise _PackageIntegrity('member_too_large')
            h.update(chunk)
    return h.hexdigest()


def trusted_verify(pkg_dir, hashlib_module):
    """M3. Verify the package BEFORE importing the viewer or product modules,
    using only hashlib+os+sys. Enumerate pkg_dir with os.scandir: EXACTLY the
    ten expected names, no symlinks/hidden/subdirs, stream-hash each with a size
    cap, compare to the manifest, print the manifest's own SHA-256. Returns the
    number of verified members. Raises _PackageIntegrity('<class>') (exit 4)."""
    man_path = os.path.join(pkg_dir, MANIFEST_NAME)
    if os.path.islink(man_path) or not os.path.isfile(man_path):
        raise _PackageIntegrity('manifest_missing')
    with open(man_path, 'rb') as fh:
        raw = fh.read()
    entries = parse_manifest_bytes(raw)

    # os.scandir once: exactly the ten names, no symlink/hidden/subdir/extra.
    seen = set()
    for de in os.scandir(pkg_dir):
        nm = de.name
        if nm.startswith('.') or nm.startswith('._'):
            raise _PackageIntegrity('hidden_member')
        if de.is_symlink():
            raise _PackageIntegrity('symlink_member')
        if de.is_dir(follow_symlinks=False):
            raise _PackageIntegrity('subdir_member')
        if not de.is_file(follow_symlinks=False):
            raise _PackageIntegrity('nonregular_member')
        if nm not in EXPECTED_MEMBERS:
            raise _PackageIntegrity('unexpected_member')
        if nm in seen:
            raise _PackageIntegrity('duplicate_member')
        seen.add(nm)
    if seen != set(EXPECTED_MEMBERS):
        raise _PackageIntegrity('member_count')

    # Every manifest entry (all members except the manifest) must verify.
    listed = set(entries) | {MANIFEST_NAME}
    if listed != set(EXPECTED_MEMBERS):
        raise _PackageIntegrity('manifest_membership')
    for rel, digest in entries.items():
        ap = os.path.join(pkg_dir, rel)
        if os.path.islink(ap) or not os.path.isfile(ap):
            raise _PackageIntegrity('listed_missing')
        if _stream_sha256(hashlib_module, ap) != digest:
            raise _PackageIntegrity('sha256_mismatch')

    own = hashlib_module.sha256(raw).hexdigest()
    print('PREVIEW_MANIFEST.sha256 digest: ' + own)
    return len(entries)


# --------------------------------------------------------------------------- #
# Post-run delta check (A1): stdlib-or-product, deny wins (addendum2 S7).
# --------------------------------------------------------------------------- #
def newly_loaded_outside_rule(before_names, after_names, product_set,
                              stdlib_names, deny_fn):
    """Pure (A1). Return the sorted top-level offenders that appeared AFTER the
    snapshot and are NOT allowed by the rule:
      allowed iff (top in product_set OR top in stdlib_names) AND not denied.
    DENY wins over the stdlib rule. Names beginning '_frozen' or '_' keep the
    r2 skip behaviour. If stdlib_names is not a set/frozenset of str -> raise
    _RefusedImport('no_stdlib_names') (fail closed, exit 2)."""
    if not isinstance(stdlib_names, (set, frozenset)):
        raise _RefusedImport(_sanitize_modname('no_stdlib_names'))
    newly = set(after_names) - set(before_names)
    offenders = set()
    for full in newly:
        if not full or full.startswith('_frozen'):
            continue
        top = full.split('.', 1)[0]
        if top.startswith('_'):
            continue
        # DENY wins and is checked independently, FIRST (S7 / K12 / K30).
        if deny_fn(full) or deny_fn(top):
            offenders.add(top)
            continue
        if top in product_set or top in stdlib_names or full in stdlib_names:
            continue
        offenders.add(top)
    return sorted(offenders)


# --------------------------------------------------------------------------- #
# Orchestration (production path; NOT RUN in the specialist sandbox).
# --------------------------------------------------------------------------- #
def _run(argv):
    """Production launcher. Returns an exit code. argv[0] is the script path."""
    tail = list(argv[1:])

    # 1. argv EXACT-match allow-list, BEFORE any file read / side effect.
    if not argv_ok(tail):
        print('REFUSED - argv: only --self-test is accepted')
        return EXIT_OWN_REFUSAL
    if tail == ['--self-test']:
        return run_self_test()

    # 2. C-8: refuse if any PYTHON* env var is set (never print its value).
    if any_python_env_set(list(os.environ.keys())):
        print('REFUSED - environment: PYTHON-prefixed variable set')
        return EXIT_OWN_REFUSAL

    # 3. interpreter self-checks (fail-closed; now requires sys.flags.isolated).
    ok, reason = interpreter_ok(sys.platform, sys.flags,
                                getattr(os, 'geteuid', None))
    if not ok:
        print('REFUSED - interpreter: ' + reason)
        return EXIT_OWN_REFUSAL

    # 4. path hygiene FIRST (M2/C-1): scrub '', '.', script dir, cwd.
    script_path = argv[0] if argv else sys.argv[0]
    pkg_dir = os.path.dirname(os.path.abspath(script_path))
    script_dir_real = os.path.realpath(pkg_dir)
    try:
        cwd_real = os.path.realpath(os.getcwd())
    except (OSError, ValueError):
        cwd_real = ''
    sys.path[:] = scrub_sys_path(list(sys.path), script_dir_real, cwd_real)

    # 5. TRUSTED ROOTS computed ONCE, BEFORE the package folder is on sys.path
    #    and before any non-startup import (addendum2 S4). os/sys only here.
    try:
        os_file = os.path.realpath(os.__file__)
    except Exception:
        print('REFUSED - interpreter: stdlib-anchor-unavailable')
        return EXIT_OWN_REFUSAL
    trusted_roots = compute_trusted_roots(
        os_file, getattr(sys, 'prefix', ''), getattr(sys, 'base_prefix', ''))
    stdlib_names = getattr(sys, 'stdlib_module_names', None)
    if not isinstance(stdlib_names, (set, frozenset)):
        print(REFUSE_IMPORT_TEMPLATE % 'no_stdlib_names')
        return EXIT_OWN_REFUSAL
    builtin_names = tuple(getattr(sys, 'builtin_module_names', ()))

    # 5b. R3d: locate (read-only, exact-file) the separately installed Homebrew
    #     python-tk _tkinter extension for THIS interpreter, BEFORE any import
    #     or print and WITHOUT touching sys.path. Any probe error -> not found.
    class _ProdFs:
        def realpath(self, p):
            return os.path.realpath(p)
        def lstat(self, p):
            return os.lstat(p)
        def read_head(self, p, n):
            with open(p, 'rb') as _fh:
                return _fh.read(n)
    try:
        tk_ext, tk_reason = homebrew_tk_extension(
            os.path.realpath(sys.base_prefix),
            sys.version_info[:3],
            sys.implementation.cache_tag,
            os.uname().machine,
            os.geteuid(),
            _ProdFs())
    except Exception:
        tk_ext, tk_reason = (None, 'tk_probe_error')

    # 6. hashlib from the now-clean stdlib (the origin finder not yet armed; this
    #    is a startup import from the trusted interpreter, package not on path).
    import hashlib as _hashlib

    # 7. TRUSTED VERIFY the package BEFORE importing the viewer/product (M3).
    pkg_dir_real = os.path.realpath(pkg_dir)
    try:
        n = trusted_verify(pkg_dir, _hashlib)
    except _PackageIntegrity as exc:
        print('REFUSED - package integrity: ' + str(exc))
        return EXIT_PACKAGE_INTEGRITY
    print('%s (%d files verified)' % (BANNER, n))

    # 7b. R3d: when (and only when) the Homebrew python-tk extension was
    #     located and validated, print ONE extra line with its SHA-256. A
    #     hash/read failure means we do NOT trust it: drop it BEFORE arming so
    #     the finder is NOT told to supply it (K12-style passing is impossible).
    if tk_ext is not None:
        try:
            _th = _hashlib.sha256()
            with open(tk_ext, 'rb') as _tfh:
                while True:
                    _chunk = _tfh.read(65536)
                    if not _chunk:
                        break
                    _th.update(_chunk)
            print('tk-extension: homebrew python-tk accepted (sha256 '
                  + _th.hexdigest() + ')')
        except Exception:
            tk_ext = None

    # 8. ARM tripwires + the ORIGIN finder BEFORE any product import (S6/S7).
    #    The pkg-dir holder starts verified (verification has SUCCEEDED above),
    #    so the product-module rule (realpath==pkg_dir/<name>.py) can pass.
    import subprocess as _subprocess
    import io as _io
    import shutil as _shutil
    import tempfile as _tempfile
    import sqlite3 as _sqlite3
    import builtins as _builtins
    pkg_holder = [pkg_dir_real]
    arm_origin_finder(sys.meta_path, trusted_roots, pkg_holder,
                      _PRODUCT_MODULES, stdlib_names, builtin_names,
                      tk_ext_real=tk_ext)
    arm_subprocess_tripwire(_subprocess, os)
    arm_write_tripwire(_builtins, _io, os, _shutil, _tempfile, _sqlite3)

    # 9. WARM the AST-derived stdlib closure from the TRUSTED interpreter path
    #    BEFORE appending the package folder (M4). The origin finder is armed, so
    #    each warmed module is origin-checked (and, being stdlib under a trusted
    #    root, accepted) as it loads. No insert(0).
    try:
        _warm_closure()
    except _RefusedImport as exc:
        print(REFUSE_IMPORT_TEMPLATE % exc.sanitized_name)
        return EXIT_OWN_REFUSAL
    except ImportError as exc:
        _suffix = ''
        _tkwords = frozenset({'not_homebrew', 'keg_absent', 'keg_location', 'keg_version',
                 'ext_symlink', 'ext_absent', 'ext_not_regular', 'ext_owner',
                 'ext_perms', 'dir_owner', 'dir_perms', 'dir_group', 'abi_name',
                 'abi_macho', 'machine_unsupported', 'tk_probe_error'})
        if (getattr(exc, 'name', None) == '_tkinter'
                and tk_reason != 'ok' and tk_reason in _tkwords):
            _suffix = ' (tk-extension: ' + tk_reason + ')'
        print('REFUSED - GUI start failure: '
              + _sanitize_modname(type(exc).__name__) + ' '
              + _sanitize_modname(getattr(exc, 'name', None) or '') + _suffix)
        return EXIT_GUI_START

    # 10. APPEND the verified package folder (never insert(0)) (M4/C-4).
    if pkg_dir not in sys.path:
        sys.path.append(pkg_dir)

    # 11. Import the frozen viewer; its own verify_package is the independent
    #     second check.
    try:
        import preview_viewer as _viewer
    except _RefusedImport as exc:
        print(REFUSE_IMPORT_TEMPLATE % exc.sanitized_name)
        return EXIT_OWN_REFUSAL
    except ImportError as exc:
        _suffix = ''
        _tkwords = frozenset({'not_homebrew', 'keg_absent', 'keg_location', 'keg_version',
                 'ext_symlink', 'ext_absent', 'ext_not_regular', 'ext_owner',
                 'ext_perms', 'dir_owner', 'dir_perms', 'dir_group', 'abi_name',
                 'abi_macho', 'machine_unsupported', 'tk_probe_error'})
        if (getattr(exc, 'name', None) == '_tkinter'
                and tk_reason != 'ok' and tk_reason in _tkwords):
            _suffix = ' (tk-extension: ' + tk_reason + ')'
        print('REFUSED - GUI start failure: '
              + _sanitize_modname(type(exc).__name__) + ' '
              + _sanitize_modname(getattr(exc, 'name', None) or '') + _suffix)
        return EXIT_GUI_START
    try:
        n2 = _viewer.verify_package(pkg_dir)
    except _viewer.IntegrityError as exc:
        print('REFUSED - package integrity: ' + str(exc))
        return EXIT_PACKAGE_INTEGRITY
    _ = n2

    # 12. Snapshot sys.modules IMMEDIATELY BEFORE run_gui (delta backstop).
    before_names = set(sys.modules)
    try:
        _viewer.run_gui(pkg_dir)
    except _RefusedImport as exc:
        print(REFUSE_IMPORT_TEMPLATE % exc.sanitized_name)
        return EXIT_OWN_REFUSAL
    except _viewer.IntegrityError as exc:
        print('REFUSED - ' + str(exc))
        return EXIT_VIEWER_INTEGRITY
    except BaseException as exc:
        # S8: GUI could not start (Tk init / run_gui raised a non-refusal,
        # non-integrity exception). Fixed line, CLASS word only, exit 6. NEVER
        # retry with relaxed settings.
        print('REFUSED - GUI start failure: ' + _sanitize_modname(type(exc).__name__))
        return EXIT_GUI_START

    # 13. Post-run deny check over ALL of sys.modules (deny wins; S7).
    present = [d for d in DENY_POSTCHECK if d in sys.modules]
    if present:
        print(REFUSE_IMPORT_TEMPLATE % _sanitize_modname(present[0]))
        return EXIT_OWN_REFUSAL

    # 14. Post-run delta: stdlib-or-product, deny wins (A1; backstop to S6).
    after_names = set(sys.modules)
    try:
        outside = newly_loaded_outside_rule(
            before_names, after_names, _PRODUCT_MODULES, stdlib_names, _is_denied)
    except _RefusedImport as exc:
        print(REFUSE_IMPORT_TEMPLATE % exc.sanitized_name)
        return EXIT_OWN_REFUSAL
    if outside:
        print(REFUSE_IMPORT_TEMPLATE % _sanitize_modname(outside[0]))
        return EXIT_OWN_REFUSAL

    return EXIT_CLEAN


# R3d-b: the macOS 'admin' group gid. MAC-ASSUMPTION: on macOS the 'admin'
# group is gid 80; this is NOT verified here. Group-write on a chain directory
# is tolerated ONLY when the directory's group is this gid (and its owner is
# the current user or root); every other group-write fails closed ('dir_group').
ADMIN_GID = 80


def homebrew_tk_extension(real_base_prefix, version3, cache_tag, machine,
                          euid, fs):
    """Pure (given ``fs``). Decide whether the separately installed Homebrew
    ``python-tk`` ``_tkinter`` extension module is present and trustworthy for
    THIS interpreter, and return ``(absolute_path_or_None, reason_word)``.

    This performs a narrowly scoped, read-only, exact-file location of ONE
    name (``_tkinter``) under a Homebrew layout. It never changes sys.path,
    never trusts libexec generally, imports nothing beyond os/sys/re, and
    fails CLOSED with a FIXED reason word at every step. ``fs`` is an injected
    object with realpath(p), lstat(p) (st_mode/st_uid/st_size) and
    read_head(p, n) -> bytes; production binds os.path.realpath / os.lstat /
    a read-only open().read(n); tests bind an in-memory fake.
    """
    import re as _re
    # (a) real_base_prefix must sit under a 'Cellar' component; the component
    #     right after 'Cellar' must be python@MAJOR.MINOR of this interpreter.
    try:
        major, minor, micro = int(version3[0]), int(version3[1]), int(version3[2])
    except Exception:
        return (None, 'not_homebrew')
    sep = os.sep
    parts = str(real_base_prefix).split(sep)
    if 'Cellar' not in parts:
        return (None, 'not_homebrew')
    ci = parts.index('Cellar')
    HB_parts = parts[:ci]                       # the path ABOVE 'Cellar'
    if not HB_parts:
        return (None, 'not_homebrew')
    if ci + 1 >= len(parts):
        return (None, 'not_homebrew')
    want_py = 'python@%d.%d' % (major, minor)
    if parts[ci + 1] != want_py:
        return (None, 'not_homebrew')
    HB = sep.join(HB_parts)
    tkname = 'python-tk@%d.%d' % (major, minor)
    # (b) K = realpath(HB/opt/<tkname>); its parent must be exactly
    #     HB/Cellar/<tkname> by component comparison; its leaf matches the
    #     MAJOR.MINOR.MICRO(_N)? version.
    opt_link = sep.join([HB, 'opt', tkname])
    try:
        K = fs.realpath(opt_link)
    except Exception:
        return (None, 'keg_absent')
    if not K:
        return (None, 'keg_absent')
    k_parts = str(K).split(sep)
    if len(k_parts) < 3:
        return (None, 'keg_location')
    want_parent = HB_parts + ['Cellar', tkname]
    if k_parts[:-1] != want_parent:
        return (None, 'keg_location')
    cellar_keg = sep.join(want_parent)
    leaf = k_parts[-1]
    if not _re.match(r'^%d\.%d\.%d(_[0-9]+)?$' % (major, minor, micro), leaf):
        return (None, 'keg_version')
    # (c) F = K/libexec/_tkinter.<cache_tag>-darwin.so ; exact, regular,
    #     sized, owned, not group/world writable; libexec + keg dirs likewise.
    D = sep.join([K, 'libexec'])
    fname = '_tkinter.' + str(cache_tag) + '-darwin.so'
    F = sep.join([D, fname])
    try:
        if fs.realpath(F) != F:
            return (None, 'ext_symlink')
    except Exception:
        return (None, 'ext_symlink')
    import stat as _stat
    try:
        st = fs.lstat(F)
    except Exception:
        return (None, 'ext_absent')
    if not _stat.S_ISREG(st.st_mode):
        return (None, 'ext_not_regular')
    if not (0 < st.st_size <= 64 * 1024 * 1024):
        return (None, 'ext_absent')
    if st.st_uid not in (euid, 0):
        return (None, 'ext_owner')
    if (st.st_mode & 0o022) != 0:
        return (None, 'ext_perms')
    # (c2) R3d-b: walk EVERY directory on F's canonical path, from D =
    #     dirname(F) up to and INCLUDING '/'. F was already proven equal to
    #     its own realpath, so no component is a symlink; we still lstat each
    #     entry and require S_ISDIR (an lstat'd symlink is NOT a directory).
    #     Per-directory rule (fail CLOSED, fixed reason word):
    #       owner st_uid in {euid, 0}            else 'dir_owner'
    #       world-write (& 0o002)                -> 'dir_perms' (sticky or not)
    #       group-write (& 0o020) allowed ONLY if st_gid == ADMIN_GID,
    #         otherwise (non-admin gid, or no st_gid) -> 'dir_group'
    #     The owner rule is checked BEFORE the group rule.
    f_parts = str(F).split(sep)
    chain = []
    for _i in range(len(f_parts) - 1, 0, -1):
        _d = sep.join(f_parts[:_i])
        chain.append(_d if _d else sep)
    for d in chain:
        try:
            ds = fs.lstat(d)
        except Exception:
            return (None, 'dir_owner')
        if not _stat.S_ISDIR(ds.st_mode):
            return (None, 'dir_owner')
        if ds.st_uid not in (euid, 0):
            return (None, 'dir_owner')
        if (ds.st_mode & 0o002) != 0:
            return (None, 'dir_perms')
        if (ds.st_mode & 0o020) != 0:
            if getattr(ds, 'st_gid', None) != ADMIN_GID:
                return (None, 'dir_group')
    # (d) ABI: cache_tag must be cpython-<MAJOR><MINOR>; the file must start
    #     with the 64-bit little-endian Mach-O magic and the cputype of the
    #     running machine.
    if str(cache_tag) != 'cpython-%d%d' % (major, minor):
        return (None, 'abi_name')
    cpu_for = {'arm64': 0x0100000C, 'x86_64': 0x01000007}
    if machine not in cpu_for:
        return (None, 'machine_unsupported')
    try:
        head = fs.read_head(F, 8)
    except Exception:
        return (None, 'abi_macho')
    if not isinstance(head, (bytes, bytearray)) or len(head) < 8:
        return (None, 'abi_macho')
    if bytes(head[:4]) != b'\xcf\xfa\xed\xfe':
        return (None, 'abi_macho')
    cputype = int.from_bytes(bytes(head[4:8]), 'little')
    if cputype != cpu_for[machine]:
        return (None, 'abi_macho')
    return (F, 'ok')


def _warm_closure():
    """Warm (import) the AST-derived stdlib closure from the trusted path. Each
    import passes through the armed origin finder. Raises _RefusedImport if the
    finder refuses any warmed name (fail closed)."""
    import importlib
    for nm in _WARM_TOPLEVEL:
        importlib.import_module(nm)
    for nm in _WARM_DOTTED:
        importlib.import_module(nm)


def main(argv=None):
    av = list(sys.argv if argv is None else argv)
    try:
        return _run(av)
    except Exception as exc:
        # R3d: sanitised catch-all for a start-up failure that escaped _run.
        # CLASS word only; no message, no path, no traceback. Do NOT catch
        # BaseException: KeyboardInterrupt / SystemExit must propagate.
        print('REFUSED - startup failure: '
              + _sanitize_modname(type(exc).__name__))
        return EXIT_GUI_START

# =========================================================================== #
# --self-test (addendum2). Offline, pure functions, stub-driven; no display, no
# macOS, no network. Every real-code check catches BaseException and records a
# FAILING check; any check that reads this file's own source prints NOT RUN when
# the source is unavailable (never a silent pass). Stub-driven checks are
# LABELLED. A BaseException in a check => a FAILING check.
# =========================================================================== #
def _read_own_source():
    """Return this file's source text, or None if unavailable (the replay
    sandbox strips __file__). Never raises."""
    try:
        path = os.path.abspath(__file__)
    except Exception:
        return None
    try:
        with open(path, 'r', encoding='utf-8') as fh:
            return fh.read()
    except Exception:
        return None


# A tiny mutable namespace used to fake a module / a spec. We do NOT use
# types.ModuleType because the specialist replay sandbox blocks `types`.
class _Ns:
    def __init__(self, **kw):
        for k, v in kw.items():
            setattr(self, k, v)


# Synthetic trusted roots and pkg dir (documentation-style absolute paths; no
# identity). POSIX separators; these never touch the real filesystem in the
# pure-function checks (classify_origin realpaths its origin input, but the
# inputs we pass are already absolute and symlink-free synthetic strings, so
# realpath is idempotent on them under the stub).
_T_STDLIB = '/opt/pyX/lib/python3.13'
_T_DYNLOAD = '/opt/pyX/lib/python3.13/lib-dynload'
_T_ROOTS = (_T_STDLIB, _T_DYNLOAD)
_T_PKG = '/opt/extract/aq-preview'
# A realistic stdlib-names stub (frozenset of str) incl. the deny-set names so
# the tests can prove DENY wins even though e.g. 'socket' IS classed stdlib.
_T_STDLIB_NAMES = frozenset({
    'os', 'sys', 'io', 'json', 're', 'hashlib', 'base64', 'pathlib', 'stat',
    'struct', 'subprocess', 'tempfile', 'threading', 'time', 'tkinter',
    'zipfile', 'argparse', 'ast', 'contextlib', 'platform', 'urllib',
    'ipaddress', 'glob', 'selectors', 'asyncio', 'socketserver', 'signal',
    'sqlite3', 'shutil', 'enum', 'collections', 'functools',
    # deny-set names that ARE standard library (prove deny wins):
    'socket', 'ssl', 'http', 'ftplib', 'smtplib', 'telnetlib', 'poplib',
    'imaplib', 'xmlrpc', 'ctypes',
    # private C-extension stdlib names CPython lists in stdlib_module_names:
    '_hashlib', '_json', '_struct', '_io', '_socket', '_ssl',
})
_T_BUILTINS = ('sys', 'builtins', '_imp', 'marshal', 'posix', '_thread')


def _co(name, origin, loader='SourceFileLoader', ssl_=None, has_spec=True,
        pkg=_T_PKG):
    """Convenience: run classify_origin with the synthetic trusted roots/stdlib
    names/builtins and the given pkg_dir_real. Returns (ok, reason)."""
    return classify_origin(name, origin, loader, ssl_, has_spec, _T_ROOTS,
                           pkg, _PRODUCT_MODULES, _T_STDLIB_NAMES, _T_BUILTINS)


def run_self_test(_own_source=None):
    checks = 0
    failed = []
    skipped = []

    def ok(cond, label):
        nonlocal checks
        checks += 1
        try:
            if not cond:
                failed.append(label)
        except BaseException:
            failed.append(label + ' (raised)')

    def ok_call(fn, label):
        nonlocal checks
        checks += 1
        try:
            if not fn():
                failed.append(label)
        except BaseException as exc:
            failed.append('%s (raised %s)' % (label, type(exc).__name__))

    def skip(label):
        skipped.append(label)

    # ----- argv exact-match table (I9) -----
    ok(argv_ok([]) is True, 'argv-empty-ok')
    ok(argv_ok(['--self-test']) is True, 'argv-selftest-ok')
    for bad in (['--self-tes'], ['--self-test=1'], ['-h'], ['--help'],
                ['--Self-Test'], ['--SELF-TEST'], ['foo'], ['--self-test', 'x'],
                ['--self-test', '--self-test'], ['']):
        ok(argv_ok(bad) is False, 'argv-refuse:' + (bad[0] if bad else 'empty'))

    # ----- interpreter/platform refusals (now requires isolated, M1/R3-K7) ----
    class _F:
        def __init__(self, iso, s, b):
            self.isolated = iso
            self.no_site = s
            self.dont_write_bytecode = b
    ok(interpreter_ok('darwin', _F(1, 1, 1), lambda: 501)[0] is True,
       'interp-ok-darwin-I-S-B-nonroot')
    ok(interpreter_ok('darwin', _F(0, 1, 1), lambda: 501) == (False, 'missing-I-isolated'),
       'interp-refuse-no-I-isolated')
    ok(interpreter_ok('linux', _F(1, 1, 1), lambda: 501)[0] is False,
       'interp-refuse-non-darwin')
    ok(interpreter_ok('darwin', _F(1, 0, 1), lambda: 501)[0] is False,
       'interp-refuse-no-S')
    ok(interpreter_ok('darwin', _F(1, 1, 0), lambda: 501)[0] is False,
       'interp-refuse-no-B')
    ok(interpreter_ok('darwin', _F(1, 1, 1), lambda: 0)[0] is False,
       'interp-refuse-root')

    # ----- C-8 PYTHON* env refusal (R3-K10) -----
    ok(any_python_env_set(['PATH', 'HOME']) is False, 'env-no-python-clean')
    ok(any_python_env_set(['PATH', 'PYTHONPATH']) is True, 'env-pythonpath-refuses')
    ok(any_python_env_set(['PYTHONSTARTUP']) is True, 'env-pythonstartup-refuses')
    ok(any_python_env_set(['PYTHONHOME']) is True, 'env-pythonhome-refuses')

    # ----- path hygiene scrub (M2/C-1) -----
    def _scrub():
        sd = '/opt/extract/aq-preview'
        cw = '/opt/work'
        res = scrub_sys_path(['', '.', sd, cw, _T_STDLIB], sd, cw)
        return res == [_T_STDLIB]
    ok_call(_scrub, 'path-hygiene-scrubs-dot-empty-scriptdir-cwd')

    # ----- trusted roots derivation (R3-K31 sequencing is proven in _run order;
    #       here prove the pure derivation + separator-aware prefix test) -----
    def _roots_derivation():
        # synthetic os.__file__ in a stdlib dir; expect that dir + lib-dynload.
        of = '/opt/pyX/lib/python3.13/os.py'
        roots = compute_trusted_roots(of, '/opt/pyX', '/opt/pyX')
        return (_T_STDLIB in roots and _T_DYNLOAD in roots)
    ok_call(_roots_derivation, 'trusted-roots-derivation-stdlib+dynload')

    # R3-K21: separator-aware prefix (string prefix is NOT enough).
    ok(_sep_aware_under('/usr/lib/python3.13/json.py', '/usr/lib/python3.13') is True,
       'sep-aware-under-true')
    ok(_sep_aware_under('/usr/lib/python3.13-evil/x.py', '/usr/lib/python3.13') is False,
       'sep-aware-reject-string-prefix (R3-K21)')
    ok(_sep_aware_under('/usr/lib/python3.13', '/usr/lib/python3.13') is True,
       'sep-aware-equal-true')

    # ===================================================================== #
    # ORIGIN classification (the heart of R3). All drive the REAL
    # classify_origin via _co(); stub inputs only (no FS, no import).
    # ===================================================================== #
    # (a) legitimate stdlib with a trusted origin passes.
    ok(_co('json', _T_STDLIB + '/json/__init__.py')[0] is True, 'origin-stdlib-trusted-pass')
    ok(_co('ipaddress', _T_STDLIB + '/ipaddress.py')[0] is True, 'origin-ipaddress-trusted-pass (T-D)')
    ok(_co('glob', _T_STDLIB + '/glob.py')[0] is True, 'origin-glob-trusted-pass (A5)')
    ok(_co('tkinter.ttk', _T_STDLIB + '/tkinter/ttk.py')[0] is True, 'origin-tkinter-sub-trusted-pass (S5)')
    # C-extension stdlib from lib-dynload via ExtensionFileLoader.
    ok(_co('_hashlib', _T_DYNLOAD + '/_hashlib.cpython-313-x.so',
           loader='ExtensionFileLoader')[0] is True, 'origin-cext-dynload-pass')

    # (b) each DENY name is refused (the finder handles deny BEFORE
    #     classify_origin; here prove _is_denied catches them even though they
    #     ARE in the stub stdlib-names set -> deny wins, S7/R3-K30).
    for dn in ('socket', '_socket', 'ssl', '_ssl', 'http', 'urllib.request',
               'urllib.error', 'paramiko', 'botocore', 'boto3', 'mcp',
               'requests', 'ftplib', 'smtplib', 'telnetlib', 'poplib',
               'imaplib', 'xmlrpc', 'ctypes'):
        ok(_is_denied(dn) is True, 'deny-' + _sanitize_modname(dn))
    ok(_is_denied('socket.foo') is True, 'deny-socket-submodule (S5)')
    ok(('socket' in _T_STDLIB_NAMES and _is_denied('socket')), 'deny-wins-over-stdlib (R3-K30)')
    ok(not _is_denied('urllib') and not _is_denied('urllib.parse'), 'urllib-parse-not-denied')

    # (c) SHADOWED stdlib: a file NAMED like a stdlib module but located INSIDE
    #     the package folder is refused by origin (R3-K22), even though its name
    #     is on the stdlib list.
    ok(_co('json', _T_PKG + '/json.py') == (False, 'shadowed_stdlib'),
       'origin-shadowed-json-in-pkg-refused (R3-K22)')
    ok(_co('hashlib', _T_PKG + '/hashlib.py') == (False, 'shadowed_stdlib'),
       'origin-shadowed-hashlib-in-pkg-refused')
    ok(_co('ipaddress', _T_PKG + '/ipaddress.py') == (False, 'shadowed_stdlib'),
       'origin-shadowed-ipaddress-in-pkg-refused')
    ok(_co('tkinter.ttk', _T_PKG + '/tkinter/ttk.py') == (False, 'shadowed_stdlib'),
       'origin-shadowed-dotted-submodule-in-pkg-refused (R3-K27)')
    # stdlib-NAMED module found in a NON-trusted location (site-packages) -> refused (R3-K23).
    ok(_co('json', '/opt/pyX/lib/python3.13/site-packages/json.py')
       == (False, 'untrusted_origin'),
       'origin-stdlib-in-site-packages-refused (R3-K23)')
    ok(_co('json', '/home/fakeuser/.local/lib/python3.13/site-packages/json.py')
       == (False, 'untrusted_origin'),
       'origin-stdlib-in-usersite-refused')
    # user-site ('.local') nested UNDER the trusted stdlib root is STILL refused
    # (brief 3b: a stdlib-named file under a user-site dir that is itself under
    # the stdlib root must be refused even though it is under the stdlib root).
    ok(_co('hashlib', _T_STDLIB + '/.local/lib/python3.13/hashlib.py')
       == (False, 'untrusted_origin'),
       'origin-stdlib-in-usersite-under-stdlib-root-refused (R3-K23, brief-3b)')

    # (d) malformed / ambiguous origins each refuse (S3 -> exit 2).
    ok(_co('x', None) == (False, 'origin_ambiguous'), 'origin-none-refused (R3-K24)')
    ok(_co('x', '') == (False, 'origin_ambiguous'), 'origin-empty-refused')
    ok(_co('x', 123) == (False, 'origin_ambiguous'), 'origin-nonstr-refused')
    ok(_co('x', 'relative/path.py') == (False, 'origin_relative'), 'origin-relative-refused')
    ok(classify_origin('ns', None, 'SourceFileLoader', ['/a/b'], True, _T_ROOTS,
                       _T_PKG, _PRODUCT_MODULES, _T_STDLIB_NAMES, _T_BUILTINS)
       == (False, 'origin_ambiguous'),
       'origin-namespace-no-origin-refused (R3-K24)')
    ok(classify_origin('x', _T_STDLIB + '/x.py', 'SourceFileLoader', None, False,
                       _T_ROOTS, _T_PKG, _PRODUCT_MODULES, _T_STDLIB_NAMES, _T_BUILTINS)
       == (False, 'no_spec'), 'origin-missing-spec-refused')
    ok(_co('x', _T_STDLIB + '/x.py', loader='WeirdLoader') == (False, 'unexpected_loader'),
       'origin-unexpected-loader-refused')
    ok(_co('x', '/opt/pyX/lib/python3.13.zip/x.py') == (False, 'zip_origin'),
       'origin-zip-refused')
    ok(_co('x', _T_STDLIB + '.zip') == (False, 'zip_origin'), 'origin-zip-suffix-refused')
    # A path that merely has the trusted root as a STRING prefix (sibling dir).
    ok(_co('json', '/opt/pyX/lib/python3.13-evil/json.py') == (False, 'untrusted_origin'),
       'origin-string-prefix-sibling-refused (R3-K21)')

    # (e) built-in / frozen (S2).
    ok(_co('sys', 'built-in', loader='BuiltinImporter')[0] is True, 'origin-builtin-accepted')
    ok(_co('notabuiltin', 'built-in', loader='BuiltinImporter') == (False, 'fake_builtin'),
       'origin-fake-builtin-refused (R3-K25)')
    ok(_co('_frozen_importlib', 'frozen', loader='FrozenImporter')[0] is True,
       'origin-frozen-accepted')
    ok(_co('evilfrozen', 'frozen', loader='FrozenImporter') == (False, 'fake_frozen'),
       'origin-fake-frozen-refused')

    # ===================================================================== #
    # R3c DEFECT FIX: class-vs-instance loader-name classification. T1-T5.
    # The genuine CPython BuiltinImporter/FrozenImporter spec.loader is the
    # IMPORTER CLASS ITSELF; the original source used type(loader).__name__ =>
    # 'type' => every real built-in/frozen module refused. These checks drive
    # the REAL _OriginFinder.find_spec and the REAL loader_class_name helper.
    # ===================================================================== #
    # R3c check-count floor sentinel (kills K6/K7 test-deletion mutants).
    _r3c_checks_before = checks
    # Obtain the genuine importer classes (function-level; always loaded).
    _R3C_BUILTIN = None
    _R3C_FROZEN = None
    try:
        import _frozen_importlib as _r3c_fi
        _R3C_BUILTIN = getattr(_r3c_fi, 'BuiltinImporter', None)
        _R3C_FROZEN = getattr(_r3c_fi, 'FrozenImporter', None)
    except BaseException:
        _R3C_BUILTIN = None
        _R3C_FROZEN = None
    _r3c_have_genuine = (_R3C_BUILTIN is not None and _R3C_FROZEN is not None)

    # Real sys.builtin_module_names / sys.stdlib_module_names if the sandbox
    # allows reading them; else a clearly-LABELLED stub set. On a real target
    # interpreter the real sets are used; the specialist replay sandbox blocks
    # both, so the LABELLED stub (superset containing the probed names) is used
    # and the label is recorded in the summary via a skip().
    _r3c_names_source = 'real'
    try:
        _r3c_builtin_names = tuple(sys.builtin_module_names)
    except BaseException:
        _r3c_builtin_names = ('sys', 'builtins', '_imp', 'time', 'itertools',
                              'errno', 'marshal', '_thread', '_io')
        _r3c_names_source = 'stub'
    try:
        _r3c_stdlib_names = frozenset(sys.stdlib_module_names)
    except BaseException:
        _r3c_stdlib_names = frozenset({
            'os', 'io', 'codecs', 'zipimport', 'abc', 'stat', 'posixpath',
            'importlib', 'runpy', 'sys', 'time', 'errno', 'itertools',
            'builtins', '_imp'})
        _r3c_names_source = 'stub'
    if _r3c_names_source == 'stub':
        skip('R3c T1 uses LABELLED STUB builtin/stdlib name sets (sandbox blocks '
             'sys.builtin_module_names and sys.stdlib_module_names); on a real '
             'interpreter the SAME test uses the real sets')

    def _r3c_make_real_finder(pkg_real):
        """Build the REAL _OriginFinder with the genuine importer classes in
        meta_path and the real/stub name sets; force the loaded-shortcut off."""
        holder = [pkg_real]
        mp = [_R3C_BUILTIN, _R3C_FROZEN]
        f = _OriginFinder(_T_ROOTS, holder, _PRODUCT_MODULES,
                          _r3c_stdlib_names, _r3c_builtin_names, meta_path=mp)
        f._loaded = set()
        return f

    def _r3c_probe_builtin(name):
        """True iff name genuinely resolves as a built-in on THIS interpreter."""
        try:
            sp = _R3C_BUILTIN.find_spec(name, None, None)
            return sp is not None and getattr(sp, 'origin', None) == 'built-in'
        except BaseException:
            return False

    def _r3c_probe_frozen(name):
        try:
            sp = _R3C_FROZEN.find_spec(name, None, None)
            return sp is not None and getattr(sp, 'origin', None) == 'frozen'
        except BaseException:
            return False

    # ---- T4: the helper on instances and None (unchanged behaviour). ----
    ok(loader_class_name(None) == '', 'r3c-T4-helper-None-empty')
    ok(loader_class_name(_SourceLoaderStub()) == 'SourceFileLoader',
       'r3c-T4-helper-source-instance-name')
    class _ExtLoaderStub:
        pass
    _ExtLoaderStub.__name__ = 'ExtensionFileLoader'
    ok(loader_class_name(_ExtLoaderStub()) == 'ExtensionFileLoader',
       'r3c-T4-helper-ext-instance-name')
    # K3 kill: an INSTANCE carrying its OWN .__name__ that DIFFERS from its
    # type name. The helper must use type(loader).__name__ (NOT loader.__name__)
    # for instances, so a K3 mutant that returns loader.__name__ is caught.
    class _SrcWithOwnName:
        pass
    _SrcWithOwnName.__name__ = 'SourceFileLoader'
    _inst_divergent = _SrcWithOwnName()
    _inst_divergent.__name__ = 'DECOY_NOT_A_LOADER'
    ok(loader_class_name(_inst_divergent) == 'SourceFileLoader',
       'r3c-T4-instance-uses-type-name-not-own-name (K3)')

    # ---- T3(a)/(d): helper fail-closed on classes. ----
    # (a) counterfeit CLASS with the right __name__ but not identity -> 'type'.
    class _CounterfeitBuiltin:
        pass
    _CounterfeitBuiltin.__name__ = 'BuiltinImporter'
    class _CounterfeitFrozen:
        pass
    _CounterfeitFrozen.__name__ = 'FrozenImporter'
    if _r3c_have_genuine:
        ok(loader_class_name(_CounterfeitBuiltin,
                             genuine=(_R3C_BUILTIN, _R3C_FROZEN)) == 'type',
           'r3c-T3a-counterfeit-builtin-class-yields-type (K2)')
        ok(loader_class_name(_CounterfeitFrozen,
                             genuine=(_R3C_BUILTIN, _R3C_FROZEN)) == 'type',
           'r3c-T3a-counterfeit-frozen-class-yields-type (K2)')
        # genuine classes return their own names.
        ok(loader_class_name(_R3C_BUILTIN,
                             genuine=(_R3C_BUILTIN, _R3C_FROZEN)) == 'BuiltinImporter',
           'r3c-helper-genuine-builtin-name')
        ok(loader_class_name(_R3C_FROZEN,
                             genuine=(_R3C_BUILTIN, _R3C_FROZEN)) == 'FrozenImporter',
           'r3c-helper-genuine-frozen-name')
    else:
        skip('r3c helper genuine-class checks (NOT RUN: _frozen_importlib classes '
             'unavailable on this interpreter)')
    # (d) genuine classes absent/None (injected) -> class yields 'type' (fail closed).
    ok(loader_class_name(_CounterfeitBuiltin, genuine=(None, None)) == 'type',
       'r3c-T3d-helper-none-genuine-fail-closed (K4)')
    if _r3c_have_genuine:
        ok(loader_class_name(_R3C_BUILTIN, genuine=(None, None)) == 'type',
           'r3c-T3d-genuine-builtin-with-none-injected-fail-closed (K4)')

    # ---- T1: REGRESSION - real CPython specs through the REAL find_spec. ----
    if _r3c_have_genuine:
        _r3c_builtin_probe = [n for n in ('sys', 'builtins', '_imp', 'time',
                                          'itertools', 'errno')
                              if _r3c_probe_builtin(n)]
        _r3c_frozen_probe = [n for n in ('os', 'io', 'codecs', 'zipimport',
                                         'abc', 'stat', 'posixpath',
                                         'importlib.util', 'importlib.machinery',
                                         'runpy')
                             if _r3c_probe_frozen(n)]
        def _r3c_t1_builtins_accept():
            f = _r3c_make_real_finder(_T_PKG)
            for nm in _r3c_builtin_probe:
                # builtin names must be in the name set used by classify_origin
                # on a real interp (real builtin_module_names); in the stub run
                # we inject them. Guard: only assert when the name is present.
                if nm not in f._builtins:
                    continue
                if f.find_spec(nm) is not None:
                    return False
            return len(_r3c_builtin_probe) >= 1
        ok_call(_r3c_t1_builtins_accept,
                'r3c-T1-real-builtin-specs-ACCEPTED-through-find_spec (K1/K5)')
        def _r3c_t1_frozen_accept():
            f = _r3c_make_real_finder(_T_PKG)
            for nm in _r3c_frozen_probe:
                top = nm.split('.', 1)[0]
                if not (nm in f._stdlib or top in f._stdlib
                        or nm.startswith('importlib')):
                    continue
                if f.find_spec(nm) is not None:
                    return False
            return len(_r3c_frozen_probe) >= 1
        ok_call(_r3c_t1_frozen_accept,
                'r3c-T1-real-frozen-specs-ACCEPTED-through-find_spec (K1/K5/K6)')
    else:
        skip('r3c-T1 real-spec regression (NOT RUN: _frozen_importlib classes '
             'unavailable)')

    # ---- T3(b): genuine BuiltinImporter but a name NOT in builtin_module_names
    #      -> refused (fake_builtin) via classify_origin. Drive the helper +
    #      classify_origin directly with a genuine class loader. ----
    if _r3c_have_genuine:
        def _r3c_t3b_builtin_name_not_listed():
            cn = loader_class_name(_R3C_BUILTIN, genuine=(_R3C_BUILTIN, _R3C_FROZEN))
            # cn == 'BuiltinImporter'; name 'notabuiltin' not in builtin set.
            return classify_origin('notabuiltin', 'built-in', cn, None, True,
                                   _T_ROOTS, _T_PKG, _PRODUCT_MODULES,
                                   _r3c_stdlib_names, ('sys', 'builtins')) \
                == (False, 'fake_builtin')
        ok_call(_r3c_t3b_builtin_name_not_listed,
                'r3c-T3b-genuine-builtin-unlisted-name-refused')
        # (e) FrozenImporter with a name outside stdlib/importlib -> refused.
        def _r3c_t3e_frozen_outside_stdlib():
            cn = loader_class_name(_R3C_FROZEN, genuine=(_R3C_BUILTIN, _R3C_FROZEN))
            return classify_origin('evilfrozen', 'frozen', cn, None, True,
                                   _T_ROOTS, _T_PKG, _PRODUCT_MODULES,
                                   frozenset({'os'}), ('sys',)) \
                == (False, 'fake_frozen')
        ok_call(_r3c_t3e_frozen_outside_stdlib,
                'r3c-T3e-genuine-frozen-nonstdlib-name-refused')
        # (c) genuine classes presented with a PATH origin -> refused as today
        #     (origin is not 'built-in'/'frozen'; loader-name 'BuiltinImporter'
        #     is not an _OK path loader -> unexpected_loader).
        def _r3c_t3c_genuine_class_path_origin():
            cn = loader_class_name(_R3C_BUILTIN, genuine=(_R3C_BUILTIN, _R3C_FROZEN))
            return classify_origin('x', _T_STDLIB + '/x.py', cn, None, True,
                                   _T_ROOTS, _T_PKG, _PRODUCT_MODULES,
                                   _r3c_stdlib_names, ('sys',)) \
                == (False, 'unexpected_loader')
        ok_call(_r3c_t3c_genuine_class_path_origin,
                'r3c-T3c-genuine-class-with-path-origin-refused')
    else:
        skip('r3c-T3 b/c/e genuine-class classify checks (NOT RUN: classes '
             'unavailable)')

    # ---- T3(a) end-to-end through find_spec: a counterfeit CLASS named
    #      BuiltinImporter/FrozenImporter as spec.loader with a built-in/frozen
    #      origin must be REFUSED (fake_builtin/fake_frozen). ----
    def _r3c_t3a_counterfeit_builtin_refused():
        spec = _Ns(origin='built-in', loader=_CounterfeitBuiltin,
                   submodule_search_locations=None)
        class _CF:
            def find_spec(self, fullname, path=None, target=None):
                return spec if fullname == 'ctrbuiltin' else None
        _cf = _CF()
        f = _OriginFinder(_T_ROOTS, [_T_PKG], _PRODUCT_MODULES,
                          _r3c_stdlib_names, ('ctrbuiltin',), meta_path=[_cf])
        f._loaded = set()
        try:
            f.find_spec('ctrbuiltin')
            return False
        except _RefusedImport as e:
            return e.sanitized_name == 'fake_builtin'
    ok_call(_r3c_t3a_counterfeit_builtin_refused,
            'r3c-T3a-counterfeit-builtin-class-through-finder-refused (K2/K7)')
    def _r3c_t3a_counterfeit_frozen_refused():
        spec = _Ns(origin='frozen', loader=_CounterfeitFrozen,
                   submodule_search_locations=None)
        class _CF:
            def find_spec(self, fullname, path=None, target=None):
                return spec if fullname == 'ctrfrozen' else None
        _cf = _CF()
        f = _OriginFinder(_T_ROOTS, [_T_PKG], _PRODUCT_MODULES,
                          frozenset({'ctrfrozen'}), ('sys',), meta_path=[_cf])
        f._loaded = set()
        try:
            f.find_spec('ctrfrozen')
            return False
        except _RefusedImport as e:
            return e.sanitized_name == 'fake_frozen'
    ok_call(_r3c_t3a_counterfeit_frozen_refused,
            'r3c-T3a-counterfeit-frozen-class-through-finder-refused (K2/K6/K7)')

    # (f) existing pure-function string cases still behave identically: a
    #     'BuiltinImporter'/'FrozenImporter' STRING loader name (as the old
    #     stub tests pass) is still accepted by classify_origin for a genuine
    #     name -> proven by the unchanged (e) checks above; assert again here.
    ok(_co('sys', 'built-in', loader='BuiltinImporter')[0] is True,
       'r3c-T3f-string-builtin-name-still-accepted')
    ok(_co('_frozen_importlib', 'frozen', loader='FrozenImporter')[0] is True,
       'r3c-T3f-string-frozen-name-still-accepted')
    # K6/K7 kill: when the genuine importer classes are available (the normal
    # case on a real interpreter), the R3c block must contribute at least 19
    # checks (including this one). Deleting the frozen test (K6) or the
    # counterfeit-class test (K7) drops the delta to 18 and trips this floor.
    # Gated on _r3c_have_genuine so an interpreter that cannot expose the
    # classes (which legitimately skips several r3c checks) does not false-fail.
    if _r3c_have_genuine:
        ok((checks - _r3c_checks_before) >= 19,
           'r3c-check-count-floor (K6/K7 test-deletion guard)')
    else:
        skip('r3c-check-count-floor (NOT RUN: genuine importer classes '
             'unavailable; floor gated off)')

    # (f) PRODUCT modules (S4): accepted only when realpath==pkg_dir/<name>.py
    #     AND verification succeeded; refused before verification; a product-
    #     named file not among the six refused; a non-product file under pkg
    #     refused.
    ok(_co('wizard', _T_PKG + '/wizard.py')[0] is True, 'origin-product-wizard-accepted')
    ok(_co('model', _T_PKG + '/model.py')[0] is True, 'origin-product-model-accepted')
    # product name but WRONG path (outside pkg) -> product_path_mismatch.
    ok(_co('wizard', _T_STDLIB + '/wizard.py') == (False, 'product_path_mismatch'),
       'origin-product-wrong-path-refused')
    # product accepted ONLY after verification: pkg_dir_real=None -> refuse (R3-K26).
    ok(classify_origin('wizard', _T_PKG + '/wizard.py', 'SourceFileLoader', None,
                       True, _T_ROOTS, None, _PRODUCT_MODULES, _T_STDLIB_NAMES,
                       _T_BUILTINS) == (False, 'product_unverified'),
       'origin-product-before-verify-refused (R3-K26)')
    # a product-NAMED file not among the six, located in pkg -> package_local.
    ok(_co('notaproduct', _T_PKG + '/notaproduct.py') == (False, 'package_local'),
       'origin-nonsix-under-pkg-refused')

    # (g) third-party / unknown name from a non-trusted, non-pkg path -> refused.
    ok(_co('fakeunexpectedmod', '/opt/site/fakeunexpectedmod.py')
       == (False, 'not_stdlib_not_product'),
       'origin-thirdparty-refused')

    # (h) missing stdlib_module_names -> fail closed (A1/R3-K13).
    ok(classify_origin('json', _T_STDLIB + '/json.py', 'SourceFileLoader', None,
                       True, _T_ROOTS, _T_PKG, _PRODUCT_MODULES, None, _T_BUILTINS)
       == (False, 'no_stdlib_names'),
       'origin-missing-stdlib-names-fail-closed (R3-K13)')

    # ===================================================================== #
    # The ORIGIN FINDER drives classify_origin pre-exec. Stub-driven: we fake
    # sys.meta_path finders returning synthetic specs; nothing is imported.
    # ===================================================================== #
    # Inject an explicit finder list + loaded set so the finder is driven WITHOUT
    # touching sys.meta_path / sys.modules (both blocked in the replay sandbox).
    def _make_finder(pkg_real, extra_finders=None, loaded=None):
        holder = [pkg_real]
        mp = []
        f = _OriginFinder(_T_ROOTS, holder, _PRODUCT_MODULES, _T_STDLIB_NAMES,
                          _T_BUILTINS, meta_path=mp)
        f._loaded = set() if loaded is None else set(loaded)
        mp.append(f)
        if extra_finders:
            mp.extend(extra_finders)
        return f, holder

    def _fake_meta(specmap):
        """A stub finder returning the spec for a name from specmap."""
        class _FakeFinder:
            def find_spec(self, fullname, path=None, target=None):
                return specmap.get(fullname)
        return _FakeFinder()

    # (i) finder: DENY is raised FIRST, before any spec lookup (R3-K30).
    def _finder_deny_first():
        f, _ = _make_finder(_T_PKG)
        try:
            f.find_spec('socket')
            return False
        except _RefusedImport as e:
            return e.sanitized_name == 'socket'
    ok_call(_finder_deny_first, 'finder-deny-raised-first (injected, R3-K30)')

    # (j) finder: a shadowed stdlib spec (origin under pkg) is REFUSED pre-exec.
    def _finder_shadow_refused():
        spec = _Ns(origin=_T_PKG + '/json.py', loader=_SourceLoaderStub(),
                   submodule_search_locations=None)
        f, _ = _make_finder(_T_PKG, extra_finders=[_fake_meta({'json': spec})])
        try:
            f.find_spec('json')
            return False
        except _RefusedImport as e:
            return e.sanitized_name == 'shadowed_stdlib'
    ok_call(_finder_shadow_refused, 'finder-shadowed-stdlib-refused-pre-exec (injected, S6)')

    # (k) finder: a legitimate stdlib spec (trusted origin) is ACCEPTED (returns
    #     None so normal machinery loads it).
    def _finder_stdlib_defers():
        spec = _Ns(origin=_T_STDLIB + '/json/__init__.py', loader=_SourceLoaderStub(),
                   submodule_search_locations=None)
        f, _ = _make_finder(_T_PKG, extra_finders=[_fake_meta({'json': spec})])
        return f.find_spec('json') is None
    ok_call(_finder_stdlib_defers, 'finder-stdlib-trusted-defers (injected)')

    # (l) finder: product before verify refused; after verify accepted (R3-K26).
    def _finder_product_gate():
        spec = _Ns(origin=_T_PKG + '/wizard.py', loader=_SourceLoaderStub(),
                   submodule_search_locations=None)
        f, holder = _make_finder(None, extra_finders=[_fake_meta({'wizard': spec})])
        try:
            f.find_spec('wizard')
            before = False
        except _RefusedImport as e:
            before = (e.sanitized_name == 'product_unverified')
        holder[0] = _T_PKG  # verification now succeeded
        after = (f.find_spec('wizard') is None)
        return before and after
    ok_call(_finder_product_gate, 'finder-product-gated-by-verification (injected, R3-K26)')

    # ===================================================================== #
    # trusted_verify via a stub hashlib + a synthetic in-memory fixture. The
    # replay sandbox blocks os.open/scandir on real dirs we cannot create here;
    # we drive parse_manifest_bytes (pure) directly for the manifest-malformation
    # kill rows and LABEL the scandir path NOT RUN when a real dir is absent.
    # ===================================================================== #
    _hex = 'a' * 64
    _good_header = (MANIFEST_LINE1 + '\n'
                    + '# identity-scan: SCANNED (private terms: 2)\n'
                    + MANIFEST_LINE3 + '\n')

    def _man(body_lines):
        return (_good_header + ''.join(body_lines)).encode('utf-8')

    # a well-formed manifest (two sorted entries) parses.
    ok_call(lambda: set(parse_manifest_bytes(
        _man([_hex + '  a.py\n', _hex + '  b.py\n']))) == {'a.py', 'b.py'},
        'manifest-wellformed-parses')
    # malformations each refuse:
    ok_call(lambda: _refuses_pkg(lambda: parse_manifest_bytes(
        b'\xef\xbb\xbf' + _man([_hex + '  a.py\n']))), 'manifest-BOM-refused')
    ok_call(lambda: _refuses_pkg(lambda: parse_manifest_bytes(
        _man([_hex + '  a.py\n']).replace(b'a.py', b'a\x00py'))), 'manifest-NUL-refused')
    ok_call(lambda: _refuses_pkg(lambda: parse_manifest_bytes(
        _man([_hex + '  a.py\n', '# sneaky extra comment\n']))),
        'manifest-extra-comment-in-body-refused (R3-K2)')
    ok_call(lambda: _refuses_pkg(lambda: parse_manifest_bytes(
        _man([_hex + '  a.py\n']).replace(b'\n', b'\r\n'))), 'manifest-CRLF-refused')
    ok_call(lambda: _refuses_pkg(lambda: parse_manifest_bytes(
        ('WRONGLINE1\n# identity-scan: SCANNED (private terms: 1)\n' + MANIFEST_LINE3
         + '\n' + _hex + '  a.py\n').encode())), 'manifest-wrong-line1-refused')
    ok_call(lambda: _refuses_pkg(lambda: parse_manifest_bytes(
        ('# almost right but not the literal\n# identity-scan: SCANNED (private terms: 1)\n'
         + MANIFEST_LINE3 + '\n' + _hex + '  a.py\n').encode())),
        'manifest-line1-hash-but-wrong-literal-refused (R3-K6)')
    ok_call(lambda: _refuses_pkg(lambda: parse_manifest_bytes(
        (MANIFEST_LINE1 + '\n# identity-scan: BAD\n' + MANIFEST_LINE3 + '\n'
         + _hex + '  a.py\n').encode())), 'manifest-wrong-line2-refused')
    ok_call(lambda: _refuses_pkg(lambda: parse_manifest_bytes(
        (MANIFEST_LINE1 + '\n# identity-scan: SCANNED (private terms: 1)\n# WRONG\n'
         + _hex + '  a.py\n').encode())), 'manifest-wrong-line3-refused')
    ok_call(lambda: _refuses_pkg(lambda: parse_manifest_bytes(
        _man([('A' * 64) + '  a.py\n']))), 'manifest-uppercase-hex-refused')
    ok_call(lambda: _refuses_pkg(lambda: parse_manifest_bytes(
        _man([_hex + '  ../a.py\n']))), 'manifest-traversal-refused')
    ok_call(lambda: _refuses_pkg(lambda: parse_manifest_bytes(
        _man([_hex + '  a.py\n', _hex + '  a.py\n']))), 'manifest-duplicate-refused')
    ok_call(lambda: _refuses_pkg(lambda: parse_manifest_bytes(
        _man([_hex + '  b.py\n', _hex + '  a.py\n']))), 'manifest-unsorted-refused')
    ok_call(lambda: _refuses_pkg(lambda: parse_manifest_bytes(_man([]))),
            'manifest-empty-body-refused')

    # scandir exact-ten path: NOT RUN without a real dir (sandbox).
    skip('trusted_verify-scandir-exact-ten + symlink/hidden/subdir/extra refuse '
         '(NOT RUN: needs a real package dir; run --self-test from the verified '
         'package dir on the target Mac). Covered by paper table in the report.')

    # ===================================================================== #
    # Post-run delta: stdlib-or-product, deny wins (A1). Drives the REAL helper.
    # ===================================================================== #
    _BEFORE = ['builtins', 'posix', 'zipimport', 'sys', 'os', 'io', 'abc',
               'stat', 'codecs', 'encodings', 'posixpath', 'time', 'marshal',
               '_frozen_importlib', 'preview_viewer', 'subprocess', 'tempfile',
               'sqlite3', 'shutil', 'hashlib']
    _AFTER_CLEAN = _BEFORE + [
        'wizard', 'model', 'quick_reg', 'deploy_lib', 'native_gateway',
        'bootstrap_lib', 'tkinter', 'tkinter.ttk', 'tkinter.messagebox',
        'tkinter.filedialog', 'json', 'urllib', 'urllib.parse', 'base64',
        'pathlib', 're', 'platform', 'struct', 'contextlib', 'argparse', 'ast',
        'enum', 'collections', 'functools', 'ipaddress', 'glob']

    # T-D: ipaddress + glob now CLEAN (allowed by the stdlib rule).
    ok_call(lambda: newly_loaded_outside_rule(
        _BEFORE, _AFTER_CLEAN, _PRODUCT_MODULES, _T_STDLIB_NAMES, _is_denied) == [],
        'delta-clean-run-ipaddress-glob-allowed (T-A/T-D/A5)')
    # a third-party name loaded late is reported.
    ok_call(lambda: newly_loaded_outside_rule(
        _BEFORE, _AFTER_CLEAN + ['fakeunexpectedmod'], _PRODUCT_MODULES,
        _T_STDLIB_NAMES, _is_denied) == ['fakeunexpectedmod'],
        'delta-thirdparty-reported')
    # T-B(i): a denied name loaded BEFORE the snapshot still gives exit 2 via the
    # deny post-check; drive the REAL post-run deny branch logic.
    def _tb_deny_in_before():
        all_mods = set(_BEFORE) | {'socket'}
        present = [d for d in DENY_POSTCHECK if d in all_mods]
        rc = EXIT_CLEAN
        line = None
        if present:
            line = REFUSE_IMPORT_TEMPLATE % _sanitize_modname(present[0])
            rc = EXIT_OWN_REFUSAL
        # and the delta (socket in before) would NOT itself catch it:
        delta = newly_loaded_outside_rule(all_mods, all_mods, _PRODUCT_MODULES,
                                          _T_STDLIB_NAMES, _is_denied)
        return (rc == 2 and line == 'REFUSED - unexpected import blocked: socket'
                and delta == [])
    ok_call(_tb_deny_in_before, 'delta-deny-in-before-still-exit2 (T-B-i, R3-K14)')
    # T-B(i) continued: a denied name appearing in the DELTA is caught by the
    # delta too (deny wins over stdlib in the delta path; R3-K12/K30).
    ok_call(lambda: newly_loaded_outside_rule(
        _BEFORE, _BEFORE + ['ssl'], _PRODUCT_MODULES, _T_STDLIB_NAMES, _is_denied)
        == ['ssl'], 'delta-deny-in-delta-wins-over-stdlib (R3-K12/K30)')
    # T-B(ii): the delta failure RETURNS the real rc 2 from the _run branch, not
    # a constant compare. Drive the actual branch shape with recording stubs.
    def _tb_delta_returns_2():
        before = set(_BEFORE)
        after = set(_AFTER_CLEAN) | {'fakeunexpectedmod'}
        outside = newly_loaded_outside_rule(before, after, _PRODUCT_MODULES,
                                            _T_STDLIB_NAMES, _is_denied)
        rc = EXIT_CLEAN
        lines = []
        if outside:
            lines.append(REFUSE_IMPORT_TEMPLATE % _sanitize_modname(outside[0]))
            rc = EXIT_OWN_REFUSAL
        return rc == 2 and lines == ['REFUSED - unexpected import blocked: fakeunexpectedmod']
    ok_call(_tb_delta_returns_2, 'delta-failure-returns-rc2-not-constant (T-B-ii, R3-K15)')
    # R3-K13 in the delta: missing stdlib_module_names -> fail closed (exit 2).
    def _delta_fail_closed():
        try:
            newly_loaded_outside_rule(_BEFORE, _AFTER_CLEAN + ['z'],
                                      _PRODUCT_MODULES, None, _is_denied)
            return False
        except _RefusedImport as e:
            return e.sanitized_name == 'no_stdlib_names'
    ok_call(_delta_fail_closed, 'delta-missing-stdlib-names-fail-closed (R3-K13)')
    # intrinsic names in before are never reported; _frozen*/_ skipped.
    ok_call(lambda: newly_loaded_outside_rule(
        _BEFORE, _AFTER_CLEAN, _PRODUCT_MODULES, _T_STDLIB_NAMES, _is_denied) == [],
        'delta-intrinsics-and-underscore-skipped')
    # a late unexpected name containing 'tk' is still reported (no substring skip).
    ok_call(lambda: 'faketkmod' in newly_loaded_outside_rule(
        _BEFORE, _AFTER_CLEAN + ['faketkmod'], _PRODUCT_MODULES, _T_STDLIB_NAMES,
        _is_denied), 'delta-no-tk-substring-skip')
    # offender routed through _sanitize_modname.
    def _delta_sanitize():
        off = newly_loaded_outside_rule(_BEFORE, _AFTER_CLEAN + ['fakeunexpectedmod'],
                                        _PRODUCT_MODULES, _T_STDLIB_NAMES, _is_denied)
        return (REFUSE_IMPORT_TEMPLATE % _sanitize_modname(off[0])
                == 'REFUSED - unexpected import blocked: fakeunexpectedmod')
    ok_call(_delta_sanitize, 'delta-offender-through-sanitize')

    # ----- DENY byte-identical to r2 (A2; R3-K18) -----
    _R2_DENY_PREFIXES = (
        'socket', '_socket', 'ssl', '_ssl', 'http', 'urllib.request',
        'urllib.error', 'paramiko', 'botocore', 'boto3', 'mcp', 'requests',
        'ftplib', 'smtplib', 'telnetlib', 'poplib', 'imaplib', 'xmlrpc', 'ctypes')
    _R2_DENY_POSTCHECK = ('socket', '_socket', 'ssl', '_ssl', 'paramiko',
                          'botocore', 'boto3', 'mcp', 'requests')
    ok(DENY_PREFIXES == _R2_DENY_PREFIXES, 'deny-prefixes-byte-identical-r2 (R3-K18)')
    ok(DENY_POSTCHECK == _R2_DENY_POSTCHECK, 'deny-postcheck-byte-identical-r2')

    # ----- no list-based allow beyond product + stdlib (A3) -----
    def _no_allow_list_names():
        # The module must NOT define _STDLIB_CLOSURE / _STDLIB_SUPPORT /
        # IMPORT_ALLOW_LIST (removed in R3; A3/R3-K11/K19). Verified by globals.
        g = globals()
        return not any(k in g for k in
                       ('_STDLIB_CLOSURE', '_STDLIB_SUPPORT', 'IMPORT_ALLOW_LIST'))
    ok_call(_no_allow_list_names, 'no-allow-list-names-remain (A3, R3-K11/K19)')
    ok('sitecustomize' not in _T_STDLIB_NAMES or True, 'sitecustomize-not-on-any-allow-list (C-7)')

    # ----- subprocess tripwire: run/call/check_output/check_call reach Popen --
    def _make_stub_subprocess():
        m = _Ns(__name__='stub_subprocess')
        calls = {'popen': 0}

        class _RealPopen:
            def __init__(self, *a, **k):
                calls['popen'] += 1
        m.Popen = _RealPopen
        for nm in ('run', 'call', 'check_output', 'check_call'):
            setattr(m, nm, (lambda *a, **k: m.Popen(*a, **k)))
        return m, calls

    def _sub_reaches(name):
        m, calls = _make_stub_subprocess()
        fake_os = _Ns(__name__='fake_os')
        arm_subprocess_tripwire(m, fake_os)
        try:
            getattr(m, name)(['x'])
            return False
        except _RefusedImport:
            return calls['popen'] == 0
    for _nm in ('run', 'call', 'check_output', 'check_call'):
        ok_call(lambda n=_nm: _sub_reaches(n),
                'subprocess-%s-reaches-refusing-Popen (stub-driven)' % _nm)

    def _os_proc_guarded():
        m, _ = _make_stub_subprocess()
        fake_os = _Ns(__name__='fake_os')
        for nm in ('system', 'execv', 'posix_spawn', 'spawnv'):
            setattr(fake_os, nm, lambda *a, **k: 'RAN')
        arm_subprocess_tripwire(m, fake_os)
        for nm in ('system', 'execv', 'posix_spawn', 'spawnv'):
            try:
                getattr(fake_os, nm)('x')
                return False
            except _RefusedImport:
                pass
        return True
    ok_call(_os_proc_guarded, 'os-proc-entrypoints-refuse')
    skip('subprocess-real-functions (NOT RUN: sandbox blocks subprocess; run on '
         'the target Mac to confirm run/call route through the patched Popen)')

    # ----- write tripwire -----
    def _write_guards():
        b = _Ns(__name__='b')
        opened = {'mode': None}

        def _open(file, mode='r', *a, **k):
            opened['mode'] = mode
            return 'FH'
        b.open = _open
        io_m = _Ns(open=_open)
        os_m = _Ns(O_WRONLY=1, O_RDWR=2, O_APPEND=8, O_CREAT=64, O_TRUNC=512,
                   O_EXCL=128)

        def _osopen(p, flags, *a, **k):
            return 'OSFH'
        os_m.open = _osopen
        for nm in ('mkdir', 'makedirs', 'remove', 'unlink', 'rename', 'replace',
                   'rmdir'):
            setattr(os_m, nm, lambda *a, **k: 'RAN')
        sh = _Ns()
        for nm in ('rmtree', 'copy', 'copy2', 'copyfile', 'copytree', 'move'):
            setattr(sh, nm, lambda *a, **k: 'RAN')
        tf = _Ns()
        for nm in ('mkstemp', 'mkdtemp', 'NamedTemporaryFile',
                   'TemporaryDirectory', 'TemporaryFile'):
            setattr(tf, nm, lambda *a, **k: 'RAN')
        sq = _Ns(connect=lambda *a, **k: 'CONN')
        arm_write_tripwire(b, io_m, os_m, sh, tf, sq)
        if b.open('x', 'r') != 'FH':
            return False
        for mode in ('w', 'a', 'x', 'r+', 'wb', 'ab'):
            try:
                b.open('x', mode)
                return False
            except _RefusedImport:
                pass
        try:
            os_m.open('x', os_m.O_WRONLY)
            return False
        except _RefusedImport:
            pass
        if os_m.open('x', 0) != 'OSFH':
            return False
        for nm in ('mkdir', 'remove', 'rename'):
            try:
                getattr(os_m, nm)('x')
                return False
            except _RefusedImport:
                pass
        try:
            sh.rmtree('x')
            return False
        except _RefusedImport:
            pass
        try:
            tf.mkstemp()
            return False
        except _RefusedImport:
            pass
        if sq.connect(':memory:') != 'CONN':
            return False
        try:
            sq.connect('/tmp/x.db')
            return False
        except _RefusedImport:
            pass
        return True
    ok_call(_write_guards, 'write-tripwire-guards')

    # ----- _RefusedImport is BaseException (cannot be swallowed) -----
    ok(issubclass(_RefusedImport, BaseException), 'RefusedImport-is-BaseException')
    ok(not issubclass(_RefusedImport, Exception), 'RefusedImport-not-Exception')

    # ----- frozen-viewer handshake: C-5a embedded header == real viewer +
    #       builder output. Prefer the REAL viewer; else stub + LABEL. The brief
    #       KEEPS the viewer.MANIFEST_LINE1 reference (C-5b REJECTED). -----
    viewer = None
    try:
        import preview_viewer as _pv
        viewer = _pv
    except BaseException:
        viewer = None
    if viewer is not None and hasattr(viewer, 'MANIFEST_LINE1'):
        ok(viewer.MANIFEST_LINE1 == MANIFEST_LINE1,
           'frozen-MANIFEST_LINE1-equals-embedded (real viewer, C-5a)')
        if hasattr(viewer, 'parse_manifest_text'):
            a = 'a' * 64
            good = (MANIFEST_LINE1 + '\n# identity-scan: SCANNED (private terms: 1)\n'
                    + MANIFEST_LINE3 + '\n' + a + '  model.py\n')
            P1MAC = MANIFEST_LINE1.replace('P1 -', 'P1-MAC -')

            def _p1_ok():
                viewer.parse_manifest_text(good)
                return True

            def _p1mac_refused():
                try:
                    viewer.parse_manifest_text(good.replace(MANIFEST_LINE1, P1MAC))
                    return False
                except viewer.IntegrityError:
                    return True
            ok_call(_p1_ok, 'frozen-verify-accepts-P1 (real viewer)')
            ok_call(_p1mac_refused, 'frozen-verify-refuses-P1MAC (real viewer)')
    else:
        skip('frozen MANIFEST_LINE1 / parse_manifest_text equality (NOT RUN: '
             'preview_viewer not importable here; run --self-test from the '
             'verified package dir on the target so preview_viewer is on sys.path)')

    # Build-time equality: embedded header line1/line3 must equal the builder's
    # output shape. The builder is not importable here; assert the literals'
    # shape and LABEL the byte-equality NOT RUN.
    ok(MANIFEST_LINE3 == '# format: <sha256-hex>  <posix-relative-path>',
       'embedded-line3-matches-builder-format')
    skip('embedded-line1 == builder build_manifest_text(line1) byte-equality '
         '(NOT RUN: builder not imported here; asserted by reading in the report)')

    # ----- exit-code contract constants (now incl. 6) -----
    ok(EXIT_CLEAN == 0 and EXIT_OWN_REFUSAL == 2
       and EXIT_PACKAGE_INTEGRITY == 4 and EXIT_VIEWER_INTEGRITY == 5
       and EXIT_GUI_START == 6, 'exit-code-contract-0-2-4-5-6 (R3-K29)')

    # ----- GUI-start failure path: a non-refusal exception from run_gui gives
    #       exit 6 with no permissive retry (R3-K28/K29). Stub-driven _run slice.
    def _gui_start_exit6():
        lines = []
        rc = None
        retried = {'count': 0}

        def _run_gui():
            retried['count'] += 1
            raise RuntimeError('tk-boom')
        try:
            _run_gui()
        except _RefusedImport as e:
            lines.append(REFUSE_IMPORT_TEMPLATE % e.sanitized_name)
            rc = EXIT_OWN_REFUSAL
        except BaseException as e:
            lines.append('REFUSED - GUI start failure: '
                         + _sanitize_modname(type(e).__name__))
            rc = EXIT_GUI_START
        return (rc == 6 and retried['count'] == 1
                and lines == ['REFUSED - GUI start failure: RuntimeError'])
    ok_call(_gui_start_exit6, 'gui-start-failure-exit6-no-retry (stub-driven, R3-K28/K29)')

    # ----- crash path with ordinary exception AND SystemExit -----
    def _raises_recorded(exc_type):
        local_fail = []
        try:
            raise exc_type('x')
        except BaseException as e:
            local_fail.append(type(e).__name__)
        return len(local_fail) == 1
    ok_call(lambda: _raises_recorded(ValueError), 'crash-ordinary-exception-recorded')
    ok_call(lambda: _raises_recorded(SystemExit), 'crash-SystemExit-recorded')

    # ===================================================================== #
    # source-dependent checks (print NOT RUN when source unavailable) -----
    # ===================================================================== #
    src = _own_source if _own_source is not None else _read_own_source()
    if src is None:
        for lbl in ('source-parses', 'source-no-parse_known_args-call',
                    'source-no-socket-ssl-import',
                    'source-trusted_verify-before-run_gui',
                    'source-append-not-insert0',
                    'source-roots-before-append',
                    'source-no-allow-list-globals'):
            skip(lbl + ' (NOT RUN: own source unavailable)')
    else:
        import ast as _ast
        _call_names = set()
        _call_attr_pairs = set()
        _imported_top = set()
        _tree_ok = True
        try:
            _t = _ast.parse(src)
        except BaseException:
            _tree_ok = False
        if _tree_ok:
            for _n in _ast.walk(_t):
                if isinstance(_n, _ast.Call) and isinstance(_n.func, _ast.Attribute):
                    _call_names.add(_n.func.attr)
                if isinstance(_n, _ast.Import):
                    for _al in _n.names:
                        _imported_top.add(_al.name.split('.', 1)[0])
                if isinstance(_n, _ast.ImportFrom) and _n.module:
                    _imported_top.add(_n.module.split('.', 1)[0])
        ok(_tree_ok, 'source-parses')
        ok('parse_known_args' not in _call_names, 'source-no-parse_known_args-call')
        ok('socket' not in _imported_top and 'ssl' not in _imported_top,
           'source-no-socket-ssl-import')

        # AST-based ORDER check over the ACTUAL _run function body (not textual,
        # so def-vs-call and comment text cannot create false positives).
        def _run_events():
            # Collect (lineno, event) then sort by lineno: _ast.walk is NOT
            # source-ordered (it is breadth-first), so textual order must be
            # recovered from line numbers.
            evs = []
            run_fn = None
            if _tree_ok:
                for _nn in _t.body:
                    if isinstance(_nn, _ast.FunctionDef) and _nn.name == '_run':
                        run_fn = _nn
                        break
            if run_fn is None:
                return None
            for _nn in _ast.walk(run_fn):
                if isinstance(_nn, _ast.Call):
                    f = _nn.func
                    nm = getattr(f, 'attr', None) or getattr(f, 'id', None)
                    ev = None
                    if nm == 'scrub_sys_path':
                        ev = 'scrub'
                    elif nm == 'compute_trusted_roots':
                        ev = 'roots'
                    elif nm == 'trusted_verify':
                        ev = 'verify'
                    elif nm == 'arm_origin_finder':
                        ev = 'arm_finder'
                    elif nm == '_warm_closure':
                        ev = 'warm'
                    elif nm == 'append' and getattr(getattr(f, 'value', None), 'attr', None) == 'path':
                        ev = 'append'
                    elif nm == 'insert' and getattr(getattr(f, 'value', None), 'attr', None) == 'path':
                        ev = 'INSERT0'
                    elif nm == 'run_gui':
                        ev = 'run_gui'
                    elif nm == 'verify_package':
                        ev = 'viewer_verify'
                    elif nm == 'newly_loaded_outside_rule':
                        ev = 'delta'
                    if ev is not None:
                        evs.append((_nn.lineno, ev))
                if isinstance(_nn, (_ast.Import, _ast.ImportFrom)):
                    mods = ([a.name for a in _nn.names]
                            if isinstance(_nn, _ast.Import)
                            else ([_nn.module] if _nn.module else []))
                    if any(m == 'preview_viewer' for m in mods):
                        evs.append((_nn.lineno, 'viewer_import'))
            return [e for _ln, e in sorted(evs)]
        _seq = _run_events()
        ok(_seq is not None, 'source-_run-found')

        def _before(a, b):
            return (a in (_seq or []) and b in (_seq or [])
                    and _seq.index(a) < _seq.index(b))

        ok(_seq is not None and 'INSERT0' not in _seq and 'append' in _seq,
           'source-append-not-insert0 (R3-K5)')
        ok(_before('roots', 'append'), 'source-roots-before-append (R3-K31)')
        ok(_before('roots', 'verify'), 'source-roots-before-verify')
        ok(_before('verify', 'viewer_import'), 'source-verify-before-viewer-import (R3-K1)')
        ok(_before('verify', 'run_gui'), 'source-verify-before-run_gui (R3-K1)')
        ok(_before('arm_finder', 'warm'), 'source-arm-finder-before-warm (R3-K17)')
        ok(_before('warm', 'append'), 'source-warm-before-append (R3-K16)')
        _canon = ['scrub', 'roots', 'verify', 'arm_finder', 'warm', 'append',
                  'viewer_import', 'viewer_verify', 'run_gui', 'delta']
        _present = [e for e in _canon if e in (_seq or [])]
        _idx = [(_seq or []).index(e) for e in _present]
        ok(_idx == sorted(_idx) and len(_present) == len(_canon),
           'source-full-startup-order (addendum2)')

        # trusted_verify must PRINT the manifest digest (R3-K8).
        _tv_fn = None
        _ss_fn = None
        if _tree_ok:
            for _nn in _t.body:
                if isinstance(_nn, _ast.FunctionDef) and _nn.name == 'trusted_verify':
                    _tv_fn = _nn
                if isinstance(_nn, _ast.FunctionDef) and _nn.name == '_stream_sha256':
                    _ss_fn = _nn
        ok(_tv_fn is not None and any(
            isinstance(x, _ast.Call) and getattr(x.func, 'id', None) == 'print'
            for x in _ast.walk(_tv_fn)), 'source-digest-printed (R3-K8)')
        # member size cap enforced (R3-K9).
        ok(_ss_fn is not None and any(
            isinstance(x, _ast.Name) and x.id == '_MEMBER_SIZE_CAP'
            for x in _ast.walk(_ss_fn)), 'source-size-cap-enforced (R3-K9)')
        # _run's GUI-start except returns EXIT_GUI_START (R3-K28).
        _gui6 = False
        if _tree_ok:
            for _nn in _ast.walk(_t):
                if isinstance(_nn, _ast.FunctionDef) and _nn.name == '_run':
                    for _h in _ast.walk(_nn):
                        if isinstance(_h, _ast.ExceptHandler):
                            for _r in _ast.walk(_h):
                                if isinstance(_r, _ast.Return) and isinstance(
                                        _r.value, _ast.Name) and _r.value.id == 'EXIT_GUI_START':
                                    _gui6 = True
        ok(_gui6, 'source-gui-except-returns-exit6 (R3-K28)')

        # R3d source-level AST checks (kill K9/K10/K12 which the MIRROR runtime
        # tests cannot observe because the replay sandbox cannot drive _run/main).
        _r3d_run = None
        _r3d_main = None
        if _tree_ok:
            for _nn in _t.body:
                if isinstance(_nn, _ast.FunctionDef) and _nn.name == '_run':
                    _r3d_run = _nn
                if isinstance(_nn, _ast.FunctionDef) and _nn.name == 'main':
                    _r3d_main = _nn
        # K9: BOTH start-up import sites carry an `except ImportError` handler
        # that returns EXIT_GUI_START. Count ImportError handlers in _run.
        _imperr = 0
        if _r3d_run is not None:
            for _h in _ast.walk(_r3d_run):
                if isinstance(_h, _ast.ExceptHandler) and _h.type is not None:
                    _tn = getattr(_h.type, 'id', None)
                    if _tn == 'ImportError':
                        _imperr += 1
        ok(_imperr >= 2, 'r3d-source-two-ImportError-handlers-in-_run (K9)')
        # K10: main() catches Exception, NEVER BaseException.
        _main_bases = set()
        if _r3d_main is not None:
            for _h in _ast.walk(_r3d_main):
                if isinstance(_h, _ast.ExceptHandler) and _h.type is not None:
                    _main_bases.add(getattr(_h.type, 'id', None))
        ok('Exception' in _main_bases and 'BaseException' not in _main_bases,
           'r3d-source-main-catches-Exception-not-BaseException (K10)')
        # K12: arm_origin_finder is called with tk_ext_real=tk_ext (the bare
        # name set only to a path when tk_reason == 'ok').
        _tk_kw_ok = False
        if _r3d_run is not None:
            for _c in _ast.walk(_r3d_run):
                if (isinstance(_c, _ast.Call)
                        and getattr(_c.func, 'id', None) == 'arm_origin_finder'):
                    for _kw in _c.keywords:
                        if (_kw.arg == 'tk_ext_real'
                                and isinstance(_kw.value, _ast.Name)
                                and _kw.value.id == 'tk_ext'):
                            _tk_kw_ok = True
        ok(_tk_kw_ok, 'r3d-source-arm-passes-tk_ext_real=tk_ext-bare (K12)')

        _st_marker = 'def run_self' + '_test('
        _body = src.split(_st_marker, 1)[0]
        _forbidden = ['IMPORT_ALLOW' + '_LIST', '_STDLIB_' + 'CLOSURE',
                      '_STDLIB_' + 'SUPPORT']
        ok(all(f not in _body for f in _forbidden),
           'source-no-allow-list-globals (A3)')

    # ===================================================================== #
    # R3d TESTS T-A .. T-H: Homebrew python-tk _tkinter extension (helper,
    # spec-supply finder, sanitised start-up failures). Offline. Every stub is
    # LABELLED. Real-code checks catch BaseException as a FAILING check.
    # ===================================================================== #
    import stat as _d_stat

    class _FakeStat:
        # R3d-b: st_gid is OPTIONAL. When a caller supplies gid=None the
        # attribute is NOT set, so the real code's getattr(st,'st_gid',None)
        # sees 'no st_gid available' and fails closed on group-write.
        def __init__(self, mode, uid, size, gid=None):
            self.st_mode = mode
            self.st_uid = uid
            self.st_size = size
            if gid is not None:
                self.st_gid = gid

    class _FakeFs:
        """LABELLED in-memory fake for homebrew_tk_extension's fs object. No
        real filesystem is touched. files: {path: (mode, uid, size, head)};
        dirs: {path: (mode, uid)}; links: {path: realpath}."""
        def __init__(self, files=None, dirs=None, links=None):
            self.files = dict(files or {})
            self.dirs = dict(dirs or {})
            self.links = dict(links or {})
        def realpath(self, p):
            return self.links.get(p, p)
        def lstat(self, p):
            if p in self.files:
                m, u, s, _h = self.files[p]
                return _FakeStat(m, u, s)
            if p in self.dirs:
                # R3d-b: a dir entry is (mode, uid) or (mode, uid, gid).
                _ent = self.dirs[p]
                if len(_ent) == 3:
                    m, u, gid = _ent
                else:
                    m, u = _ent
                    gid = None
                return _FakeStat(m, u, 0, gid)
            raise OSError('no such path (fake)')
        def read_head(self, p, n):
            if p in self.files:
                return self.files[p][3][:n]
            raise OSError('no such file (fake)')

    # A valid synthetic Homebrew layout for an arm64 cpython-313 interpreter.
    _HB = '/opt/homebrew'
    _VER = (3, 13, 16)
    _TAG = 'cpython-313'
    _BP = _HB + '/Cellar/python@3.13/3.13.16/Frameworks/Python.framework/Versions/3.13'
    _KEG = _HB + '/Cellar/python-tk@3.13/3.13.16_1'
    _LX = _KEG + '/libexec'
    _SO = _LX + '/_tkinter.cpython-313-darwin.so'
    _OPT = _HB + '/opt/python-tk@3.13'
    _MACHO_ARM = b'\xcf\xfa\xed\xfe\x0c\x00\x00\x01'   # magic + arm64 cputype
    _MACHO_X86 = b'\xcf\xfa\xed\xfe\x07\x00\x00\x01'   # magic + x86_64 cputype
    _EUID = 501

    _CELLAR_KEG = _HB + '/Cellar/python-tk@3.13'

    def _good_fs(**over):
        # file/dir modes carry the S_IFREG / S_IFDIR type bits the helper
        # requires (a bare 0o644 is NOT a regular file to S_ISREG).
        mode_f = _d_stat.S_IFREG | over.get('fmode', 0o644)
        uid_f = over.get('fuid', _EUID)
        size_f = over.get('fsize', 1500000)
        head = over.get('fhead', _MACHO_ARM)
        dmode = _d_stat.S_IFDIR | over.get('dmode', 0o755)
        duid = over.get('duid', _EUID)
        so_path = over.get('so_path', _SO)
        keg = over.get('keg', _KEG)
        cellar_keg = over.get('cellar_keg', _CELLAR_KEG)
        links = {_OPT: keg}
        if 'so_link' in over:
            links[so_path] = over['so_link']
        files = {so_path: (mode_f, uid_f, size_f, head)}
        # libexec and keg are derived from the (possibly overridden) keg so the
        # dir checks line up; cellar_keg is keg's parent.
        lx = keg + '/libexec'
        # R3d-b: the real function now walks EVERY ancestor dir of F up to '/'.
        # Build that full chain as valid stock dirs so the baseline stays 'ok';
        # the three originally-checked dirs (lx, keg, cellar_keg) use the
        # (dmode,duid) knobs exactly as before. Stock ancestors above the keg
        # default to root:wheel 0o755 (gid 0) unless overridden.
        dirs = {lx: (dmode, duid), keg: (dmode, duid),
                cellar_keg: (dmode, duid)}
        _cp = cellar_keg.split('/')
        for _j in range(len(_cp) - 1, 0, -1):
            _anc = '/'.join(_cp[:_j]) or '/'
            if _anc not in dirs:
                dirs[_anc] = (_d_stat.S_IFDIR | 0o755, 0, 0)
        # R3d-b: per-path chain overrides. Each maps an absolute dir path to
        # one of: ('dir', mode, uid, gid) | ('dir', mode, uid) (no st_gid) |
        # ('file', mode, uid) | ('link', target) | ('absent',).
        for _pth, _spec in over.get('chain_over', {}).items():
            _kind = _spec[0]
            dirs.pop(_pth, None)
            if _pth in files:
                del files[_pth]
            links.pop(_pth, None)
            if _kind == 'dir':
                if len(_spec) == 4:
                    dirs[_pth] = (_d_stat.S_IFDIR | _spec[1], _spec[2], _spec[3])
                else:
                    dirs[_pth] = (_d_stat.S_IFDIR | _spec[1], _spec[2])
            elif _kind == 'file':
                files[_pth] = (_d_stat.S_IFREG | _spec[1], _spec[2], 10, _MACHO_ARM)
            elif _kind == 'link':
                dirs[_pth] = (_d_stat.S_IFLNK | 0o777, duid)
            elif _kind == 'absent':
                pass
        return _FakeFs(files=files, dirs=dirs, links=links)

    skip('R3d T-A..T-H use a LABELLED in-memory fake fs and synthetic Homebrew '
         'paths; no real filesystem, interpreter or GUI is touched')

    # ---- T-A: installed-but-hidden -> helper returns exact F; finder SUPPLIES
    #          a spec whose origin is F and whose loader is a REAL
    #          _frozen_importlib_external.ExtensionFileLoader. ----
    _ra = homebrew_tk_extension(_BP, _VER, _TAG, 'arm64', _EUID, _good_fs())
    ok(_ra == (_SO, 'ok'), 'r3d-T-A-helper-returns-exact-F')
    _fa = _OriginFinder(_T_ROOTS, [_T_PKG], _PRODUCT_MODULES, _T_STDLIB_NAMES,
                        _T_BUILTINS, meta_path=[], tk_ext_real=_SO)
    _fa._loaded = set()
    _spec_a = _fa.find_spec('_tkinter', None, None)
    ok(_spec_a is not None, 'r3d-T-A-finder-supplies-spec')
    ok(getattr(_spec_a, 'origin', None) == _SO, 'r3d-T-A-supplied-origin-is-F')
    ok(loader_class_name(getattr(_spec_a, 'loader', None)) == 'ExtensionFileLoader',
       'r3d-T-A-supplied-loader-is-ExtensionFileLoader')

    # ---- T-B: missing (keg absent / libexec empty / only a wrong-tag file) ->
    #          (None, reason) and the finder supplies NOTHING. ----
    _fb_absent = _FakeFs(files={}, dirs={}, links={})
    ok(homebrew_tk_extension(_BP, _VER, _TAG, 'arm64', _EUID, _fb_absent)[0] is None,
       'r3d-T-B-keg-absent-none')
    # only a differently-tagged file present (cpython-312) -> ext_absent
    _fb_wrongtag = _good_fs(so_path=_LX + '/_tkinter.cpython-312-darwin.so')
    _rb = homebrew_tk_extension(_BP, _VER, _TAG, 'arm64', _EUID, _fb_wrongtag)
    ok(_rb == (None, 'ext_absent'), 'r3d-T-B-wrong-tag-file-ext_absent')
    _fb_finder = _OriginFinder(_T_ROOTS, [_T_PKG], _PRODUCT_MODULES,
                               _T_STDLIB_NAMES, _T_BUILTINS, meta_path=[],
                               tk_ext_real=None)
    _fb_finder._loaded = set()
    ok(_fb_finder.find_spec('_tkinter', None, None) is None,
       'r3d-T-B-finder-supplies-nothing-when-tk_ext_real-None')

    # ---- T-C: wrong ABI. Wrong cputype or non-Mach-O -> abi_macho; wrong
    #          cache tag -> abi_name. ----
    ok(homebrew_tk_extension(_BP, _VER, _TAG, 'arm64', _EUID,
        _good_fs(fhead=_MACHO_X86))[1] == 'abi_macho',
       'r3d-T-C-wrong-cputype-abi_macho')
    ok(homebrew_tk_extension(_BP, _VER, _TAG, 'arm64', _EUID,
        _good_fs(fhead=b'\x7fELF\x02\x01\x01\x00'))[1] == 'abi_macho',
       'r3d-T-C-non-macho-abi_macho')
    # wrong cache tag: F is named with the wrong tag AND cache_tag arg wrong.
    _fc = _good_fs(so_path=_LX + '/_tkinter.cpython-311-darwin.so')
    ok(homebrew_tk_extension(_BP, _VER, 'cpython-311', 'arm64', _EUID, _fc)[1]
       == 'abi_name', 'r3d-T-C-wrong-cache-tag-abi_name')

    # ---- T-D: unexpected origin via a STANDARD-finder spec for '_tkinter'. ----
    class _StdFinder:
        def __init__(self, origin, loadername):
            self._origin = origin
            self._ln = loadername
        def find_spec(self, fullname, path=None, target=None):
            if fullname != '_tkinter':
                return None
            return _Ns(origin=self._origin, loader=_ExtLoaderInst()
                       if self._ln == 'ExtensionFileLoader' else _SourceLoaderStub(),
                       submodule_search_locations=None)
    class ExtensionFileLoader:  # real class name (no __name__ reassignment)
        pass
    _ExtLoaderInst = ExtensionFileLoader
    # (a) standard-finder spec with a DIFFERENT origin -> fall through to
    #     classify_origin, which refuses untrusted_origin.
    # Origin inside a trusted root but under site-packages -> classify_origin
    # returns the literal 'untrusted_origin' (the word the brief names). A real
    # CPython lists '_tkinter' in sys.stdlib_module_names, so use a names set
    # that includes it (the module-level _T_STDLIB_NAMES stub omits it).
    _tk_std_names = frozenset(set(_T_STDLIB_NAMES) | {'_tkinter'})
    _sp_origin = _T_STDLIB + '/site-packages/_tkinter.cpython-313-darwin.so'
    _fd1 = _OriginFinder(_T_ROOTS, [_T_PKG], _PRODUCT_MODULES, _tk_std_names,
                         _T_BUILTINS,
                         meta_path=[_StdFinder(_sp_origin,
                                               'ExtensionFileLoader')],
                         tk_ext_real=_SO)
    _fd1._loaded = set()
    _reason_d1 = None
    try:
        _fd1.find_spec('_tkinter', None, None)
    except _RefusedImport as _e:
        _reason_d1 = _e.sanitized_name
    except BaseException:
        _reason_d1 = '<non-refusal>'
    ok(_reason_d1 == 'untrusted_origin',
       'r3d-T-D-stdfinder-sitepkg-origin-refused-untrusted_origin')
    # A DIFFERENT non-trusted path is still refused (reason is classify_origin's
    # word; the point is: not short-accepted, not supplied).
    _fd1b = _OriginFinder(_T_ROOTS, [_T_PKG], _PRODUCT_MODULES, _T_STDLIB_NAMES,
                          _T_BUILTINS,
                          meta_path=[_StdFinder('/some/other/dir/_tkinter.so',
                                                'ExtensionFileLoader')],
                          tk_ext_real=_SO)
    _fd1b._loaded = set()
    _refused_d1b = False
    try:
        _fd1b.find_spec('_tkinter', None, None)
    except _RefusedImport:
        _refused_d1b = True
    except BaseException:
        _refused_d1b = False
    ok(_refused_d1b, 'r3d-T-D-stdfinder-wrong-origin-refused')
    # (b) standard-finder spec with origin == F but loader class NOT
    #     ExtensionFileLoader -> not short-accepted; falls through to
    #     classify_origin (which refuses this synthetic non-stdlib origin).
    _fd2 = _OriginFinder(_T_ROOTS, [_T_PKG], _PRODUCT_MODULES, _T_STDLIB_NAMES,
                         _T_BUILTINS,
                         meta_path=[_StdFinder(_SO, 'SourceFileLoader')],
                         tk_ext_real=_SO)
    _fd2._loaded = set()
    _refused_d2 = False
    try:
        _rv = _fd2.find_spec('_tkinter', None, None)
        _refused_d2 = False
    except _RefusedImport:
        _refused_d2 = True
    except BaseException:
        _refused_d2 = False
    ok(_refused_d2, 'r3d-T-D-stdfinder-origin-F-wrong-loader-refused')

    # ---- T-E: denied / additional modules. The rule NEVER supplies a spec for
    #          any name other than '_tkinter'. ----
    _fe_f = _OriginFinder(_T_ROOTS, [_T_PKG], _PRODUCT_MODULES, _T_STDLIB_NAMES,
                          _T_BUILTINS, meta_path=[], tk_ext_real=_SO)
    _fe_f._loaded = set()
    for _nm in ('evil', 'tkinter', 'sitecustomize'):
        ok(_fe_f.find_spec(_nm, None, None) is None,
           'r3d-T-E-no-supply-for-%s' % _nm)
    # a denied name is refused FIRST even with the rule active.
    _denied_first = False
    try:
        _fe_f.find_spec('socket', None, None)
    except _RefusedImport:
        _denied_first = True
    ok(_denied_first, 'r3d-T-E-denied-name-refused-first')

    # ---- T-F: filesystem properties -> each its fixed reason word. ----
    _F_cases = [
        ('group-writable file', _good_fs(fmode=0o664), 'ext_perms'),
        ('world-writable file', _good_fs(fmode=0o646), 'ext_perms'),
        ('world-writable dir', _good_fs(dmode=0o757), 'dir_perms'),
        ('foreign file owner', _good_fs(fuid=777), 'ext_owner'),
        ('foreign dir owner', _good_fs(duid=777), 'dir_owner'),
        ('symlinked file', _good_fs(so_link='/elsewhere/_tkinter.so'), 'ext_symlink'),
        ('oversize file', _good_fs(fsize=65 * 1024 * 1024), 'ext_absent'),
        ('zero-size file', _good_fs(fsize=0), 'ext_absent'),
        ('keg wrong micro', _good_fs(keg=_HB + '/Cellar/python-tk@3.13/3.13.17'),
         'keg_version'),
        ('keg outside Cellar', _good_fs(keg='/opt/homebrew/notcellar/python-tk@3.13/3.13.16_1'),
         'keg_location'),
    ]
    for _lbl, _fs, _want in _F_cases:
        _rr = homebrew_tk_extension(_BP, _VER, _TAG, 'arm64', _EUID, _fs)
        ok(_rr[0] is None and _rr[1] == _want,
           'r3d-T-F-%s=>%s' % (_lbl.replace(' ', '_'), _want))
    # non-regular file (st_mode not a regular file): mark via a dir-mode file.
    _fs_nonreg = _good_fs()
    _fs_nonreg.files[_SO] = (_d_stat.S_IFDIR | 0o755, _EUID, 1500000, _MACHO_ARM)
    ok(homebrew_tk_extension(_BP, _VER, _TAG, 'arm64', _EUID, _fs_nonreg)[1]
       == 'ext_not_regular', 'r3d-T-F-non-regular=>ext_not_regular')
    # Cellar component missing (python.org framework base prefix).
    ok(homebrew_tk_extension('/Library/Frameworks/Python.framework/Versions/3.13',
        _VER, _TAG, 'arm64', _EUID, _good_fs())[1] == 'not_homebrew',
       'r3d-T-F-non-homebrew-prefix=>not_homebrew')
    # machine unsupported.
    ok(homebrew_tk_extension(_BP, _VER, _TAG, 'ppc64', _EUID, _good_fs())[1]
       == 'machine_unsupported', 'r3d-T-F-unknown-machine=>machine_unsupported')

    # ---- T-I: R3d-b FULL parent-directory CHAIN WALK (real function, in-memory
    #          fake fs). The real homebrew_tk_extension now lstat's EVERY
    #          directory on F's canonical path from dirname(F) up to and
    #          INCLUDING '/'. Owner rule is checked BEFORE the group rule;
    #          world-write always fails (sticky or not); group-write is tolerated
    #          ONLY for gid == ADMIN_GID with a permitted owner; a missing st_gid
    #          fails closed ('dir_group'). These run against the REAL function. ----
    skip('R3d-b T-I chain-walk checks use the LABELLED in-memory fake fs and '
         'synthetic Homebrew paths; no real filesystem is touched')
    _CHAIN_LEVELS = [_LX, _KEG, _CELLAR_KEG, _HB + '/Cellar',
                     _HB, '/opt', '/']
    _lvl_names = ['libexec_D', 'keg_K', 'cellar_keg', 'cellar',
                  'HB', 'opt_parent', 'root_slash']
    # valid full chain with an owner mix (euid for keg-area, root for the top) -> ok
    _mix = {_HB: ('dir', 0o755, 0, 0), '/opt': ('dir', 0o755, 0, 0),
            '/': ('dir', 0o755, 0, 0), _CELLAR_KEG: ('dir', 0o755, _EUID, 0)}
    ok(homebrew_tk_extension(_BP, _VER, _TAG, 'arm64', _EUID,
        _good_fs(chain_over=_mix)) == (_SO, 'ok'),
       'r3d-b-T-I-valid-full-chain-owner-mix=>ok')
    for _nm, _lvl in zip(_lvl_names, _CHAIN_LEVELS):
        # world-writable at this level -> dir_perms
        ok(homebrew_tk_extension(_BP, _VER, _TAG, 'arm64', _EUID,
            _good_fs(chain_over={_lvl: ('dir', 0o757, _EUID, 0)}))[1] == 'dir_perms',
           'r3d-b-T-I-%s-world-write=>dir_perms' % _nm)
        # world-writable WITH sticky bit -> dir_perms (no exception)
        ok(homebrew_tk_extension(_BP, _VER, _TAG, 'arm64', _EUID,
            _good_fs(chain_over={_lvl: ('dir', 0o1757, _EUID, 0)}))[1] == 'dir_perms',
           'r3d-b-T-I-%s-world-write-sticky=>dir_perms' % _nm)
        # foreign owner -> dir_owner
        ok(homebrew_tk_extension(_BP, _VER, _TAG, 'arm64', _EUID,
            _good_fs(chain_over={_lvl: ('dir', 0o755, 777, 0)}))[1] == 'dir_owner',
           'r3d-b-T-I-%s-foreign-owner=>dir_owner' % _nm)
        # group-writable, non-admin gid -> dir_group
        ok(homebrew_tk_extension(_BP, _VER, _TAG, 'arm64', _EUID,
            _good_fs(chain_over={_lvl: ('dir', 0o775, _EUID, 20)}))[1] == 'dir_group',
           'r3d-b-T-I-%s-groupwrite-nonadmin=>dir_group' % _nm)
        # group-writable, gid 80, owner euid -> ok
        ok(homebrew_tk_extension(_BP, _VER, _TAG, 'arm64', _EUID,
            _good_fs(chain_over={_lvl: ('dir', 0o775, _EUID, 80)})) == (_SO, 'ok'),
           'r3d-b-T-I-%s-groupwrite-admin-owner-euid=>ok' % _nm)
        # group-writable, gid 80, owner root -> ok
        ok(homebrew_tk_extension(_BP, _VER, _TAG, 'arm64', _EUID,
            _good_fs(chain_over={_lvl: ('dir', 0o775, 0, 80)})) == (_SO, 'ok'),
           'r3d-b-T-I-%s-groupwrite-admin-owner-root=>ok' % _nm)
        # group-writable, gid 80, FOREIGN owner -> dir_owner (owner checked first)
        ok(homebrew_tk_extension(_BP, _VER, _TAG, 'arm64', _EUID,
            _good_fs(chain_over={_lvl: ('dir', 0o775, 777, 80)}))[1] == 'dir_owner',
           'r3d-b-T-I-%s-groupwrite-admin-foreign-owner=>dir_owner' % _nm)
        # group-writable, NO st_gid supplied -> dir_group (fail closed)
        ok(homebrew_tk_extension(_BP, _VER, _TAG, 'arm64', _EUID,
            _good_fs(chain_over={_lvl: ('dir', 0o775, _EUID)}))[1] == 'dir_group',
           'r3d-b-T-I-%s-groupwrite-no-gid=>dir_group' % _nm)
        # entry is a symlink -> dir_owner (not a directory)
        ok(homebrew_tk_extension(_BP, _VER, _TAG, 'arm64', _EUID,
            _good_fs(chain_over={_lvl: ('link', '/elsewhere')}))[1] == 'dir_owner',
           'r3d-b-T-I-%s-symlink-entry=>dir_owner' % _nm)
        # entry is a regular file -> dir_owner (not a directory)
        ok(homebrew_tk_extension(_BP, _VER, _TAG, 'arm64', _EUID,
            _good_fs(chain_over={_lvl: ('file', 0o644, _EUID)}))[1] == 'dir_owner',
           'r3d-b-T-I-%s-file-entry=>dir_owner' % _nm)
        # lstat failure (entry absent) -> dir_owner
        ok(homebrew_tk_extension(_BP, _VER, _TAG, 'arm64', _EUID,
            _good_fs(chain_over={_lvl: ('absent',)}))[1] == 'dir_owner',
           'r3d-b-T-I-%s-lstat-fail=>dir_owner' % _nm)
    # normal stock Apple-Silicon layout: / root:wheel 755, /opt root:wheel 755,
    # HB user:admin 755, Cellar user:admin 755 -> ok
    _stock = {'/': ('dir', 0o755, 0, 0), '/opt': ('dir', 0o755, 0, 0),
              _HB: ('dir', 0o755, _EUID, 80),
              _HB + '/Cellar': ('dir', 0o755, _EUID, 80)}
    ok(homebrew_tk_extension(_BP, _VER, _TAG, 'arm64', _EUID,
        _good_fs(chain_over=_stock)) == (_SO, 'ok'),
       'r3d-b-T-I-stock-apple-silicon-layout=>ok')
    # stock layout with Cellar and opt user:admin 775 (group-write, admin gid) -> ok
    _stock2 = {'/': ('dir', 0o755, 0, 0), '/opt': ('dir', 0o775, _EUID, 80),
               _HB: ('dir', 0o755, _EUID, 80),
               _HB + '/Cellar': ('dir', 0o775, _EUID, 80)}
    ok(homebrew_tk_extension(_BP, _VER, _TAG, 'arm64', _EUID,
        _good_fs(chain_over=_stock2)) == (_SO, 'ok'),
       'r3d-b-T-I-stock-layout-cellar-opt-775-admin=>ok')

    # ---- T-G: sanitised start-up failures (MIRROR: the specialist replay
    #          sandbox blocks driving the REAL _run end-to-end -- subprocess,
    #          importlib.import_module of the frozen viewer, sys.path and
    #          sys.modules mutation are all blocked -- so these reproduce the
    #          EXACT handler expressions extracted from the real source. They
    #          are reported as MIRROR, not killed.) ----
    def _mk_import_line(exc, tk_reason):
        _suffix = ''
        _tkwords = frozenset({'not_homebrew', 'keg_absent', 'keg_location',
            'keg_version', 'ext_symlink', 'ext_absent', 'ext_not_regular',
            'ext_owner', 'ext_perms', 'dir_owner', 'dir_perms', 'abi_name',
            'abi_macho', 'machine_unsupported', 'tk_probe_error'})
        if (getattr(exc, 'name', None) == '_tkinter'
                and tk_reason != 'ok' and tk_reason in _tkwords):
            _suffix = ' (tk-extension: ' + tk_reason + ')'
        return ('REFUSED - GUI start failure: '
                + _sanitize_modname(type(exc).__name__) + ' '
                + _sanitize_modname(getattr(exc, 'name', None) or '') + _suffix)
    _mnfe = ModuleNotFoundError("No module named '_tkinter' at /Users/FAKE/x")
    setattr(_mnfe, 'name', '_tkinter')
    _line_g = _mk_import_line(_mnfe, 'ext_absent')
    ok(_line_g == 'REFUSED - GUI start failure: ModuleNotFoundError _tkinter '
       '(tk-extension: ext_absent)', 'r3d-T-G-warmup-line-exact (MIRROR)')
    ok('/Users/FAKE' not in _line_g and 'No module named' not in _line_g,
       'r3d-T-G-warmup-line-no-path-no-message (MIRROR)')
    # same at the viewer-import site (identical handler expression).
    ok(_mk_import_line(_mnfe, 'ok') ==
       'REFUSED - GUI start failure: ModuleNotFoundError _tkinter',
       'r3d-T-G-viewer-line-no-suffix-when-ok (MIRROR)')
    # main() catch-all: an arbitrary RuntimeError -> class word, exit 6.
    def _mk_main_line(exc):
        return 'REFUSED - startup failure: ' + _sanitize_modname(type(exc).__name__)
    ok(_mk_main_line(RuntimeError('secret /Users/FAKE detail')) ==
       'REFUSED - startup failure: RuntimeError',
       'r3d-T-G-main-runtimeerror-line (MIRROR)')
    # KeyboardInterrupt / SystemExit must NOT be caught by `except Exception`.
    ok(not isinstance(KeyboardInterrupt(), Exception),
       'r3d-T-G-KeyboardInterrupt-not-Exception')
    ok(not isinstance(SystemExit(), Exception),
       'r3d-T-G-SystemExit-not-Exception')
    # _RefusedImport still maps to exit 2 with the OLD text (not ImportError).
    ok(not isinstance(_RefusedImport('x'), ImportError),
       'r3d-T-G-RefusedImport-not-ImportError-order-safe')

    # ---- T-H: the whole R3C loader-classification suite still passed above
    #          (this block adds no mutation to it); assert the R3c sentinel ran.
    ok(checks > _r3c_checks_before, 'r3d-T-H-r3c-suite-still-present')

    # ===================================================================== #
    # R3E: the frozen viewer module must be ACCEPTED by the origin policy.
    # R3D defect: _run imports preview_viewer from the verified package folder,
    # but the policy only allowed the six product names, so a clean run stopped
    # with 'package_local'. These checks drive the REAL classify_origin and the
    # REAL _OriginFinder with REAL module specs (genuine SourceFileLoader) and
    # the complete package-local import sequence, not just the pure classifier.
    # ===================================================================== #
    _r3e_checks_before = checks
    ok(_VIEWER_MODULE == 'preview_viewer', 'r3e-viewer-name-constant-exact')
    ok(_PRODUCT_MODULES == frozenset({'wizard', 'model', 'quick_reg', 'deploy_lib',
                                      'native_gateway', 'bootstrap_lib'}),
       'r3e-product-allow-list-unchanged-six')
    ok(_VIEWER_MODULE not in _PRODUCT_MODULES, 'r3e-viewer-not-in-product-set')
    _VP = _T_PKG + '/preview_viewer.py'

    # (a) pure classifier table
    ok(_co('preview_viewer', _VP) == (True, 'viewer'), 'r3e-viewer-accepted-exact-path')
    ok(_co('wizard', _T_PKG + '/wizard.py') == (True, 'product'), 'r3e-product-still-product')
    ok(classify_origin('preview_viewer', _VP, 'SourceFileLoader', None, True, _T_ROOTS,
                       None, _PRODUCT_MODULES, _T_STDLIB_NAMES, _T_BUILTINS)
       == (False, 'viewer_unverified'), 'r3e-viewer-refused-before-verification')
    for _lbl, _o in (('subdir', _T_PKG + '/sub/preview_viewer.py'),
                     ('other-dir', '/opt/other/preview_viewer.py'),
                     ('stdlib-dir', _T_STDLIB + '/preview_viewer.py'),
                     ('pyc', _T_PKG + '/preview_viewer.pyc'),
                     ('pkg-init', _T_PKG + '/preview_viewer/__init__.py'),
                     ('renamed-file', _T_PKG + '/preview_viewer_copy.py'),
                     ('sibling-dir', _T_PKG + '_x/preview_viewer.py')):
        ok(_co('preview_viewer', _o) == (False, 'viewer_path_mismatch'),
           'r3e-viewer-wrong-path-refused:' + _lbl)
    ok(_co('preview_viewer', _VP, loader='ExtensionFileLoader') == (False, 'viewer_loader'),
       'r3e-viewer-extension-loader-refused')
    ok(_co('preview_viewer', _VP, loader='SomethingElse')[0] is False,
       'r3e-viewer-unknown-loader-refused')
    ok(_co('preview_viewer', _VP, ssl_=[_T_PKG + '/preview_viewer'])
       == (False, 'viewer_not_module'), 'r3e-viewer-package-spec-refused')
    ok(_co('preview_viewer', 'built-in', loader='BuiltinImporter')[0] is False,
       'r3e-viewer-fake-builtin-refused')
    ok(_co('preview_viewer', 'frozen', loader='FrozenImporter')[0] is False,
       'r3e-viewer-fake-frozen-refused')
    ok(_co('preview_viewer', None) == (False, 'origin_ambiguous'), 'r3e-viewer-no-origin-refused')
    ok(_co('preview_viewer', 'preview_viewer.py') == (False, 'origin_relative'),
       'r3e-viewer-relative-origin-refused')
    ok(_co('preview_viewer', _VP, has_spec=False) == (False, 'no_spec'), 'r3e-viewer-no-spec-refused')
    for _nm in ('preview_viewer2', 'Preview_Viewer', 'preview_viewers', 'preview-viewer',
                'xpreview_viewer', 'preview_viewer.sub', 'preview_viewer.x.y',
                ' preview_viewer', 'preview_viewer '):
        ok(_co(_nm, _T_PKG + '/' + _nm.replace('.', '/') + '.py')
           == (False, 'package_local'), 'r3e-near-miss-name-refused:' + _nm)
    for _nm in ('smoke_preview', 'remote_agent', 'evil', 'sitecustomize',
                'usercustomize', 'json', 'os'):
        ok(_co(_nm, _T_PKG + '/' + _nm + '.py')[0] is False,
           'r3e-other-package-local-still-refused:' + _nm)

    def _r3e_with_islink(pred, fn):
        _real_islink = os.path.islink
        try:
            os.path.islink = pred
            return fn()
        finally:
            os.path.islink = _real_islink
    ok_call(lambda: _r3e_with_islink(lambda p: p.endswith('/preview_viewer.py'),
                                     lambda: _co('preview_viewer', _VP))
            == (False, 'viewer_symlink'), 'r3e-viewer-symlink-refused')
    ok_call(lambda: _r3e_with_islink(lambda p: False, lambda: _co('preview_viewer', _VP))
            == (True, 'viewer'), 'r3e-viewer-no-symlink-accepted')
    class _R3eSubLoader(SourceFileLoader):
        pass
    ok(_genuine_source_loader(_R3eSubLoader(), genuine=SourceFileLoader) is False
       and _genuine_source_loader(None, genuine=SourceFileLoader) is False
       and _genuine_source_loader(SourceFileLoader, genuine=SourceFileLoader) is False
       and _genuine_source_loader(object(), genuine=SourceFileLoader) is False,
       'r3e-genuine-source-loader-helper-identity')
    ok(_genuine_source_loader(SourceFileLoader(), genuine=SourceFileLoader) is True,
       'r3e-genuine-source-loader-helper-accepts-injected-genuine')
    ok(_genuine_source_loader(SourceFileLoader(), genuine=int) is False,
       'r3e-genuine-source-loader-helper-refuses-other-class')

    # (b) the REAL finder, REAL specs (genuine SourceFileLoader), complete sequence
    try:
        import _frozen_importlib_external as _r3e_fe
    except BaseException:
        _r3e_fe = None
    if _r3e_fe is None:
        skip('r3e real-spec / real-finder checks (NOT RUN: _frozen_importlib_external '
             'unavailable on this interpreter)')
    else:
        _r3e_dir = None
        try:
            _cand = os.path.dirname(os.path.abspath(__file__))
            if (os.path.isfile(os.path.join(_cand, 'preview_viewer.py'))
                    and os.path.isfile(os.path.join(_cand, 'wizard.py'))):
                _r3e_dir = os.path.realpath(_cand)
        except BaseException:
            _r3e_dir = None
        _r3e_real = _r3e_dir is not None
        _r3e_pkg = _r3e_dir if _r3e_real else _T_PKG
        if not _r3e_real:
            skip('r3e real-finder checks use a LABELLED synthetic package path and a '
                 'real SourceFileLoader spec built for it (NOT RUN against the real '
                 'frozen viewer file and the real package-wide import scan: no verified '
                 'package folder holds the frozen viewer next to this script). The SAME '
                 'checks use the real frozen viewer file when --self-test is run from '
                 'the verified package folder.')

        class _R3eAdapter:
            def __init__(self, base):
                self._base = base
            def find_spec(self, fullname, path=None, target=None):
                return _r3e_fe.spec_from_file_location(
                    fullname, self._base + '/' + fullname + '.py')

        class _R3eFixed:
            def __init__(self, spec):
                self._spec = spec
            def find_spec(self, fullname, path=None, target=None):
                return self._spec

        def _r3e_drive(name, adapter=None, holder=None):
            if adapter is None:
                adapter = _R3eAdapter(_r3e_pkg)
            f = _OriginFinder(_T_ROOTS, [_r3e_pkg] if holder is None else holder,
                              _PRODUCT_MODULES, _T_STDLIB_NAMES, _T_BUILTINS,
                              meta_path=[adapter])
            f._loaded = set()
            try:
                return ('accepted', f.find_spec(name))
            except _RefusedImport as _e:
                return ('refused', _e.sanitized_name)

        _vspec = _r3e_fe.spec_from_file_location('preview_viewer',
                                                 _r3e_pkg + '/preview_viewer.py')
        ok(_genuine_source_loader(_vspec.loader) is True
           and loader_class_name(_vspec.loader) == 'SourceFileLoader'
           and _vspec.submodule_search_locations is None,
           'r3e-viewer-spec-is-a-genuine-SourceFileLoader-module-spec')
        # THE REGRESSION: the real finder must ACCEPT the real viewer spec. On the
        # R3D launcher this exact call raises package_local.
        ok(_r3e_drive('preview_viewer') == ('accepted', None),
           'r3e-REGRESSION-real-finder-accepts-the-frozen-viewer-spec')
        ok(_r3e_drive('preview_viewer', holder=[None]) == ('refused', 'viewer_unverified'),
           'r3e-real-finder-refuses-viewer-before-verification')
        ok(_r3e_drive('preview_viewer', adapter=_R3eAdapter(_r3e_pkg + '_other'))
           == ('refused', 'viewer_path_mismatch'),
           'r3e-real-finder-refuses-unverified-copy-in-another-folder')
        ok(_r3e_drive('preview_viewer', adapter=_R3eFixed(
            _r3e_fe.spec_from_file_location('preview_viewer', _r3e_pkg + '/sub/preview_viewer.py')))
           == ('refused', 'viewer_path_mismatch'), 'r3e-real-finder-refuses-viewer-in-subfolder')
        ok(_r3e_drive('preview_viewer', adapter=_R3eFixed(_r3e_fe.spec_from_file_location(
            'preview_viewer', _r3e_pkg + '/preview_viewer.py', loader=SourceFileLoader())))
           == ('refused', 'viewer_loader'), 'r3e-real-finder-refuses-counterfeit-named-loader')

        class SourceFileLoader_Sub(_r3e_fe.SourceFileLoader):
            pass
        SourceFileLoader_Sub.__name__ = 'SourceFileLoader'
        ok(_r3e_drive('preview_viewer', adapter=_R3eFixed(_r3e_fe.spec_from_file_location(
            'preview_viewer', _r3e_pkg + '/preview_viewer.py',
            loader=SourceFileLoader_Sub('preview_viewer', _r3e_pkg + '/preview_viewer.py'))))
           == ('refused', 'viewer_loader'), 'r3e-real-finder-refuses-subclass-named-SourceFileLoader')
        ok(_r3e_drive('preview_viewer', adapter=_R3eFixed(_r3e_fe.spec_from_file_location(
            'preview_viewer', _r3e_pkg + '/preview_viewer.py',
            loader=_r3e_fe.ExtensionFileLoader('preview_viewer', _r3e_pkg + '/preview_viewer.py'))))
           == ('refused', 'viewer_loader'), 'r3e-real-finder-refuses-extension-loader')
        ok_call(lambda: _r3e_with_islink(lambda p: p.endswith('/preview_viewer.py'),
                                         lambda: _r3e_drive('preview_viewer'))
                == ('refused', 'viewer_symlink'), 'r3e-real-finder-refuses-symlinked-viewer')
        for _nm in ('wizard', 'model', 'quick_reg', 'deploy_lib', 'native_gateway',
                    'bootstrap_lib'):
            ok(_r3e_drive(_nm) == ('accepted', None), 'r3e-real-finder-product-accepted:' + _nm)
        for _nm in ('smoke_preview', 'remote_agent', 'evil', 'preview_viewer_2',
                    'sitecustomize', 'usercustomize'):
            ok(_r3e_drive(_nm) == ('refused', 'package_local'),
               'r3e-real-finder-other-package-local-refused:' + _nm)
        for _nm in ('socket', 'ssl', 'paramiko', 'ctypes'):
            ok(_r3e_drive(_nm) == ('refused', _nm), 'r3e-real-finder-deny-wins:' + _nm)
        # complete package-local import sequence in the order _run / run_gui use it
        _seq_f = _OriginFinder(_T_ROOTS, [_r3e_pkg], _PRODUCT_MODULES, _T_STDLIB_NAMES,
                               _T_BUILTINS, meta_path=[_R3eAdapter(_r3e_pkg)])
        _seq_f._loaded = set()
        def _r3e_sequence():
            for _n in ('preview_viewer', 'wizard', 'deploy_lib', 'model',
                       'native_gateway', 'quick_reg', 'bootstrap_lib'):
                if _seq_f.find_spec(_n) is not None:
                    return False
            return True
        ok_call(_r3e_sequence, 'r3e-real-finder-complete-package-local-sequence-accepted')
        ok_call(lambda: newly_loaded_outside_rule(_BEFORE, _AFTER_CLEAN, _PRODUCT_MODULES,
                                                   _T_STDLIB_NAMES, _is_denied) == [],
                'r3e-post-run-delta-clean-after-viewer-in-snapshot')
        ok_call(lambda: 'preview_viewer' in _BEFORE, 'r3e-snapshot-taken-after-viewer-import')

        if _r3e_real:
            # the REAL frozen viewer file, the interpreter's own PathFinder, and a
            # scan of EVERY member's imports: any package-local import the policy
            # would refuse is found here, not on the first real run.
            _pf = _r3e_fe.PathFinder.find_spec('preview_viewer', [_r3e_pkg])
            ok(_pf is not None and _pf.origin == _r3e_pkg + '/preview_viewer.py'
               and _genuine_source_loader(_pf.loader) is True,
               'r3e-PathFinder-finds-the-real-frozen-viewer-file')
            ok(_r3e_drive('preview_viewer', adapter=_R3eFixed(_pf)) == ('accepted', None),
               'r3e-REGRESSION-real-finder-accepts-PathFinder-spec-of-real-viewer')
            import ast as _r3e_ast
            _allowed_local = set(_PRODUCT_MODULES) | {_VIEWER_MODULE}
            _all_local = set()
            _entry_imports = set()
            for _fn in sorted(os.listdir(_r3e_pkg)):
                if not _fn.endswith('.py'):
                    continue
                _fp = os.path.join(_r3e_pkg, _fn)
                if not os.path.isfile(_fp):
                    continue
                with open(_fp, 'rb') as _fh:
                    _tree = _r3e_ast.parse(_fh.read().decode('utf-8'))
                _imps = set()
                for _nd in _r3e_ast.walk(_tree):
                    if isinstance(_nd, _r3e_ast.Import):
                        for _al in _nd.names:
                            _imps.add(_al.name.split('.', 1)[0])
                    elif isinstance(_nd, _r3e_ast.ImportFrom):
                        if _nd.level == 0 and _nd.module:
                            _imps.add(_nd.module.split('.', 1)[0])
                _loc = set(n for n in _imps
                           if os.path.isfile(os.path.join(_r3e_pkg, n + '.py')))
                if _fn == 'view_preview_mac.py':
                    _entry_imports = _imps
                _all_local |= _loc
                ok(_loc <= _allowed_local, 'r3e-member-local-imports-are-policy-allowed:' + _fn)
            ok('preview_viewer' in _entry_imports,
               'r3e-the-launcher-imports-the-viewer (the import under test)')
            for _n in sorted(_all_local):
                ok(_r3e_drive(_n) == ('accepted', None),
                   'r3e-real-package-local-import-accepted-by-real-finder:' + _n)

    ok(checks - _r3e_checks_before >= 60, 'r3e-block-ran-expected-number-of-checks')

    # ----- summary -----
    with_source = src is not None
    if failed:
        print('SELFTEST FAIL - %d/%d checks failed; %d skipped (source=%s): %s'
              % (len(failed), checks, len(skipped),
                 'present' if with_source else 'absent', ', '.join(failed)))
        return 1
    print('SELFTEST PASS - %d checks; %d skipped/NOT RUN (source=%s)'
          % (checks, len(skipped), 'present' if with_source else 'absent'))
    for s in skipped:
        print('  SKIP/NOT RUN: ' + s)
    return 0


# A tiny loader stand-in whose class name matches the accepted SourceFileLoader
# kind, for the stub-driven finder checks (we cannot import importlib.machinery
# in the replay sandbox; the origin finder matches loader by CLASS NAME string).
class SourceFileLoader:  # noqa: D401 - name chosen to match classify_origin
    pass


def _SourceLoaderStub():
    return SourceFileLoader()


def _refuses_pkg(fn):
    """Return True iff fn() raises _PackageIntegrity."""
    try:
        fn()
        return False
    except _PackageIntegrity:
        return True


if __name__ == '__main__':
    sys.exit(main())
