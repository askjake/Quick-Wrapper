"""AQ-MCP Connector Wizard v0.4, local desktop UI (tkinter).
No web listener, no Quick database mutations, no saved PATs or passwords.

MERGE NOTE (2026-10-20): this file is the v0.3.1 safety-hardened wizard (S2 Git/Local
refusal on a wizard-bootstrapped host, S4 confirmation parity, S5 plain-language plan
summary, S7 redacted-by-default Copy/Export with a FULL-variant warning, bootstrap
receipt save/load, 0600 receipts) with the v0.4 native-local feature re-applied on top
(transport selector, NativeGateway, quick_copy_fields Command/Arguments panel, native
bootstrap/inspect flow, GUI smoke hooks). Where the two sides interact the SAFER
behaviour is kept and marked inline with an [S2]/[S4]/[S5]/[S7] / [v04] tag.
"""
import json
import os
import threading
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

from deploy_lib import SSHGateway, ConnectorDeployer, DeploymentError
from native_gateway import NativeGateway
from model import (validate_gateway, validate_spec, validate_spec_for_host, ValidationError,
                   quick_connector, config_export, backend_identity, risk_tool_names,
                   host_is_wizard_lambda_only, plain_language_summary, mutating_confirm_text,
                   secure_write_json, FULL_VARIANT_WARNING, RedactionError)
from quick_reg import (quick_instructions, quick_instructions_variants,
                       write_quick_config, inspect_dips_read_only, quick_copy_fields)

# Single source of truth for the wizard version string (shown in the title bar and
# wherever a version is referenced in the UI). Bump this one place on a release.
WIZARD_VERSION='v0.4'

BG='#101826'
PANEL='#1B2738'
FG='#EDF2FA'
SOFT='#AFC0D1'
ACCENT='#56C5E6'

class Wizard(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('AQ-MCP Connector Wizard  \u2022  '+WIZARD_VERSION)
        self.geometry('970x710')
        self.minsize(760,620)
        self.configure(bg=BG)
        self.style=ttk.Style(self)
        self.style.theme_use('clam')
        self.style.configure('TFrame',background=BG)
        self.style.configure('TLabel',background=BG,foreground=FG,font=('Segoe UI',10))
        self.style.configure('Muted.TLabel',background=BG,foreground=SOFT,font=('Segoe UI',9))
        self.style.configure('Heading.TLabel',background=BG,foreground=FG,font=('Segoe UI Semibold',16))
        self.style.configure('TButton',padding=(13,8),font=('Segoe UI',10))
        self.style.configure('TEntry',fieldbackground='white',foreground='#101826')
        self.style.configure('TCombobox',fieldbackground='white',foreground='#101826')
        self.style.configure('TCheckbutton',background=BG,foreground=FG)
        self.step=0
        self.prepared=None
        # S2: a bootstrap receipt THIS wizard produced/loaded for the current host.
        # When it proves a wizard Lambda-only bootstrap, Git/Local are disabled & refused.
        self.bootstrap_receipt=None
        self.last_receipt=None
        self.last_gateway=None
        self.discovered=[]
        self.gateway_inspection=None
        self.backend_verification=None
        self.busy=False
        self.vars={
            'host':tk.StringVar(), 'user':tk.StringVar(),
            'known_hosts':tk.StringVar(value=os.path.expanduser('~/.ssh/known_hosts')),
            'transport':tk.StringVar(value='linux-ssh'),
            'kind':tk.StringVar(value='lambda'), 'target':tk.StringVar(value='epg-demo'),
            'display_name':tk.StringVar(value='AQ EPG Demo'),
            'url':tk.StringVar(), 'server':tk.StringVar(value='aq_build_artifacts_mcp.py')}
        self.screens=['Gateway','Backend','Tool policy','Review & deploy','Quick registration']
        self.heading=ttk.Frame(self,padding=(24,18));self.heading.pack(fill='x')
        ttk.Label(self.heading,text='AQ-MCP  /  CONNECTOR WIZARD',style='Muted.TLabel').pack(anchor='w')
        ttk.Label(self.heading,text='Build a verified MCP connector',style='Heading.TLabel').pack(anchor='w',pady=(6,0))
        self.pill=ttk.Label(self.heading,text='PLAN FIRST  \u2022  NO QUICK DATABASE WRITES',style='Muted.TLabel')
        self.pill.pack(anchor='w',pady=(7,0))
        self.step_label=ttk.Label(self,text='',style='Muted.TLabel')
        self.step_label.pack(anchor='w',padx=25)
        self.body=ttk.Frame(self,padding=(26,18)); self.body.pack(fill='both',expand=True)
        foot=ttk.Frame(self,padding=(24,8))
        foot.pack(fill='x',side='bottom')
        self.back_btn=ttk.Button(foot,text='\u2190 Back',command=self.go_back);self.back_btn.pack(side='left')
        self.next_btn=ttk.Button(foot,text='Continue \u2192',command=self.go_next);self.next_btn.pack(side='right')
        self.status=ttk.Label(foot,text='Ready',style='Muted.TLabel')
        self.status.pack(side='right',padx=15)
        self.render()

    def field(self,parent,label,key,placeholder=None):
        ttk.Label(parent,text=label).pack(anchor='w',pady=(12,5))
        e=ttk.Entry(parent,textvariable=self.vars[key],width=90)
        e.pack(fill='x')
        return e

    def helper(self,parent,text):
        ttk.Label(parent,text=text,style='Muted.TLabel',wraplength=840,justify='left').pack(anchor='w',pady=7)

    def text_area(self,parent,height=8):
        holder=ttk.Frame(parent)
        holder.pack(fill='both',expand=True,pady=8)
        scroll=ttk.Scrollbar(holder,orient='vertical')
        scroll.pack(side='right',fill='y')
        t=tk.Text(holder,height=height,wrap='word',background=PANEL,foreground=FG,
                  insertbackground=FG,relief='flat',font=('Consolas',10),padx=12,pady=12,
                  yscrollcommand=scroll.set)
        t.pack(side='left',fill='both',expand=True)
        scroll.config(command=t.yview)
        return t

    def render(self):
        for item in self.body.winfo_children():item.destroy()
        self.step_label.config(text='   /   '.join(('[{}] {}'.format(i+1,n) if i==self.step else '{} {}'.format(i+1,n)) for i,n in enumerate(self.screens)))
        self.back_btn.config(state='disabled' if self.step==0 else 'normal')
        self.next_btn.config(text='Finish' if self.step==4 else 'Continue \u2192')
        if self.step==0:self.render_gateway()
        elif self.step==1:self.render_backend()
        elif self.step==2:self.render_tools()
        elif self.step==3:self.render_review()
        else:self.render_quick()

    def render_gateway(self):
        # [v04] transport selector: native localhost (no SSH/admin) vs the existing Linux
        # SSH jump server. [S2] install/repair approvals and the create-only inspect flow
        # from v0.3.1 are preserved below.
        ttk.Label(self.body,text='01  Select gateway location',style='Heading.TLabel').pack(anchor='w')
        self.helper(self.body,'Use native localhost on Windows with NO SSH server or admin rights, or keep your existing Linux SSH jump server. Native localhost does not open an inbound port.')
        selector=ttk.Frame(self.body);selector.pack(anchor='w',pady=6)
        for label,value in [('Linux SSH jump server (existing v0.3 workflow)','linux-ssh'),
                            ('Native gateway on THIS computer (no SSH/admin)','native-local')]:
            ttk.Radiobutton(selector,text=label,value=value,variable=self.vars['transport'],
                            command=self.transport_changed).pack(anchor='w')
        if self.vars['transport'].get()=='linux-ssh':
            self.helper(self.body,'Strict SSH host-key verification. Inspect first: a missing gateway can be installed; an existing group-writable gateway can be reviewed and repaired with explicit approval. No existing runtime is overwritten. 127.0.0.1 is valid if your own computer runs Linux SSH.')
            self.field(self.body,'Jump server hostname / IP','host')
            self.field(self.body,'Remote SSH username','user')
            self.field(self.body,'Local known_hosts path','known_hosts')
        else:
            self.helper(self.body,'Native gateway folder: ~/AQ-MCP-Gateway. Runs under your current Windows account and uses its own venv. Linux/macOS native-local is experimental. No WSL2, Docker, SSH daemon or admin rights required for Lambda targets.')
        buttons=ttk.Frame(self.body);buttons.pack(anchor='w',pady=(16,4))
        ttk.Button(buttons,text='Inspect gateway (read only)',command=self.inspect_action).pack(side='left',padx=(0,8))
        ttk.Button(buttons,text='Install missing gateway',command=self.bootstrap_action).pack(side='left',padx=(0,8))
        # [v04] permission repair is a Linux SSH-only operation; hide it in native-local.
        if self.vars['transport'].get()=='linux-ssh':
            ttk.Button(buttons,text='Repair core permissions',command=self.repair_action).pack(side='left',padx=(0,8))
            ttk.Button(buttons,text='Load bootstrap receipt',command=self.load_bootstrap_receipt_action).pack(side='left',padx=(0,8))
            ttk.Button(buttons,text='Save bootstrap receipt',command=self.save_bootstrap_receipt_action).pack(side='left')
        self.helper(self.body,'Fresh install is create-only and needs approved Python package downloads. AWS credentials are configured separately; no PATs or Quick database writes. Existing installations are never overwritten. Permission repair removes group/world write on owned core files only (may affect shared workflows).')
        self.gateway_result=self.text_area(self.body,9)
        self.gateway_result.insert('1.0','Click Inspect. A missing gateway can be installed only with approval; core permission repair is separate.')

    def render_backend(self):
        ttk.Label(self.body,text='02  Select MCP backend',style='Heading.TLabel').pack(anchor='w')
        self.helper(self.body,'Choose the approved backend. Native-local v0.4 supports SigV4 Lambda; Git and existing local servers remain Linux SSH-only.')
        group=ttk.Frame(self.body);group.pack(fill='x',pady=8)
        # S2: a host THIS wizard bootstrapped carries the Lambda lane only; disable the
        # Git and Build Artifacts options and say why. Decided only from held state
        # (self.bootstrap_receipt), never guessed from the remote.
        lambda_only=host_is_wizard_lambda_only(self.bootstrap_receipt)
        if lambda_only and self.vars['kind'].get() in ('git','local'):
            self.vars['kind'].set('lambda')
        # [v04] native-local offers the Lambda lane only (Git/local stay Linux SSH). This
        # is a superset of the S2 constraint, so when BOTH apply the result is still
        # Lambda-only; neither safety rule is weakened.
        modes=[('AWS Lambda Function URL (SigV4)','lambda')]
        if self.vars['transport'].get()=='linux-ssh':
            modes += [('Guarded Git MCP (existing)','git'),('Local approved MCP (existing)','local')]
        if self.vars['transport'].get()=='native-local' and self.vars['kind'].get() in ('git','local'):
            self.vars['kind'].set('lambda')
        for label,value in modes:
            rb=ttk.Radiobutton(group,text=label,value=value,variable=self.vars['kind'],command=self.kind_changed)
            rb.pack(anchor='w',pady=4)
            if lambda_only and value in ('git','local'):
                rb.configure(state='disabled')
        if self.vars['transport'].get()=='native-local':
            self.helper(self.body,'Native-local supports SigV4 Lambda only; Git and existing local servers are Linux SSH-only.')
        elif lambda_only:
            self.helper(self.body,'This host was bootstrapped by the wizard with the Lambda '
                        'lane only; the Git and Build Artifacts launchers are not installed.')
        self.field(self.body,'Registry / Git target name','target')
        self.field(self.body,'Quick connector display name','display_name')
        if self.vars['kind'].get()=='lambda':
            self.field(self.body,'AWS Lambda Function URL (HTTPS, IAM-authorized)','url')
            self.helper(self.body,'Example: https://EXAMPLE.lambda-url.us-west-2.on.aws/mcp. No other HTTP domains are permitted by this proxy.')
        elif self.vars['kind'].get()=='git':
            self.helper(self.body,'Choose existing gateway target github-ghes or gitlab. The wizard never edits Docker images, token stores, or branch guards.')
            ttk.Button(self.body,text='Use github-ghes',command=lambda:self.vars['target'].set('github-ghes')).pack(anchor='w')
            ttk.Button(self.body,text='Use gitlab',command=lambda:self.vars['target'].set('gitlab')).pack(anchor='w')
        else:
            self.helper(self.body,'Local mode registers an existing local target such as build-artifacts; it cannot execute arbitrary scripts.')
            ttk.Button(self.body,text='Use build-artifacts',command=lambda:self.vars['target'].set('build-artifacts')).pack(anchor='w')
        ttk.Button(self.body,text='Test / Verify Backend (MCP handshake)',command=self.verify_backend_action).pack(anchor='w',pady=(15,7))
        self.backend_result=self.text_area(self.body,7)
        v=self.backend_verification
        if v and v.get('backend_identity_sha256')==backend_identity(self.spec()):
            self.backend_result.insert('1.0',self.describe_backend(v))
        else:
            self.backend_result.insert('1.0','Not verified. Test the selected backend before continuing.\n'
                                       'The check requests MCP initialize + tools/list, but does not execute application tools.\n'
                                       'Git/local verification starts the existing approved MCP launcher.')

    def describe_backend(self,report):
        lines=['STATUS: '+report['status'],
               'Registry target: '+('EXISTING (registration-only)' if report.get('existing_target') else 'NEW (eligible for create-only install)'),
               'Handshake: '+report['handshake'],
               'Offered tools: '+str(report['tool_count']),
               'Backend identity: '+report['backend_identity_sha256'][:20]+'...',
               'Verification only: no application tool calls.']
        for warning in report.get('warnings',[]):lines.append('WARNING: '+warning)
        if report.get('potentially_mutating_tools_name_only'):
            lines.append('REVIEW potential mutators (name-based guess, NOT a safety verdict):')
            lines.extend('  - '+name for name in report['potentially_mutating_tools_name_only'])
        lines.extend('  '+t['name'] for t in report['tools'])
        return '\n'.join(lines)

    def verify_backend_action(self):
        spec=self.spec()
        # Backend verification does not require choosing tool policy yet.
        if spec['kind']=='lambda':spec['allow']=['verification-placeholder']
        def done(ok,result):
            if not ok:
                self.backend_verification=None
                messagebox.showerror('Backend verification failed',str(result))
                if self.step==1:self.backend_result.delete('1.0','end');self.backend_result.insert('1.0','FAILED: '+str(result))
                return
            if result.get('backend_identity_sha256')!=backend_identity(self.spec()):
                self.backend_verification=None
                messagebox.showwarning('Inputs changed','The selected backend changed while verification was running. Test again.');return
            self.backend_verification=result
            self.prepared=None
            if self.vars['kind'].get()=='lambda':
                self.discovered=list(result['tools'])
                self.tool_selection=list(result.get('existing_allow') or [])
            if self.step==1:
                self.backend_result.delete('1.0','end')
                self.backend_result.insert('1.0',self.describe_backend(result))
            messagebox.showinfo('Backend verification','MCP tools/list succeeded: {} tool(s).\n'
                                'Review warnings and choose the allowed tools next.'.format(result['tool_count']))
        self.action(lambda:ConnectorDeployer(self.gateway()).verify_backend(spec),done)

    def transport_changed(self):
        # [v04] switching transport resets verification/plan state; native-local forces the
        # Lambda lane (Git/local are Linux SSH-only).
        self.gateway_inspection=None
        self.backend_verification=None
        self.prepared=None
        self.discovered=[]
        self.tool_selection=[]
        if self.vars['transport'].get()=='native-local':
            self.vars['kind'].set('lambda')
        self.render()

    def kind_changed(self):
        self.prepared=None
        self.backend_verification=None
        self.discovered=[]
        self.tool_selection=[]
        k=self.vars['kind'].get()
        self.vars['target'].set({'lambda':'epg-demo','git':'github-ghes','local':'build-artifacts'}[k])
        self.render()

    def render_tools(self):
        ttk.Label(self.body,text='03  Tool discovery and allow-list',style='Heading.TLabel').pack(anchor='w')
        if self.vars['kind'].get()!='lambda':
            self.helper(self.body,'This backend is already registered on the gateway. Its existing Git guard / local tool policy is not modified.')
            return
        self.helper(self.body,'Discover tools through the chosen gateway (MCP initialize + tools/list only). Check exact tools to expose. An empty list is prohibited because the current proxy treats empty as ALL.')
        ttk.Button(self.body,text='Re-test / refresh backend tool list',command=self.discover_action).pack(anchor='w',pady=6)
        self.helper(self.body,'WARNING: Tool names and descriptions are not safety guarantees. An EPG label with Alerts/export tools may indicate the wrong Lambda URL.')
        self.tool_box=tk.Listbox(self.body,selectmode='multiple',height=12,exportselection=False,
                                 bg=PANEL,fg=FG,selectbackground='#28617D',
                                 selectforeground='white',font=('Consolas',10),relief='flat')
        self.tool_box.pack(fill='both',expand=True,pady=10)
        for i,t in enumerate(self.discovered):
            self.tool_box.insert('end',t['name']+'   '+t.get('description','')[:85])
            if t['name'] in getattr(self,'tool_selection',[]): self.tool_box.selection_set(i)
        self.helper(self.body,'Select explicitly. An actual deployment will rediscover and verify every selected name before writing.')
        if self.backend_verification:
            for warning in self.backend_verification.get('warnings',[]):self.helper(self.body,'WARNING: '+warning)

    def show_quick_copy_fields(self, parent, connector):
        """[v04] Expose Quick Command and Arguments separately, with copy buttons."""
        for child in parent.winfo_children():
            child.destroy()
        if not connector:
            ttk.Label(parent, text='Quick Command / Arguments appear here after plan generation.',
                      style='Muted.TLabel').pack(anchor='w')
            return
        try:
            values=quick_copy_fields(connector)
        except ValueError as exc:
            ttk.Label(parent, text='Cannot format Quick settings: '+str(exc),
                      style='Muted.TLabel').pack(anchor='w')
            return
        ttk.Label(parent, text='COPY INTO AMAZON QUICK (Local connector)',
                  style='Muted.TLabel').pack(anchor='w', pady=(3,4))
        for label,key in [('Command','command'),('Arguments (paste entire line)','arguments')]:
            ttk.Label(parent,text=label).pack(anchor='w',pady=(5,2))
            row=ttk.Frame(parent);row.pack(fill='x')
            field=ttk.Entry(row)
            field.insert(0,values[key]);field.configure(state='readonly')
            field.pack(side='left',fill='x',expand=True)
            ttk.Button(row,text='Copy '+('command' if key=='command' else 'arguments'),
                       command=lambda value=values[key]:self.copy_text(value)).pack(side='left',padx=(8,0))
        self.helper(parent,'Quick ID: {}  |  Name: {}  |  Timeout: {} s  |  Environment: EMPTY'.format(
                    values['id'],values['name'],values['timeout_seconds']))

    def render_review(self):
        ttk.Label(self.body,text='04  Plan, deploy and verify',style='Heading.TLabel').pack(anchor='w')
        self.helper(self.body,'The verified backend and selected tools produce a plan automatically. The live registry is checked before approval; Apply is locked until planning finishes.')
        controls=ttk.Frame(self.body);controls.pack(fill='x',pady=6)
        ttk.Button(controls,text='Refresh deployment plan',command=self.plan_action).pack(side='left',padx=(0,10))
        ttk.Button(controls,text='Deploy approved plan',command=self.deploy_action).pack(side='left',padx=(0,10))
        ttk.Button(controls,text='Rollback last deployment',command=self.rollback_action).pack(side='left',padx=(0,10))
        ttk.Button(controls,text='Save receipt',command=self.save_receipt_action).pack(side='left')
        # [v04] Command / Arguments panel for the generated connector, with Copy buttons.
        self.quick_copy_area=ttk.Frame(self.body);self.quick_copy_area.pack(fill='x',pady=(6,10))
        self.show_quick_copy_fields(self.quick_copy_area, (self.prepared or {}).get('quick_connector'))
        # S5: plain-language summary a non-expert can read BEFORE approving a deploy.
        ttk.Label(self.body,text='Plain-language summary',style='Muted.TLabel').pack(anchor='w',pady=(4,0))
        self.summary_view=self.text_area(self.body,8)
        self.summary_view.insert('1.0',self.summary_text())
        self.summary_view.configure(state='disabled')
        self.plan_view=self.text_area(self.body,12)
        if self.prepared:self.plan_view.insert('1.0',json.dumps(self.prepared,indent=2))
        else:self.plan_view.insert('1.0','Generating a deployment plan automatically from verified backend and selected tools...')
        self.after(75,self.auto_plan)

    def summary_text(self):
        """S5: render the plain-language deploy summary from the current plan (or a wait note)."""
        if not self.prepared:
            return ('The plain-language summary will appear here once the deployment plan '
                    'has been generated from the verified backend and your selected tools.')
        discovered=None
        if self.backend_verification and self.backend_verification.get('backend_identity_sha256')==backend_identity(self.spec()):
            discovered=self.backend_verification.get('tool_count')
        try:
            return plain_language_summary(self.spec(),self.prepared,discovered_count=discovered)
        except Exception as e:
            return 'Summary unavailable: '+str(e)

    def render_quick(self):
        ttk.Label(self.body,text='05  Register in Amazon Quick',style='Heading.TLabel').pack(anchor='w')
        self.helper(self.body,'Gateway deployment and Quick Desktop registration are separate steps. Native-local uses direct Python (no SSH); Linux SSH uses ssh. This version NEVER writes to the DIPS database; its schema and supported registration lifecycle are unverified.')
        try:
            variants=quick_instructions_variants(self.spec())
            # On-screen we show the FULL text because the user runs this command on their
            # own machine; the Copy buttons below choose redacted (default) vs full.
            msg=variants['full']
        except Exception as e:
            variants=None;msg='Complete prior steps: '+str(e)
        self._quick_variants=variants
        # [v04] Command / Arguments panel for the live connector (SSH or native-local).
        self.quick_copy_area=ttk.Frame(self.body);self.quick_copy_area.pack(fill='x',pady=(5,10))
        try:self.show_quick_copy_fields(self.quick_copy_area,quick_connector(self.spec()))
        except Exception:self.show_quick_copy_fields(self.quick_copy_area,None)
        self.manual=self.text_area(self.body,12)
        self.manual.insert('1.0',msg)
        controls=ttk.Frame(self.body);controls.pack(fill='x',pady=12)
        ttk.Button(controls,text='Copy Quick settings (redacted)',command=self.copy_quick_redacted).pack(side='left',padx=(0,10))
        ttk.Button(controls,text='Copy FULL (real login/host)',command=self.copy_quick_full).pack(side='left',padx=(0,10))
        ttk.Button(controls,text='Export JSON example (redacted)',command=self.export_action).pack(side='left',padx=(0,10))
        ttk.Button(controls,text='Export FULL JSON',command=self.export_full_action).pack(side='left',padx=(0,10))
        ttk.Button(controls,text='Inspect DIPS schema (read-only)',command=self.dips_action).pack(side='left')
        self.helper(self.body,'After saving in Quick, open a NEW Quick chat, verify tools/list or a harmless read, and review per-tool permission settings. Registration status: MANUAL_REQUIRED.')

    def auto_plan(self):
        if self.step != 3 or self.busy:return
        current=self.spec()
        if self.prepared and self.prepared.get('backend_identity_sha256')==backend_identity(current):
            if current['kind']!='lambda' or self.prepared.get('registry_entry',{}).get('allow')==sorted(current.get('allow',[])):
                return
        self.plan_action()

    def spec(self):
        spec={k:v.get().strip() for k,v in self.vars.items() if k!='known_hosts'}
        # [v04] native-local pins the loopback host and a fixed local user so no SSH
        # login/hostname is ever required or stored for a native gateway.
        if spec.get('transport')=='native-local':
            spec['host']='127.0.0.1'
            spec['user']='local'
        if spec['kind']=='lambda':
            if hasattr(self,'tool_box') and self.tool_box.winfo_exists():
                spec['allow']=[self.discovered[int(i)]['name'] for i in self.tool_box.curselection()]
            elif hasattr(self,'tool_selection'):
                spec['allow']=list(self.tool_selection)
            else: spec['allow']=[]
        return spec

    def save_selection(self):
        if self.step==2 and self.vars['kind'].get()=='lambda' and hasattr(self,'tool_box'):
            self.tool_selection=[self.discovered[int(i)]['name'] for i in self.tool_box.curselection()]
        if self.step==1: self.prepared=None

    def gateway(self):
        spec=self.spec()
        validate_gateway(spec['host'],spec['user'])
        # [v04] native-local uses the user-owned local gateway (no SSH object built).
        if spec.get('transport')=='native-local':return NativeGateway()
        return SSHGateway(spec['host'],spec['user'],self.vars['known_hosts'].get().strip())

    def action(self,task,callback=None):
        if self.busy:return
        self.busy=True
        self.back_btn.config(state='disabled');self.next_btn.config(state='disabled')
        self.status.config(text='Working\u2026')
        self.configure(cursor='watch')
        def run():
            try:result=task();ok=True
            except Exception as e:result=str(e);ok=False
            def done():
                self.busy=False
                self.configure(cursor='');self.status.config(text='Ready' if ok else 'Operation failed')
                self.back_btn.config(state='disabled' if self.step==0 else 'normal');self.next_btn.config(state='normal')
                if callback:callback(ok,result)
                elif not ok:messagebox.showerror('Operation failed',result)
            self.after(0,done)
        threading.Thread(target=run,daemon=True).start()

    def inspect_action(self):
        def done(ok,result):
            self.gateway_result.delete('1.0','end')
            self.gateway_inspection=result if ok else None
            self.gateway_result.insert('1.0',json.dumps(result,indent=2) if ok else result)
        self.action(lambda:ConnectorDeployer(self.gateway()).inspect(),done)

    def bootstrap_action(self):
        state=self.gateway_inspection
        if not state or state.get('state')!='MISSING':
            messagebox.showerror('Inspect first','Only a confirmed missing gateway can be installed. Click Inspect first.');return
        # [v04] native vs SSH install wording; both are create-only and never overwrite.
        location=('a new user-owned ~/AQ-MCP-Gateway on THIS computer' if self.vars['transport'].get()=='native-local' else 'a new PRIVATE ~/aq-mcp gateway on this Linux SSH server')
        if not messagebox.askyesno('Install new gateway',
            'Install '+location+'?\n\n'
            'This installs reviewed gateway Python sources and downloads pinned packages using the jump server configured pip index. '
            'No existing installation will be overwritten. AWS credentials are NOT created.\n\nProceed?'):
            return
        self.action(lambda:ConnectorDeployer(self.gateway()).bootstrap(approved=True),
                    lambda ok,result:self.install_done(ok,result))

    def repair_action(self):
        state=self.gateway_inspection
        if not state or state.get('state')!='PERMISSIONS_NEED_REPAIR':
            messagebox.showerror('Inspect first','Permission repair requires an inspected owned gateway with unsafe core-file modes.');return
        names=', '.join(x['file'] for x in state['mode_issues'])
        if not messagebox.askyesno('Change access modes',
            'Remove group/world WRITE permission from these owned gateway files:\n'+names+'\n\n'
            'This may affect other users or shared workflows. No unrelated files are changed. Continue?'):
            return
        self.action(lambda:ConnectorDeployer(self.gateway()).repair_permissions(state,approved=True),
                    lambda ok,result:self.install_done(ok,result))

    def install_done(self,ok,result):
        if not ok:
            messagebox.showerror('Gateway action failed',str(result));return
        self.gateway_inspection=None
        # S2: if this was a wizard bootstrap, remember it so Git/Local are disabled/refused.
        if host_is_wizard_lambda_only(result):
            self.bootstrap_receipt=result
        messagebox.showinfo('Gateway action',json.dumps(result,indent=2)[:2000]+'\n\nInspect again before deploying a target.')
        self.inspect_action()

    def load_bootstrap_receipt_action(self):
        """S2: let the user point the wizard at a bootstrap receipt the wizard wrote.
        Only a receipt that proves a wizard Lambda-only bootstrap takes effect; anything
        else is ignored (we never guess a host is Lambda-only)."""
        path=filedialog.askopenfilename(title='Select a wizard bootstrap receipt (JSON)',
                                        filetypes=[('JSON','*.json')])
        if not path:return
        try:
            with open(path,'r',encoding='utf-8') as fp:receipt=json.load(fp)
        except Exception as e:
            messagebox.showerror('Could not read receipt',str(e));return
        if host_is_wizard_lambda_only(receipt):
            self.bootstrap_receipt=receipt
            messagebox.showinfo('Bootstrap receipt loaded',
                'This host is marked as wizard-bootstrapped (Lambda lane only). The Git and '
                'Build Artifacts options are now disabled.')
            if self.step==1:self.render()
        else:
            messagebox.showwarning('Not a wizard Lambda-only bootstrap receipt',
                'This file is not a wizard Lambda-only bootstrap receipt; it was ignored. '
                'Git/Local options are unchanged.')

    def discover_action(self):
        sp=self.spec();sp['allow']=['discovery-placeholder']
        def done(ok,result):
            if not ok:
                self.backend_verification=None;self.discovered=[];self.tool_selection=[]
                messagebox.showerror('Discovery failed',result);return
            self.backend_verification=result
            self.prepared=None
            self.discovered=list(result['tools']);self.tool_selection=list(result.get('existing_allow') or [])
            self.render()
            messagebox.showinfo('Discovery','{} tools returned. Select exact tools, and review the potential mutators.'.format(len(self.discovered)))
        self.action(lambda:ConnectorDeployer(self.gateway()).verify_backend(sp),done)

    def plan_action(self):
        spec=self.spec()
        if not self.backend_verification or self.backend_verification.get('backend_identity_sha256')!=backend_identity(spec):
            self.prepared=None
            messagebox.showerror('Backend not verified','Return to Step 2 and test the selected backend before generating a plan.');return
        def done(ok,result):
            if not ok:
                self.prepared=None;self.plan_view.delete('1.0','end');self.plan_view.insert('1.0','Plan failed: '+str(result))
                messagebox.showerror('Plan failed',str(result));return
            if result.get('backend_identity_sha256')!=backend_identity(self.spec()):
                self.prepared=None;messagebox.showerror('Plan stale','The backend fields changed; regenerate the plan.');return
            result['verification_summary']={'status':'BACKEND_VERIFIED',
                'handshake':self.backend_verification['handshake'],
                'offered_tool_count':self.backend_verification['tool_count'],
                'offered_name_sha256':__import__('hashlib').sha256(','.join(sorted(x['name'] for x in self.backend_verification['tools'])).encode()).hexdigest()}
            self.prepared=result
            # [v04] refresh the Command/Arguments panel from the freshly generated plan.
            self.show_quick_copy_fields(self.quick_copy_area,result.get('quick_connector'))
            self.plan_view.delete('1.0','end');self.plan_view.insert('1.0',json.dumps(result,indent=2))
            self.refresh_summary_view()
        self.action(lambda:ConnectorDeployer(self.gateway()).prepare(spec),done)

    def refresh_summary_view(self):
        """S5: keep the on-screen summary in step with the latest plan."""
        view=getattr(self,'summary_view',None)
        if view is None or not view.winfo_exists():return
        view.configure(state='normal')
        view.delete('1.0','end');view.insert('1.0',self.summary_text())
        view.configure(state='disabled')

    def deploy_action(self):
        if not self.prepared:messagebox.showerror('Plan first','Wait for the automatically generated deployment plan first.');return
        spec=self.spec();prepared=dict(self.prepared)
        if prepared.get('backend_identity_sha256')!=backend_identity(spec) or prepared.get('quick_connector')!=quick_connector(spec):
            messagebox.showerror('Stale plan','Backend/connector settings changed. Refresh the plan before deployment.');return
        if spec['kind']=='lambda' and (prepared.get('registry_entry') or {}).get('allow')!=sorted(spec.get('allow',[])):
            messagebox.showerror('Stale tool policy','Tool selection changed. Refresh the plan before deployment.');return
        try:
            # S2: refuse Git/Local on a host THIS wizard bootstrapped (Lambda lane only).
            validate_spec_for_host(spec,self.bootstrap_receipt)
        except Exception as exc:messagebox.showerror('Validation',str(exc));return
        risky=prepared.get('potentially_mutating_tools_name_only',[])
        # S4 parity: identical mutating-tool warning text as the CLI apply path.
        if risky and not messagebox.askyesno('Review selected tools',mutating_confirm_text(risky)):
            return
        if prepared.get('warnings') and not messagebox.askyesno('Backend warnings',
            '\n'.join(prepared['warnings'])+'\n\nConfirm this is the correct endpoint and tool set?'):
            return
        # S5: show the plain-language summary in the final approval dialog, before confirm.
        # [v04] wording covers either transport (native-local gateway or SSH jump server).
        target_phrase=('on the native gateway on this computer' if spec.get('transport')=='native-local'
                       else 'on the approved jump server')
        if not messagebox.askyesno('Approve gateway change',
             self.summary_text()+'\n\nDeploy only {} {} now?'.format(spec['target'],target_phrase)):
            return
        gw=self.gateway()
        def done(ok,result):
            if not ok:messagebox.showerror('Deployment failed',result);return
            self.last_receipt=result;self.last_gateway=gw
            # [v04] surface the live Command/Arguments for copy/paste into Quick.
            connector=result.get('quick_connector') or prepared.get('quick_connector')
            self.show_quick_copy_fields(self.quick_copy_area,connector)
            try:
                fields=quick_copy_fields(connector)
                paste='QUICK COMMAND (COPY/PASTE):\n'+fields['command']+'\n\nQUICK ARGUMENTS (PASTE ENTIRE LINE):\n'+fields['arguments']+'\n\n'
            except Exception:
                paste=''
            self.plan_view.delete('1.0','end');self.plan_view.insert('1.0',paste+json.dumps(result,indent=2))
            messagebox.showinfo('Gateway result',result['status']+'\n\nQuick Command and Arguments are available above the receipt, with separate Copy buttons.\nQuick registration remains manual.')
        self.action(lambda:ConnectorDeployer(gw).deploy(spec,prepared,True),done)

    def save_receipt_action(self):
        # [v04] native receipts use backup_file; SSH receipts use backup_name. Accept either.
        if not self.last_receipt or not (self.last_receipt.get('backup_name') or self.last_receipt.get('backup_file')):
            messagebox.showerror('No deployment receipt','Deploy a new Lambda target before saving a receipt.');return
        path=filedialog.asksaveasfilename(title='Save private rollback receipt',
                                          defaultextension='.json',filetypes=[('JSON','*.json')])
        if not path:return
        try:
            # B2b S7: owner-only (0600), create-only. The receipt holds the real gateway
            # address (needed for rollback) so it is NOT redacted, but it IS mode-locked.
            secure_write_json(path,self.last_receipt)
            messagebox.showinfo('Receipt saved','Keep this file internal: it includes the gateway/connector address. '
                'Saved with owner-only permissions (POSIX 0600; on Windows the read-only attribute only).')
        except Exception as e:messagebox.showerror('Could not save receipt',str(e))

    def save_bootstrap_receipt_action(self):
        """B2b S2 follow-up: persist the held bootstrap receipt so S2 state survives across
        sessions. Only a receipt that proves a wizard Lambda-only bootstrap is written; it is
        saved with S7 permissions and reloads through 'Load bootstrap receipt'."""
        receipt=self.bootstrap_receipt
        if not host_is_wizard_lambda_only(receipt):
            messagebox.showerror('No bootstrap receipt to save',
                'Bootstrap this host (or load a wizard bootstrap receipt) first. Only a wizard '
                'Lambda-only bootstrap receipt can be saved.');return
        path=filedialog.asksaveasfilename(title='Save wizard bootstrap receipt (JSON)',
                                          defaultextension='.json',filetypes=[('JSON','*.json')])
        if not path:return
        try:
            secure_write_json(path,receipt)
            messagebox.showinfo('Bootstrap receipt saved',
                'Saved with owner-only permissions. Load it with "Load bootstrap receipt" next '
                'session to keep Git/Local disabled on this Lambda-only host.')
        except Exception as e:messagebox.showerror('Could not save bootstrap receipt',str(e))

    def rollback_action(self):
        # [v04] accept native (backup_file) or SSH (backup_name) receipts.
        if not self.last_receipt or not (self.last_receipt.get('backup_name') or self.last_receipt.get('backup_file')):
            messagebox.showerror('No rollback receipt','Only newly installed Lambda entries can be rolled back.');return
        if not messagebox.askyesno('Confirm rollback','Restore only if the registry SHA has NOT changed since deployment?'):
            return
        self.action(lambda:ConnectorDeployer(self.last_gateway).rollback(self.last_receipt),
                    lambda ok,result:messagebox.showinfo('Rollback' if ok else 'Rollback blocked',str(result)))

    def copy_text(self,value):
        self.clipboard_clear();self.clipboard_append(value);self.update()
        self.status.config(text='Copied to clipboard')

    def copy_quick_redacted(self):
        # B2b S7 DEFAULT: copy the REDACTED (shareable) Quick settings - placeholders in
        # place of the real login, host/IP and home path.
        v=getattr(self,'_quick_variants',None)
        if not v:
            messagebox.showerror('Nothing to copy','Complete the earlier steps first.');return
        self.copy_text(v['redacted'])
        self.status.config(text='Copied REDACTED Quick settings')

    def copy_quick_full(self):
        # B2b S7 explicit second action: copy the FULL text (real login/host). Warn first.
        v=getattr(self,'_quick_variants',None)
        if not v:
            messagebox.showerror('Nothing to copy','Complete the earlier steps first.');return
        if not messagebox.askyesno('Copy FULL (real login/host)',
            FULL_VARIANT_WARNING+'\n\nCopy the FULL text to the clipboard anyway?'):
            return
        self.copy_text(v['full'])
        self.status.config(text='Copied FULL Quick settings (real login/host)')

    def export_action(self):
        # B2b S7 DEFAULT: write the REDACTED (shareable) JSON example, owner-only (0600).
        self._export(redacted=True)

    def export_full_action(self):
        # B2b S7 explicit second action: write the FULL JSON (real login/host). Warn first.
        if not messagebox.askyesno('Export FULL JSON',
            FULL_VARIANT_WARNING+'\n\nWrite the FULL export anyway?'):
            return
        self._export(redacted=False)

    def _export(self,redacted=True):
        spec=self.spec()
        try:validate_spec(spec)
        except Exception as e:messagebox.showerror('Invalid form',str(e));return
        title=('Save REDACTED example (not directly importable)' if redacted
               else 'Save FULL example - contains real login/host')
        path=filedialog.asksaveasfilename(title=title,defaultextension='.json',filetypes=[('JSON','*.json')])
        if not path:return
        try:write_quick_config(spec,path,redacted=redacted)
        except Exception as exc:messagebox.showerror('Export failed',str(exc));return
        note=('Redacted export written (safe to share). This file is NOT proof that Quick can import it.'
              if redacted else
              'FULL export written. '+FULL_VARIANT_WARNING)
        messagebox.showinfo('Example saved',note)

    def dips_action(self):
        path=filedialog.askopenfilename(title='Select Quick DIPS database (read only)')
        if not path:return
        if not messagebox.askyesno('Read only','Close Quick before inspecting. Continue with read-only schema inventory?'):return
        try:result=inspect_dips_read_only(path)
        except Exception as e:messagebox.showerror('Inspection failed',str(e));return
        messagebox.showinfo('Schema inventory (no writes)',json.dumps(result,indent=2)[:3000])

    def go_next(self):
        if self.step==4:messagebox.showinfo('Finish','Complete registration manually in Quick and verify a safe tool call.');return
        if self.step==0:
            try:
                # [v04] use spec() so native-local's pinned host/user validate correctly.
                g=self.spec()
                validate_gateway(g['host'],g['user'])
            except Exception as e:messagebox.showerror('Invalid gateway',str(e));return
        if self.step==1:
            try:
                s=self.spec();s['allow']=s.get('allow') or ['discovery-placeholder']
                # S2: refuse Git/Local on a host THIS wizard bootstrapped (Lambda lane only).
                validate_spec_for_host(s,self.bootstrap_receipt)
            except Exception as e:messagebox.showerror('Invalid backend',str(e));return
            if not self.backend_verification or self.backend_verification.get('backend_identity_sha256')!=backend_identity(self.spec()):
                messagebox.showerror('Backend verification required','Click Test / Verify Backend and wait for a successful MCP tools/list before continuing.');return
        if self.step==2:
            self.save_selection()
            if self.vars['kind'].get()=='lambda' and not self.tool_selection:
                messagebox.showerror('No tools','Discover and select at least one exact tool.');return
        self.step+=1;self.render()

    def go_back(self):
        if self.step>0:self.save_selection();self.step-=1;self.render()

if __name__=='__main__':
    Wizard().mainloop()
