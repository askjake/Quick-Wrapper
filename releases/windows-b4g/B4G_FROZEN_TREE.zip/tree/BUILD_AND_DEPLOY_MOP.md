# MOP: AQ-MCP Wizard v0.3 — Validate, provision, deploy, recover

**Change control:** no production runtime replacement, no Quick database edits, no tokens in manifests, no port/service restart, no write to Git `main`/`master`. No sudo. Pilot first on a disposable Linux account/host before allowing first install on any shared enterprise jump server.

## 0. Preconditions / evidence

- Windows workstation with `py -3`, tkinter, Paramiko >=3.4<4, trusted SSH host key and key/agent authentication.
- Linux jump server with SSH access for an owned home directory. Fresh install requires Linux Python >=3.10, `python3 -m venv`, pip and network access to an approved dependency repository.
- Approved Lambda Function URL and a valid AWS identity already established on gateway (credentials never shipped from installer).
- Separate review/approval for changes to existing access modes. If other engineers rely on group write to `~/aq-mcp`, coordinate before repairing permissions.

## 1. Safe inspection on existing 3090

Open the wizard UI, enter jump host/user/known-hosts and click **Inspect**.

The supplied gateway archive recorded root directory mode `0775` and core files such as `targets.json` mode `0664`; the wizard (v0.3.1) reports `PERMISSIONS_NEED_REPAIR`, shows the individual problematic paths, and does **not** write anything. If `INCOMPLETE` or `FOREIGN`, stop rather than bootstrap/repair.

If changing group write permissions is approved, click **Repair core permissions** and confirm the displayed paths. Expected: permission changes only for the owned gateway directory and 5 core files, then subsequent Inspect reports `READY`. If shared access is required, **do not repair**; define a separate private gateway installation design and change control instead.

## 2. Create a gateway from scratch (fresh disposable Linux host only)

On a host with no `~/aq-mcp`, Inspect must return `MISSING`. Select **Install missing gateway**; acknowledge host package downloads and explicit new-directory creation. The worker receives a curated, SHA-checked ZIP in memory via existing authenticated SSH stdin. It will:

1. Refuse an existing, symlinked, incomplete or foreign `~/aq-mcp`.
2. Verify bundle digest and exact allowed member names; stage under an owner-private home directory.
3. Write the four curated launcher/proxy/check sources and initially empty `targets.json`.
4. Build a staged `venv`; install from the hash-pinned `requirements-gateway.lock` with `pip install --require-hashes --no-deps` (no extra package index unless the operator sets one explicitly); import-test. **If the lock is still the shipped template (`REPLACE_WITH_REAL_HASH`) or is malformed, the worker refuses before any venv/pip work** (see the lock paragraph below).
5. Exclusively create owner-private `~/aq-mcp` then move staged contents without overwriting any existing installation. Files use mode `0600`, launcher mode `0700`, directory mode `0700`.
6. Report `BOOTSTRAPPED`, then re-inspect for `READY`. It does NOT install credentials, PATs, Docker, or Quick connectors.

The bundle is LF-normalised at build time (CRLF→LF for the shell launcher, `.py` sources and `requirements-gateway.txt`), so a Windows checkout with CRLF line endings cannot ship a `#!/bin/bash\r` shebang. The worker additionally refuses any bootstrap member whose `aq-run.sh` or `.py` content still contains a carriage return. Line endings are pinned in `.gitattributes` (`bootstrap_payload/*` and `*.sh` → LF; `*.bat` → CRLF).

**Hash-pinned dependencies (Security H-2):** `bootstrap_payload/requirements-gateway.lock` is a hash-pinned lockfile installed with `pip install --require-hashes --no-deps -r requirements-gateway.lock`. It **ships as a template** (`--hash=sha256:REPLACE_WITH_REAL_HASH`) and the gateway worker **refuses** a template, an empty lock, or any requirement without a well-formed `--hash=sha256:<64 hex>`. **Fresh-host bootstrap stays BLOCKED until the real lock is generated; it has never run end to end.** The gateway is CPython 3.10 on Linux x86_64, so generate the lock on a connected build machine. Because the gateway installs with `--no-deps` (pip does NOT resolve dependencies at install time), the lock must contain the FULL TRANSITIVE CLOSURE, so the `pip download` below is run WITHOUT `--no-deps` to fetch every wheel in the closure:

```bash
pip download -r bootstrap_payload/requirements-gateway.txt \
    -d ./gateway-wheels --only-binary=:all: \
    --python-version 3.10 --platform manylinux2014_x86_64 \
    --implementation cp --abi cp310
python tools/make_gateway_lock.py \
    --requirements bootstrap_payload/requirements-gateway.txt \
    --wheel-dir ./gateway-wheels \
    --output bootstrap_payload/requirements-gateway.lock
```

`tools/make_gateway_lock.py` is stdlib-only and never touches the network. It turns every wheel in the directory into one hash-pinned `name==version --hash=sha256:...` line (so the generated lock is the full closure, not just the three top-level pins), and it **prints the resolved closure (names + versions) for you to review**. It refuses if any top-level pin in `requirements-gateway.txt` is absent or present at the wrong version, if a package appears at two different versions, or if the directory contains any non-wheel file other than an optional `README`. Commit the regenerated lock (with its transitive dependencies) and regenerate `SHA256SUMS` before a bootstrap attempt.

Stop on any error and inspect `~/aq-mcp` before retrying. If a failure happens during the final few file moves, the private folder can be `INCOMPLETE` and requires operator reconciliation; do not automatically delete files from the new path.

**Acceptance on fresh host:** `~/aq-mcp/venv/bin/python -c "import mcp,botocore,httpx2"`, `~/aq-mcp/venv/bin/python ~/aq-mcp/aq_registry.py list`, and a `tools/list` check after the first Lambda target and valid AWS identity are present.

## 3. Add a Lambda MCP target

Pick Lambda backend, enter `https://<id>.lambda-url.<region>.on.aws[/mcp]`, discover tools, select the exact allow-listed names (nonempty), review and approve. The deployed registry entry resembles:

```json
{
  "url": "https://example123.lambda-url.us-west-2.on.aws/mcp",
  "region": "us-west-2",
  "env": "wizard",
  "note": "Installed by AQ-MCP Connector Wizard",
  "allow": ["get_programs", "list_genres"]
}
```

No tools/call is sent by discovery. New target names cannot replace existing targets. A registry SHA mismatch aborts; re-plan before retrying. Post-apply `aq_check` must show `OK` and exactly the selected number of exposed tools. The target is rolled back on health failure if the registry has not changed again.

## 4. Register in Amazon Quick

Use the generated Local connector settings. For Lambda and approved existing local targets, use `ssh` with `-T`, `-q`, user@host, `/home/<user>/aq-mcp/aq-run.sh`, target-name (UI may display five chips). For guarded existing Git, use venv python, `aq_git_run.py`, target-name (six chips). Keep Quick Environment Variables blank; do not put AWS/Git tokens there. Set the connector **Timeout** to the wizard-generated value: **30 seconds for a Lambda target** (matching the live Epg connector) and **120 seconds for a Git target**. Save connector and open a new chat for current tools. Quick DIPS is read-only inspection only; no automated SQLite mutations are supported.

## 5. Rollback and audit

Save deployment receipt. Use GUI rollback or CLI after identifying exact target and approved gateway:

```cmd
py -3 cli.py rollback --receipt-file applied-receipt.json --host trusted-jump.example.internal --user engineer --approve-target demo-epg
```

If rollback reports a conflicting hash, stop and reconcile only the changed registry entry; do not force overwrite someone else's changes. No Quick connector is automatically removed by registry rollback.

## 6. Known gaps / qualification gates

1. Windows tkinter GUI and Paramiko live host-key flow not yet executed as part of this packaging session.
2. Linux fresh-host package installation and relocated venv runtime not yet validated on a real disposable host; only mocked installation tests passed.
3. Gateway bootstrap cannot issue AWS identity credentials or open corporate network access. Verify with site security owners.
4. Git and local adapter provisioning remain out of scope; only existing target registration supported.
5. Quick local registration requires manual UI until a vendor-supported registration API is verified. SQLite row injection is prohibited.
6. Dependencies are now hash-pinned via `requirements-gateway.lock` (`--require-hashes --no-deps`), but the lock **ships as a template** and must be regenerated with the real **transitive closure** of hashes (`tools/make_gateway_lock.py`) before bootstrap can run. A fully vendored offline wheelhouse with signed provenance is still recommended for production. **Bootstrap has never run end to end and stays BLOCKED until the real lock exists.**
7. Unit tests: **150 defined** across 12 files (`grep -c 'def test_' tests/*.py`): test_b2a_safety 20, test_b2b_hardening 17, test_bootstrap 32, test_c1_review_fixes 34, test_deploy_lib 6, test_gui_v03 1, test_model 11, test_quick_reg 2, test_remote_agent 15, test_remote_discovery 1, test_tool_count 1, test_v03_backend 10. This supersedes the earlier stale **79**, **116** and **145** figures; patch B2b added 17 hardening tests, patch C1 added review-fix tests, and patch C2 adds lock line-end parity tests (test_c1_review_fixes now 34: lock-validator only---hash enforcement, no-backslash/no-control-character parity, case-insensitive fail-closed redaction, secure_open O_NOFOLLOW). **These 150 methods have NOT been run by the engineering team and the GUI has never been launched in any agent environment** (the agent self-tested only pure functions by stub replay; the sandbox blocks `os.O_CREAT`, so the POSIX 0600 file-creation tests were NOT RUN there). On Linux all run; Windows intentionally skips POSIX-only filesystem/subprocess tests (reported as skips, not failures) and should have no import errors. Run `py -m unittest discover -s tests -v` from the repo root and record exact Windows test output as acceptance evidence. Do NOT read the method count as a pass count.
8. B2b export/receipt hardening (0600 file modes, redacted-by-default Copy/Export, Save bootstrap receipt) is verified by code reading and pure-function stub replay only; the real 0600 file creation and the tkinter GUI were never executed in the agent environment. Confirm on Windows that exported/receipt files are created and that the redacted Copy/Export contains no real login/host before sharing.


## v0.3 backend and automatic-plan acceptance

Before deploying any selected backend, use **Test / Verify Backend** on Step 2. It must return `BACKEND_VERIFIED` with a positive MCP `tools/list` count. An existing Git/local target needs a successful live metadata handshake, not merely valid configuration. After selecting tools in Step 3, Step 4 builds the plan automatically; compare target name, Lambda URL, selected allow-list and warnings before approval. For existing targets, the plan must be registration-only. Quick registration remains manual and must use the generated one-field SSH Arguments string with empty environment variables. See `ACCEPTANCE_MOP_v0_3.md`.
