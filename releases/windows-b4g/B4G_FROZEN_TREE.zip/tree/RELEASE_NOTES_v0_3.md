# AQ-MCP Connector Wizard v0.3 — backend qualification + automatic plans

**Status:** local engineering candidate, 2026-10-19. Not yet qualified on the user's Windows host or live gateway using this revision.

## Changes

1. **Step 2 — Test / Verify Backend.** A real remote MCP metadata handshake is required before moving to Step 3. Lambda uses the SigV4 proxy; existing Git targets use `aq_git_run.py` and the guarded Docker launcher; existing local targets use `aq_registry.py run <target>`. In all cases the wizard sends `initialize`, `notifications/initialized`, and `tools/list` only. No application `tools/call`. A successful Git config check alone no longer qualifies the backend.
2. **Step 3 — informed tool policy.** The discovered tool set is bound to the backend input fingerprint. A name-based review list warns about potentially mutating tools (not a permission or safety verdict). A specific EPG-versus-RTR Alerts mismatch hint detects the pattern shown in the user's screenshots. Selected risky tools require another explicit acknowledgment before mutation.
3. **Step 4 — plan automatically.** Entering Step 4 generates the plan asynchronously from the verified backend and selected tools. Plan details include the live registry SHA, exact allow-list, installation steps, possible risks, verification evidence, and a manual Quick registration step. Changing backend/connector identity or the tool selection invalidates deployment of the old plan.
4. **Existing Lambda registrations.** An existing Lambda target may be verified if its URL matches exactly, and can produce a registration-only plan when the selected tool names equal the installed allow-list. No gateway mutation is performed. Differing URL/allow-list refuses; no edit-in-place behavior.
5. **Step 5 — manual Quick walkthrough.** Provides Local, ID, name, `ssh` command, one-line Arguments input, numbered expected chips, empty environment variables, connection test, Save changes, NEW chat verification, and permission review. Export is advisory; DIPS remains read-only.
6. Retains create-only bootstrap, explicit permission repair, strict host-key trust, guarded registry transactions, health verification, and byte-checksummed rollback from v0.2.

## Patch A (2026-10-19, blocker fixes)

- **Line endings (F1).** The bootstrap bundle is LF-normalised at build time (shell launcher, `.py` sources, `requirements-gateway.txt`) before hashing and upload, so a CRLF checkout can no longer ship a `#!/bin/bash\r` shebang or break the LF-based pinned-dependency gate. The gateway worker now refuses any bootstrap member whose `aq-run.sh` or `.py` content contains a carriage return. Line endings are pinned in a new `.gitattributes` (`bootstrap_payload/*` and `*.sh` → LF; `*.bat` → CRLF).
- **SHA256SUMS (F2).** Regenerated over the delivered on-disk bytes (`.bat` files remain CRLF), so `sha256sum -c SHA256SUMS` passes on the delivered checkout.
- **Connector timeout (F3).** `timeout_seconds` is now per-kind: Lambda **30** (matching the live Epg connector), Git **120** (matching the live GitHub connector), local **120**. Tests guard each kind.
- **Claim consistency (F5).** Test count reconciled to the real total everywhere; stale `v0.1` wording removed from a v0.3 error message; Python 3.8+ (GUI/deploy) vs 3.10+ (gateway bootstrap) stated explicitly; Quick registration stays `MANUAL_REQUIRED`; a sentence was added clarifying the wizard makes no GitLab authentication claim.
- **Regex parity (S6).** The model-side Lambda function-URL validation now stores a lowercased id so it matches the gateway's stricter lowercase-only validator; a parity test exercises both on a shared sample set.

## Patch B2b (2026-10-19, export/receipt safety + S2 persistence + cosmetic)

- **S7 export/receipt safety (Security M-2).** Every file the wizard writes for the user
  (deploy/rollback receipts, JSON config exports, saved bootstrap receipts) is now created
  **owner-only (0600)**, create-only (never overwrites): `model.secure_open`/`secure_write_text`/
  `secure_write_json`. On POSIX this is `os.open(O_CREAT|O_EXCL|O_WRONLY, 0o600)` + `fchmod` + a
  `stat` refusal if any group/other bit survives. **On Windows the stdlib cannot set a POSIX ACL**:
  the file is created and `os.chmod(path, 0o600)` is called, which on Windows only toggles the
  read-only attribute and does NOT restrict group/other. This is stated plainly in the code and the
  README; no ACL is claimed that was not set.
- **Redacted vs full sharing.** The GUI **Copy Quick settings** and **Export JSON** actions, and the
  CLI `export` operation, now DEFAULT to a **redacted** variant that replaces the real login,
  host/IP and home path with `<user>@<3090-host>` and `/home/<user>/aq-mcp`. The **full** variant
  (real login/host) is a clearly labelled, explicit second action (GUI: "Copy FULL"/"Export FULL";
  CLI: `--full-export`) carrying "contains your real login and host - do not paste into tickets,
  decks or chat". Covered everywhere the real login is rendered: `quick_reg.quick_instructions`
  (new `redacted=` flag + `quick_instructions_variants`), `quick_reg.config_export_text`,
  `wizard.py` copy/export, and `cli.py` export. Receipts keep the real address (needed for rollback)
  but are mode-locked 0600.
- **S2 persistence.** New **Save bootstrap receipt** action (GUI) and `cli.py save-bootstrap-receipt`
  persist the wizard-held Lambda-only bootstrap receipt with 0600 perms. It round-trips through
  `host_is_wizard_lambda_only`, so **Load bootstrap receipt** next session still disables Git/Local.
- **Cosmetic.** `model.mutating_confirm_text([])` now returns neutral text instead of printing the
  "Potentially MUTATING tool names were selected:" header over an empty list. The non-empty text is
  **byte-for-byte unchanged** (S4 parity preserved).

## Patch C1 (2026-10-19, review fixes)

Small review fixes from the v0.3.1 Tester / Reviewer / Security re-check. No safety property was
weakened and no honesty statement was removed.

- **Lock validator — only `--hash` after the pin (Security MED-1).** `remote_agent.validate_gateway_lock`
  now requires that, after the `name==version` token, **every** remaining token on a requirement line is
  exactly `--hash=sha256:<64 lowercase hex>`. Any other pip option (`--index-url`, `--extra-index-url`,
  `--find-links`, `-i`, `-r`, `-c`), a `name @ url` direct reference, an inline comment, a continuation
  backslash, or any control character is refused **before any venv/pip work**. The template / empty / missing-hash /
  short / non-hex refusals are all kept. `tools/make_gateway_lock.py` additionally charset-validates each
  wheel name/version, so its generated lock can never contain a token other than `--hash`.
- **Redaction case-insensitive + fail-closed (E2 / LOW-3 / N1).** `model.redact_identity` now matches the
  login **and** the host case-insensitively, and **fails closed**: it raises `RedactionError` (a
  `ValueError`) when the user or host is empty/None/whitespace. Every caller (`quick_reg.py`, `wizard.py`,
  `cli.py`) surfaces the message and **refuses** the redacted (shareable) Copy/Export rather than emitting
  unredacted text. Receipts still keep the real address and stay 0600.
- **`secure_open` O_NOFOLLOW (LOW-4).** `model.secure_open` adds `O_NOFOLLOW` where the platform has it
  (`getattr(os,'O_NOFOLLOW',0)`), for symmetry with the O_EXCL create-only behaviour; no other behaviour change.
- **Stale strings (Reviewer C3).** The stale GUI "v0.2" line is gone (the wizard now carries a single
  `v0.3.1` version constant); the BUILD MOP section 1 "v0.1/v0.2" wording and the ACCEPTANCE MOP install
  block (now `.venv`-based, matching README) were aligned.
- **New tests.** `tests/test_c1_review_fixes.py` adds **29** methods for the above (lock-validator refusals
  and a well-formed multi-hash acceptance, generator charset rejection, case-insensitive + fail-closed
  redaction and caller refusal, and the `secure_open` O_NOFOLLOW flag). As with the rest of the suite, these
  have **not** been run by the engineering team in any agent environment — run the suite yourself.

## Patch C2 (2026-10-19, lock-validator / pip line-end parity, Security MED-1 re-closure)

- **Validator and pip must never disagree about where a line ends.** `remote_agent.validate_gateway_lock`
  previously joined pip-style backslash continuations (`text.replace('\\\n',' ')`) BEFORE skipping comment
  lines. pip's own requirements parser (`join_lines`) never continues a COMMENT line, so a lock whose comment
  line ended in a backslash would swallow the next line into the comment on our side while pip treated that
  next line as a real option — reopening the MED-1 hole (a commented backslash followed by `--index-url …`).
  Continuation support is removed entirely (the lock generator never emits a backslash, so it was never
  needed). **Lock files may not contain backslashes or control characters; the validator and pip must never
  disagree about where a line ends.** The validator now refuses any backslash anywhere, and any control
  character other than `\n` (including `\r`, `\x0b`, `\x0c`, `\u2028`), with a one-line error before any
  venv/pip work. Every other refusal/acceptance is unchanged (comments on their own line and blank lines are
  still ignored; each requirement is `name==version` followed only by `--hash=sha256:<64 lowercase hex>`).
- **Tests.** `tests/test_c1_review_fixes.py` replaces the former
  `test_accepts_comments_blanks_and_backslash_continuation` with
  `test_accepts_comments_and_blanks_without_continuation` and adds five `test_c2_*` cases (any backslash
  refused, the exact three-line comment-continuation exploit refused, a comment line ending in a backslash
  refused, a single-line multi-hash lock still accepted, and control characters refused). As with the rest of
  the suite, these have **not** been run by the engineering team — run the suite yourself.

**Trust model and open design items (so "bundle-verified" is not over-read).**

- **Separate tools on purpose.** This wizard and the separate allow-list tooling (the cleared
  `w3_apply_allowlists.py`) are distinct tools on purpose; the wizard does not call or replace it.
- **Bundle SHA-256 is an integrity check, not a signature (INFO-7).** The bundle SHA-256 is computed by the
  wizard and re-checked by the remote agent. It detects corruption in transit. It is not a signature and
  does not prove who built the bundle.
- **Package index (H-2).** The pip package index used by bootstrap is whatever the gateway's pip is
  configured to use; the pinned `--hash` values still enforce integrity regardless of the index. Vendoring
  the wheels inside the bundle (`--no-index --find-links`) is an open design decision.
- **Bundled proxy vs live gateway (E1/E7).** `bootstrap_payload/aq_mcp_stdio.py` differs from the live
  gateway copy only by log-file hardening (0600, `fchmod` repair, wrapped so a logging failure cannot stop
  the proxy); bringing the live gateway to this revision is a separate, approved, dry-run-first change.

## Line endings

The Python sources (`model.py`, `cli.py`, `wizard.py`, `deploy_lib.py`, `quick_reg.py`) are now
**LF**; the `.bat` files remain CRLF. `.gitattributes` (`text=auto`) normalises on commit, so the
committed bytes stay stable regardless of a contributor's checkout.


## Verification evidence

- **Test-method count (reconciled).** `grep -c 'def test_' tests/*.py` now totals **150** methods across 12 files: test_b2a_safety 20, test_b2b_hardening 17, test_bootstrap 32, test_c1_review_fixes 34, test_deploy_lib 6, test_gui_v03 1, test_model 11, test_quick_reg 2, test_remote_agent 15, test_remote_discovery 1, test_tool_count 1, test_v03_backend 10. Earlier notes quoted 41 (an old Linux/Xvfb run), 50 (after patch A), 116 (before patch C1) and 145 (after patch C1, before patch C2); those are superseded. **These 150 methods have NOT been run by the Executive's engineering team, and the GUI has never been launched in any agent environment** - the agent self-tested only pure functions by stub replay (and the sandbox blocks `os.O_CREAT`, so the POSIX 0600 file-creation tests were NOT RUN there either). Run the suite yourself from the repo root on Windows and record the exact output as acceptance evidence:

  `py -m unittest discover -s tests -v`

  POSIX-only filesystem tests (including the B2b 0600 tempfile tests) are skipped on Windows, reported as skips not failures. Do NOT read the method count as a pass count.
- POSIX/Linux-only filesystem tests are deliberately skipped on Windows, not imported through a top-level `fcntl` dependency.
- **Not tested:** live Windows Quick UI registration, credentials/SSH to the user's hosts, GHES/GitLab live containers or token validity with v0.3, and a live fresh-host bootstrap end-to-end.

## Known limitations

- A backend metadata handshake validates the configured MCP endpoint's ability to list tools. It **does not** verify tool semantics, read-only status, intended service identity beyond limited heuristics, credential lifetime, or actual tool execution.
- Configured existing Git/local targets can be verified and registered in Quick but cannot be newly provisioned by v0.3. A fresh gateway only includes the Lambda adapter.
- Unknown Quick registration API: **never write the DIPS SQLite store**. Manual GUI registration is required (`MANUAL_REQUIRED`). Rollback reverts only the single `targets.json` write — it does not remove the Quick connector or restart services.
- The gateway bootstrap doesn't provision AWS credentials, Git PATs, Docker images, corporate CAs, or Quick permissions.
- Generated plan risk classification is name-based and advisory; all chosen tools should be reviewed against their actual descriptions and schemas.
- Bootstrapped Python dependencies are hash-pinned (patch B1): the gateway installs with `--require-hashes --no-deps` from `requirements-gateway.lock`, which SHIPS AS A TEMPLATE. Fresh-host bootstrap stays BLOCKED until the real lock is generated and has never run end to end.
