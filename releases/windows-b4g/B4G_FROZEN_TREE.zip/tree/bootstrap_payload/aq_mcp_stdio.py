"""
aq-mcp-stdio — local stdio MCP proxy that SigV4-signs and forwards to an IAM-protected
MCP server (AWS Lambda Function URL). Signs with the LOCAL AWS credential chain.

Config env vars:
    AQ_TARGET_URL     (required)
    AQ_SIGV4_SERVICE  (default "lambda")
    AQ_REGION         (default "us-west-2")
    AQ_TOOL_ALLOWLIST (optional, comma-separated)

Run:
    python aq_mcp_stdio.py            -> MCP stdio server (what Quick launches)
    python aq_mcp_stdio.py --selftest -> connect, list tools, print them, exit

NOTE: this SDK build vendors httpx as `httpx2`. The auth object MUST subclass the SAME
httpx flavor the SDK's client uses, or httpx rejects it ("Invalid auth argument"). We
build the client via the SDK's own create_mcp_http_client, so we base our auth on the
httpx module THAT factory uses — httpx2 when present, else stock httpx.
"""
from __future__ import annotations
import os, sys, asyncio, logging, json, re, hashlib, datetime

from botocore.auth import SigV4Auth
from botocore.awsrequest import AWSRequest
from botocore.session import Session as BotoSession

_FMT = "%(asctime)s pid=%(process)d %(levelname)s %(message)s"
logging.basicConfig(stream=sys.stderr, level=os.environ.get("AQ_LOG_LEVEL", "INFO"), format=_FMT)
log = logging.getLogger("aq-mcp-stdio")
# Also append to a file so LIVE Quick invocations (whose stderr the UI may not surface)
# leave a readable trace. Override path with AQ_LOG_FILE; default ~/aq-mcp/aq-mcp.log.
# Security S8: the log can carry diagnostic detail, so it must never be group/world
# readable. _secure_log_file() creates it mode 0600 (forced past the umask) and, if it
# already exists as a regular non-symlink file, verifies its mode via stat and repairs
# it to 0600. It only ever clears group/world bits; it never weakens a stricter mode.


def _secure_log_file(path):
    """Open *path* for append as a 0600 regular file, repairing an over-open mode.

    Refuses to follow a symlink (O_NOFOLLOW where available). Creates missing files with
    mode 0600 and, when the file already exists, uses fstat to detect any group/world
    bits and fchmod to clear them. POSIX-only enforcement; on a non-POSIX runner (no
    O_NOFOLLOW/fchmod) it degrades to a plain append open. Returns an open text stream.
    """
    import stat as _stat_local
    nofollow = getattr(os, "O_NOFOLLOW", 0)
    flags = os.O_WRONLY | os.O_CREAT | os.O_APPEND | nofollow
    fd = os.open(path, flags, 0o600)
    try:
        if hasattr(os, "fchmod"):
            st = os.fstat(fd)
            if _stat_local.S_ISREG(st.st_mode) and (st.st_mode & 0o077):
                os.fchmod(fd, st.st_mode & ~0o077)
        return os.fdopen(fd, "a", encoding="utf-8")
    except Exception:
        os.close(fd)
        raise


try:
    _logfile = os.environ.get("AQ_LOG_FILE") or os.path.expanduser("~/aq-mcp/aq-mcp.log")
    _fh = logging.StreamHandler(_secure_log_file(_logfile))
    _fh.setFormatter(logging.Formatter(_FMT))
    logging.getLogger().addHandler(_fh)
except Exception as _e:  # never fail startup over logging
    log.warning("could not open AQ_LOG_FILE: %s", _e)

TARGET_URL = os.environ.get("AQ_TARGET_URL")
SERVICE = os.environ.get("AQ_SIGV4_SERVICE", "lambda")
REGION = os.environ.get("AQ_REGION", "us-west-2")
ALLOW = [t.strip() for t in os.environ.get("AQ_TOOL_ALLOWLIST", "").split(",") if t.strip()]


# --- D-2 allow-list floor: proxy-side defence in depth (begin) -----------------------------
# The launcher (aq_registry.py) is the primary gate. This is a second, independent check so a
# direct/hand invocation of the proxy on a floor-enabled gateway cannot silently expose all
# tools. It is ACTIVE only when a gateway_policy.json marker sits next to this proxy OR the
# launcher handed us AQ_ALLOWLIST_MODE. With neither present -> legacy behaviour: legacy
# environment, exit codes and output are unchanged (one extra caught os.lstat for the marker per
# start). Pure functions; no import-time I/O.
#
# This control stops MISCONFIGURATION, a BARE env override (AQ_ALLOWLIST_MODE=unrestricted on its
# own) and partial/mismatched configuration -- NOT a same-user attacker who can set ALL of the
# AQ_UNRESTRICTED_* variables consistently (that residual is the F-2 code-integrity track; the
# piece-2 deployment receipt carries the real audit trail).
AQ_ALLOWLIST_MODE = os.environ.get("AQ_ALLOWLIST_MODE")
_POLICY_MARKER = os.path.join(os.path.dirname(os.path.abspath(__file__)), "gateway_policy.json")
_MARKER_MAX = 65536
# P1: an allow-list name the proxy will refuse to honour under the floor (a comma would split
# one name into two; control/whitespace would corrupt the set). _ALLOW_NAME_MAX matches launcher.
_ALLOW_NAME_MAX = 128
# P3: env vars the launcher hands us so we can RE-validate an unrestricted exception ourselves.
_ENV_REASON = "AQ_UNRESTRICTED_REASON"
_ENV_APPROVAL_ID = "AQ_UNRESTRICTED_APPROVAL_ID"
_ENV_APPROVED_UTC = "AQ_UNRESTRICTED_APPROVED_UTC"
_ENV_DIGEST = "AQ_UNRESTRICTED_DIGEST"
# Exception-field rules -- DUPLICATED from the launcher on purpose so the two boundaries share one
# definition of a valid exception (kept in lock-step by tests). Anchored \A...\Z + ASCII only.
_APPROVAL_RE = re.compile(r"\A[A-Za-z0-9._:-]{8,128}\Z", re.ASCII)
_UTC_RE = re.compile(r"\A[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z\Z", re.ASCII)
_UTC_FMT = "%Y-%m-%dT%H:%M:%SZ"
_REASON_MIN = 12
_REASON_MAX = 500
_FUTURE_SKEW_SECONDS = 24 * 3600
# P4: one plain-language remedy line appended to every refusal -- no env values/URLs/tool names.
_REMEDY = ("Fix: add an allow-list of the tools this target should expose, or ask the gateway "
           "operator to add an approved unrestricted exception.")


def _utcnow():
    """Naive UTC 'now', warning-free on Python 3.10/3.12/3.13 (mirrors the launcher helper).

    datetime.datetime.utcnow() is deprecated on 3.12+ (Security R2-L1 / Tester T-2). We use
    the timezone-aware now() and drop the tzinfo so the result stays a NAIVE UTC datetime,
    directly comparable with the naive datetime.strptime() result and a naive injected ``now``.
    """
    return datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None)


class AllowlistFloorError(Exception):
    """Raised to refuse serving under the proxy-side allow-list floor."""


def _marker_floor_on(path=None):
    """Mirror of the launcher's marker read: fail CLOSED on a present-but-unsafe marker.

    Regular-file only (os.lstat refuses a symlink), size-capped, strict-JSON object with a
    real bool allowlist_floor. Absent marker -> False (legacy). Windows-portable (no O_NOFOLLOW).
    """
    import stat as _st
    p = path or _POLICY_MARKER
    try:
        st = os.lstat(p)
    except FileNotFoundError:
        return False
    except OSError:
        return True
    if _st.S_ISLNK(st.st_mode):
        return True
    if not _st.S_ISREG(st.st_mode):
        return True
    if st.st_size > _MARKER_MAX:
        return True
    try:
        with open(p, "r", encoding="utf-8") as f:
            obj = json.load(f)
    except (OSError, ValueError):
        return True
    if not isinstance(obj, dict):
        return True
    floor = obj.get("allowlist_floor")
    if floor is True:
        return True
    if floor is False:
        return False
    return True


def _bad_allow_name(name):
    """P1: short reason string if *name* is unsafe as an allow-list member, else None. Mirrors
    the launcher's _bad_allow_name so a comma/control/whitespace name can never silently split."""
    if not isinstance(name, str):
        return "allow-list entries must be strings"
    s = name.strip()
    if not s:
        return "allow-list entries must not be blank"
    if len(s) > _ALLOW_NAME_MAX:
        return "an allow-list entry is too long"
    for c in s:
        if c == "," or ord(c) < 32 or ord(c) == 127 or c.isspace():
            return "an allow-list entry contains a comma, control character or whitespace"
    return None


def _validate_allow_raw(raw):
    """P1: re-parse the raw AQ_TOOL_ALLOWLIST the proxy received and refuse a corrupt set.

    Under the floor we refuse a comma/control/whitespace/duplicate name rather than silently
    enforce a mis-split set. Returns the normalised, de-duplicated list. Pure. *raw* is the
    comma-joined env string the proxy received from the launcher (or a direct invocation).
    """
    out = []
    seen = set()
    for part in (raw or "").split(","):
        s = part.strip()
        if not s:
            continue
        bad = _bad_allow_name(s)
        if bad:
            raise AllowlistFloorError(bad)
        if s in seen:
            raise AllowlistFloorError("the allow-list contains a duplicate tool name")
        seen.add(s)
        out.append(s)
    return out


def _has_control_char(s):
    return any(ord(c) < 32 or ord(c) == 127 for c in s)


def validate_exception_fields(reason, approval_id, approved_utc, now=None):
    """P3: re-validate the exception fields the launcher handed us, with the SAME rules as the
    launcher's _validate_exception. Raise AllowlistFloorError on any problem; return the
    normalised fields dict on success. Pure; *now* injectable for tests."""
    if not isinstance(reason, str) or _has_control_char(reason):
        raise AllowlistFloorError("unrestricted exception reason is missing or malformed")
    reason_s = reason.strip()
    if len(reason_s) < _REASON_MIN or len(reason_s) > _REASON_MAX:
        raise AllowlistFloorError("unrestricted exception reason has an invalid length")
    if (not isinstance(approval_id, str) or _has_control_char(approval_id)
            or not _APPROVAL_RE.fullmatch(approval_id)):
        raise AllowlistFloorError("unrestricted exception approval_id is missing or malformed")
    if not isinstance(approved_utc, str) or not _UTC_RE.fullmatch(approved_utc):
        raise AllowlistFloorError("unrestricted exception approved_utc is missing or malformed")
    try:
        when = datetime.datetime.strptime(approved_utc, _UTC_FMT)
    except ValueError:
        raise AllowlistFloorError("unrestricted exception approved_utc is not a real date-time")
    ref = now if now is not None else _utcnow()
    if (when - ref).total_seconds() > _FUTURE_SKEW_SECONDS:
        raise AllowlistFloorError("unrestricted exception approved_utc is too far in the future")
    return {"reason": reason_s, "approval_id": approval_id, "approved_utc": approved_utc}


def unrestricted_digest(target_name, fields):
    """P3: recompute the SAME digest the launcher binds over (target name + three fields).
    Not a secret/HMAC -- a consistency binding so a bare/partial/mismatched env set is detected."""
    payload = "\x1f".join([
        "aq-d2-unrestricted-v1",
        target_name or "",
        fields["reason"],
        fields["approval_id"],
        fields["approved_utc"],
    ])
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def check_allowlist_policy(allow_list, env_mode, marker_present, exc_env=None, target_name=None):
    """Pure proxy-side decision. Returns a mode label when the floor is active, else None.

    Raise AllowlistFloorError to refuse serving. Active iff marker_present or env_mode is set.
      - mode 'unrestricted' + a non-empty allow-list -> refuse (ambiguous).
      - enforced (or marker present, mode absent) + an EMPTY allow-list -> refuse.
      - an unknown non-empty env_mode value -> refuse.
      - P3: on an ACTIVE gateway, mode 'unrestricted' is accepted ONLY if the launcher-supplied
        exception fields (exc_env) re-validate AND the digest over (target_name + fields) matches
        AQ_UNRESTRICTED_DIGEST. A bare AQ_ALLOWLIST_MODE=unrestricted from the environment alone
        (no fields / wrong digest) is REFUSED. exc_env is a dict of the four AQ_UNRESTRICTED_*
        env values (reason/approval_id/approved_utc/digest); None means "not supplied".
    """
    active = marker_present or (env_mode is not None)
    if not active:
        return None                      # legacy / direct-invocation on a non-floor gateway
    if env_mode is None:
        env_mode = "enforced"            # marker present but launcher mode absent -> enforce
    if env_mode not in ("enforced", "unrestricted"):
        raise AllowlistFloorError("unknown AQ_ALLOWLIST_MODE %r" % (env_mode,))
    if env_mode == "unrestricted":
        if allow_list:
            raise AllowlistFloorError("AQ_ALLOWLIST_MODE=unrestricted but a non-empty "
                                      "allow-list is set; refusing (ambiguous policy)")
        # P3: require the re-validated exception + matching digest. This stops a bare env override.
        exc_env = exc_env or {}
        fields = validate_exception_fields(exc_env.get("reason"),
                                           exc_env.get("approval_id"),
                                           exc_env.get("approved_utc"))
        supplied_digest = exc_env.get("digest")
        if not isinstance(supplied_digest, str) or not supplied_digest:
            raise AllowlistFloorError("unrestricted mode is missing its approval digest")
        if unrestricted_digest(target_name, fields) != supplied_digest:
            raise AllowlistFloorError("unrestricted mode approval digest does not match "
                                      "the supplied exception fields")
        return "unrestricted"
    # enforced
    if not allow_list:
        raise AllowlistFloorError("allow-list floor is on but the allow-list is empty; "
                                  "refusing to serve all upstream tools")
    return "enforced"


def _enforce_allowlist_floor():
    """Startup hook called from the real serve/selftest paths. Refuse -> non-zero exit, plain
    stderr (+ one remedy line, no env/secret echo), never proceed to serve. Logs one clear line
    in unrestricted mode that includes the validated approval_id and target, never the reason."""
    marker_present = _marker_floor_on()
    active = marker_present or (AQ_ALLOWLIST_MODE is not None)
    try:
        # P1: under the floor, re-validate the raw allow-list string so a comma/control-char name
        # that slipped past the launcher (e.g. a direct invocation) is refused, not split. On a
        # legacy gateway (not active) we leave the historical ALLOW untouched -- byte-identical.
        allow = _validate_allow_raw(os.environ.get("AQ_TOOL_ALLOWLIST", "")) if active else ALLOW
        exc_env = {
            "reason": os.environ.get(_ENV_REASON),
            "approval_id": os.environ.get(_ENV_APPROVAL_ID),
            "approved_utc": os.environ.get(_ENV_APPROVED_UTC),
            "digest": os.environ.get(_ENV_DIGEST),
        }
        target_name = os.environ.get("AQ_TARGET_NAME")
        mode = check_allowlist_policy(allow, AQ_ALLOWLIST_MODE, marker_present,
                                      exc_env=exc_env, target_name=target_name)
    except AllowlistFloorError as e:
        sys.stderr.write("aq-mcp-stdio: %s\n" % e)
        sys.stderr.write(_REMEDY + "\n")    # P4
        raise SystemExit(3)
    if mode == "unrestricted":
        # Log line carries the validated approval_id (a charset-limited string) and target only;
        # never the reason (which could carry awkward text) -- reason control chars are rejected
        # above anyway, but we still keep the log minimal.
        log.warning("allow-list floor: UNRESTRICTED mode active (approval_id=%s target=%s) — "
                    "forwarding ALL upstream tools",
                    os.environ.get(_ENV_APPROVAL_ID, "?"),
                    os.environ.get("AQ_TARGET_NAME", "?"))
    return mode
# --- D-2 allow-list floor: proxy-side defence in depth (end) -------------------------------


def _load_extra_headers():
    raw = os.environ.get("AQ_EXTRA_HEADERS", "").strip()
    if not raw:
        return {}
    try:
        d = json.loads(raw)
    except ValueError:
        sys.exit("AQ_EXTRA_HEADERS must be a JSON object")
    out = {}
    for k, v in (d or {}).items():
        if not re.fullmatch(r"X-[A-Za-z0-9-]{1,64}", k) or k.lower().startswith("x-amz"):
            sys.exit("AQ_EXTRA_HEADERS: header name not allowed: %r" % (k,))
        v = str(v)
        if not v or len(v) > 200 or re.search(r"[\r\n\x00]", v):
            sys.exit("AQ_EXTRA_HEADERS: bad value for %s" % k)
        out[k] = v
    return out

EXTRA_HEADERS = _load_extra_headers()
log.info("extra request headers: %s", sorted(EXTRA_HEADERS) or "none")

# --- forced arguments (begin)
def _load_forced_args():
    raw = os.environ.get("AQ_FORCED_ARGS", "").strip()
    if not raw:
        return {}
    try:
        data = json.loads(raw)
    except ValueError:
        sys.exit("AQ_FORCED_ARGS must be a JSON object")
    if not isinstance(data, dict):
        sys.exit("AQ_FORCED_ARGS must be a JSON object")
    out = {}
    for tool, args in data.items():
        if not re.fullmatch(r"[A-Za-z0-9_]{1,100}", str(tool)) or not isinstance(args, dict) or not args:
            sys.exit("AQ_FORCED_ARGS: bad entry for tool %r" % (tool,))
        clean = {}
        for key, value in args.items():
            scalar = value is None or isinstance(value, (bool, int, float, str))
            if not re.fullmatch(r"[A-Za-z0-9_]{1,64}", str(key)) or not scalar:
                sys.exit("AQ_FORCED_ARGS: bad argument %r for %s" % (key, tool))
            clean[key] = value
        out[tool] = clean
    return out


FORCED_ARGS = _load_forced_args()
log.info("forced arguments for tools: %s", sorted(FORCED_ARGS) or "none")


def _apply_forced(name, arguments):
    # returns (arguments with this tool's forced values written over whatever the caller sent, names overridden)
    forced = FORCED_ARGS.get(name)
    if not forced:
        return arguments, []
    merged = dict(arguments or {})
    overridden = [k for k, v in forced.items() if k in merged and merged[k] != v]
    merged.update(forced)
    return merged, overridden
# --- forced arguments (end)

# --- secret arguments (begin)
# AQ_SECRET_ARGS = {"tool": {"arg": "/path/to/file"}}. The env holds only PATHS. The value is read from the file on
# every call, written over whatever the caller sent, never logged and never put in an error message.
import stat as _stat


def _load_secret_args():
    raw = os.environ.get("AQ_SECRET_ARGS", "").strip()
    if not raw:
        return {}
    try:
        data = json.loads(raw)
    except ValueError:
        sys.exit("AQ_SECRET_ARGS must be a JSON object")
    if not isinstance(data, dict):
        sys.exit("AQ_SECRET_ARGS must be a JSON object")
    out = {}
    for tool, args in data.items():
        if not re.fullmatch(r"[A-Za-z0-9_]{1,100}", str(tool)) or not isinstance(args, dict) or not args:
            sys.exit("AQ_SECRET_ARGS: bad entry for tool %r" % (tool,))
        clean = {}
        for key, path in args.items():
            if not re.fullmatch(r"[A-Za-z0-9_]{1,64}", str(key)) or not isinstance(path, str) or not path.strip():
                sys.exit("AQ_SECRET_ARGS: bad argument %r for %s" % (key, tool))
            clean[key] = os.path.abspath(os.path.expanduser(path))
        out[tool] = clean
    return out


SECRET_ARGS = _load_secret_args()
log.info("secret arguments (names only): %s", {t: sorted(a) for t, a in SECRET_ARGS.items()} or "none")


def _read_secret_file(path):
    try:
        fd = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
    except OSError:
        raise ValueError("secret file is missing, unreadable or a symlink") from None
    try:
        st = os.fstat(fd)
        if not _stat.S_ISREG(st.st_mode):
            raise ValueError("secret file is not a regular file")
        if hasattr(os, "geteuid") and st.st_uid != os.geteuid():
            raise ValueError("secret file is not owned by the user running the proxy")
        if st.st_mode & 0o077:
            raise ValueError("secret file permissions are too open (chmod 600)")
        if st.st_size < 1 or st.st_size > 4096:
            raise ValueError("secret file is empty or larger than 4096 bytes")
        data = os.read(fd, 4097)
    finally:
        os.close(fd)
    try:
        value = data.decode("utf-8").strip()
    except UnicodeDecodeError:
        raise ValueError("secret file is not valid UTF-8") from None
    if not value or re.search(r"\s", value) or any(ord(c) < 32 or ord(c) == 127 for c in value):
        raise ValueError("secret file must hold one token with no whitespace or control characters")
    return value


def _apply_secrets(name, arguments):
    # returns (arguments with this tool's secret values written over whatever the caller sent, names supplied)
    wanted = SECRET_ARGS.get(name)
    if not wanted:
        return arguments, []
    merged = dict(arguments or {})
    for key, path in wanted.items():
        try:
            merged[key] = _read_secret_file(path)
        except ValueError as e:
            raise ValueError("%s: cannot supply %r: %s" % (name, key, e)) from None
    return merged, sorted(wanted)
# --- secret arguments (end)

# --- error surfacing (begin)
# Convert ANY upstream failure into a well-formed CallToolResult(isError=True) whose text is
# never empty, carries the HTTP status when discoverable, and a short SCRUBBED body snippet.
# The snippet is built only from the upstream response/exception, never the request arguments.
# The secret value(s) injected for THIS call are passed in and removed by exact match first,
# so the token cannot survive regardless of charset/newlines/delimiters; pattern scrub then
# redacts any other long opaque runs or sensitive key=value material a server might echo.
import re as _re_es

_ES_PREFIX = "upstream call failed"
_ES_OKTA = ("AWS credentials look expired or unauthorized (HTTP 403). Refresh Okta on the 3090 "
            "(re-run your AWS/Okta login), then relaunch the connector.")
_ES_SNIPPET_CAP = 200
_ES_TEXT_CAP = 1000
# A maximal run of >=24 opaque chars (heavy token ~64; AWS v4 signatures 64 hex). \S so a
# token containing punctuation outside base64 is still caught by the secondary pattern.
_ES_OPAQUE = _re_es.compile(r"\S{24,}")
# Sensitive "key=value" / "key: value" (incl. JSON "key":"value"), value redacted wholesale.
_ES_SENSITIVE_KW = _re_es.compile(
    r'(?i)\b(authorization|x-amz[a-z0-9-]*|heavy_auth_token|aws_session_token|security_token|'
    r'signature|credential)\b["\']?\s*[=:]\s*["\']?[^\s,;&"\']+')
_ES_AUTH_SIG = _re_es.compile(r"(?i)expired|unauthorized|forbidden|not\s+authorized|access\s*denied|security\s+token")


def _es_discover_status(exc):
    resp = getattr(exc, "response", None)
    code = getattr(resp, "status_code", None)
    if isinstance(code, int):
        return code
    r = repr(exc)
    # Anchored patterns only -- avoid matching ':443' (https port) or ids like 'R456'.
    for _pat in (r"status_code[=:\s]+(\d{3})", r"HTTP/?\s*(\d{3})", r"['\"](4\d\d|5\d\d)\b"):
        m = _re_es.search(_pat, r)
        if m:
            return int(m.group(1))
    return None


def _es_scrub(text):
    text = _ES_SENSITIVE_KW.sub(lambda m: m.group(1) + "=[REDACTED]", text)
    text = _ES_OPAQUE.sub("[REDACTED]", text)
    return text.replace("\n", " ").replace("\r", " ").strip()


def _es_safe_snippet(exc, secrets=()):
    resp = getattr(exc, "response", None)
    body = None
    if resp is not None:
        body = getattr(resp, "text", None)
        if not isinstance(body, str):
            raw = getattr(resp, "content", None)
            if isinstance(raw, (bytes, bytearray)):
                body = raw.decode("utf-8", "replace")
    if not body:
        body = str(exc) or repr(exc)
    # PRIMARY defense: remove the exact injected secret value(s) first, before any pattern
    # scrub and before truncation -- airtight regardless of charset/newlines/delimiters.
    for s in secrets:
        if s:
            body = body.replace(s, "[REDACTED]")
    return _es_scrub(body)[:_ES_SNIPPET_CAP]


def _es_describe(exc):
    # for the log line ONLY: status or type, never body/arguments/token
    status = _es_discover_status(exc)
    return ("HTTP %d" % status) if status else ("exc " + str(type(exc)))


def _error_result(exc, types, secrets=()):
    status = _es_discover_status(exc)
    snippet = _es_safe_snippet(exc, secrets)
    head = _ES_PREFIX + ((" (HTTP %d)" % status) if status else "")
    parts = [head]
    if status == 403 or _ES_AUTH_SIG.search(snippet):
        parts.append(_ES_OKTA)
    parts.append(snippet)
    text = "\n".join(p for p in parts if p)[:_ES_TEXT_CAP] or _ES_PREFIX
    # belt-and-suspenders: exact-remove any injected secret from the final text too
    for s in secrets:
        if s:
            text = text.replace(s, "[REDACTED]")
    return types.CallToolResult(content=[types.TextContent(type="text", text=text)], isError=True)
# --- error surfacing (end)

# Use the SAME httpx flavor the MCP SDK's client factory uses. This build vendors it as
# httpx2; fall back to stock httpx on a standard SDK.
try:
    import httpx2 as _httpx
except ImportError:  # pragma: no cover
    import httpx as _httpx


class SigV4HttpxAuth(_httpx.Auth):
    """Sign every outgoing request with SigV4 from the local credential chain."""
    requires_request_body = True
    def __init__(self):
        creds = BotoSession().get_credentials()
        if creds is None:
            raise RuntimeError("no AWS credentials — SigV4 signing impossible")
        self._creds = creds
    def auth_flow(self, request):
        aws = AWSRequest(method=request.method, url=str(request.url),
                         data=request.content or b"",
                         headers={**dict(request.headers), **EXTRA_HEADERS})
        if "connection" in aws.headers:
            del aws.headers["connection"]
        SigV4Auth(self._creds, SERVICE, REGION).add_auth(aws)
        request.headers.update(dict(aws.headers))
        yield request



# --- sse event size (begin)
# Optional override of the MCP client's per-SSE-event byte cap (SDK default 1,048,576).
# UNSET => pass nothing (zero behavior change). An int in [1048576, 67108864] => raise to that
# many bytes. Disabling (None) is NOT allowed on this shared single-process proxy (OOM footgun).
# Anything else (none/0/negative/decimal/underscored/signed/out-of-range) => refuse at startup.
_AQ_SSE_MIN = 1048576       # the SDK default; never LOWER the cap (that only breaks more results)
_AQ_SSE_MAX = 67108864      # 64 MiB hard ceiling -> bounds the in-memory SSE buffer on the shared proxy
def _load_sse_kwargs():
    raw = os.environ.get("AQ_MAX_SSE_EVENT_SIZE", "").strip()
    if not raw:
        return {}
    if not raw.isdigit():
        sys.exit("AQ_MAX_SSE_EVENT_SIZE must be a plain positive integer number of bytes "
                 "(no sign, decimal point, underscores, or 'none'); disabling the cap is not allowed")
    n = int(raw)
    if n < _AQ_SSE_MIN or n > _AQ_SSE_MAX:
        sys.exit("AQ_MAX_SSE_EVENT_SIZE must be between %d and %d bytes (got %d)"
                 % (_AQ_SSE_MIN, _AQ_SSE_MAX, n))
    return {"max_sse_event_size": n}


_AQ_SSE_KW = _load_sse_kwargs()
log.info("SSE event-size override: %s", _AQ_SSE_KW or "none (SDK default)")
# --- sse event size (end)

def _require_target():
    if not TARGET_URL:
        sys.exit("AQ_TARGET_URL is required")


def _make_client():
    """Build the httpx(2) client with SigV4 auth using the SDK's own factory."""
    from mcp.client.streamable_http import create_mcp_http_client
    return create_mcp_http_client(auth=SigV4HttpxAuth())


async def _selftest() -> int:
    _require_target()
    _enforce_allowlist_floor()
    from mcp.client.session import ClientSession
    from mcp.client.streamable_http import streamable_http_client
    log.info("selftest -> %s (service=%s region=%s)", TARGET_URL, SERVICE, REGION)
    client = _make_client()
    async with streamable_http_client(TARGET_URL, http_client=client) as (read, write):
        async with ClientSession(read, write) as s:
            await s.initialize()
            tools = (await s.list_tools()).tools
            names = [t.name for t in tools]
            shown = [n for n in names if (not ALLOW or n in ALLOW)]
            print(f"OK: upstream returned {len(names)} tools; "
                  f"{len(shown)} after allow-list filter")
            for n in shown:
                print(f"  - {n}")
    return 0


async def _upstream_call(method_name: str, *args):
    """Open a FRESH upstream connection, initialize, run one call, close.
    Per-request (not a held session) so there is no long-lived idle SSE stream to be
    torn down — that teardown was exiting the whole process and making Quick retry."""
    from mcp.client.session import ClientSession
    from mcp.client.streamable_http import streamable_http_client
    client = _make_client()
    async with streamable_http_client(TARGET_URL, http_client=client, **_AQ_SSE_KW) as (read, write):
        async with ClientSession(read, write) as upstream:
            await upstream.initialize()
            fn = getattr(upstream, method_name)
            return await fn(*args)


async def _serve() -> None:
    _require_target()
    _enforce_allowlist_floor()
    import mcp.types as types
    from mcp.server import Server
    from mcp.server.stdio import stdio_server

    app = Server("aq-mcp-stdio")

    # MCP 2.x: register handlers explicitly. Each handler does its own upstream round-trip
    # via _upstream_call (fresh connection per request).
    async def handle_list_tools(ctx, params):
        log.info("handle_list_tools: querying upstream %s", TARGET_URL)
        tools = (await _upstream_call("list_tools")).tools
        tools = [t for t in tools if (not ALLOW or t.name in ALLOW)]
        log.info("handle_list_tools: returning %d tools", len(tools))
        return types.ListToolsResult(tools=tools)

    async def handle_call_tool(ctx, params):
        name = params.name
        arguments = getattr(params, "arguments", None) or {}
        if ALLOW and name not in ALLOW:
            raise ValueError(f"tool '{name}' not permitted")
        arguments, overridden = _apply_forced(name, arguments)
        if name in FORCED_ARGS:
            log.info("call %s: forced %s%s", name, sorted(FORCED_ARGS[name]),
                     (" (overrode caller values for %s)" % overridden) if overridden else "")
        arguments, supplied = _apply_secrets(name, arguments)
        if supplied:
            log.info("call %s: supplied %s from secret file (value not logged)", name, supplied)
        try:
            return await _upstream_call("call_tool", name, arguments)
        except Exception as _exc:
            log.warning("call %s failed upstream: %s", name, _es_describe(_exc))
            _es_secrets = [arguments[k] for k in supplied if isinstance(arguments.get(k), str)]
            return _error_result(_exc, types, _es_secrets)

    app.add_request_handler("tools/list", types.PaginatedRequestParams, handle_list_tools)
    app.add_request_handler("tools/call", types.CallToolRequestParams, handle_call_tool)

    # The stdio loop owns the process lifetime — it runs until stdin closes (i.e. until
    # Quick shuts the server down), NOT until some upstream stream ends.
    log.info("serve: handlers registered; entering stdio loop (allow=%s)", ALLOW or "ALL")
    async with stdio_server() as (sr, sw):
        await app.run(sr, sw, app.create_initialization_options())
    log.info("serve: stdio loop ended (stdin closed)")


def main() -> None:
    if "--selftest" in sys.argv[1:]:
        raise SystemExit(asyncio.run(_selftest()))
    asyncio.run(_serve())


if __name__ == "__main__":
    main()
