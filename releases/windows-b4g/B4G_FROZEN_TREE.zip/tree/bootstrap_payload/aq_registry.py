#!/usr/bin/env python3
"""Registry-driven launcher for stdio MCP servers (runs on the 3090).

  aq_registry.py run <target>    exec the stdio MCP server for one target (stdout stays clean: MCP only)
  aq_registry.py list            show all targets

Two target kinds are supported:

  remote (default; any target with no "kind" field)
      SigV4-signs and forwards to an IAM-protected Lambda Function URL via aq_mcp_stdio.py.
      Only https://<id>.lambda-url.<region>.on.aws hosts are ever signed for.

  "kind": "local"
      exec a LOCAL read-only stdio MCP server from this directory. The script must be named
      in LOCAL_SERVERS, so a registry edit can never point a target at an arbitrary program.
      Local targets must not define "url", are never signed, and make no network calls.
"""
import json, os, re, sys, subprocess, hashlib, datetime
HERE = os.path.dirname(os.path.abspath(__file__))
REG = os.environ.get("AQ_REGISTRY", os.path.join(HERE, "targets.json"))
STDIO = os.environ.get("AQ_STDIO_SCRIPT", os.path.join(HERE, "aq_mcp_stdio.py"))
NAME_RE = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")
URL_RE = re.compile(r"^https://[a-z0-9]+\.lambda-url\.([a-z0-9-]+)\.on\.aws(/.*)?$")

# Local stdio servers a "kind":"local" target is allowed to exec (basenames in HERE).
LOCAL_SERVERS = {"aq_build_artifacts_mcp.py"}

# --- D-2 allow-list floor (begin) ----------------------------------------------------------
# A gateway_policy.json marker in this directory (the gateway root) switches on an allow-list
# FLOOR for targets launched here. The marker is created create-only by the wizard bootstrap
# (native_gateway / remote_agent), NEVER by this launcher and NEVER shipped in the payload.
# Gateways without the marker (the existing 3090/3080) keep today's behaviour byte-for-byte.
# This control stops MISCONFIGURATION / silent exposure, not a malicious same-user process
# (a same-user process can edit the marker or the environment; that is the F-2 integrity track).
POLICY_MARKER = os.environ.get("AQ_POLICY_MARKER", os.path.join(HERE, "gateway_policy.json"))
_MARKER_MAX = 65536  # a policy marker is tiny; anything larger is refused (fail closed)
# AQ_ALLOWLIST_MODE values handed to the proxy when the floor is on.
MODE_ENFORCED = "enforced"
MODE_UNRESTRICTED = "unrestricted"
# Exception object (on a registry entry, key "unrestricted") required to run a no-allow target.
# P2 (Rev 2): anchored with \A...\Z (not ^...$, which would let a trailing newline through) and
# ASCII-only via re.ASCII so Unicode/full-width digits cannot pass. approval_id 8..128 chars.
_APPROVAL_RE = re.compile(r"\A[A-Za-z0-9._:-]{8,128}\Z", re.ASCII)
_UTC_RE = re.compile(r"\A[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z\Z", re.ASCII)
_UTC_FMT = "%Y-%m-%dT%H:%M:%SZ"
_EXCEPTION_KEYS = {"reason", "approval_id", "approved_utc"}
_REASON_MIN = 12
_REASON_MAX = 500          # cap so an approved reason stays a short, clean audit string
_APPROVAL_MIN = 8
_APPROVAL_MAX = 128
# P2: a far-future approved_utc is almost certainly a typo or a forged forward-date; reject more
# than this many seconds ahead of "now". This is a SANITY check (clock-skew tolerance), NOT an
# authenticity check -- the launcher cannot verify that an approval was actually granted.
_FUTURE_SKEW_SECONDS = 24 * 3600
# P1 (Rev 2): a validated allow-list name. The floor serialises AQ_TOOL_ALLOWLIST from the
# NORMALISED list so launcher and proxy enforce the SAME set; a comma/control char can never
# silently split one name into two. Max length keeps a single name sane.
_ALLOW_NAME_MAX = 128
# P3 (Rev 2): fields the launcher hands the proxy so the proxy can RE-validate an unrestricted
# exception itself (a bare AQ_ALLOWLIST_MODE=unrestricted from the environment alone is not
# enough on a marked gateway). AQ_UNRESTRICTED_DIGEST binds the three fields to the target name.
_ENV_REASON = "AQ_UNRESTRICTED_REASON"
_ENV_APPROVAL_ID = "AQ_UNRESTRICTED_APPROVAL_ID"
_ENV_APPROVED_UTC = "AQ_UNRESTRICTED_APPROVED_UTC"
_ENV_DIGEST = "AQ_UNRESTRICTED_DIGEST"


def _utcnow():
    """Naive UTC 'now', warning-free on Python 3.10/3.12/3.13.

    datetime.datetime.utcnow() is deprecated on 3.12+ (Security R2-L1 / Tester T-2). We use the
    timezone-aware now() and drop the tzinfo so the result stays a NAIVE UTC datetime, directly
    comparable with the naive datetime.strptime() result and with a naive injected ``now``.
    """
    return datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None)


class AllowlistFloorError(Exception):
    """Raised to refuse a launch under the allow-list floor. Carries only a safe message."""


# P4 (Reviewer (h)): one plain-language remedy line appended to every refusal. It names NO env
# values, URLs, tool names or tokens -- just what a non-expert operator should do next.
_REMEDY = ("Fix: add an allow-list of the tools this target should expose, or ask the gateway "
           "operator to add an approved unrestricted exception.")


def _marker_floor_on(path=None):
    """Return True if a valid floor marker is present, False if absent or an explicit opt-out.

    FAIL CLOSED (return True) on any present-but-unsafe marker: symlink, oversize, unreadable,
    non-JSON, non-object, or a missing/non-bool allowlist_floor. Only a regular-file marker that
    parses to an object with allowlist_floor === false counts as a deliberate opt-out.
    Uses os.lstat + a plain regular-file open (portable to Windows; no O_NOFOLLOW dependency).
    """
    p = path or POLICY_MARKER
    try:
        st = os.lstat(p)
    except FileNotFoundError:
        return False                      # no marker at all -> legacy
    except OSError:
        return True                       # cannot even stat it -> fail closed
    import stat as _st
    if _st.S_ISLNK(st.st_mode):
        return True                       # refuse to follow a symlink -> fail closed
    if not _st.S_ISREG(st.st_mode):
        return True                       # not a regular file -> fail closed
    if st.st_size > _MARKER_MAX:
        return True                       # implausibly large -> fail closed
    try:
        with open(p, "r", encoding="utf-8") as f:
            obj = json.load(f)
    except (OSError, ValueError):
        return True                       # unreadable / not JSON -> fail closed
    if not isinstance(obj, dict):
        return True                       # not an object -> fail closed
    floor = obj.get("allowlist_floor")
    if floor is True:
        return True
    if floor is False:
        return False                      # explicit, well-formed opt-out
    return True                           # missing / non-bool -> fail closed


def _entry_allow(entry):
    """The effective allow-list of a registry entry: non-blank, trimmed names only.

    LEGACY-SAFE view used only to decide "is there any allow-list present?" (presence test for
    the floor). This is lenient on purpose (it mirrors the pre-floor behaviour of just dropping
    blanks). Strict per-name validation happens in _entry_allow_strict, applied ONLY when the
    floor is on (see resolve_allowlist_policy / _allowlist_for_env). REQUIREMENT 5 forbids
    changing legacy behaviour, so the lenient view must never raise.
    """
    return [t.strip() for t in (entry.get("allow") or []) if isinstance(t, str) and t.strip()]


def _bad_allow_name(name):
    """Return a short reason string if *name* is not a safe allow-list member, else None.

    P1 (Security F-1/F-3): a name that is not a str, is empty after strip, contains a comma
    (which the proxy's split would turn into two different names) or any other control/
    whitespace-inside character, or exceeds _ALLOW_NAME_MAX, must be REFUSED when the floor is
    on -- never silently split or coerced. Applied ONLY under the floor; legacy serialisation
    is left byte-identical (see _allowlist_for_env).
    """
    if not isinstance(name, str):
        return "allow-list entries must be strings"
    s = name.strip()
    if not s:
        return "allow-list entries must not be blank"
    if len(s) > _ALLOW_NAME_MAX:
        return "an allow-list entry is too long"
    # A comma would be split by the proxy into two names; any ASCII control char (<32 or 127)
    # or internal whitespace would corrupt the comma-joined AQ_TOOL_ALLOWLIST round-trip.
    for c in s:
        if c == "," or ord(c) < 32 or ord(c) == 127 or c.isspace():
            return "an allow-list entry contains a comma, control character or whitespace"
    return None


def _entry_allow_strict(entry):
    """Normalised, de-duplicated allow-list for a FLOORED target. Raise on any bad member.

    P1: launcher and proxy must enforce the SAME set, so AQ_TOOL_ALLOWLIST is serialised from
    THIS list (see _allowlist_for_env). Order is preserved; exact duplicates are refused (a
    duplicate is almost always a copy/paste mistake and makes the intended set ambiguous).
    """
    raw = entry.get("allow") or []
    if not isinstance(raw, list):
        raise AllowlistFloorError("allow-list must be a JSON array of tool names")
    out = []
    seen = set()
    for item in raw:
        bad = _bad_allow_name(item)
        if bad:
            raise AllowlistFloorError(bad)
        s = item.strip()
        if s in seen:
            raise AllowlistFloorError("the allow-list contains a duplicate tool name")
        seen.add(s)
        out.append(s)
    return out


def _has_real_allow_member(entry):
    """True iff *entry* carries a REAL (non-blank) allow-list member. Pure; never raises.

    NOTE (Rev 4 / R3-M1): this helper is NO LONGER used by resolve_allowlist_policy -- the
    exception path now applies an explicit per-member rule (see that function) that refuses a
    non-string allow member for parity with the enforced path. The helper is RETAINED because
    tests/test_allowlist_floor.py::test_t1_has_real_allow_member_helper imports and asserts it
    directly; its body is unchanged. It documents the OLD lenient view: a "real member" is a str
    whose strip() is non-empty inside a list/tuple; a non-list/tuple allow value, or a list of
    only blanks / non-str items, has NO real member.

    NOTE (I-1, follow-up): "blank" throughout this floor follows Python str.strip()/str.isspace().
    NBSP ('\u00a0') and ideographic space ('\u3000') COUNT AS BLANK (strip to empty) and, as the
    only members beside a valid exception, resolve UNRESTRICTED; NUL ('\x00') and the zero-width
    family (ZWSP '\u200b', BOM '\ufeff', word-joiner '\u2060') are NOT whitespace, so they count
    as REAL members and are REFUSED (ambiguous). Intentional and fail-safe: only all-whitespace
    members can reach UNRESTRICTED.
    """
    allow = entry.get("allow")
    if not isinstance(allow, (list, tuple)):
        return False
    return any(isinstance(x, str) and x.strip() for x in allow)


def _has_control_char(s):
    """True if *s* contains any ASCII control character (ord < 32, including CR/LF, or 127)."""
    return any(ord(c) < 32 or ord(c) == 127 for c in s)


def _validate_exception(exc, now=None):
    """Validate the 'unrestricted' exception object. Raise AllowlistFloorError on any problem.

    Returns the three NORMALISED fields (reason stripped, approval_id/approved_utc as-is after
    validation) as a dict, so the launcher can hand EXACTLY these to the proxy (P3). Pure: no
    I/O; *now* (a naive UTC datetime) is injectable for tests.

    P2 (Tester D-1..D-5, Security F-4):
      - approval_id / approved_utc use re.fullmatch with ASCII-only classes (no Unicode digits,
        no trailing-newline acceptance).
      - approved_utc must be a REAL calendar date-time (datetime.strptime), not just the shape.
      - approved_utc more than _FUTURE_SKEW_SECONDS ahead of now is refused (SANITY check for a
        typo/forward-date, NOT an authenticity check).
      - reason rejects control characters (incl. CR/LF) and is capped at _REASON_MAX.
      - approval_id rejects control characters (the regex already excludes them, belt-and-braces).
    """
    if not isinstance(exc, dict):
        raise AllowlistFloorError("unrestricted exception must be a JSON object")
    extra = set(exc) - _EXCEPTION_KEYS
    if extra:
        raise AllowlistFloorError("unrestricted exception has unknown field(s): "
                                  + ", ".join(sorted(extra)))
    missing = _EXCEPTION_KEYS - set(exc)
    if missing:
        raise AllowlistFloorError("unrestricted exception missing field(s): "
                                  + ", ".join(sorted(missing)))
    reason = exc.get("reason")
    if not isinstance(reason, str):
        raise AllowlistFloorError("unrestricted exception reason must be a string")
    if _has_control_char(reason):
        raise AllowlistFloorError("unrestricted exception reason contains a control character")
    reason_s = reason.strip()
    if len(reason_s) < _REASON_MIN or len(reason_s) > _REASON_MAX:
        raise AllowlistFloorError("unrestricted exception reason must be %d..%d characters"
                                  % (_REASON_MIN, _REASON_MAX))
    approval = exc.get("approval_id")
    if (not isinstance(approval, str) or _has_control_char(approval)
            or not _APPROVAL_RE.fullmatch(approval)):
        raise AllowlistFloorError("unrestricted exception approval_id is missing or has an "
                                  "invalid format")
    approved = exc.get("approved_utc")
    if not isinstance(approved, str) or not _UTC_RE.fullmatch(approved):
        raise AllowlistFloorError("unrestricted exception approved_utc must be strict UTC "
                                  "YYYY-MM-DDTHH:MM:SSZ")
    try:
        when = datetime.datetime.strptime(approved, _UTC_FMT)
    except ValueError:
        raise AllowlistFloorError("unrestricted exception approved_utc is not a real "
                                  "calendar date-time")
    ref = now if now is not None else _utcnow()
    if (when - ref).total_seconds() > _FUTURE_SKEW_SECONDS:
        raise AllowlistFloorError("unrestricted exception approved_utc is too far in the "
                                  "future (sanity check, not authenticity)")
    return {"reason": reason_s, "approval_id": approval, "approved_utc": approved}


def unrestricted_digest(target_name, fields):
    """P3: a stable digest binding the validated exception fields to the TARGET name.

    The launcher computes it and passes it to the proxy via AQ_UNRESTRICTED_DIGEST; the proxy
    recomputes it over the fields it independently re-validates. A mismatch (or a missing/invalid
    field set) on a marked gateway => the proxy refuses. This stops accidental/partial
    configuration and a BARE env override; it does NOT stop a same-user attacker who can set all
    four variables consistently (that residual is the F-2 code-integrity track; the piece-2
    receipt carries the real audit trail). Not a secret/HMAC -- purely a consistency binding.
    """
    payload = "\x1f".join([
        "aq-d2-unrestricted-v1",
        target_name or "",
        fields["reason"],
        fields["approval_id"],
        fields["approved_utc"],
    ])
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def resolve_allowlist_policy(entry, marker_present, now=None):
    """Pure policy decision for the launcher. No I/O, no side effects.

    Returns a (mode, fields) tuple:
      - mode is None when the floor is off (legacy: the launcher must NOT set AQ_ALLOWLIST_MODE
        and leaves the environment byte-identical), else MODE_ENFORCED or MODE_UNRESTRICTED.
      - fields is None unless mode is MODE_UNRESTRICTED, in which case it is the dict of
        validated, normalised exception fields the launcher must hand the proxy (P3).
    Raises AllowlistFloorError to refuse the launch.

    P1: under the floor, the allow-list is validated STRICTLY (_entry_allow_strict); a bad name
    (comma/control/whitespace/non-string/over-length/duplicate) is refused here, so the exact
    same normalised set is what _allowlist_for_env serialises for the proxy. On a LEGACY host
    (no marker) this function returns (None, None) immediately and NOTHING about the allow-list
    is re-checked -- requirement 5 keeps legacy behaviour byte-identical.
    """
    if not marker_present:
        return (None, None)               # legacy host/gateway -> unchanged behaviour
    exc = entry.get("unrestricted")
    if exc is not None:
        fields = _validate_exception(exc, now=now)   # malformed/unknown shape -> refuse
        # CHANGE 1 (T-1) + R3-M1 (Rev 4): ambiguity + type validity are decided by an EXPLICIT
        # rule on entry["allow"], NOT the lenient _has_real_allow_member view. Rationale
        # (Security R3-M1 MEDIUM; Executive decision FIX; "never silently widen"): the enforced
        # path refuses a non-string allow member ("entries must be strings"); the exception path
        # MUST agree, so a non-string-garbage list such as [1, None] / [123] beside a valid
        # exception is now REFUSED instead of being silently swallowed as "no real member" and
        # resolving UNRESTRICTED. The rule, applied AFTER _validate_exception has passed:
        #   * allow absent / None            -> OK (fall through to UNRESTRICTED)
        #   * allow is a list                -> iterate members:
        #       - any member not a str       -> REFUSE ("allow-list entries must be strings")
        #       - any str non-blank after strip() -> REFUSE (ambiguous: exception + non-empty allow)
        #     an empty list or a blanks-only list falls through to UNRESTRICTED (Rev 3 T-1 stays)
        #   * allow is any other type        -> REFUSE ("allow-list must be a JSON array of tool names")
        # The non-exception (enforced) path below is UNCHANGED: it still uses _entry_allow_strict,
        # which fails closed on a blank member exactly as today. (tuple/str/dict/int/bool are NOT
        # JSON arrays, so they are refused as a type error, matching _entry_allow_strict's guard.)
        allow_val = entry.get("allow")
        if allow_val is not None:
            if not isinstance(allow_val, list):
                raise AllowlistFloorError("allow-list must be a JSON array of tool names")
            for item in allow_val:
                if not isinstance(item, str):
                    raise AllowlistFloorError("allow-list entries must be strings")
                # I-1: "blank" == Python str.strip() whitespace ONLY. NBSP / ideographic space are
                # blank (fall through -> UNRESTRICTED); NUL and zero-width chars (ZWSP/BOM/word-
                # joiner) are NOT stripped, so they remain a real member here and REFUSE. Intentional
                # and fail-safe: only all-whitespace members can ever reach UNRESTRICTED.
                if item.strip():
                    raise AllowlistFloorError("ambiguous policy: an unrestricted exception and a "
                                              "non-empty allow-list cannot both be set")
        # reaching here => allow is absent, None, [], or a blanks-only list -> UNRESTRICTED
        return (MODE_UNRESTRICTED, fields)
    allow = _entry_allow_strict(entry)
    if not allow:
        raise AllowlistFloorError("allow-list floor is on: this target has no allow-list and "
                                  "no approved unrestricted exception; refusing to start")
    return (MODE_ENFORCED, None)


def _allowlist_for_env(entry, marker_present, mode=None):
    """The comma-joined AQ_TOOL_ALLOWLIST value the proxy will receive.

    P1 (Security F-1/F-3): when the floor is ON, serialise from the STRICT, normalised list so
    the launcher's validated set and the proxy's enforced set are the same bytes (no silent
    comma split, no non-string TypeError). When the floor is OFF (legacy / no marker), fall back
    to the EXACT historical serialisation (",".join(entry.get("allow") or [])) so legacy output
    is byte-for-byte unchanged (requirement 5). Only used by the remote/local env builders.

    CHANGE 1 (T-1): *mode* is the policy resolved by resolve_allowlist_policy. On the
    UNRESTRICTED path the registry entry may legitimately carry a blanks-only allow-list next
    to its exception; serialising that through _entry_allow_strict would RAISE on the blank
    member. Under the floor in UNRESTRICTED mode we therefore emit an EMPTY AQ_TOOL_ALLOWLIST
    (the proxy refuses unrestricted + a non-empty allow-list), so a blanks-only registry entry
    reaches the proxy as the empty string -- never as a raised error and never as a stray name.
    The default mode=None keeps every existing caller and the legacy/enforced behaviour
    byte-identical (floor-on, mode None or enforced -> strict normalised join as before).
    """
    if marker_present and mode == MODE_UNRESTRICTED:
        return ""
    if marker_present:
        return ",".join(_entry_allow_strict(entry))
    return ",".join(entry.get("allow") or [])
# --- D-2 allow-list floor (end) ------------------------------------------------------------

def load():
    with open(REG) as f:
        return json.load(f)

def _target(name):
    if not NAME_RE.match(name or ""):
        raise SystemExit(f"invalid target name: {name!r}")
    reg = load()
    t = reg["targets"].get(name)
    if t is None:
        raise SystemExit(f"unknown target {name!r}; known: {', '.join(sorted(reg['targets']))}")
    return t

def _remote_env(name, t, marker_present=False, mode=None):
    url = t["url"].rstrip("/")
    m = URL_RE.match(url)
    if not m:
        raise SystemExit(f"refusing non-Lambda-URL target for {name!r}: {url}")
    if not url.endswith("/mcp"):
        url += "/mcp"
    return {"AQ_TARGET_URL": url,
            "AQ_REGION": t.get("region") or m.group(1),
            "AQ_TOOL_ALLOWLIST": _allowlist_for_env(t, marker_present, mode),
            "AQ_EXTRA_HEADERS": json.dumps(t.get("headers") or {}),
            "AQ_FORCED_ARGS": json.dumps(t.get("forced_args") or {}),
            "AQ_SECRET_ARGS": json.dumps(t.get("secret_args") or {}),
            "AQ_LOG_FILE": os.path.join(HERE, "aq-mcp.log")}   # always set -> inherited env can't leak in

def _local_env(name, t, marker_present=False, mode=None):
    server = t.get("server")
    if not isinstance(server, str) or server not in LOCAL_SERVERS:
        raise SystemExit(f"local target {name!r}: server must be one of "
                         f"{', '.join(sorted(LOCAL_SERVERS))}, got {server!r}")
    if t.get("url"):
        raise SystemExit(f"local target {name!r} must not define a url")
    cfg = t.get("config") or {}
    if not isinstance(cfg, dict):
        raise SystemExit(f"local target {name!r}: config must be a JSON object")
    # Every variable is always set so inherited environment can never widen a local target.
    return {"AQ_TARGET_URL": "",
            "AQ_TOOL_ALLOWLIST": _allowlist_for_env(t, marker_present, mode),
            "AQ_EXTRA_HEADERS": "{}",
            "AQ_FORCED_ARGS": "{}",
            "AQ_BA_CONFIG_JSON": json.dumps(cfg)}

def target_kind(name):
    return (_target(name).get("kind") or "remote").strip().lower()

def target_env(name, marker_present=False, mode=None):
    # marker_present defaults to False so every existing caller (and the legacy path) gets the
    # byte-identical historical env; main() passes the real marker state when the floor is on.
    # CHANGE 1 (T-1): *mode* (the resolved policy) is forwarded so the UNRESTRICTED path emits
    # an empty AQ_TOOL_ALLOWLIST; default None keeps legacy/enforced output byte-identical.
    t = _target(name)
    kind = (t.get("kind") or "remote").strip().lower()
    if kind == "local":
        return _local_env(name, t, marker_present, mode)
    if kind != "remote":
        raise SystemExit(f"target {name!r}: unknown kind {kind!r} (expected remote or local)")
    return _remote_env(name, t, marker_present, mode)

def target_script(name):
    """Absolute path of the stdio script that `run <target>` will exec."""
    t = _target(name)
    kind = (t.get("kind") or "remote").strip().lower()
    if kind == "local":
        server = t.get("server")
        if not isinstance(server, str) or server not in LOCAL_SERVERS:
            raise SystemExit(f"local target {name!r}: server must be one of "
                             f"{', '.join(sorted(LOCAL_SERVERS))}, got {server!r}")
        return os.path.join(HERE, server)
    return STDIO

def main(argv):
    if len(argv) >= 2 and argv[0] == "run":
        name = argv[1]
        entry = _target(name)
        # D-2 floor: decide policy BEFORE building env or launching anything. A refusal exits
        # non-zero with a plain message and never reaches the proxy launch below. On a LEGACY
        # host (no marker) resolve returns (None, None): the environment, exit codes and output
        # are unchanged (one extra caught os.lstat for the marker per start -- see report F-5).
        marker = _marker_floor_on()
        try:
            mode, fields = resolve_allowlist_policy(entry, marker)
        except AllowlistFloorError as e:
            sys.stderr.write("aq_registry: refusing to launch %r: %s\n" % (name, e))
            sys.stderr.write(_REMEDY + "\n")   # P4: one plain-language next step, no values
            raise SystemExit(2)
        env = {**os.environ, **target_env(name, marker, mode)}
        # P3: a bare AQ_ALLOWLIST_MODE must not be enough on the proxy side. When the floor is on
        # the launcher always sets the mode; for an UNRESTRICTED decision it also hands the proxy
        # the validated exception fields plus a digest binding them to this target, so the proxy
        # re-validates and recomputes the digest and refuses a bare/partial/mismatched set.
        if mode is not None:
            env["AQ_ALLOWLIST_MODE"] = mode   # floor on -> tell the proxy which mode applies
        if mode == MODE_UNRESTRICTED and fields is not None:
            env[_ENV_REASON] = fields["reason"]
            env[_ENV_APPROVAL_ID] = fields["approval_id"]
            env[_ENV_APPROVED_UTC] = fields["approved_utc"]
            env["AQ_TARGET_NAME"] = name          # proxy binds the digest to this target name
            env[_ENV_DIGEST] = unrestricted_digest(name, fields)
        if os.name == 'nt':
            # Windows lacks Unix exec replacement semantics; retain the stdio
            # pipe and exit with the child MCP server's status.
            raise SystemExit(subprocess.call([sys.executable, target_script(name)], env=env))
        os.execve(sys.executable, [sys.executable, target_script(name)], env)
    elif argv[:1] == ["list"]:
        for n, t in sorted(load()["targets"].items()):
            print(f"{n:24} {t.get('env','?'):11} allow={len(t.get('allow') or [])} {t.get('note','')}")
    else:
        raise SystemExit(__doc__)

if __name__ == "__main__":
    main(sys.argv[1:])
