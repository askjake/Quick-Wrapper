"""P2 Slice 1: capability gates for the macOS wizard (stdlib only).

Windows/Linux: every function returns None immediately and never inspects its
arguments, so existing behaviour is unchanged. On macOS (sys.platform ==
'darwin'):
  * G1b (any SSH connection / remote process / backend handshake) needs an
    OPERATION-BOUND typed approval (Amendment A1): scope 'inspect-gateway' needs
    'INSPECT GATEWAY <user>@<host>' and allows op 'inspect' only; scope
    'verify-backend' needs 'VERIFY BACKEND <target>' and allows ops inspect,
    inspect_lambda_target, discover, probe_existing only.
  * G2 (gateway install / modify) is always refused; no token unlocks it.
  * G3 writes (Quick config / import file) are always refused.
  * G4 (live provider execution) is always refused.
There is no module-level unlock flag: every protected call must receive its
token explicitly. Messages are fixed strings and never echo caller input.
"""
from platform_p2 import is_darwin


class GateRefused(Exception):
    pass


FULL_COPY_TOKEN = 'COPY FULL'
FULL_EXPORT_TOKEN = 'EXPORT FULL'


SCOPE_INSPECT_GATEWAY = 'inspect-gateway'
SCOPE_VERIFY_BACKEND = 'verify-backend'
# A1.2: the remote ops each scope may send. Everything else is refused on macOS.
G1B_SCOPE_OPS = {
    SCOPE_INSPECT_GATEWAY: frozenset(['inspect']),
    SCOPE_VERIFY_BACKEND: frozenset(['inspect', 'inspect_lambda_target', 'discover',
                                     'probe_existing']),
}
_SCOPE_PREFIX = {SCOPE_INSPECT_GATEWAY: 'INSPECT GATEWAY ',
                 SCOPE_VERIFY_BACKEND: 'VERIFY BACKEND '}
# Zero-width, bidi-control, soft-hyphen and BOM code points are refused in labels
# (most are already non-printable; listed explicitly so the rule does not depend on
# the Unicode database version).
_INVISIBLE = frozenset(['\u00ad', '\u200b', '\u200c', '\u200d', '\u200e', '\u200f',
                        '\u202a', '\u202b', '\u202c', '\u202d', '\u202e', '\u2060',
                        '\u2061', '\u2062', '\u2063', '\u2064', '\u2066', '\u2067',
                        '\u2068', '\u2069', '\ufeff'])


def _bad_label(label):
    """A1.2 rule e: non-empty exact str, printable, no whitespace, no control or
    zero-width characters. str subclasses are refused (exact type only)."""
    if type(label) is not str or label == '':
        return True
    return any(ch.isspace() or not ch.isprintable() or ch in _INVISIBLE for ch in label)


def gateway_label(user, host):
    """The validated 'user@host' label of the inspect-gateway scope."""
    if _bad_label(user) or _bad_label(host) or '@' in user or '@' in host:
        raise GateRefused('Invalid SSH user or host for the typed confirmation')
    return user + '@' + host


def g1b_token(scope, label):
    """The exact text the operator must type for this scope and label."""
    prefix = _SCOPE_PREFIX.get(scope) if type(scope) is str else None
    if prefix is None:
        raise GateRefused('Unknown remote-access scope for the typed confirmation')
    if _bad_label(label):
        raise GateRefused('Invalid label for the typed confirmation')
    if scope == SCOPE_INSPECT_GATEWAY:
        parts = label.split('@')
        if len(parts) != 2:
            raise GateRefused('Invalid SSH user or host for the typed confirmation')
        label = gateway_label(parts[0], parts[1])
    return prefix + label


def token_matches(expected, supplied):
    """Strict equality only: no strip, no case folding, no normalisation.
    B3c (F-T1-01): both values must be EXACT str (type(x) is str). A str subclass is
    refused, so a rigged __eq__ can never satisfy a typed confirmation."""
    return (type(expected) is str and type(supplied) is str
            and expected != '' and expected == supplied)


def require_g1b(scope, label, supplied, op, plat=None):
    """non-darwin: return None, looking at nothing. darwin: GateRefused unless the
    scope is known AND op is in that scope's op set AND the supplied text equals
    g1b_token(scope, label) exactly (supplied must be an exact str)."""
    if not is_darwin(plat):
        return None
    ops = G1B_SCOPE_OPS.get(scope) if type(scope) is str else None
    if ops is None:
        raise GateRefused('Remote access was not authorized: unknown scope')
    if type(op) is not str or op not in ops:
        raise GateRefused('Remote access was not authorized for this operation')
    expected = g1b_token(scope, label)
    if type(supplied) is not str or not token_matches(expected, supplied):
        raise GateRefused('Remote access was not authorized: '
                          'the typed confirmation did not match')
    return None


def refuse_g2(operation, plat=None):
    if not is_darwin(plat):
        return None
    raise GateRefused('Gateway install or modification is not available '
                      'on macOS in Slice 1')


def refuse_g3_write(operation, plat=None):
    if not is_darwin(plat):
        return None
    raise GateRefused('Writing Quick configuration or an import file is not '
                      'available on macOS in Slice 1 (preview only)')


def refuse_g4(operation, plat=None):
    if not is_darwin(plat):
        return None
    raise GateRefused('Live provider tool execution is not available on '
                      'macOS in Slice 1')


def require_full_variant(kind, supplied, plat=None):
    if not is_darwin(plat):
        return None
    if kind == 'copy':
        expected = FULL_COPY_TOKEN
    elif kind == 'export':
        expected = FULL_EXPORT_TOKEN
    else:
        raise GateRefused('Unknown full-variant request')
    if not token_matches(expected, supplied):
        raise GateRefused('The typed confirmation for the FULL variant '
                          'did not match')
    return None
