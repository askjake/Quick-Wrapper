"""Headless engineering interface to the same safe wizard deployment engine."""
import argparse
import json
import pathlib
import sys
from deploy_lib import SSHGateway, ConnectorDeployer
import capability_gate
import platform_p2
from native_gateway import NativeGateway
from model import (validate_spec, validate_spec_for_host, quick_connector,
                   plain_language_summary, mutating_confirm_text, host_is_wizard_lambda_only,
                   secure_write_json, FULL_VARIANT_WARNING, RedactionError,
                   assert_identity_safe, redact_identity_strict, IdentityRedactionError,
                   IDENTITY_UNSAFE_REFUSAL)
from quick_reg import (write_quick_config, quick_instructions, quick_instructions_screen,
                       emit_quick_import_file, find_quick_profile_configs,
                       check_name_collision, verify_quick_import, import_instructions,
                       ImportFileError, path_looks_synced)


def read_json(path):
    return json.loads(pathlib.Path(path).read_text(encoding='utf-8'))


def write_new_json(path,data):
    # B2b S7: owner-only (0600) create-only write. Receipts/plans may contain the real
    # gateway host/user (needed for rollback), so they are NOT redacted but ARE mode-locked.
    secure_write_json(path,data)


def load_bootstrap_receipt(path):
    """Load a wizard-written bootstrap receipt (S2 state the wizard holds).

    Returns the parsed dict, or None when no path is given. A path that is present
    but unreadable/not JSON is a hard error: the user asked us to consider that
    receipt, so we must not silently ignore it and fall through to the permissive
    'no state' path.
    """
    if not path:
        return None
    receipt=read_json(path)
    if not isinstance(receipt,dict):
        raise ValueError('--bootstrap-receipt must be a JSON object produced by a wizard bootstrap')
    return receipt


def _import_settings(spec):
    """Build the import-file settings for a spec by RE-DERIVING command/args from
    the spec via the existing quick_connector builder (never typed by hand).

    quick_connector returns {id, name, connection_type, command, arguments(list),
    timeout_seconds, environment_variables}. The import connector name must match
    ^[a-z0-9][a-z0-9-]{0,63}$; the human display 'name' (e.g. 'AQ rtr-demo') does
    not, so we emit under the stable 'id' (e.g. 'aq-<target>') and drop the display
    name. command/args come straight from the builder, byte-for-byte with what the
    manual/export path would show.
    """
    cfg = quick_connector(spec)
    return {'command': cfg['command'],
            'args': list(cfg['arguments']),
            'id': cfg['id']}


def _import_name(spec):
    """The connector name an import of THIS spec will use: the stable id."""
    return quick_connector(spec)['id']


def _path_looks_synced(path):
    """True if a path sits inside a known cloud-sync folder.

    F-2 / Tester D-1 single-source: this delegates to quick_reg.path_looks_synced,
    the ONE authoritative marker list, so the CLI advisory pre-check and the
    emitter's refusal share identical markers (including 'iCloud Drive') and can
    never drift apart again.
    """
    return path_looks_synced(path)


def main(argv=None):
    p=argparse.ArgumentParser(description='AQ-MCP Wizard CLI (registered Quick connector still requires manual UI action)')
    p.add_argument('operation',choices=['inspect','discover','plan','apply','export','rollback','bootstrap','repair-permissions','save-bootstrap-receipt','import-file','import-check','import-verify'])
    p.add_argument('manifest',nargs='?',help='JSON manifest (no secrets)')
    p.add_argument('--known-hosts',default=str(pathlib.Path.home()/'.ssh/known_hosts'))
    # v04 native-local: use/create a user-owned gateway on this computer with no SSH.
    p.add_argument('--native-local',action='store_true',help='Use/create user-owned gateway on this computer without SSH')
    p.add_argument('--plan-file')
    p.add_argument('--receipt-file')
    p.add_argument('--output-file')
    p.add_argument('--approve-target',default='')
    p.add_argument('--host')
    p.add_argument('--user')
    p.add_argument('--approve-bootstrap',action='store_true',help='Create missing gateway and install pinned dependencies')
    p.add_argument('--approve-repair',action='store_true',help='Remove group/world write from inspected owned core files')
    # S4: explicit, non-interactive confirmation for apply (GUI parity). Default refuses.
    p.add_argument('--approve-apply',action='store_true',
                   help='Explicitly approve the gateway registry change for apply. Without this '
                        'flag, apply refuses unless you type yes at an interactive prompt.')
    # S2: a bootstrap receipt THIS wizard wrote. When it proves the host is the
    # Lambda-only bootstrapped lane, git/local manifests are refused.
    p.add_argument('--bootstrap-receipt',
                   help='Path to a bootstrap receipt the wizard wrote for this host. If it shows a '
                        'wizard Lambda-only bootstrap, Git and Local manifests are refused.')
    # B2b S7: export is REDACTED (shareable) by default; --full-export writes the real login/host.
    p.add_argument('--full-export',action='store_true',
                   help='Write the FULL export (real login/host). Default export is REDACTED for '
                        'sharing. The full file must not be pasted into tickets, decks or chat.')
    # Import-phase (stage 2a) options. import-file writes the single import file; the
    # read-only import-check / import-verify commands read Quick's own mcp_config.json.
    p.add_argument('--out-dir',
                   help='import-file: directory to write the Quick import file into. Must be '
                        'outside any git repo and (unless --allow-synced) outside synced folders.')
    p.add_argument('--allow-synced',action='store_true',
                   help='import-file: permit --out-dir inside a OneDrive/Dropbox/Google Drive/'
                        'iCloud folder. The import file carries your login/host; off by default.')
    p.add_argument('--name',
                   help='import-check/import-verify: the connector name to look for in Quick.')
    p.add_argument('--profile-dir',
                   help='import-check: Quick home dir to scan (defaults to ~/.quickwork).')
    p.add_argument('--config-path',
                   help='import-verify: a single mcp_config.json to check instead of discovery.')
    # P2 Slice 1 (macOS only; ignored on Windows/Linux): typed G1b confirmation.
    # A1.1 P2-SEC-054: the accurate wording is used on macOS only; off macOS the pre-A1
    # merged-tree wording is kept byte-for-byte so Windows/Linux --help does not change.
    p.add_argument('--ack',default=None,
                   help=(DARWIN_ACK_HELP if platform_p2.is_darwin() else
                         'macOS: type exactly VERIFY BACKEND <target> to allow the SSH metadata '
                         'handshake (inspect/discover/plan with remote read). Ignored elsewhere.'))
    args=p.parse_args(argv)
    if platform_p2.is_darwin():
        _darwin_preflight(p,args)
    if args.operation in ('bootstrap','repair-permissions'):
        # v04 native-local: native gateway needs no --host/--user; SSH still does.
        if not args.native_local and (not args.host or not args.user):
            p.error('remote bootstrap/repair requires --host and --user')
        d=ConnectorDeployer(NativeGateway() if args.native_local else SSHG(args.host,args.user,args.known_hosts))
        if args.operation=='bootstrap':
            if not args.approve_bootstrap:p.error('bootstrap requires --approve-bootstrap')
            result=d.bootstrap(approved=True)
        else:
            # v04: permission repair is an SSH/Linux-only operation.
            if args.native_local:p.error('permission repair is Linux SSH only')
            if not args.approve_repair:p.error('repair-permissions requires --approve-repair')
            before=d.inspect()
            result=d.repair_permissions(before,approved=True)
        print(json.dumps(result,indent=2));return 0
    if args.operation=='save-bootstrap-receipt':
        # B2b S2 follow-up: persist the receipt the wizard already holds so S2 state
        # survives across sessions. Round-trips through host_is_wizard_lambda_only and is
        # written with S7 permissions. It only verifies the receipt; it does not touch SSH.
        if not args.manifest or not args.output_file:
            p.error('save-bootstrap-receipt requires a receipt JSON path and --output-file')
        receipt=read_json(args.manifest)
        if not host_is_wizard_lambda_only(receipt):
            p.error('Not a wizard Lambda-only bootstrap receipt; refusing to save it as one.')
        write_new_json(args.output_file,receipt)
        print(json.dumps({'status':'BOOTSTRAP_RECEIPT_SAVED','output_file':args.output_file,
                          'wizard_lambda_only':True},indent=2));return 0
    if args.operation=='rollback':
        # v04 native-local: native rollback needs no --host/--user; SSH still does.
        if not args.receipt_file or (not args.native_local and (not args.host or not args.user)):
            p.error('rollback requires --receipt-file and for SSH --host and --user')
        receipt=read_json(args.receipt_file)
        if args.approve_target != receipt.get('target'):
            p.error('--approve-target must match the rollback receipt target')
        result=ConnectorDeployer(NativeGateway() if args.native_local else SSHG(args.host,args.user,args.known_hosts)).rollback(receipt)
        print(json.dumps(result,indent=2));return 0
    # ---- Import-phase read/low-risk commands (stage 2a) ----
    # import-check reads Quick's mcp_config.json files only; no manifest/spec needed.
    if args.operation=='import-check':
        if not args.name:
            p.error('import-check requires --name')
        return _run_import_check(p, args)
    # import-file and import-verify both RE-DERIVE command/args from the manifest spec.
    if args.operation in ('import-file','import-verify'):
        if not args.manifest:
            p.error(args.operation+' requires a manifest (the same spec export takes)')
        if args.operation=='import-file' and not args.out_dir:
            p.error('import-file requires --out-dir')
        if args.operation=='import-verify' and not args.name:
            p.error('import-verify requires --name')
        spec=read_json(args.manifest)
        # S2 host refusal applies to the spec exactly as for export/plan/apply.
        bootstrap_receipt=load_bootstrap_receipt(args.bootstrap_receipt)
        validate_spec_for_host(spec,bootstrap_receipt)
        if args.operation=='import-file':
            return _run_import_file(p, args, spec)
        return _run_import_verify(p, args, spec)
    if not args.manifest:p.error('manifest required')
    spec=read_json(args.manifest)
    # S2: refuse git/local on a host THIS wizard bootstrapped with the Lambda lane only.
    bootstrap_receipt=load_bootstrap_receipt(args.bootstrap_receipt)
    validate_spec_for_host(spec,bootstrap_receipt)
    if args.operation=='export':
        if platform_p2.is_darwin():return _darwin_export(p,args,spec)
        if not args.output_file:p.error('export requires --output-file')
        # B2b S7: redacted by default; --full-export for the real login/host variant.
        redacted=not args.full_export
        # E2/N1 fail-closed: for the redacted (shareable) export, redact_identity
        # refuses (RedactionError) if the login/host is empty. Show the message and
        # refuse the share rather than writing an unredacted file.
        try:
            write_quick_config(spec,args.output_file,redacted=redacted)
            instructions=quick_instructions(spec,redacted=redacted)
        except RedactionError as exc:
            p.error('Refusing to write a shareable export: '+str(exc))
        if args.full_export:
            print(FULL_VARIANT_WARNING,file=sys.stderr)
        # The on-screen instructions follow the same redaction choice as the written file.
        print(instructions);return 0
    # v04 native-local: the transport flag and manifest transport must agree, so a native
    # run can never be dispatched over SSH (and vice versa). Checked AFTER the S2 host
    # refusal and BEFORE building a deployer, so neither safety side is bypassed.
    if bool(args.native_local)!=(spec.get('transport')=='native-local'):
        p.error('Transport mismatch: --native-local must match manifest transport=native-local')
    if platform_p2.is_darwin():
        return _darwin_remote(p,args,spec)
    d=ConnectorDeployer(NativeGateway() if args.native_local else SSHG(spec['host'],spec['user'],args.known_hosts))
    if args.operation=='inspect': result=d.inspect()
    elif args.operation=='discover': result=d.discover(spec)
    elif args.operation=='plan':
        result=d.prepare(spec)
        # S5: show the plain-language summary alongside the machine plan.
        print(plain_language_summary(spec,result),file=sys.stderr)
        if args.plan_file:write_new_json(args.plan_file,result)
    elif args.operation=='apply':
        if not args.plan_file or not args.receipt_file or args.approve_target!=spec['target']:
            p.error('apply requires --plan-file, --receipt-file and --approve-target matching manifest target')
        prepared=read_json(args.plan_file)
        # S5: plain-language summary BEFORE the confirm gate, on stderr so stdout stays clean JSON.
        print(plain_language_summary(spec,prepared),file=sys.stderr)
        # S4: GUI-parity confirmation. Show the mutating-tool warning when name-flagged
        # mutators are present, then require an explicit flag OR an interactive typed 'yes'.
        risky=prepared.get('potentially_mutating_tools_name_only') or []
        if risky:
            print(mutating_confirm_text(risky),file=sys.stderr)
        if not confirm_apply(args.approve_apply,spec['target']):
            p.error('apply not approved: pass --approve-apply or type "yes" at the prompt. Nothing was changed.')
        result=d.deploy(spec,prepared,True)
        write_new_json(args.receipt_file,result)
    print(json.dumps(result,indent=2));return 0


def _run_import_file(p, args, spec):
    """import-file: RE-DERIVE command/args from the spec, write ONE Quick import
    file into --out-dir, and print path/sha/bytes/name + a loud login/host warning
    + the import instructions. Never prints the file content. Refuses synced
    folders unless --allow-synced. Exit 0 on success, 2 on refusal."""
    # Follow-up (Security cond A / F-1 timing): warn to stderr BEFORE anything is
    # written, so the user sees the placement caution even when the file is about
    # to be created. Placed at the very top of the handler so it prints FIRST -
    # including on a refused destination (synced / git / project folder), which
    # returns before emit and therefore never reaches the post-write warning.
    print('CAUTION: about to write a Quick import file holding your login and the '
          'gateway address into --out-dir; it is NOT permission-protected on Windows. '
          'Use a PRIVATE local folder OUTSIDE any synced, shared, cloud-backed-up or '
          'git folder, and delete it right after Quick loads it.', file=sys.stderr)
    if not args.allow_synced and _path_looks_synced(args.out_dir):
        print('REFUSED: --out-dir is inside a synced folder (OneDrive/Dropbox/Google '
              'Drive/iCloud). The import file carries your login and host and must not '
              'sync off this machine. Pass --allow-synced only if you accept that. '
              'Note: this is a NAME-BASED heuristic and cannot see OneDrive Known '
              'Folder Move redirection, network shares, mapped drives or cloud-synced '
              'folders with unusual names, so you must choose a private local folder '
              'yourself.',
              file=sys.stderr)
        return 2
    try:
        settings=_import_settings(spec)
        # allow_inside_repo stays False (not exposed on the CLI): the import file must
        # never land inside a git work tree or this project folder.
        result=emit_quick_import_file(settings, args.out_dir, allow_synced=args.allow_synced)
    except ImportFileError as exc:
        print('REFUSED: '+str(exc), file=sys.stderr)
        return 2
    # Print ONLY metadata (never the file content / command / args).
    print('Import file written:')
    print('  path   : {}'.format(result['path']))
    print('  sha256 : {}'.format(result['sha256']))
    print('  bytes  : {}'.format(result['bytes']))
    print('  name   : {}'.format(result['name']))
    print('')
    # F-1: the import file holds the real login + gateway address and, on Windows, is
    # NOT permission-protected (it inherits the containing folder's access rules - no
    # ACL is applied). Say so plainly; do not claim any protection.
    print('!!! WARNING: this import file contains your login and the gateway address. '
          'On Windows it is NOT permission-protected - it inherits the containing '
          'folder\'s access rules, so anyone who can read that folder can read it. '
          'Create it only in a PRIVATE folder OUTSIDE any synced, shared, cloud-backed-up '
          'or git folder, and delete it right after Quick has created the connector. '
          'Never commit or publish it.')
    print('')
    print(import_instructions(settings, spec.get('kind', 'local'), import_path=result['path']))
    return 0


def _run_import_check(p, args):
    """import-check: read-only name-collision scan of Quick's mcp_config.json.
    Prints only counts and a plain verdict COLLISION / NO_COLLISION / UNREADABLE.
    Never names any other connector. Exit 0 either way (it is a status query)."""
    try:
        configs=find_quick_profile_configs(args.profile_dir)
    except Exception:
        print('UNREADABLE')
        print('configs_scanned: 0')
        return 0
    if not configs:
        print('NO_COLLISION')
        print('configs_scanned: 0')
        print('collisions: 0')
        return 0
    total=0
    scanned=0
    for cfg in configs:
        scanned+=1
        res=check_name_collision(args.name, cfg)
        total+=res.get('count', 0)
    print('COLLISION' if total>0 else 'NO_COLLISION')
    print('configs_scanned: {}'.format(scanned))
    print('collisions: {}'.format(total))
    return 0


def _run_import_verify(p, args, spec):
    """import-verify: RE-DERIVE command/args from the spec and read-only verify the
    stored connector in each discovered mcp_config.json (or --config-path). Prints
    the status, booleans, and the timeout NUMBER + location if present, plus a
    plain next step per status. Never prints args/env/source/other connectors.
    Exit 0 only if some config reports FOUND_MATCH, else 2."""
    cfg=quick_connector(spec)
    expected_command=cfg['command']
    expected_args=list(cfg['arguments'])
    name=args.name
    if args.config_path:
        configs=[args.config_path]
    else:
        configs=find_quick_profile_configs(args.profile_dir)
    if not configs:
        print('status: NOT_FOUND')
        print('next: no Quick mcp_config.json was found to check; confirm Quick is '
              'installed for this user, or pass --config-path.')
        return 2
    any_match=False
    for cfg_path in configs:
        res=verify_quick_import(name, expected_command, expected_args, cfg_path)
        status=res.get('status')
        if status=='FOUND_MATCH':
            any_match=True
        print('status: {}'.format(status))
        if status in ('FOUND_MATCH','FOUND_MISMATCH_COMMAND','FOUND_MISMATCH_ARGS'):
            print('  disabled            : {}'.format(res.get('disabled')))
            print('  has_env             : {}'.format(res.get('has_env')))
            print('  has_startup_timeout : {}'.format(res.get('has_startup_timeout')))
            if res.get('has_startup_timeout'):
                print('  startup_timeout     : {}'.format(res.get('startup_timeout')))
                print('  startup_timeout_at  : {}'.format(res.get('startup_timeout_location')))
            if 'auto_disabled' in res:
                print('  auto_disabled       : {}'.format(res.get('auto_disabled')))
        print('  next: {}'.format(_verify_next_step(status, res, spec)))
    return 0 if any_match else 2


def _verify_next_step(status, res, spec):
    """A plain-language next step for each verify status. No secrets, no args."""
    kind=spec.get('kind', 'local')
    tmo='30 s' if kind=='lambda' else '120 s'
    if status=='FOUND_MATCH':
        msg=('the stored command matches. ')
        if not res.get('has_startup_timeout'):
            msg+=('Set the timeout in the connector\'s edit dialog ({} for this '
                  'connector: Lambda 30 s, Git/local 120 s), then '.format(tmo))
        else:
            msg+='Then '
        msg+='open a NEW chat and try one harmless read-only action.'
        return msg
    if status=='MULTIPLE_MATCHES':
        return ('more than one connector matches this name. Delete the duplicate(s) '
                'yourself in Quick\'s Customize > Connectors page, then re-check.')
    if status=='FOUND_MISMATCH_COMMAND':
        return ('a connector with this name exists but its command differs from this '
                'spec. You may have imported a different file; delete it and re-import.')
    if status=='FOUND_MISMATCH_ARGS':
        return ('a connector with this name exists but its arguments differ from this '
                'spec. You may have imported a different file; delete it and re-import.')
    if status=='UNREADABLE':
        return ('this config file could not be read as expected; it may be open/locked '
                'or in an unexpected format. Close Quick and try again.')
    # NOT_FOUND
    return ('no connector with this name was found. You may not have saved the import '
            'yet, or you imported a different file. Re-run import-file and import in Quick.')


DARWIN_G2_CLI_OPS=('bootstrap','repair-permissions','apply','rollback')
DARWIN_G1B_CLI_OPS=('inspect','discover')
DARWIN_CLI_ACK_HINT={'inspect':'INSPECT GATEWAY <user>@<host>','discover':'VERIFY BACKEND <target>'}
DARWIN_ACK_HELP=('macOS only: the exact typed approval. inspect: INSPECT GATEWAY <user>@<host>; '
                 'discover: VERIFY BACKEND <target>; export --full-export: EXPORT FULL. plan is '
                 'always offline on macOS (no SSH) and refuses --ack.')
DARWIN_PLAN_ACK_REFUSED=('plan is offline on macOS in Slice 1 and does not accept --ack '
                         '(no SSH is opened for planning)')
# [P2-S1 / B4d] F-B4c-03: fixed refusal for the macOS offline-plan identity-safety
# boundary below. Never carries the login, host, target or the original exception
# text; matches the tone of DARWIN_REMOTE_ERROR_FALLBACK (deploy_lib.py) and
# DARWIN_SUMMARY_UNAVAILABLE (wizard.py), the two existing identity-output fallbacks.
# [P2-S1 / B4e] Q-B / R-01: the cause of an identity refusal can be the target name, a
# selected tool name, the Lambda URL/region, the gateway host, an empty identity, or a
# login that equals a word of the fixed summary/plan text - so the advice no longer
# tells the user to rename the target. Still one fixed literal, never interpolated.
DARWIN_PLAN_SUMMARY_UNSAFE=('Offline plan refused: the plain-language summary or the plan '
                            'output could not be confirmed identity-safe on macOS (your SSH '
                            'login or the gateway host would still be readable). No summary, '
                            'plan JSON or plan file was produced. Check the target name, the '
                            'selected tool names and the connection details, then try again.')
# [P2-S1 / B4e] Q-B / R-02 / F-SA-03: SEPARATE fixed text for any OTHER (non-identity)
# internal failure while preparing the macOS plan output. It makes no claim about the
# cause and never carries the original exception text, class, args or traceback.
DARWIN_PLAN_INTERNAL_ERROR=('Offline plan refused on macOS: an internal error occurred while '
                            'preparing the plan output, so its identity safety could not be '
                            'checked. No summary, plan JSON or plan file was produced.')
# [P2-S1 / B4e] exit status for DARWIN_PLAN_INTERNAL_ERROR: 1, the code this CLI already
# uses for an unexpected internal error (the __main__ handler). 2 stays reserved for
# argparse usage errors and deliberate refusals (incl. DARWIN_PLAN_SUMMARY_UNSAFE).
DARWIN_PLAN_INTERNAL_EXIT=1
# [P2-S1 / B4f] S-04: fixed --plan-file write failures on the macOS plan path (no path, no
# errno text). An existing file is a refusal (exit 2, like the other macOS refusals); any
# other file error uses the internal-error exit 1.
DARWIN_PLAN_FILE_EXISTS=('Refusing to write --plan-file on macOS: a file already exists there. It '
                         'was not changed, and nothing was printed. Choose a new file name.')
DARWIN_PLAN_FILE_WRITE_ERROR=('The --plan-file could not be written on macOS (file error). Nothing '
                              'was printed. Check that its folder exists and is writable.')
DARWIN_PLAN_FILE_EXISTS_EXIT=2
# [P2-S1 / B4g] D3 / N-03: fixed texts for file errors of the macOS export branch
# (_darwin_export). No path, errno text, exception text or class name. Existing file ->
# exit 2 (a refusal; the file is not touched), any other file error -> exit 1.
DARWIN_EXPORT_FILE_EXISTS=('Refusing to write the export file on macOS: a file already exists '
                           'there. It was not changed. Choose a new file name.')
DARWIN_EXPORT_FILE_WRITE_ERROR=('The export file could not be written on macOS (file error). '
                                'Check that its folder exists and is writable.')


def _darwin_preflight(p,args):
    """P2 Slice 1, macOS only. Runs right after parsing, BEFORE any manifest read,
    gateway construction, file write or network step. Refusals exit nonzero (2)."""
    if args.native_local:
        p.error('--native-local is not available on macOS in Slice 1; use the Linux SSH gateway')
    try:
        if args.operation in DARWIN_G2_CLI_OPS:
            capability_gate.refuse_g2(args.operation)
            raise capability_gate.GateRefused('Gateway install or modification is not '
                                              'available on macOS in Slice 1')
        if args.operation=='import-file':
            capability_gate.refuse_g3_write(args.operation)
            raise capability_gate.GateRefused('Writing an import file is not available on '
                                              'macOS in Slice 1')
    except capability_gate.GateRefused as exc:
        p.error(str(exc))
    if args.operation=='plan' and args.ack is not None:
        p.error(DARWIN_PLAN_ACK_REFUSED)
    # User decision B: no CLI file path may point into a Quick-owned folder or at
    # mcp_config.json (symlinks and '..' resolved; see quick_reg).
    from quick_reg import p2_export_destination_refused
    for flag,path in (('--output-file',args.output_file),('--plan-file',args.plan_file),
                      ('--receipt-file',args.receipt_file),('--out-dir',args.out_dir)):
        if path and p2_export_destination_refused(path,(args.profile_dir,)):
            p.error(flag+' points into a Quick-owned folder or at mcp_config.json; refused on '
                    'macOS (Quick configuration is never written in Slice 1)')
    if args.operation=='export' and args.full_export:
        try:
            capability_gate.require_full_variant('export',args.ack)
        except capability_gate.GateRefused as exc:
            p.error(str(exc)+' (pass --ack "EXPORT FULL" together with --full-export)')
    if args.operation=='import-check' and not args.profile_dir:
        p.error('On macOS import-check requires an explicit --profile-dir (the Quick home is not assumed)')
    if args.operation=='import-verify' and not (args.config_path or args.profile_dir):
        p.error('On macOS import-verify requires an explicit --config-path or --profile-dir')
    if args.operation in DARWIN_G1B_CLI_OPS and not args.ack:
        p.error(args.operation+' on macOS requires --ack typed exactly as: '
                +DARWIN_CLI_ACK_HINT[args.operation])


def _darwin_remote(p,args,spec):
    """P2 Slice 1 / A1, macOS only: inspect / discover / plan. plan is ALWAYS offline
    (G1a, no gateway object at all). inspect needs INSPECT GATEWAY <user>@<host> (scope
    inspect-gateway); discover needs VERIFY BACKEND <target> (scope verify-backend). One
    gateway is built for the one action, bound to that scope."""
    if args.operation not in ('inspect','discover','plan'):
        p.error('This operation is not available on macOS in Slice 1')
    if args.operation=='plan':
        if args.ack is not None:
            p.error(DARWIN_PLAN_ACK_REFUSED)
        # [P2-S1 / B4g] D2 / P1: the --plan-file destination policy (Google Drive, git work
        # tree, synced folder, program folder, absolute as given, the private folder when
        # Drive for desktop is detected) is applied BEFORE the plan is built, printed or
        # written. A refusal is a FIXED text (no path), exit 2, nothing created or printed.
        if args.plan_file:
            from quick_reg import p2_plan_file_destination_refusal
            plan_dest_refusal=p2_plan_file_destination_refusal(args.plan_file)
            if plan_dest_refusal is not None:
                p.exit(DARWIN_PLAN_FILE_EXISTS_EXIT,'ERROR: '+plan_dest_refusal+'\n')
        result=ConnectorDeployer(None).prepare_offline(spec)
        # [P2-S1 / B4d] F-B4c-03: validate the COMPLETE plain-language summary for
        # identity safety BEFORE anything is printed or written. model.plain_language_summary
        # stays byte-frozen (not modified); this is a call-site boundary only, matching
        # wizard.Wizard._darwin_summary_text (F-B4b-02) and
        # deploy_lib._darwin_redact_remote_error (F-B4b-01). Same fail-closed rule: on ANY
        # failure (unsafe text, empty/malformed identity, or any other error) nothing
        # identity-bearing is printed or written and a fixed refusal is used instead.
        #
        # Output classification (F-B4c-03 review note): the plan JSON (printed to stdout
        # and optionally written to --plan-file) is the SAME pre-existing, intentionally
        # unredacted, mode-locked machine artifact used identically on Windows/Linux (B2b
        # S7: 'Receipts/plans may contain the real gateway host/user ... NOT redacted but
        # ARE mode-locked'); it is a PRIVATE artifact, not a shareable/export surface, and
        # this fix does not change its format or redaction policy. It IS withheld together
        # with the summary on refusal below, so one failed identity check cannot leave a
        # partially-produced result (fail-closed for the whole operation, not a redesign).
        #
        # [P2-S1 / B4e] F-SA-01 (A): the stdout plan JSON is now REDACTED on macOS with the
        # existing macOS boundary (_darwin_plan_stdout_text: model.redact_identity_strict,
        # the same placeholders as the GUI Step 4 view), validated again in full, and
        # computed together with the summary BEFORE anything is written or printed. The
        # --plan-file artifact stays the private, unredacted, 0600 create-only file.
        # [P2-S1 / B4e] Q-B (B): identity failures (RedactionError, incl. its subclass
        # IdentityRedactionError) and any OTHER internal failure get SEPARATE fixed
        # messages. The refusal is raised AFTER the except blocks, so no exception
        # context is attached; SystemExit / KeyboardInterrupt are not caught.
        # The _spec_identity import stays inside the try on purpose: moving it to module
        # level would turn its failure into an import-time crash on every platform
        # instead of the fail-closed internal-error refusal below.
        refusal=None
        try:
            from quick_reg import _spec_identity
            summary=assert_identity_safe(plain_language_summary(spec,result),*_spec_identity(spec))
            stdout_text=_darwin_plan_stdout_text(spec,result)
        except RedactionError:
            refusal=DARWIN_PLAN_SUMMARY_UNSAFE
        except Exception:
            refusal=DARWIN_PLAN_INTERNAL_ERROR
        if refusal==DARWIN_PLAN_SUMMARY_UNSAFE:
            p.error(DARWIN_PLAN_SUMMARY_UNSAFE)
        if refusal is not None:
            p.exit(DARWIN_PLAN_INTERNAL_EXIT,'ERROR: '+DARWIN_PLAN_INTERNAL_ERROR+'\n')
        # [P2-S1 / B4e] the private file is written BEFORE anything is printed, so an
        # existing --plan-file (create-only refusal) leaves both streams empty.
        # [P2-S1 / B4f] S-04: a create-only collision or any other OSError from the plan-file
        # write no longer escapes to the __main__ handler (which printed the error text,
        # including the user's path). It becomes a FIXED message, raised after the handler
        # (no exception context): existing file -> exit 2 (a refusal; the file is not
        # touched), any other file error -> exit 1. Nothing is printed on stdout.
        plan_file_failure=None
        if args.plan_file:
            try:
                write_new_json(args.plan_file,result)
            except FileExistsError:
                plan_file_failure=DARWIN_PLAN_FILE_EXISTS
            except OSError:
                plan_file_failure=DARWIN_PLAN_FILE_WRITE_ERROR
        if plan_file_failure==DARWIN_PLAN_FILE_EXISTS:
            p.exit(DARWIN_PLAN_FILE_EXISTS_EXIT,'ERROR: '+DARWIN_PLAN_FILE_EXISTS+'\n')
        if plan_file_failure is not None:
            p.exit(DARWIN_PLAN_INTERNAL_EXIT,'ERROR: '+DARWIN_PLAN_FILE_WRITE_ERROR+'\n')
        print(summary,file=sys.stderr)
        print(stdout_text);return 0
    try:
        if args.operation=='inspect':
            scope=capability_gate.SCOPE_INSPECT_GATEWAY
            label=capability_gate.gateway_label(spec.get('user'),spec.get('host'))
            op='inspect'
        else:
            scope=capability_gate.SCOPE_VERIFY_BACKEND
            label=spec.get('target')
            op='discover'
        capability_gate.require_g1b(scope,label,args.ack,op)
    except capability_gate.GateRefused as exc:
        p.error(str(exc))
    gw=SSHGateway(spec['host'],spec['user'],args.known_hosts,ack=args.ack,scope=scope,
                  label=None if scope==capability_gate.SCOPE_INSPECT_GATEWAY else label)
    d=ConnectorDeployer(gw)
    if args.operation=='inspect': result=d.inspect()
    else: result=d.discover(spec)
    print(json.dumps(result,indent=2));return 0


def _darwin_plan_shape(obj):
    """[P2-S1 / B4e] Structure of a JSON value: dict keys, list lengths and value
    types, ignoring string contents. Used to prove redaction kept the plan schema."""
    if isinstance(obj,dict):
        return ('dict',tuple(sorted((k,_darwin_plan_shape(v)) for k,v in obj.items())))
    if isinstance(obj,list):
        return ('list',tuple(_darwin_plan_shape(v) for v in obj))
    return type(obj).__name__


def _darwin_plan_stdout_text(spec,result):
    """[P2-S1 / B4e] F-SA-01, macOS only: the plan JSON text for STDOUT, redacted with
    the existing macOS boundary model.redact_identity_strict (redact_identity's
    placeholders <user> / <3090-host> + assert_identity_safe), i.e. the same policy the
    GUI Step 4 view (wizard.darwin_step4_view) applies to this plan. No new redaction
    scheme. Afterwards the COMPLETE text is checked again: it must still parse to the
    same JSON structure (same keys, list lengths and types - only identity values may
    differ), and the login, host, user@host and the /home/<login> path must all be
    absent. Any doubt raises IdentityRedactionError (fixed text); the caller refuses."""
    from quick_reg import _spec_identity
    user,host=_spec_identity(spec)
    full=json.dumps(result,indent=2)
    text=redact_identity_strict(full,user,host)
    try:
        same=_darwin_plan_shape(json.loads(text))==_darwin_plan_shape(json.loads(full))
    except ValueError:
        same=False
    if not same:
        raise IdentityRedactionError(IDENTITY_UNSAFE_REFUSAL)
    if ('/home/'+user.strip()).lower() in text.lower():
        raise IdentityRedactionError(IDENTITY_UNSAFE_REFUSAL)
    return assert_identity_safe(text,user,host)


def _darwin_export(p,args,spec):
    """P2 Slice 1 (user decision B), macOS only: export stays a local REFERENCE example,
    redacted by default. write_quick_config itself refuses Quick-owned destinations and
    needs the exact EXPORT FULL token for the full variant; refusals exit nonzero."""
    if not args.output_file:p.error('export requires --output-file')
    redacted=not args.full_export
    # [P2-S1 / B4g] D3 / N-03: a file error no longer escapes to the __main__ handler (which
    # printed the error text incl. the path); fixed message, raised after the try block.
    export_file_failure=None
    try:
        # [P2-S1 / B4b] macOS: for the REDACTED (shareable) variant the COMPLETE output
        # safety validation runs BEFORE any file is created, so an identity refusal
        # leaves NO output file behind. quick_instructions_screen refuses when the real
        # login or host would still be readable - e.g. a login carried only in
        # display_name, which the JSON export itself does not contain (config_export
        # emits no 'name' field), so the export check alone cannot see it.
        # The FULL variant keeps its exact previous order: write_quick_config enforces
        # the typed EXPORT FULL token and the destination guard FIRST, and only then is
        # the full text built. Windows/Linux use the separate non-darwin branch in main
        # and are untouched.
        if redacted:
            instructions=quick_instructions_screen(spec)['redacted']
            write_quick_config(spec,args.output_file,redacted=True,full_ack=args.ack)
        else:
            write_quick_config(spec,args.output_file,redacted=False,full_ack=args.ack)
            instructions=quick_instructions(spec,redacted=False)
    except RedactionError as exc:
        p.error('Refusing to write a shareable export: '+str(exc))
    except capability_gate.GateRefused as exc:
        p.error(str(exc))
    # [P2-S1 / B4g] D3: file errors -> fixed texts (no path); exit 2 existing file, 1 other.
    except FileExistsError:
        export_file_failure=DARWIN_EXPORT_FILE_EXISTS
    except OSError:
        export_file_failure=DARWIN_EXPORT_FILE_WRITE_ERROR
    if export_file_failure==DARWIN_EXPORT_FILE_EXISTS:
        p.exit(DARWIN_PLAN_FILE_EXISTS_EXIT,'ERROR: '+DARWIN_EXPORT_FILE_EXISTS+'\n')
    if export_file_failure is not None:
        p.exit(DARWIN_PLAN_INTERNAL_EXIT,'ERROR: '+DARWIN_EXPORT_FILE_WRITE_ERROR+'\n')
    if args.full_export:
        print(FULL_VARIANT_WARNING,file=sys.stderr)
    print(instructions);return 0


def confirm_apply(approve_flag,target):
    """Return True only on explicit approval (S4). The flag approves non-interactively;
    otherwise require an interactive typed 'yes'. A non-interactive run without the flag
    refuses (default-deny)."""
    if approve_flag:
        return True
    if not sys.stdin.isatty():
        return False
    try:
        answer=input('Type "yes" to approve deploying "{}" to the gateway registry: '.format(target))
    except EOFError:
        return False
    return answer.strip().lower()=='yes'


def SSHG(host,user,known_hosts):
    return SSHGateway(host,user,known_hosts)

if __name__=='__main__':
    try:sys.exit(main())
    except Exception as e:
        print('ERROR: '+str(e),file=sys.stderr);sys.exit(1)
