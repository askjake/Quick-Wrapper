"""Transport and safe gateway transactions, Python 3.8+.

Paramiko is optional until a live SSH operation. Uses RejectPolicy only.
All fixed remote Python source is supplied as base64 code; request data travels via stdin.
No password/token authentication is implemented (SSH keys/agent only).
"""
import base64
import json
import os
import pathlib
import threading

import capability_gate
import platform_p2
from model import (validate_spec, make_registry_entry, plan, quick_connector,
                   backend_identity, risk_tool_names, identity_warnings, ValidationError)

HERE = pathlib.Path(__file__).resolve().parent

class DeploymentError(RuntimeError):
    pass


# P2 Slice 1 (macOS): operation classes on the Linux SSH gateway (remote_agent ops).
# Amendment A1: exactly the union of capability_gate.G1B_SCOPE_OPS. 'check' and
# 'git_check' are NOT allowed on macOS in Slice 1 (plan is always offline there).
G1B_OPS = frozenset(['inspect', 'discover', 'probe_existing', 'inspect_lambda_target'])
G2_OPS = frozenset(['bootstrap', 'repair_permissions', 'apply', 'rollback'])
OFFLINE_SENTINEL = 'NOT READ (offline plan)'
DARWIN_NO_SSH_LIB = 'SSH client library not available; nothing was installed'
DARWIN_OP_REFUSED = 'This gateway operation is not available on macOS in Slice 1'
DARWIN_G2_REFUSED = 'Gateway install or modification is not available on macOS in Slice 1'
TARGET_NOT_AUTHORIZED = 'Backend verification was not authorized for this target'
SCOPE_NOT_AUTHORIZED = 'This remote operation is not covered by the typed approval for this action'
DARWIN_PLAN_OFFLINE = ('plan is offline on macOS in Slice 1: use the offline plan '
                       '(prepare_offline); no SSH is opened for planning')
OFFLINE_PLAN_REFUSED = ('This is an offline plan: no gateway state was read, so it cannot be '
                        'deployed. Verify the backend and plan again.')
# A1.1 (macOS only): the exact request shapes the wizard sends per op (P2-SEC-055/059),
# the pre-connect size limit (UTF-8 bytes) and the fallback remote-error text (P2-SEC-060).
DARWIN_REQUEST_KEYS = {'inspect': frozenset(['op']),
                       'discover': frozenset(['op', 'entry']),
                       'inspect_lambda_target': frozenset(['op', 'target']),
                       'probe_existing': frozenset(['op', 'kind', 'target'])}
DARWIN_REQUEST_REFUSED = ('This remote request is not in the form the wizard sends on macOS '
                          'in Slice 1')
DARWIN_INVALID_GATEWAY = 'Invalid SSH user or host.'
DARWIN_REQUEST_LIMIT = 262144
DARWIN_REMOTE_ERROR_FALLBACK = 'Remote operation failed'
DARWIN_REMOTE_ERROR_MAX = 300
# Masks applied BEFORE model.redact_identity: URLs, any user@host, key=value secrets,
# IPv4 literals, dotted host names (2+ dots), home-style absolute paths and long
# token-like runs.
_DARWIN_ERROR_MASKS = (
    (r'[A-Za-z][A-Za-z0-9+.-]*://[^\s\'"<>]+', '<URL>'),
    (r'[^\s@\'"<>]+@[^\s@\'"<>]+', '<user>@<host>'),
    (r'(?i)\b(token|secret|password|passwd|passphrase|key|credential|authorization|signature)'
     r'\b\s*[=:]\s*[^\s,;]+', r'\1=<REDACTED>'),
    (r'(?<![0-9])(?:[0-9]{1,3}\.){3}[0-9]{1,3}(?![0-9])', '<ip>'),
    (r'\b(?:[A-Za-z0-9-]+\.){2,}[A-Za-z][A-Za-z0-9-]*\b', '<host>'),
    (r'(?:/home|/Users|/root|/private|/var|/tmp)/[^\s\'"<>]*', '<path>'),
    (r'[A-Za-z0-9+/_=-]{32,}', '<LONG>'),
)


def describe_auth_sources():
    """Plain-language list of the login sources SSHGateway.run can use (read from the
    connect() call below). Pure: no I/O. The macOS G1b confirmation dialogs show it.
    This states the CURRENT behaviour, which A1 does not change (allow_agent=True,
    look_for_keys=True); an agent-only change is a separate pending decision and has
    NOT been made."""
    # A1.1 / Security S-RUN 2.2.4: items 1 and 2 state that every agent key may be offered
    # and that this program itself opens and reads the default key files.
    return ['Keys held by a running SSH agent (allow_agent=True). The agent may offer ALL of '
            'its keys to the server. The agent is used for login only; agent forwarding is '
            'NOT requested. Every key held by the agent may be offered to the server, one '
            'after another.',
            'Default private key files in your ~/.ssh folder (id_rsa, id_ecdsa, id_ed25519, '
            'id_dsa), which this program opens and reads (look_for_keys=True). Unencrypted '
            'keys are tried; passphrase-protected keys are skipped (no passphrase is asked '
            'for) and work only through the agent.',
            'Nothing else: no password, no explicit key file, no ~/.ssh/config IdentityFile, '
            'no GSSAPI/Kerberos.',
            'The server host key must already be in your known_hosts file (system file and '
            'the selected file); an unknown host is rejected (RejectPolicy) and nothing is '
            'added.']


def _darwin_redact_remote_error(text, user, host):
    """A1.1 P2-SEC-060 (macOS only): the gateway worker's `error` text, redacted before it
    is raised or displayed: the _DARWIN_ERROR_MASKS, then model.redact_identity for this
    gateway's user/host, non-ASCII/non-printable characters replaced, length capped.
    Fails closed to a fixed text on anything unexpected."""
    import re
    if not isinstance(text, str) or not text.strip():
        return DARWIN_REMOTE_ERROR_FALLBACK
    try:
        from model import redact_identity
        out = text
        for pattern, repl in _DARWIN_ERROR_MASKS:
            out = re.sub(pattern, repl, out)
        out = redact_identity(out, user, host)
    except Exception:
        return DARWIN_REMOTE_ERROR_FALLBACK
    out = ''.join(ch if (' ' <= ch <= '~') else '?' for ch in out)
    if len(out) > DARWIN_REMOTE_ERROR_MAX:
        out = out[:DARWIN_REMOTE_ERROR_MAX] + '...'
    # [P2-S1 / B4c] F-B4b-01: final standalone-login safety check on the ACTUAL text
    # that would be returned (after masking, redaction, ASCII sanitising AND the length
    # cap), using the same boundary rule as B4. redact_identity treats '-' as a word
    # character, so a login embedded in an approved target name ('fakeuser-epg',
    # 'aq-fakeuser-epg') survives its substitution; that text must never be displayed.
    # Fails closed: a malformed identity makes login_token_present raise, which is
    # caught here and yields the fixed fallback. The unsafe text is never returned,
    # echoed or recorded.
    try:
        from model import assert_identity_safe
        assert_identity_safe(out, user, host)
    except Exception:
        # Covers a surviving standalone login, a surviving host or user@host composite,
        # and an empty / whitespace / non-str / non-ASCII identity (fail closed). Same
        # strict helper the macOS Step 4 summary and Step 5 boundaries use, so all
        # identity-output paths share one rule.
        return DARWIN_REMOTE_ERROR_FALLBACK
    return out


class SSHGateway(object):
    def __init__(self, host, user, known_hosts=None, timeout=15, ack=None, scope=None, label=None):
        self.host=host
        self.user=user
        self.known_hosts=known_hosts or os.path.expanduser('~/.ssh/known_hosts')
        self.timeout=timeout
        # P2 Slice 1 / A1 (macOS only; ignored elsewhere): the typed G1b approval, its scope
        # (inspect-gateway | verify-backend) and, for verify-backend, the approved target
        # label. For inspect-gateway the label is computed in run() from THIS object's
        # user@host, never taken from the caller. Not an unlock flag: re-checked on EVERY run().
        self.ack=ack
        self.scope=scope
        self.label=label

    def _darwin_expected_label(self):
        """A1 rule c: for inspect-gateway the expected label is computed HERE from this
        gateway's own user@host; for verify-backend it is the pinned target label."""
        if self.scope==capability_gate.SCOPE_INSPECT_GATEWAY:
            return capability_gate.gateway_label(self.user,self.host)
        if self.scope==capability_gate.SCOPE_VERIFY_BACKEND:
            return self.label
        raise capability_gate.GateRefused(SCOPE_NOT_AUTHORIZED)

    def _darwin_gate(self, request):
        op=request.get('op') if isinstance(request,dict) else None
        if not isinstance(op,str):
            raise capability_gate.GateRefused(DARWIN_OP_REFUSED)
        if op in G2_OPS:
            capability_gate.refuse_g2(op)
            raise capability_gate.GateRefused(DARWIN_G2_REFUSED)
        if op not in G1B_OPS:
            raise capability_gate.GateRefused(DARWIN_OP_REFUSED)
        expected=self._darwin_expected_label()
        capability_gate.require_g1b(self.scope, expected, self.ack, op)
        # A1 rule b: a request that names a target must name the APPROVED target.
        if self.scope==capability_gate.SCOPE_INSPECT_GATEWAY:
            if 'target' in request:
                raise capability_gate.GateRefused(TARGET_NOT_AUTHORIZED)
        elif op in ('inspect_lambda_target','probe_existing') or 'target' in request:
            # A1.1 P2-SEC-055: exact str only (a str subclass with a custom __eq__/__ne__
            # must never match), and equal to the approved label.
            tgt=request.get('target')
            if type(tgt) is not str or type(expected) is not str or tgt!=expected:
                raise capability_gate.GateRefused(TARGET_NOT_AUTHORIZED)
        return None

    def _darwin_preconnect_checks(self, request):
        """A1.1 P2-SEC-059 / F9 (macOS only): request shape, host/user/target/entry
        validation and the request size limit, all BEFORE paramiko is imported and before
        any connect / exec_command / worker start. Fixed messages; never echoes input."""
        from model import validate_gateway, validate_lambda_url, normalize_tools, TARGET_RE
        if type(self.host) is not str or type(self.user) is not str:
            raise ValidationError(DARWIN_INVALID_GATEWAY)
        validate_gateway(self.host,self.user)
        op=request.get('op')
        allowed=DARWIN_REQUEST_KEYS.get(op)
        if allowed is None or any(type(k) is not str or k not in allowed for k in request):
            raise capability_gate.GateRefused(DARWIN_REQUEST_REFUSED)
        if op in ('inspect_lambda_target','probe_existing') or 'target' in request:
            tgt=request.get('target')
            if type(tgt) is not str or not TARGET_RE.fullmatch(tgt):
                raise ValidationError('Target: lowercase letters, digits, dashes (max 64).')
        if op=='probe_existing' and request.get('kind') not in ('git','local'):
            raise capability_gate.GateRefused(DARWIN_REQUEST_REFUSED)
        if op=='discover':
            entry=request.get('entry')
            if not isinstance(entry,dict):
                raise capability_gate.GateRefused(DARWIN_REQUEST_REFUSED)
            validate_lambda_url(entry.get('url',''))
            normalize_tools(entry.get('allow'))
        try:
            payload=json.dumps(request,sort_keys=True)
        except (TypeError,ValueError):
            raise DeploymentError('Request cannot be encoded')
        if len(payload.encode('utf-8'))>DARWIN_REQUEST_LIMIT:
            raise DeploymentError('Request exceeds safety size limit')
        return None

    def run(self, request, timeout=65):
        if platform_p2.is_darwin():
            # P2 Slice 1: gate BEFORE importing paramiko and before any socket. Never pip.
            self._darwin_gate(request)
            # A1.1 P2-SEC-059 / F9: everything checkable locally, before any connect.
            self._darwin_preconnect_checks(request)
            try:
                import paramiko
            except Exception:
                # A1.1 P2-SEC-058: ANY failure to load the SSH library (not only
                # ImportError) gives the fixed message; no path text; nothing installed.
                raise DeploymentError(DARWIN_NO_SSH_LIB)
        else:
            try:
                import paramiko
            except ImportError:
                raise DeploymentError('Install Paramiko first: py -m pip install paramiko')
        if not os.path.isfile(self.known_hosts):
            raise DeploymentError('Known-hosts file is missing. Connect via trusted OpenSSH first; verify host fingerprint.')
        src=(HERE/'remote_agent.py').read_bytes()
        cmd='python3 -c "import base64;exec(base64.b64decode(\'{}\'))"'.format(base64.b64encode(src).decode('ascii'))
        client=paramiko.SSHClient()
        client.load_system_host_keys()
        client.load_host_keys(self.known_hosts)
        client.set_missing_host_key_policy(paramiko.RejectPolicy())
        try:
            client.connect(self.host,username=self.user,timeout=self.timeout,auth_timeout=self.timeout,
                           banner_timeout=self.timeout,allow_agent=True,look_for_keys=True)
            inp,out,err=client.exec_command(cmd,timeout=timeout)
            payload=json.dumps(request,sort_keys=True)
            if len(payload)>262144:
                raise DeploymentError('Request exceeds safety size limit')
            inp.write(payload.encode('utf-8'))
            inp.flush()
            inp.channel.shutdown_write()
            raw=out.read(1024*1024)
            stderr=err.read(8192) # never echo stderr: may contain internal URLs
            status=out.channel.recv_exit_status()
            if status!=0:
                raise DeploymentError('Gateway worker exited with status {}'.format(status))
            data=json.loads(raw.decode('utf-8'))
            if not data.get('ok'):
                if platform_p2.is_darwin():
                    # A1.1 P2-SEC-060: the worker's error text is redacted on macOS.
                    raise DeploymentError(_darwin_redact_remote_error(
                        data.get('error','Remote operation failed'),self.user,self.host))
                raise DeploymentError(data.get('error','Remote operation failed'))
            return data['result']
        except DeploymentError:
            raise
        except Exception as exc:
            # Paramiko error strings can disclose usernames and internal URLs; display type only.
            raise DeploymentError('SSH/transport failed ({}). Check trusted host key, SSH agent and connectivity.'.format(type(exc).__name__))
        finally:
            client.close()


class ConnectorDeployer(object):
    def __init__(self, gateway):
        self.gateway=gateway

    def _g1b_entry(self, spec=None, op='inspect'):
        """P2 Slice 1 / A1 (macOS): fail closed at the deployer entry too, so a missed call
        site cannot reach the gateway. The gateway must carry a known scope whose op set
        contains `op` plus the exact typed approval; a spec (verify/discover) requires the
        verify-backend scope and spec target == the approved label."""
        if not platform_p2.is_darwin():
            return None
        gw=self.gateway
        scope=getattr(gw,'scope',None)
        if scope==capability_gate.SCOPE_INSPECT_GATEWAY:
            label=capability_gate.gateway_label(getattr(gw,'user',None),getattr(gw,'host',None))
        elif scope==capability_gate.SCOPE_VERIFY_BACKEND:
            label=getattr(gw,'label',None)
        else:
            raise capability_gate.GateRefused(SCOPE_NOT_AUTHORIZED)
        capability_gate.require_g1b(scope, label, getattr(gw,'ack',None), op)
        if spec is not None:
            if scope!=capability_gate.SCOPE_VERIFY_BACKEND:
                raise capability_gate.GateRefused(SCOPE_NOT_AUTHORIZED)
            if (not isinstance(spec,dict) or type(spec.get('target')) is not str
                    or type(label) is not str or spec.get('target')!=label):
                raise capability_gate.GateRefused(TARGET_NOT_AUTHORIZED)
        return None

    def inspect(self):
        self._g1b_entry()
        return self.gateway.run({'op':'inspect'})

    def bootstrap(self, approved=False):
        """Creates gateway only when absent. Requires explicit dependency-install consent."""
        capability_gate.refuse_g2('bootstrap')
        if not approved:
            raise DeploymentError('Fresh gateway install requires explicit approval')
        state = self.inspect()
        if state.get('state') != 'MISSING':
            raise DeploymentError('Bootstrap refused: gateway is not absent (' + str(state.get('state')) + ')')
        from bootstrap_lib import make_bundle
        payload = make_bundle()
        reply = self.gateway.run(dict(op='bootstrap', confirm='CREATE_FRESH_GATEWAY',
                                      install_dependencies=True, **payload), timeout=490)
        after = self.inspect()
        if after.get('state') != 'READY':
            raise DeploymentError('Gateway bootstrap did not produce READY state; inspect manually')
        return reply

    def repair_permissions(self, observed, approved=False):
        capability_gate.refuse_g2('repair_permissions')
        if not approved:
            raise DeploymentError('Permission repair requires explicit approval')
        if observed.get('state') != 'PERMISSIONS_NEED_REPAIR':
            raise DeploymentError('Gateway is not in repairable permission state')
        result=self.gateway.run({'op':'repair_permissions',
                                 'confirm':'REPAIR_OWNED_CORE_PERMISSIONS',
                                 'mode_issues':observed['mode_issues']})
        if self.inspect().get('state')!='READY':
            raise DeploymentError('Permission repair incomplete; inspect before proceeding')
        return result

    def verify_backend(self, spec):
        """Live MCP metadata-only backend check. Does NOT execute application tools."""
        self._g1b_entry(spec,'discover' if isinstance(spec,dict) and spec.get('kind')=='lambda'
                        else 'probe_existing')
        valid=dict(spec)
        if valid.get('kind')=='lambda':
            valid['allow']=['verification-placeholder']
        validate_spec(valid)
        state=self.inspect()
        if state.get('state')!='READY':
            raise DeploymentError('Gateway not READY; inspect gateway first: '+str(state.get('state')))
        kind=spec['kind']
        name=spec['target']
        installed=None
        if kind=='lambda':
            if name in state.get('target_names',[]):
                installed=self.gateway.run({'op':'inspect_lambda_target','target':name})
                if installed['url'].rstrip('/')!=spec['url'].rstrip('/'):
                    raise DeploymentError('This name already targets a DIFFERENT Lambda URL; refuse verification under the wrong label.')
            info=self.discover(valid)
            method='SigV4 Lambda Function URL -> MCP initialize/tools/list'
        else:
            if kind=='git':
                if name not in state.get('git_targets',[]):
                    raise DeploymentError('Git target is not configured on this gateway')
            elif name not in state.get('target_names',[]) or state.get('kinds',{}).get(name)!='local':
                raise DeploymentError('Selected local MCP target is not registered on gateway')
            info=self.gateway.run({'op':'probe_existing','kind':kind,'target':name},timeout=63)
            method=('Guarded Git MCP launcher -> initialize/tools/list' if kind=='git' else
                    'Existing local registry launcher -> initialize/tools/list')
        names=[t['name'] for t in info.get('tools',[])]
        if info.get('truncated') or info.get('count')!=len(names) or not names or len(set(names))!=len(names):
            raise DeploymentError('Incomplete or empty MCP tools/list result; backend not verified')
        return {'status':'BACKEND_VERIFIED', 'kind':kind,'target':name,
                'existing_target': installed is not None,
                'existing_allow': installed['allow'] if installed else None,
                'existing_extra_config_present': installed.get('extra_config_present',[]) if installed else [],
                'backend_identity_sha256':backend_identity(spec),
                'registry_sha256':state['sha256'],
                'handshake':method,'tool_count':len(names),'tools':info['tools'],
                'potentially_mutating_tools_name_only':risk_tool_names(names),
                'warnings':identity_warnings(spec,names),
                'qualification':'MCP metadata handshake only: no tool execution, no proof of write safety'}

    def prepare(self,spec):
        if platform_p2.is_darwin():
            # A1: remote read-for-plan is dropped on macOS; plan is ALWAYS offline there.
            raise capability_gate.GateRefused(DARWIN_PLAN_OFFLINE)
        validate_spec(spec)
        info=self.inspect()
        if info.get('state')!='READY':
            raise DeploymentError('Gateway not ready: '+str(info.get('state'))+'. Inspect, bootstrap or repair permissions first.')
        if spec['kind']=='git':
            if spec['target'] not in info['git_targets']:
                raise DeploymentError('Git target is not installed/configured on the gateway')
            result=self.gateway.run({'op':'git_check','target':spec['target']})
            if not result.get('ok'):
                raise DeploymentError('Git launcher preflight failed. Check target configuration and token file mode.')
        elif spec['kind']=='local':
            if spec['target'] not in info['target_names'] or info['kinds'].get(spec['target'])!='local':
                raise DeploymentError('MVP Local mode supports registration of an EXISTING local registry target only')
            result=self.gateway.run({'op':'check','target':spec['target']})
            if not result.get('ok'):
                raise DeploymentError('Local target tools/list health check failed')
        elif spec['target'] in info['target_names']:
            installed=self.gateway.run({'op':'inspect_lambda_target','target':spec['target']})
            if installed.get('registry_sha256')!=info['sha256']:
                raise DeploymentError('Registry changed during inspection; replan')
            if installed['url'].rstrip('/')!=spec['url'].rstrip('/') or sorted(installed['allow'])!=sorted(spec['allow']):
                raise DeploymentError('Existing target differs in URL or allow-list; this wizard never overwrites it. Match the installed configuration or use a new target name.')
            result=plan(spec,info['sha256'])
            result['mode']='existing-target-registration-only'
            result['execution_plan']=['1. Confirm existing Lambda URL and allow-list match your selection.',
                '2. Validate the existing target through aq_check.py (tools/list only).',
                '3. Leave the registry and existing target UNCHANGED.',
                '4. Register the Local SSH connector manually in Quick.',
                '5. Start a new Quick chat and verify one harmless read.']
            result['warnings'].append('This target already exists: registration-only; no gateway files will be changed.')
            result['gateway']={'host':spec['host'],'user':spec['user']}
            return result
        result=plan(spec,info['sha256'])
        result['gateway']={'host':spec['host'],'user':spec['user']}
        # S5: how many existing targets stay unchanged (this new target is NOT among them).
        result['existing_target_count']=len(info.get('target_names',[]))
        return result

    def prepare_offline(self, spec):
        """G1a: the same keys prepare() returns for a new target, built WITHOUT the
        gateway (no SSH, no network, no subprocess). Remote-state fields carry
        OFFLINE_SENTINEL; offline=True; deploy() refuses it on every platform."""
        validate_spec(spec)
        result=plan(spec,OFFLINE_SENTINEL)
        result['mode']='offline-plan-only'
        result['gateway']={'host':spec['host'],'user':spec['user']}
        result['existing_target_count']=OFFLINE_SENTINEL
        result['warnings'].append('Offline plan: the gateway registry was NOT read. Verify '
                                  'the backend and plan again before any deployment.')
        result['offline']=True
        return result

    def discover(self,spec):
        self._g1b_entry(spec,'discover')
        validate_spec(dict(spec,allow=spec.get('allow') or ['discovery-placeholder']))
        if spec['kind']!='lambda':
            raise DeploymentError('MVP live discovery supports AWS Lambda Function URLs only')
        return self.gateway.run({'op':'discover','entry':make_registry_entry(dict(spec,allow=['discovery-placeholder']))},timeout=55)

    def deploy(self,spec,prepared,confirm):
        capability_gate.refuse_g2('apply')
        if isinstance(prepared,dict) and prepared.get('offline'):
            raise DeploymentError(OFFLINE_PLAN_REFUSED)
        validate_spec(spec)
        if not confirm:
            raise DeploymentError('Explicit deploy approval is required')
        if (prepared.get('target')!=spec['target'] or prepared.get('kind')!=spec['kind'] or
                prepared.get('gateway')!={'host':spec['host'],'user':spec['user']}):
            raise DeploymentError('Plan and target no longer match')
        if spec['kind']!='lambda':
            # Git / local adapter only tests existing installation: no remote writes.
            return {'status':'EXISTING_TARGET_ONLY','target':spec['target'],
                    'registration':'MANUAL_REQUIRED','quick_connector':quick_connector(spec)}
        if prepared.get('mode')=='existing-target-registration-only':
            current=self.inspect()
            if current.get('sha256')!=prepared.get('expected_registry_sha256'):
                raise DeploymentError('Registry changed since existing-target plan; replan')
            existing=self.gateway.run({'op':'inspect_lambda_target','target':spec['target']})
            if existing['url'].rstrip('/')!=spec['url'].rstrip('/') or sorted(existing['allow'])!=sorted(spec['allow']):
                raise DeploymentError('Installed target changed; no registration receipt produced')
            health=self.gateway.run({'op':'check','target':spec['target'],
                                     'expected_allow_count':len(spec['allow'])},timeout=70)
            if not health.get('ok'):
                raise DeploymentError('Existing target tools/list failed; no registry modifications attempted')
            return {'status':'EXISTING_TARGET_VERIFIED','target':spec['target'],
                    'registration':'MANUAL_REQUIRED','quick_connector':quick_connector(spec)}
        entry=make_registry_entry(spec)
        # Re-discover using IAM on the actual gateway just before any registry change.
        offered=self.discover(spec)
        names={t['name'] for t in offered['tools']}
        if offered.get('truncated') or not set(spec['allow']).issubset(names):
            raise DeploymentError('Tool discovery incomplete or selected tool absent: no deployment')
        if entry!=prepared.get('registry_entry'):
            raise DeploymentError('Plan differs from current form; preview again')
        receipt=self.gateway.run({'op':'apply','target':spec['target'],'entry':entry,
                                 'expected_sha256':prepared['expected_registry_sha256']})
        try:
            check=self.gateway.run({'op':'check','target':spec['target'],
                                    'expected_allow_count':len(entry['allow'])},timeout=70)
            if not check.get('ok'):
                raise DeploymentError('Gateway MCP health check failed; auto-rollback requested')
        except Exception as exc:
            try:
                self.gateway.run({'op':'rollback','receipt':receipt})
            except Exception as rollback_exc:
                raise DeploymentError('Health check failed AND rollback was blocked; inspect registry before retrying. Original: {}; rollback: {}'.format(str(exc),str(rollback_exc)))
            raise DeploymentError('Health check failed; registry was safely rolled back. '+str(exc))
        receipt['status']='GATEWAY_VERIFIED'
        receipt['registration']='MANUAL_REQUIRED'
        receipt['quick_connector']=quick_connector(spec)
        return receipt

    def rollback(self,receipt):
        capability_gate.refuse_g2('rollback')
        return self.gateway.run({'op':'rollback','receipt':receipt})
