"""User-owned, no-admin local MCP gateway. Does not open any listener.

Native-local is intentionally distinct from SSH/Linux remote_agent. It uses the
same curated MCP proxy but executes it directly through the local Python venv.
"""
import base64
import contextlib
import hashlib
import json
import os
from pathlib import Path
import platform as _platform
import re
import shutil
import struct
import subprocess
import sys
import tempfile
import time

from model import validate_lambda_url, normalize_tools
from bootstrap_lib import FILES, PAYLOAD
from deploy_lib import DeploymentError
from platform_p2 import is_darwin as _p2_is_darwin

# P2 Slice 1: the native gateway is DISABLED on macOS (deferred to Slice 2).
NATIVE_DISABLED_ON_DARWIN = ('Native gateway is not available on macOS in Slice 1; use the Linux SSH gateway')


def _p2_refuse_native():
    """Raise DeploymentError on darwin; no-op elsewhere. Touches nothing."""
    if _p2_is_darwin():
        raise DeploymentError(NATIVE_DISABLED_ON_DARWIN)

NAME = re.compile(r'^[a-z0-9][a-z0-9-]{0,63}$')

# Strict numeric dotted version pattern for the read-only pyvenv.cfg parse. Only
# a plain "3.13" or "3.13.1" shape is accepted; anything else (shell junk, paths,
# extra tokens) is rejected and reported as 'unknown'. See read_gateway_venv_version.
_VENV_VERSION_RE = re.compile(r'^[0-9]{1,2}\.[0-9]{1,3}(\.[0-9]{1,3})?$')

# Extended dotted shape written as 'version_info' in some pyvenv.cfg layouts, e.g.
# '3.13.2.final.0' (major.minor.micro optionally followed by '.<releaselevel>.<serial>').
# Only the leading three numeric components are captured; the trailing
# '.<letters>.<digits>' tail, if present, must match exactly or the whole value is
# rejected. This is used ONLY for the 'version_info' fallback -- 'version' stays the
# strict numeric _VENV_VERSION_RE above. See read_gateway_venv_version.
_VENV_VERSION_INFO_RE = re.compile(
    r'^([0-9]{1,2}\.[0-9]{1,3}\.[0-9]{1,3})(?:\.[A-Za-z]+\.[0-9]{1,3})?$')

# --- Enforced supported-interpreter table (native Windows only) -------------
# Policy source: Charter Amendment 4 + Planner Option D (artifacts). The native
# bootstrap builds a CREDENTIAL-BEARING venv on the user's laptop, so the
# interpreter that will run it must be qualified, not merely ">=3.10". This table
# is the ONE place that qualification is declared. Today it has exactly one row;
# adding a future interpreter MUST be only a new row here plus tests -- never a
# code change to the gate logic, and never silent widening.
#
# Each row: (implementation, (py_major, py_minor), platform_tag).
#   implementation -- 'CPython' only today (PyPy etc. are refused).
#   (major, minor) -- qualified CPython feature version, e.g. (3, 13).
#   platform_tag   -- the wheel-style platform tag, e.g. 'win_amd64' (64-bit
#                     x86-64 Windows). 'win32' (32-bit) and 'win_arm64' are
#                     DISTINCT tags and are NOT covered unless listed here.
#
# NOTE on ABI (Security C-1 / C-1b / F-2): a bare (impl, (major, minor), tag)
# match is NECESSARY but NOT SUFFICIENT. Free-threaded (cp313t), debug (cp313d)
# and pre-release builds all report the SAME version/impl/tag yet consume a
# DIFFERENT wheel ABI than the cp313 hash-pinned lock. check_interpreter rejects
# those below so the lock and the runtime ABI actually agree.
SUPPORTED_WINDOWS_INTERPRETERS = (
    ('CPython', (3, 13), 'win_amd64'),
)


def _running_platform_tag(platform_name=None, machine=None, pointer_bits=None):
    """Derive the wheel-style platform tag from the ENVIRONMENT, never user input.

    Inputs default to the live interpreter (sys.platform / platform.machine() /
    struct pointer size) and are only overridable so the pure gate can be unit
    tested offline. This governs native Windows only; off-Windows it returns a
    'non-windows:<sys.platform>' sentinel that is never in the table, so the gate
    is inert off-Windows (the caller skips it entirely -- see check-site comment).
    """
    try:
        plat = sys.platform if platform_name is None else str(platform_name)
    except Exception:
        plat = ''
    if not plat.startswith('win'):
        return 'non-windows:' + plat
    # Pointer width decides 32- vs 64-bit regardless of a mislabelled machine.
    try:
        bits = (struct.calcsize('P') * 8) if pointer_bits is None else int(pointer_bits)
    except Exception:
        bits = 0
    try:
        mach = (_platform.machine() if machine is None else str(machine)).lower()
    except Exception:
        mach = ''
    if mach in ('arm64', 'aarch64'):
        return 'win_arm64'
    if bits == 64:
        return 'win_amd64'
    if bits == 32:
        return 'win32'
    return 'win_unknown'


def check_interpreter(version_info=None, implementation=None, machine=None,
                      platform=None, pointer_bits=None, gil_disabled=None,
                      debug_build=None, releaselevel=None):
    """Pure, never-raising check of the running interpreter against the table.

    Returns a small dict:
      {'ok': bool,
       'running': 'CPython 3.x.y win_amd64'  (NO paths, NO identity; may carry a
                  ' (free-threaded)' / ' (debug)' / ' (pre-release)' suffix),
       'reason': plain-language string,
       'supported': tuple of the table rows}

    All parameters default to the live interpreter; they exist only so this can be
    unit-tested offline. Nothing here reads user input, touches disk, or raises on
    odd input (strings, None, negatives, garbage all yield ok=False with a reason).

    ABI guards (Security C-1 / C-1b / F-2): even when (impl, (major, minor), tag)
    matches a table row, the interpreter is REFUSED when it is a free-threaded
    (GIL-disabled, cp313t ABI) build, a debug (cp313d ABI) build, or a
    pre-release (releaselevel != 'final'), because the cp313 hash-pinned lock does
    not cover those ABIs. Each guard is derived from the environment inside a
    try/except so the never-raise contract always holds.

    The ABI override params gil_disabled / debug_build accept True, False or None
    ONLY. None means "detect from the live interpreter" (the production path). Any
    OTHER type (e.g. a non-empty string, an int, a list) is NOT a valid flag and is
    treated as True -- i.e. fail CLOSED (refuse), because bool() of any such value
    this function will see is True; these params exist solely for offline tests, so
    erring toward refusal on a malformed flag is the safe direction. releaselevel is
    compared by string equality to 'final'; any non-'final' value is a pre-release.
    """
    rows = SUPPORTED_WINDOWS_INTERPRETERS
    # --- implementation name ---
    try:
        if implementation is None:
            impl = _platform.python_implementation()
        else:
            impl = str(implementation)
    except Exception:
        impl = ''
    # --- version triple (major, minor, micro) ---
    try:
        if version_info is None:
            vmajor, vminor, vmicro = (sys.version_info.major,
                                      sys.version_info.minor,
                                      sys.version_info.micro)
        else:
            vmajor = int(version_info[0])
            vminor = int(version_info[1])
            vmicro = int(version_info[2]) if len(version_info) > 2 else 0
    except Exception:
        vmajor = vminor = vmicro = -1
    # --- free-threaded (GIL-disabled, cp313t ABI) detection (Security C-1) ---
    # Default from sysconfig's Py_GIL_DISABLED; also treat sys._is_gil_enabled()
    # returning False as free-threaded. Wrapped so it can never raise.
    try:
        if gil_disabled is None:
            gil_flag = False
            try:
                import sysconfig
                gil_flag = bool(sysconfig.get_config_var('Py_GIL_DISABLED'))
            except Exception:
                gil_flag = False
            try:
                is_gil_enabled = getattr(sys, '_is_gil_enabled', None)
                if callable(is_gil_enabled) and is_gil_enabled() is False:
                    gil_flag = True
            except Exception:
                pass
            gil = gil_flag
        elif gil_disabled is True or gil_disabled is False:
            gil = gil_disabled
        else:
            # Not a real bool and not None: malformed flag -> fail CLOSED (treat as
            # free-threaded so the interpreter is refused). See docstring (MINOR-A).
            gil = True
    except Exception:
        gil = False
    # --- debug build (cp313d ABI) detection (Security C-1b) ---
    try:
        if debug_build is None:
            dbg = hasattr(sys, 'gettotalrefcount')
        elif debug_build is True or debug_build is False:
            dbg = debug_build
        else:
            # Not a real bool and not None: malformed flag -> fail CLOSED (treat as
            # debug build so the interpreter is refused). See docstring (MINOR-A).
            dbg = True
    except Exception:
        dbg = False
    # --- release level (reject pre-releases) (Security F-2) ---
    # 'final' passes; 'alpha'/'beta'/'candidate' (and anything else) are refused.
    try:
        if releaselevel is None:
            if version_info is None:
                rel = sys.version_info[3]
            else:
                rel = version_info[3]
        else:
            rel = releaselevel
        rel = str(rel)
    except Exception:
        # No releaselevel available (e.g. a short injected tuple) -> treat as final
        # so garbage-input callers keep the never-raise, table-only behaviour.
        rel = 'final'
    is_prerelease = (rel != 'final')
    # --- platform tag (derived, not user-supplied) ---
    tag = _running_platform_tag(platform_name=platform, machine=machine,
                                pointer_bits=pointer_bits)
    # Running description (Tester MINOR-B): built ONLY from safe, sanitised pieces so
    # it can NEVER echo an input repr and can NEVER contain '/' or '\\'. The three
    # pieces are each clamped to a known safe form; 'tag' (used for table matching
    # above) is left untouched -- only the DISPLAY tag here is sanitised.
    #   impl_disp : the implementation name iff it is one of a small allow-set,
    #               otherwise the literal 'unknown-impl'.
    #   vtext     : digits-only 'major.minor.micro' iff all three are real
    #               non-negative ints, otherwise the literal 'unknown'.
    #   tag_disp  : one of the known wheel tags, or 'non-windows' / 'unknown'. A
    #               'non-windows:<plat>' sentinel is kept ONLY when <plat> passes a
    #               [a-z0-9_-]{1,16} filter; otherwise it collapses to 'unknown'.
    _IMPL_ALLOW = ('CPython', 'PyPy', 'Jython', 'IronPython', 'GraalPy')
    impl_disp = impl if (isinstance(impl, str) and impl in _IMPL_ALLOW) else 'unknown-impl'
    try:
        if vmajor >= 0 and vminor >= 0 and vmicro >= 0:
            vtext = '%d.%d.%d' % (vmajor, vminor, vmicro)
        else:
            vtext = 'unknown'
    except Exception:
        vtext = 'unknown'
    _KNOWN_TAGS = ('win_amd64', 'win32', 'win_arm64')
    if tag in _KNOWN_TAGS:
        tag_disp = tag
    elif isinstance(tag, str) and tag.startswith('non-windows:'):
        _plat_part = tag[len('non-windows:'):]
        if re.match(r'^[a-z0-9_-]{1,16}$', _plat_part):
            tag_disp = 'non-windows:' + _plat_part
        else:
            tag_disp = 'unknown'
    elif tag == 'non-windows':
        tag_disp = 'non-windows'
    else:
        # Covers 'win_unknown' and anything unexpected; never echo a raw string.
        tag_disp = 'unknown'
    running = '%s %s %s' % (impl_disp, vtext, tag_disp)
    annotations = []
    if gil:
        annotations.append('free-threaded')
    if dbg:
        annotations.append('debug')
    if is_prerelease:
        annotations.append('pre-release')
    if annotations:
        running = running + ' (' + ', '.join(annotations) + ')'
    # --- decision: match a table row on (impl, (major, minor), tag) AND the
    # ABI guards must all be clear (not free-threaded, not debug, not pre-release).
    table_ok = any(impl == r_impl and (vmajor, vminor) == r_ver and tag == r_tag
                   for (r_impl, r_ver, r_tag) in rows)
    ok = table_ok and not gil and not dbg and not is_prerelease
    if ok:
        reason = 'Running interpreter is a supported native-Windows interpreter.'
    elif table_ok and gil:
        reason = ('Free-threaded (GIL-disabled) CPython is not a supported '
                  'native-Windows interpreter: free-threaded builds use a '
                  'different ABI than the qualified lock. Detected ' + running +
                  '. Run the wizard under a supported interpreter; the wizard '
                  'will not switch interpreters for you.')
    elif table_ok and dbg:
        reason = ('Debug-build CPython is not a supported native-Windows '
                  'interpreter: debug builds use a different ABI than the '
                  'qualified lock. Detected ' + running + '. Run the wizard '
                  'under a supported interpreter; the wizard will not switch '
                  'interpreters for you.')
    elif table_ok and is_prerelease:
        reason = ('Pre-release CPython is not a supported native-Windows '
                  'interpreter: only a final release matches the qualified '
                  'lock. Detected ' + running + '. Run the wizard under a '
                  'supported interpreter; the wizard will not switch '
                  'interpreters for you.')
    else:
        wanted = '; '.join('%s %d.%d %s' % (ri, rv[0], rv[1], rt)
                           for (ri, rv, rt) in rows)
        reason = ('Unsupported interpreter for the native-Windows gateway. '
                  'Detected ' + running + '. Supported: ' + wanted + '. '
                  'Run the wizard under a supported interpreter; the wizard will '
                  'not switch interpreters for you.')
    return {'ok': ok, 'running': running, 'reason': reason, 'supported': rows}


def read_gateway_venv_version(root):
    """Read <root>/venv/pyvenv.cfg as PLAIN TEXT and report only the Python version.

    Pure, read-only, NEVER-raising. It does NOT execute anything, does NOT import
    the venv, and NEVER runs the venv python. It exists so inspect() can surface an
    INFORMATIONAL note about the interpreter an EXISTING gateway's venv was built
    with -- it never changes state, never blocks, never writes, never touches the
    venv itself.

    Returns a small dict ONLY:
      {'version': '3.13.1' | 'unknown', 'matches_supported': True | False | None}

    It NEVER returns or logs the cfg's 'home', 'executable', 'command' or any path.
    Safety posture (matches the codebase's symlink/size-cap conventions):
      - refuse if the cfg is a symlink or not a regular file (os.lstat)  -> unknown
      - read at most 16 KiB; a larger file                              -> unknown
      - decode UTF-8 with errors='replace'; non-UTF8 parses what decodes -> unknown
      - parse 'key = value' lines for 'version' (fallback 'version_info')
      - accept only a strict numeric dotted shape (3.13 / 3.13.1)        -> else unknown
      - missing file / any error                                        -> unknown
    """
    CAP = 16 * 1024
    try:
        cfg = Path(root) / 'venv' / 'pyvenv.cfg'
    except Exception:
        return {'version': 'unknown', 'matches_supported': None}
    try:
        st = os.lstat(str(cfg))
    except Exception:
        # Missing file or any stat error.
        return {'version': 'unknown', 'matches_supported': None}
    # Refuse a symlink or a non-regular file (dir/device/fifo).
    try:
        import stat as _stat
        if _stat.S_ISLNK(st.st_mode) or not _stat.S_ISREG(st.st_mode):
            return {'version': 'unknown', 'matches_supported': None}
    except Exception:
        return {'version': 'unknown', 'matches_supported': None}
    # Size cap: anything larger than CAP -> unknown without reading it all.
    try:
        if st.st_size > CAP:
            return {'version': 'unknown', 'matches_supported': None}
    except Exception:
        return {'version': 'unknown', 'matches_supported': None}
    # Bounded plain-text read (read at most CAP bytes, even if the size check was
    # somehow stale), decode defensively.
    try:
        with open(str(cfg), 'rb') as fh:
            raw = fh.read(CAP + 1)
        if len(raw) > CAP:
            return {'version': 'unknown', 'matches_supported': None}
        text = raw.decode('utf-8', errors='replace')
    except Exception:
        return {'version': 'unknown', 'matches_supported': None}
    # Parse 'key = value' lines; ONLY 'version' / 'version_info' are considered.
    version_text = None
    fallback_text = None
    try:
        for line in text.splitlines():
            if '=' not in line:
                continue
            key, _, value = line.partition('=')
            key = key.strip().lower()
            value = value.strip()
            if key == 'version':
                version_text = value
            elif key == 'version_info':
                fallback_text = value
    except Exception:
        return {'version': 'unknown', 'matches_supported': None}
    # 'version' is preferred and must match the strict numeric dotted shape. Only
    # when 'version' is absent do we fall back to 'version_info', which some layouts
    # write in the extended 'major.minor.micro.releaselevel.serial' form (e.g.
    # '3.13.2.final.0'); for that fallback we accept the extended shape and keep ONLY
    # the leading three numeric components ('3.13.2'). Any other shape stays 'unknown'.
    from_version = version_text is not None
    candidate = version_text if from_version else fallback_text
    if candidate is None:
        return {'version': 'unknown', 'matches_supported': None}
    try:
        candidate = candidate.strip()
    except Exception:
        return {'version': 'unknown', 'matches_supported': None}
    if from_version:
        if not _VENV_VERSION_RE.match(candidate):
            return {'version': 'unknown', 'matches_supported': None}
    else:
        m = _VENV_VERSION_INFO_RE.match(candidate)
        if not m:
            return {'version': 'unknown', 'matches_supported': None}
        # Keep ONLY the leading three numeric components (drop any .releaselevel.serial).
        candidate = m.group(1)
    # Compare major.minor to the single supported row's version.
    try:
        parts = candidate.split('.')
        cmajor, cminor = int(parts[0]), int(parts[1])
        supported_mm = set((rv[0], rv[1]) for (_ri, rv, _rt)
                           in SUPPORTED_WINDOWS_INTERPRETERS)
        matches = (cmajor, cminor) in supported_mm
    except Exception:
        return {'version': 'unknown', 'matches_supported': None}
    return {'version': candidate, 'matches_supported': matches}


def native_root():
    """One predictable per-user root; never a system or application directory."""
    return Path.home() / 'AQ-MCP-Gateway'


def local_python(root):
    return root / 'venv' / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')


def digest(data):
    return hashlib.sha256(data).hexdigest()


def ensure_safe_root(root):
    _p2_refuse_native()
    if root.is_symlink() or not root.is_dir():
        raise DeploymentError('Native gateway is missing or is a symlink')
    if (root / 'targets.json').is_symlink():
        raise DeploymentError('Native registry must not be a symlink')


@contextlib.contextmanager
def exclusive_lock(root):
    """Advisory cross-platform exclusive file lock, shared by wizard transactions."""
    _p2_refuse_native()
    lock = root / '.wizard.lock'
    if lock.is_symlink():
        raise DeploymentError('Gateway lock must not be a symlink')
    with open(lock, 'a+b') as fh:
        fh.seek(0)
        if fh.read(1) == b'':
            fh.write(b'0'); fh.flush()
        fh.seek(0)
        if os.name == 'nt':
            import msvcrt
            # LK_LOCK waits for access; one byte at position zero.
            msvcrt.locking(fh.fileno(), msvcrt.LK_LOCK, 1)
            try: yield
            finally:
                fh.seek(0); msvcrt.locking(fh.fileno(), msvcrt.LK_UNLCK, 1)
        else:
            import fcntl
            fcntl.flock(fh.fileno(), fcntl.LOCK_EX)
            try: yield
            finally: fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def atomic_write(path, data):
    """Create a user-owned temporary file adjacent to the destination, then replace."""
    _p2_refuse_native()
    fd, tmp = tempfile.mkstemp(prefix='.aq-wizard-', dir=str(path.parent))
    try:
        with os.fdopen(fd,'wb') as fh:
            if os.name != 'nt': os.fchmod(fh.fileno(), 0o600)
            fh.write(data); fh.flush(); os.fsync(fh.fileno())
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp): os.unlink(tmp)


class NativeGateway:
    """Implements the same operation surface as SSHGateway for a local host."""
    def __init__(self, root=None):
        self.root = Path(root) if root is not None else native_root()
        self.root = self.root.expanduser().absolute()
        self.registry = self.root / 'targets.json'
        self.backups = self.root / '.wizard-backups'

    def inspect(self):
        _p2_refuse_native()
        root = self.root
        if root.is_symlink():
            return {'state':'SYMLINK','installed':False}
        if not root.exists():
            return {'state':'MISSING','installed':False}
        if not root.is_dir():
            return {'state':'FOREIGN','installed':False}
        needed = ['aq_registry.py','aq_mcp_stdio.py','aq_check.py','targets.json',
                  'requirements-gateway.txt']
        missing = [x for x in needed if not (root/x).is_file() or (root/x).is_symlink()]
        if not local_python(root).is_file(): missing.append('venv/python')
        if missing: return {'state':'INCOMPLETE','installed':False,'missing':missing}
        if self.registry.is_symlink():return {'state':'SYMLINK','installed':False}
        try:
            data,raw,sha = self._load()
        except (ValueError, OSError, DeploymentError):
            return {'state':'INCOMPLETE','installed':False,'message':'Registry invalid'}
        # Informational only: 'wizard_interpreter' reports the interpreter running
        # THIS wizard process and whether it is a supported native-Windows
        # interpreter. It describes the WIZARD, not the existing gateway's venv
        # (Security I-1 relabel). This NEVER changes state (READY stays READY) and
        # NEVER blocks inspect/check/discover on an existing gateway -- the gate
        # governs bootstrap only. Off-Windows, _chk.ok is False (sentinel tag),
        # which is expected and still does not affect state.
        _chk = check_interpreter()
        result = {'state':'READY','installed':True,'sha256':sha,
                  'target_names':sorted(data['targets']),
                  'kinds':{k:v.get('kind','remote') for k,v in data['targets'].items()},
                  'git_targets':[], 'runtime':'NATIVE_LOCAL',
                  'root':str(self.root), 'python':str(local_python(root)),
                  'wizard_interpreter':{'running':_chk['running'],'supported':_chk['ok']},
                  'message':'User-owned native gateway; OS ACL policy requires separate review'}
        # Informational-only (WARN-ONLY), read-only note about the EXISTING gateway
        # venv's Python, parsed as plain text from venv/pyvenv.cfg. It NEVER changes
        # READY/not-READY state, NEVER blocks, NEVER writes, NEVER touches the venv,
        # and carries NO path/identity (only a dotted version string or 'unknown').
        # If the venv was built with a Python that is not the qualified one, a plain
        # 'note' is added; it is a display warning only -- the tool does NOT and will
        # not modify an existing gateway (Charter Amendment 4 / Amendment 5).
        _venv = read_gateway_venv_version(root)
        gateway_interpreter = {'venv_version':_venv['version'],
                               'matches_supported':_venv['matches_supported']}
        # Security D-7: an UNKNOWN read (unreadable/absent version) is NOT a proven
        # mismatch, so it gets its own plain note; a KNOWN different version keeps the
        # mismatch note. Neither note implies the tool will modify, upgrade or rebuild
        # the existing venv (Charter Amendment 4 / Amendment 5) -- both say nothing was
        # or will be changed.
        if _venv['version'] == 'unknown':
            gateway_interpreter['note'] = ('could not determine which Python built the '
                'existing gateway venv; nothing was changed')
        elif _venv['matches_supported'] is False:
            gateway_interpreter['note'] = ('existing gateway venv was built with a '
                'different Python than the qualified one; it has NOT been changed')
        result['gateway_interpreter'] = gateway_interpreter
        return result

    def _load(self):
        _p2_refuse_native()
        ensure_safe_root(self.root)
        raw = self.registry.read_bytes()
        if len(raw) > 1048576:raise DeploymentError('Registry exceeds 1 MiB')
        data=json.loads(raw.decode('utf-8'))
        if not isinstance(data,dict) or not isinstance(data.get('targets'),dict):
            raise DeploymentError('Registry missing targets object')
        return data,raw,digest(raw)

    def bootstrap(self, approved=False, install_dependencies=True):
        _p2_refuse_native()
        if not approved:raise DeploymentError('Explicit native-local installation approval required')
        if self.inspect().get('state')!='MISSING':
            raise DeploymentError('Create-only native bootstrap refuses existing gateway')
        if not install_dependencies:raise DeploymentError('Dependency installation approval missing')
        # Cygwin/MSYS refusal (Security F-1), fail-closed BEFORE anything is created.
        # On Cygwin/MSYS CPython os.name is 'posix' and the native-Windows interpreter
        # gate below (guarded by os.name=='nt') would be SKIPPED, yet local_python()
        # would build a POSIX-layout venv under the Windows user's home -- a blind spot.
        # Refuse explicitly here so nothing is ever created in that configuration. This
        # is placed before the >=3.10 check and before any mkdir/marker/venv/pip, so a
        # refusal leaves NOTHING on disk. Genuine Linux/macOS (sys.platform 'linux'/
        # 'darwin') is unaffected -- behaviour there stays byte-identical to today.
        try:
            _plat = sys.platform
        except Exception:
            _plat = ''
        if _plat.startswith('cygwin') or _plat.startswith('msys'):
            raise DeploymentError('Cygwin/MSYS Python is not a supported '
                                  'native-Windows interpreter; run the wizard under '
                                  'a supported native interpreter. The wizard will '
                                  'not switch interpreters for you.')
        # Windows Python >=3.10 is required by the underlying MCP runtime.
        if sys.version_info < (3,10):raise DeploymentError('Python 3.10 or newer required')
        # Enforced supported-interpreter gate (native Windows ONLY). The native venv
        # is credential-bearing, so the interpreter that will build and run it must be
        # a qualified row in SUPPORTED_WINDOWS_INTERPRETERS -- not merely >=3.10 -- and
        # must not be a free-threaded / debug / pre-release build (different ABI).
        # This runs BEFORE root.mkdir / marker write / venv / pip, so a refusal leaves
        # NOTHING on disk (the gateway root is never created). We NEVER fall back to a
        # different interpreter, never search for one, never invoke the py launcher.
        # On non-Windows hosts (os.name != 'nt') behaviour is EXACTLY as before: the
        # table governs native Windows only, so the gate is skipped entirely here.
        if os.name == 'nt':
            _chk = check_interpreter()
            if not _chk['ok']:
                raise DeploymentError(_chk['reason'])
        # D-2 floor (piece 2a): one definition of the marker bytes lives in remote_agent
        # (build_floor_marker / write_floor_marker / POLICY_MARKER_NAME). native_gateway
        # reuses it exactly as it already reuses check_entry / _read_stdio_tools from
        # remote_agent, so there is ONE marker definition across both bootstraps and the
        # tests (a parity test guards this).
        from remote_agent import write_floor_marker, POLICY_MARKER_NAME
        self.root.mkdir(mode=0o700,parents=False,exist_ok=False)
        try:
            for name in FILES:
                if name == 'aq-run.sh':continue  # never invoke Bash on Windows
                p=PAYLOAD/name
                if p.is_symlink() or not p.is_file():raise DeploymentError('Reviewed payload missing: '+name)
                dest=self.root/name
                with dest.open('xb') as fh: fh.write(p.read_bytes())
                if os.name!='nt':dest.chmod(0o600)
            atomic_write(self.registry,b'{"targets": {}}\n')
            # Write the D-2 policy marker CREATE-ONLY BEFORE the venv/pip step. Rationale
            # (argued in the report): the floor must be present the instant the gateway can
            # be READY -- there must never be a READY gateway with no marker (that would be
            # fail-OPEN). Writing it before venv/pip means a later pip failure still leaves
            # the floor in place AND leaves the gateway INCOMPLETE (inspect() does not report
            # READY until venv/python exists), while a marker-write failure aborts here and is
            # reported as INCOMPLETE below -- so no path yields a READY gateway without a
            # marker. The marker is NOT in FILES/PAYLOAD and NOT in SHA256SUMS: it is created
            # only at install time, so a payload that later lands on a legacy host has no floor.
            # write_floor_marker is create-only (O_EXCL, refuses a symlink) and 0600 where the
            # OS supports it; it returns the sha256 of the exact bytes on disk.
            marker_sha=write_floor_marker(self.root/POLICY_MARKER_NAME)
            subprocess.run([sys.executable,'-m','venv',str(self.root/'venv')],
                           stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,
                           timeout=90,check=True)
            py=local_python(self.root)
            subprocess.run([str(py),'-m','pip','install','-r',
                            str(self.root/'requirements-gateway.txt')],
                           stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,
                           timeout=300,check=True)
            subprocess.run([str(py),'-c','import mcp,botocore'],
                           stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,
                           timeout=15,check=True)
        except Exception as exc:
            # Do NOT delete a partially installed gateway; never erase operator data. A
            # marker-write failure lands here too: the gateway is reported INCOMPLETE and is
            # NOT READY (venv/python absent), so there is never a READY gateway without a marker.
            raise DeploymentError('Native bootstrap incomplete; inspect and reconcile before retrying. Cause: '+type(exc).__name__)
        # Report the marker alongside the standard inspect() receipt so the deploy flow can
        # record marker_sha256 and prove the floor was created (piece 2b will persist this in
        # the deployment receipt). inspect() returns READY only once venv/python is present.
        return dict(self.inspect(), marker_sha256=marker_sha, marker_created=True)

    def _probe_entry(self,entry):
        _p2_refuse_native()
        # Only Lambda Function URLs; cannot probe arbitrary HTTP endpoints.
        url=entry['url']
        _host,region=validate_lambda_url(url)
        from remote_agent import _read_stdio_tools
        env=os.environ.copy()
        env.update(AQ_TARGET_URL=url.rstrip('/') if url.rstrip('/').endswith('/mcp') else url.rstrip('/')+'/mcp',
                   AQ_REGION=region,AQ_TOOL_ALLOWLIST=','.join(entry.get('allow') or []),
                   AQ_EXTRA_HEADERS='{}',AQ_FORCED_ARGS='{}',AQ_SECRET_ARGS='{}',
                   AQ_LOG_FILE=str(self.root/'aq-mcp.log'))
        return _read_stdio_tools([str(local_python(self.root)),str(self.root/'aq_mcp_stdio.py')],env)

    def run(self, request, timeout=65):
        _p2_refuse_native()
        op=request.get('op')
        if op=='inspect':return self.inspect()
        if op=='bootstrap':
            return self.bootstrap(approved=request.get('confirm')=='CREATE_FRESH_GATEWAY',
                                  install_dependencies=request.get('install_dependencies') is True)
        if op=='discover':
            if self.inspect()['state']!='READY':raise DeploymentError('Native gateway not READY')
            entry=request['entry']
            return self._probe_entry(dict(entry,allow=[]))
        if op=='inspect_lambda_target':
            data,raw,sha=self._load()
            name=request['target'];t=data['targets'].get(name)
            if t is None or t.get('kind','remote')!='remote':raise DeploymentError('Lambda target not found')
            return {'target':name,'url':t['url'],'allow':list(t.get('allow') or []),
                    'registry_sha256':sha,
                    'extra_config_present':[k for k in ('headers','forced_args','secret_args') if t.get(k)]}
        if op=='apply':return self._apply(request)
        if op=='rollback':return self._rollback(request['receipt'])
        if op=='check':
            data,_,_=self._load();t=data['targets'].get(request['target'])
            if not t:raise DeploymentError('Target not found')
            result=self._probe_entry(t)
            count=result['count'];expected=request.get('expected_allow_count')
            return {'ok':expected is None or count==expected,
                    'status':'OK' if expected is None or count==expected else 'FAIL',
                    'tool_count':count}
        if op=='probe_existing':
            raise DeploymentError('Native-local v0.4 supports new Lambda targets only; Git/local adapters remain Linux SSH')
        if op in ('git_check','repair_permissions'):
            raise DeploymentError('Unsupported native-local operation: '+op)
        raise DeploymentError('Unknown native-local operation')

    def _apply(self,request):
        _p2_refuse_native()
        from remote_agent import check_entry
        target=request['target']
        if not isinstance(target,str) or not NAME.fullmatch(target):raise DeploymentError('Invalid target')
        entry=dict(request['entry'])
        normalize_tools(entry.get('allow',[]))
        check_entry(target,entry)
        with exclusive_lock(self.root):
            data,old,sha=self._load()
            if sha!=request['expected_sha256']:raise DeploymentError('Registry changed; regenerate plan')
            if target in data['targets']:raise DeploymentError('Target already exists; never overwrite')
            self.backups.mkdir(mode=0o700,exist_ok=True)
            backup=self.backups/(sha+'-'+target+'.json')
            if backup.exists() or backup.is_symlink():raise DeploymentError('Backup already exists; investigate')
            with backup.open('xb') as fd:fd.write(old)
            if os.name!='nt':backup.chmod(0o600)
            if digest(self.registry.read_bytes())!=sha:
                raise DeploymentError('CONFLICT: external registry change before write')
            data['targets'][target]=entry
            new=(json.dumps(data,indent=2,sort_keys=True)+'\n').encode('utf-8')
            atomic_write(self.registry,new)
            return {'target':target,'before_sha256':sha,'after_sha256':digest(new),
                    'backup_file':str(backup),'status':'REGISTRY_UPDATED',
                    'gateway_kind':'NATIVE_LOCAL'}

    def _rollback(self,receipt):
        _p2_refuse_native()
        with exclusive_lock(self.root):
            data,current,sha=self._load()
            if sha != receipt.get('after_sha256'):
                raise DeploymentError('Registry changed since deployment; refuse unsafe rollback')
            name=receipt.get('target')
            if not isinstance(name,str) or not NAME.fullmatch(name):
                raise DeploymentError('Invalid rollback target')
            if not re.fullmatch(r'[0-9a-f]{64}',receipt.get('before_sha256','')):
                raise DeploymentError('Invalid rollback base hash')
            if name not in data['targets']:raise DeploymentError('Deployed target absent')
            backup=self.backups/(receipt['before_sha256']+'-'+name+'.json')
            if backup.is_symlink() or str(backup)!=receipt.get('backup_file'):
                raise DeploymentError('Invalid rollback backup identity')
            prior=backup.read_bytes()
            if digest(prior)!=receipt['before_sha256']:raise DeploymentError('Backup hash mismatch')
            atomic_write(self.registry,prior)
            return {'status':'ROLLED_BACK','target':name,'registry_sha256':digest(prior)}
