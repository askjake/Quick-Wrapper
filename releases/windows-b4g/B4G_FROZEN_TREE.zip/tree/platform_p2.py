"""P2 Slice 1: platform helper (stdlib only; no side effects at import)."""
import sys


def is_darwin(plat=None):
    """True only for macOS. `plat` is injectable so tests never need a Mac."""
    return (sys.platform if plat is None else str(plat)) == 'darwin'
