"""Quick registration export and DIPS read-only inspection.

Direct writes to undocumented Quick SQLite schemas are intentionally prohibited.
A Quick-created connector can have internal cross-table invariants, signing or migrations.
"""
import json
import os
import sqlite3
from model import (quick_connector, config_export, redact_identity, secure_write_text,
                   assert_identity_safe,
                   secure_open, TIMEOUT_SECONDS, FULL_VARIANT_WARNING, RedactionError)
import capability_gate as _p2_gate
from platform_p2 import is_darwin as _p2_is_darwin

class RegistrationUnsupported(RuntimeError):
    pass


def _spec_identity(spec):
    """The (user, host) this spec renders into instructions/exports, for redaction."""
    return spec.get('user', ''), spec.get('host', '')


def config_export_text(spec, redacted=True):
    """The JSON export string. redacted=True (DEFAULT, shareable) replaces the real
    login, host/IP and home path with placeholders; redacted=False is the FULL variant
    that contains the real values (only for an explicit second user action).

    E2/N1 fail-closed: for the redacted (shareable) variant, redact_identity raises
    RedactionError if user or host is empty; this propagates so a caller NEVER emits a
    half-redacted export. Callers (wizard.py, cli.py) catch it, show the message, and
    refuse the share rather than writing unredacted text."""
    text = config_export(spec)
    if redacted:
        user, host = _spec_identity(spec)
        return redact_identity(text, user, host)
    return text


def write_quick_config(spec, file_path, redacted=True, full_ack=None):
    """Create-only, owner-only (0600) write of the Quick config JSON example.

    Default writes the REDACTED (shareable) variant. Pass redacted=False only for a
    deliberate FULL export that carries the real login/host. NEVER overwrites an
    existing file, and NEVER touches the Quick application profile.

    P2 Slice 1 (macOS only; ignored elsewhere): the FULL variant needs the exact typed
    EXPORT FULL token as full_ack, and a destination that resolves inside a Quick-owned
    folder (or is a file named mcp_config.json) is refused, before anything is written.
    """
    if _p2_is_darwin():
        _p2_darwin_export_guard(file_path, redacted, full_ack, spec)
    if not str(file_path).lower().endswith('.json'):
        raise ValueError('Configuration export must be .json')
    if os.path.exists(file_path):
        raise FileExistsError('Refusing to overwrite an existing export.')
    # secure_write_text is create-only (O_EXCL) with 0600 perms (POSIX enforced;
    # Windows best-effort read-only attribute only - see model.secure_open).
    secure_write_text(file_path, config_export_text(spec, redacted=redacted))
    return file_path


# ---------------------------------------------------------------------------
# P2 Slice 1 (macOS only), user decision B: export destination guard. Pure path
# logic plus os.path.realpath (reads link metadata only; never writes).
# ---------------------------------------------------------------------------
P2_QUICK_DIR_REFUSED = ('Refusing this export destination on macOS: it is inside a Quick-owned '
                        'folder or is a file named mcp_config.json. Quick configuration is never '
                        'written in Slice 1 (preview only); choose a private folder elsewhere.')
P2_QUICK_PROTECTED_NAMES = ('mcp_config.json',)


def _p2_fold(path_text):
    """Comparison form: NFC + casefold. macOS volumes are usually case- and
    normalisation-insensitive, so the guard must not be bypassed by case or encoding
    (on a case-sensitive volume this only over-refuses)."""
    import unicodedata
    return unicodedata.normalize('NFC', path_text).casefold()


def p2_quick_owned_roots(quick_homes=()):
    """Folders the macOS export guard protects: the quick_home DEFAULT (~/.quickwork,
    the folder find_quick_profile_configs scans when no home is given) plus every
    explicit Quick home the caller knows about. find_quick_profile_configs only finds
    mcp_config.json files UNDER such a home, so protecting the homes covers every
    discovered config."""
    roots = [os.path.join(os.path.expanduser('~'), '.quickwork')]
    for home in quick_homes or ():
        if home:
            roots.append(str(home))
    return roots


def _p2_within(child, parent):
    c = _p2_fold(child)
    r = _p2_fold(parent)
    if c == r:
        return True
    prefix = r if r.endswith(os.sep) else r + os.sep
    return c.startswith(prefix)


def p2_export_destination_refused(file_path, quick_homes=()):
    """True when an export/file destination must be REFUSED on macOS. Fails closed
    (True) on any unresolvable or malformed path. Each destination is compared both
    lexically (abspath) and resolved (realpath: symlinks and '..'), with and without
    '~' expansion, against every Quick-owned root (also compared in both forms)."""
    try:
        raw = os.fspath(file_path)
    except TypeError:
        return True
    if not isinstance(raw, str) or raw == '' or '\x00' in raw:
        return True
    try:
        cands = []
        for text in (raw, os.path.expanduser(raw)):
            cands.append(os.path.abspath(text))
            cands.append(os.path.realpath(text))
        roots = []
        for root in p2_quick_owned_roots(quick_homes):
            root = os.path.expanduser(root)
            roots.append(os.path.abspath(root))
            roots.append(os.path.realpath(root))
    except (OSError, ValueError):
        return True
    names = [os.path.basename(raw)] + [os.path.basename(c) for c in cands]
    if any(_p2_fold(n) in P2_QUICK_PROTECTED_NAMES for n in names):
        return True
    for cand in cands:
        for root in roots:
            if _p2_within(cand, root):
                return True
    return False


def _p2_darwin_export_guard(file_path, redacted, full_ack, spec=None):
    """macOS only (caller checks): FULL token first, then the destination, then - for a
    REDACTED (shareable) export - the [P2-S1 / B4] identity-safety check.

    `spec` is optional so an existing 3-argument call keeps working; when it IS given
    and the export is the redacted variant, this REFUSES (IdentityRedactionError)
    before write_quick_config opens or creates anything, so a refused export leaves no
    file behind. config_export_text is byte-frozen for Windows parity, so the check
    lives in this darwin-only guard instead of in the shared formatter.
    """
    if not redacted:
        _p2_gate.require_full_variant('export', full_ack)
    if p2_export_destination_refused(file_path):
        raise _p2_gate.GateRefused(P2_QUICK_DIR_REFUSED)
    # [P2-S1 / B4e] SEC-B-01 (C): the FULL variant (real login/host) is also refused
    # inside a git work tree / this program folder / a known cloud-synced folder, or
    # wherever that cannot be confirmed - still BEFORE write_quick_config creates
    # anything. The redacted variant is unchanged.
    # [P2-S1 / B4f] F3 (user decision M2): when Google Drive for desktop is detected on this
    # Mac by local evidence, the FULL file may only be written directly inside the ONE
    # private export folder (validated - and created only if missing - by
    # p2_ensure_private_export_dir). Checked after the token and Quick-owned checks and
    # before the destination classifier below; returns a fixed refusal text or None.
    if not redacted:
        drive_refusal = _p2_drive_private_dir_refusal(file_path)
        if drive_refusal is not None:
            raise _p2_gate.GateRefused(drive_refusal)
    if not redacted and _p2_full_export_destination_unsafe(file_path):
        raise _p2_gate.GateRefused(P2_FULL_EXPORT_DEST_REFUSED)
    if redacted and spec is not None:
        assert_identity_safe(config_export_text(spec, redacted=True), *_spec_identity(spec))


def inspect_dips_read_only(path):
    """Inventory table/schema NAMES only; no personal connector rows or database writes."""
    _p2_gate.refuse_g3_write('inspect_dips_read_only')
    if not os.path.isfile(path):
        raise FileNotFoundError(path)
    # URI read-only avoids modifying schema; Quick should be closed for consistent inspection.
    from pathlib import Path
    uri = Path(path).resolve().as_uri() + '?mode=ro'
    cn = sqlite3.connect(uri, uri=True, timeout=1)
    try:
        cn.execute('PRAGMA query_only=ON')
        return [{'name': row[0], 'type': row[1]}
                for row in cn.execute("SELECT name,type FROM sqlite_master WHERE type IN ('table','view') ORDER BY name")]
    finally:
        cn.close()


def register_quick_automatically(*args, **kwargs):
    raise RegistrationUnsupported('No supported Quick connector registration interface verified. Use guided manual entry.')


def quick_copy_fields(connector):
    """Format a validated wizard connector for direct manual Quick GUI entry.

    This is a display/export helper only; it never registers a connector in Quick.
    Both SSH and native-local connectors use a single space-separated Arguments
    field in the observed Quick UI. Paths containing spaces require separate
    validation before use (native-local model rejects such paths).
    """
    if not isinstance(connector, dict):
        raise ValueError('Quick connector configuration is missing')
    command = connector.get('command')
    arguments = connector.get('arguments')
    if not isinstance(command, str) or not command.strip():
        raise ValueError('Missing Quick connector command')
    if not isinstance(arguments, list) or not arguments or any(
            not isinstance(arg, str) or not arg.strip() or any(ch in arg for ch in ('\n', '\r', '\x00'))
            for arg in arguments):
        raise ValueError('Invalid Quick connector arguments')
    if any(any(ch.isspace() for ch in arg) for arg in arguments):
        raise ValueError('Quick Arguments include spaces within an argument; validate UI parsing before copying')
    return {'command': command, 'arguments': ' '.join(arguments),
            'id': connector.get('id', ''), 'name': connector.get('name', ''),
            'timeout_seconds': connector.get('timeout_seconds', 120)}


def quick_instructions(spec, redacted=False):
    """Human-executable setup steps grounded in observed Quick Edit MCP UI.

    This is manual UI registration, not a DIPS mutation or import contract.

    B2b S7: redacted=False (DEFAULT) renders the real login/host so the user can
    actually run the command on their own machine. When the text is to be SHARED
    (Copy/Export), callers pass redacted=True, which replaces the real login,
    host/IP and home path with placeholders (<user>@<3090-host>, /home/<user>/aq-mcp).
    The GUI 'Copy Quick settings' and 'Export' actions default to the redacted text
    and offer the full text only behind an explicit second action.

    v0.4 native-local merge: the Command line is no longer hard-coded to 'ssh'; it
    renders cfg['command'] so a native-local connector (command = the local Python
    interpreter path) shows the correct launcher. For SSH specs cfg['command'] is
    'ssh', so SSH wording is unchanged.
    """
    cfg=quick_connector(spec)
    args=' '.join(cfg['arguments'])
    chips='\n'.join('    {}. {}'.format(i+1, value) for i,value in enumerate(cfg['arguments']))
    text=("AMAZON QUICK \u2014 MANUAL LOCAL MCP CONNECTOR SETUP\n"
            "================================================\n"
            "Prerequisite: gateway was inspected and backend passed MCP tools/list.\n"
            "The gateway write and Quick registration are TWO separate operations.\n\n"
            "1. Open Amazon Quick Desktop. Go to Customize > Connectors.\n"
            "2. Open Create/Add MCP (exact label may vary by Quick version).\n"
            "3. Set these fields in the Edit MCP form:\n"
            "   Connection type : Local\n"
            "   ID              : {id}\n"
            "   Name            : {name}\n"
            "   Command         : {command}\n"
            "   Arguments       : {args}\n"
            "   Environment variables : EMPTY \u2014 never enter AWS credentials/PATs.\n"
            "   Timeout (seconds)     : {timeout} (adjust for the tool family)\n\n"
            "   The Arguments field is ONE input; Quick displays parsed chips.\n"
            "   Expected {count} argument chips:\n{chips}\n\n"
            "4. Click Test connection (if offered). Diagnose any failure before saving.\n"
            "5. Click Save changes. If updating a connector, Edit > Save relaunches\n"
            "   its process in the observed Quick build; a toggle alone may not.\n"
            "6. Open a NEW Quick chat so that the model sees the refreshed tool list.\n"
            "7. Request a safe read-only tool or inspect tools/list. Check it returns\n"
            "   data from the intended backend; a different tool family is a red flag.\n"
            "8. Review per-tool Quick permissions: keep mutations Ask each time\n"
            "   or Always deny unless explicitly approved. The gateway allow-list\n"
            "   is a separate permission layer.\n\n"
            "   Example prompt: Using the {name} connector, list your available\n"
            "   tools and perform one harmless read-only query. Do not modify data.\n\n"
            "NOTICE: This wizard does not modify Quick's undocumented DIPS DB,\n"
            "register a connector, grant permissions, or prove tool execution\n"
            "inside Quick. Exported JSON is a reference example, NOT a verified\n"
            "import format. Capture the test result and mark registration verified\n"
            "only after a real Quick chat call succeeds.\n").format(
                id=cfg['id'],name=cfg['name'],command=cfg['command'],args=args,
                timeout=cfg['timeout_seconds'],count=len(cfg['arguments']),chips=chips)
    if redacted:
        user, host = _spec_identity(spec)
        return redact_identity(text, user, host)
    return text


def quick_instructions_variants(spec):
    """Both variants for the GUI: the DEFAULT redacted (shareable) text and the FULL
    text with its warning banner. The GUI shows the full text only on an explicit
    'Show full (real login/host)' action."""
    full=quick_instructions(spec, redacted=False)
    return {'redacted': quick_instructions(spec, redacted=True),
            'full': full,
            'full_labeled': FULL_VARIANT_WARNING + '\n\n' + full}


def quick_instructions_screen(spec):
    """P2 Slice 1 (macOS): the on-screen / redacted builder. It builds ONLY the redacted
    text and never returns the FULL text (that needs quick_instructions_full + COPY FULL).

    [P2-S1 / B4] This is the macOS formatting boundary for the Step 5 panel text, the
    shareable text and the redacted clipboard copy (the wizard holds ONLY what this
    returns), so the identity-safety refusal is applied HERE rather than in a button
    handler. It REFUSES (IdentityRedactionError) when the real login or host would
    still be readable after redaction - e.g. a login embedded in an approved target
    name, which renders as the Quick id 'aq-<login>-epg'. The text is never edited and
    no approved target name is rewritten; the whole artifact is withheld.

    quick_instructions itself is byte-frozen for Windows parity (the independent
    acceptance suite pins its source), so the check is added in this darwin-only
    wrapper and the Windows path is untouched.
    """
    return {'redacted': assert_identity_safe(quick_instructions(spec, redacted=True),
                                             *_spec_identity(spec))}


def quick_instructions_full(spec, copy_ack=None):
    """The FULL (real login/host) Quick setup text for an explicit Copy FULL action.

    P2 Slice 1 (macOS only; ignored elsewhere): the exact typed COPY FULL token is
    required BEFORE the text is built, mirroring write_quick_config's EXPORT FULL
    requirement. Off macOS this returns quick_instructions(spec, redacted=False)."""
    if _p2_is_darwin():
        _p2_gate.require_full_variant('copy', copy_ack)
    return quick_instructions(spec, redacted=False)
# ===========================================================================
# v0.4 Import-phase additions (stage 1 of 3): Quick "Import" workflow helpers.
#
# These functions ADD a *generate-an-import-file / read-only-verify* path on top
# of the existing manual-registration helpers above. They never write to Quick's
# own store (mcp_config.json / DIPS); emit_quick_import_file writes an import file
# ELSEWHERE, and the discovery/collision/verify helpers only READ Quick's
# mcp_config.json. Every existing name and behaviour above is preserved.
#
# Observed facts these are built on (executed on the user's machine, 2026-10-20):
#   * Quick's Add-MCP dialog has an Import mode that reads a standard mcpServers
#     JSON file by path.
#   * A file with ONE server {command, args} (no env, no _quick) imported and
#     worked. Quick stored it under a key = <name>-<random 8 hex> with fields
#     command, args and a Quick-added _quick object
#     {name: <source name>, source: <import file path>, upstream_id: <source name>};
#     NO startupTimeout was recorded. Deleting the connector restored the file.
#   * In a LATER executed read of the real profile mcp_config.json (2026-10-20),
#     11 of 19 entries carried startupTimeout, name and autoDisabled INSIDE the
#     per-entry _quick object (not at the entry top level). So the verifier reads
#     startupTimeout from _quick first and falls back to a top-level value, and
#     reports which location it used (startup_timeout_location).
#
# NOT observed (so NOTHING below claims it): whether Quick shows a command-
# confirmation prompt, the default timeout value, duplicate-import behaviour.
# ===========================================================================

import re as _re
import hashlib as _hashlib

# Connector key / import-file server name: lowercase, digit/hyphen, 1..64 chars,
# must start with [a-z0-9]. This is the charset the observed import used.
QUICK_IMPORT_NAME_RE = _re.compile(r'^[a-z0-9][a-z0-9-]{0,63}$')

# Windows reserved device names (compared case-insensitively, with or without an
# extension). These can never be a safe connector/server name.
_WINDOWS_RESERVED_NAMES = frozenset(
    ['con', 'prn', 'aux', 'nul']
    + ['com%d' % n for n in range(1, 10)]
    + ['lpt%d' % n for n in range(1, 10)])

# Cloud-sync folder markers; an import file dropped inside one of these would be
# copied off the machine by the sync client (the file carries the real login/host),
# so emit refuses such a destination unless allow_synced=True.
#
# F-2 / Tester D-1 single-source: this is the ONE authoritative marker list.
# cli.py's advisory pre-check imports the public helper path_looks_synced (below)
# instead of carrying its own copy, so the CLI message and the emitter refusal can
# never diverge. SYNCED_PATH_MARKERS is the public alias of this same object.
_SYNCED_PATH_MARKERS = ('onedrive', 'dropbox', 'google drive', 'googledrive',
                        'icloud', 'icloud drive', 'icloudrive')
# Public alias (same object) so callers can reference the markers without reaching
# for the underscore-prefixed name. Do NOT redefine this list elsewhere.
SYNCED_PATH_MARKERS = _SYNCED_PATH_MARKERS

# Hard cap for reading Quick's mcp_config.json read-only (defensive; the real file
# is a few KB). Anything larger is treated as UNREADABLE rather than parsed.
_QUICK_CONFIG_MAX_BYTES = 5 * 1024 * 1024


class ImportFileError(ValueError):
    """Raised when an import file cannot be emitted safely. Its message NEVER
    contains the file content or any argument/command value - only the reason."""
    pass


def _is_windows_reserved_name(name):
    """True if name is a Windows reserved device name, with or without an
    extension and regardless of case (e.g. 'CON', 'con.json', 'COM1.txt')."""
    stem = str(name).split('.', 1)[0].strip().lower()
    return stem in _WINDOWS_RESERVED_NAMES


def _validate_import_name(name):
    """Validate the single mcpServers key. Returns the name on success, else
    raises ImportFileError with a reason that never echoes other content."""
    if not isinstance(name, str) or not name:
        raise ImportFileError('Import connector name must be a non-empty string.')
    if not QUICK_IMPORT_NAME_RE.match(name):
        raise ImportFileError(
            "Import connector name must match ^[a-z0-9][a-z0-9-]{0,63}$ "
            "(lowercase letters, digits, hyphen; 1-64 chars; no leading hyphen).")
    if _is_windows_reserved_name(name):
        raise ImportFileError('Import connector name must not be a Windows reserved device name.')
    return name


def _coerce_import_server(settings):
    """Validate the wizard settings into exactly {command, args}.

    'settings' is the existing quick_copy_fields / quick_connector output: it
    carries a string 'command' and an arguments list (key 'args' or 'arguments')
    plus a display name ('name' or 'id'). We take those VERBATIM; we do not
    re-derive the command or args. Returns (name, command, args_list).

    Enforces: exactly one server (settings is a single connector dict), command a
    non-empty str, args a list of non-empty strs without control chars/newlines,
    NO 'env', NO '_quick', NO unknown keys beyond the known wizard field set.
    """
    if not isinstance(settings, dict):
        raise ImportFileError('Connector settings must be a dict (one server).')
    # Explicitly refuse metadata that must never reach an import file.
    if 'env' in settings and settings.get('env') not in (None, {}):
        raise ImportFileError("Import file must not carry an 'env' block.")
    if '_quick' in settings:
        raise ImportFileError("Import file must not carry a '_quick' block (Quick adds it).")
    # Known wizard field set (quick_copy_fields / quick_connector). Anything else
    # is an unknown key and is refused so we never silently pass a surprise field
    # into the import file.
    known = {'command', 'arguments', 'args', 'id', 'name', 'timeout_seconds',
             'connection_type', 'environment_variables'}
    unknown = set(settings) - known
    if unknown:
        raise ImportFileError('Unknown connector settings key(s) present; refusing to emit.')
    command = settings.get('command')
    if not isinstance(command, str) or not command.strip():
        raise ImportFileError('Connector command must be a non-empty string.')
    args = settings.get('args', settings.get('arguments'))
    if not isinstance(args, list) or not args:
        raise ImportFileError('Connector args must be a non-empty list.')
    for a in args:
        if not isinstance(a, str) or not a:
            raise ImportFileError('Each connector arg must be a non-empty string.')
        if any((ord(ch) < 0x20 or ord(ch) == 0x7f) for ch in a):
            raise ImportFileError('Connector args must not contain control characters or newlines.')
    name = settings.get('name') or settings.get('id') or ''
    return name, command, list(args)


def _build_import_payload(name, command, args):
    """The exact bytes written to an import file: UTF-8, no BOM, LF, indent 2,
    key order {command, args}. Pure; returns a bytes object. Never logged."""
    body = ('{\n'
            '  "mcpServers": {\n'
            '    ' + json.dumps(name) + ': {\n'
            '      "command": ' + json.dumps(command) + ',\n'
            '      "args": [\n'
            + ''.join('        ' + json.dumps(a) + (',' if i < len(args) - 1 else '') + '\n'
                      for i, a in enumerate(args))
            + '      ]\n'
            '    }\n'
            '  }\n'
            '}\n')
    return body.encode('utf-8')  # no BOM, LF only


def _path_is_synced(dest_dir):
    """True if dest_dir sits inside a known cloud-sync folder (name match on any
    path component, case-insensitive). Uses the single authoritative marker list
    _SYNCED_PATH_MARKERS; see path_looks_synced for the public entry point."""
    norm = str(dest_dir).replace('\\', '/').lower()
    parts = [p for p in norm.split('/') if p]
    for p in parts:
        if p in _SYNCED_PATH_MARKERS:
            return True
    return False


def path_looks_synced(path):
    """Public, single-source synced-folder check (F-2 / Tester D-1).

    Returns True if `path` sits inside a known cloud-sync folder. This is the ONE
    implementation; cli.py imports and calls it so the CLI advisory pre-check and
    the emitter refusal share the exact same markers (including 'icloud drive')
    and can never drift apart. Behaviour is identical to _path_is_synced; this is
    the name external callers should use.
    """
    return _path_is_synced(path)


def emit_quick_import_file(settings, dest_dir, *, filename=None, allow_synced=False,
                           allow_inside_repo=False):
    """Write a minimal, Quick-importable mcpServers JSON file for ONE server.

    settings: the existing quick_copy_fields / quick_connector output (command +
        args list + display name). command and args are used VERBATIM.
    dest_dir: a directory to write into (NOT Quick's profile dir). Create-only.
    filename: optional base filename (no path separators). On collision a numbered
        new filename is chosen; an existing file is NEVER overwritten.
    allow_synced: must be True to permit a dest_dir inside a OneDrive/Dropbox/
        Google Drive/iCloud-named path (the file carries the real login/host).
    allow_inside_repo: TEST-ONLY override. When False (the default, and the only
        value the CLI ever uses) the destination is REFUSED if it lies inside a
        git work tree (a .git directory OR file found by walking up from dest_dir)
        or inside the folder that contains this module (the project's own
        repo/work copy). The import file carries the real login/host and must
        never be committed or published, so it must not land in a repo.

    Writes {"mcpServers": {name: {"command":..., "args":[...]}}} as UTF-8 without
    BOM, LF, indent 2. Owner-only (0600) where the OS supports it; refuses a
    symlink destination (O_NOFOLLOW/O_EXCL via model.secure_open).

    Returns {path, name, sha256, bytes, contains_identity_warning: True}. The file
    CONTENT is NEVER included in the result or in any exception message.
    """
    _p2_gate.refuse_g3_write('emit_quick_import_file')
    name, command, args = _coerce_import_server(settings)
    name = _validate_import_name(name)
    payload = _build_import_payload(name, command, args)

    if not isinstance(dest_dir, str) or not dest_dir:
        raise ImportFileError('Destination directory must be a non-empty path string.')
    if not allow_synced and _path_is_synced(dest_dir):
        raise ImportFileError(
            'Destination is inside a cloud-sync folder; the import file carries your '
            'login/host. Pass allow_synced=True only if you accept that it will sync.')
    if not os.path.isdir(dest_dir):
        raise ImportFileError('Destination directory does not exist.')
    if not allow_inside_repo and _dest_inside_repo(dest_dir):
        raise ImportFileError(
            'Destination is inside a git work tree or this project folder; the import '
            'file contains your login and host and must never be committed or published. '
            'Choose a directory outside any repository.')

    # Filename: default is the connector name; reject any path separators so the
    # file can only land inside dest_dir.
    base = filename if filename else (name + '.json')
    if not isinstance(base, str) or not base:
        raise ImportFileError('Filename must be a non-empty string.')
    if ('/' in base) or ('\\' in base) or (os.sep in base) or (os.altsep and os.altsep in base):
        raise ImportFileError('Filename must not contain a path separator.')
    if not base.lower().endswith('.json'):
        base = base + '.json'
    stem = base[:-len('.json')]

    # Create-only: on collision pick a numbered new filename, never overwrite.
    candidate = base
    n = 1
    last_err = None
    path = None
    while n <= 1000:
        full = os.path.join(dest_dir, candidate)
        try:
            # secure_open is O_CREAT|O_EXCL|O_WRONLY|O_NOFOLLOW, 0600: it refuses an
            # existing file AND a symlink at the path. We write payload bytes as-is
            # (no newline translation: O_BINARY on Windows).
            # F-8 (informational): on Windows O_NOFOLLOW is defined as 0, so there
            # the symlink refusal rests on O_EXCL (which refuses an existing reparse
            # point) together with the realpath-based checks in _dest_inside_repo /
            # _is_within below. This note documents existing behaviour; nothing here
            # changes on either platform.
            fd = secure_open(full)
            try:
                os.write(fd, payload)
            finally:
                os.close(fd)
            if os.name == 'nt':
                try:
                    os.chmod(full, 0o600)  # Windows: read-only attribute only.
                except OSError:
                    pass
            path = full
            break
        except FileExistsError as e:
            last_err = e
            candidate = '%s-%d.json' % (stem, n)
            n += 1
            continue
    if path is None:
        # Exhausted numbered candidates; reason only, never content.
        raise ImportFileError('Could not create a new import file (too many name collisions).')

    return {'path': path,
            'name': name,
            'sha256': _hashlib.sha256(payload).hexdigest(),
            'bytes': len(payload),
            'contains_identity_warning': True}


def _dest_inside_repo(dest_dir):
    """True if dest_dir lies inside a git work tree or inside the folder that
    contains this module (the project's own repo/work copy).

    A git work tree is detected by walking UP from dest_dir looking for a `.git`
    entry that exists as either a directory (normal clone) OR a file (worktree/
    submodule gitlink). The project-folder check refuses a destination at or
    under the directory that holds quick_reg.py itself.

    F-3 hardening:
      * Every path (the destination, the project folder and each ancestor in the
        git walk) is resolved with os.path.realpath - NOT os.path.abspath - so
        junctions / 8.3 short names / symlinked ancestors collapse to their real
        location before the comparison.
      * The project-folder guard must not silently vanish. If __file__ is
        unavailable we fall back to the current working directory (realpath'd);
        if NEITHER the module path nor the cwd can be resolved we FAIL CLOSED
        (return True, refusing the destination) rather than dropping the guard.
      * An unresolvable destination also fails closed.
    """
    try:
        dest = os.path.realpath(dest_dir)
    except OSError:
        return True  # fail closed: cannot resolve the destination
    # Determine the project's own folder. Prefer __file__; if it is unavailable
    # (frozen/exec'd module) fall back to the current working directory; if
    # NEITHER resolves, fail closed rather than skip the guard.
    module_dir = None
    try:
        module_dir = os.path.realpath(os.path.dirname(__file__))
    except (NameError, OSError):
        module_dir = None
    if module_dir is None:
        try:
            module_dir = os.path.realpath(os.getcwd())
        except OSError:
            module_dir = None
    if module_dir is None:
        return True  # fail closed: project root undeterminable
    if _is_within(dest, module_dir):
        return True
    # Walk up looking for a .git entry (directory OR file), on realpath'd paths.
    cur = dest
    while True:
        git_marker = os.path.join(cur, '.git')
        if os.path.isdir(git_marker) or os.path.isfile(git_marker):
            return True
        parent = os.path.realpath(os.path.dirname(cur))
        if parent == cur:
            break
        cur = parent
    return False


def _is_within(child, parent):
    """True if `child` is `parent` or a path under it.

    F-3: both ends are resolved with os.path.realpath (collapsing symlinks, 8.3
    short names and junctions) before the normcase prefix comparison, so a
    symlinked ancestor cannot slip a destination past the project-folder guard.

    Follow-up (Security cond D / Tester D-1): on an OSError from os.path.realpath
    this now FAILS CLOSED (returns True, i.e. "treat as inside/refuse") to match
    _dest_inside_repo's posture. _is_within has exactly one caller - the
    project-folder guard in _dest_inside_repo, where True means "inside -> refuse"
    - so returning True on an unresolvable path refuses rather than silently
    skipping the guard. This matters for the work copy, which has NO .git tree, so
    the .git walk is NOT a backstop for the project-folder guard.
    """
    try:
        child_n = os.path.normcase(os.path.realpath(child))
        parent_n = os.path.normcase(os.path.realpath(parent))
    except OSError:
        return True  # fail closed: an unresolvable path is treated as "inside"
    if child_n == parent_n:
        return True
    prefix = parent_n if parent_n.endswith(os.sep) else parent_n + os.sep
    return child_n.startswith(prefix)


# [P2-S1 / B4e] SEC-B-01, macOS FULL-JSON export only (called from the darwin-only
# _p2_darwin_export_guard). Reuses the EXISTING classifiers of the import-file emitter:
# _path_is_synced (the single _SYNCED_PATH_MARKERS list) and _dest_inside_repo (git
# work tree walk + this program folder). No new path list or marker is introduced.
P2_FULL_EXPORT_DEST_REFUSED = ('Refusing this FULL export destination on macOS: it is inside a '
                               'git work tree, this program folder or a cloud-synced folder, or '
                               'its location could not be confirmed safe. The FULL file contains '
                               'your real login and host. Choose a private local folder (full '
                               'path) outside any repository or synced folder.')


def _p2_full_export_destination_unsafe(file_path):
    """[P2-S1 / B4e] True when a macOS FULL export destination must be REFUSED.

    Refuses a destination whose folder is inside a git work tree or this program
    folder (_dest_inside_repo) or a known cloud-synced folder (_path_is_synced, checked
    on the path as given, '~'-expanded and fully resolved). FAILS CLOSED (True) whenever
    the classification is uncertain: non-str/empty/NUL path, a path that is not
    absolute after '~' expansion, a folder that cannot be resolved or stat'ed
    (missing, not a directory, symlink loop, permission error), or any ancestor whose
    '.git' entry cannot be checked (anything but 'does not exist'). Pure path logic plus
    realpath/stat/lstat (metadata reads only); never creates, writes or deletes.

    [P2-S1 / B4f] S-02: the path must be absolute AS GIVEN (write_quick_config opens the
    raw path, so a '~' or relative path is refused instead of being classified at a
    different place than the one written). F1: Google Drive for desktop locations
    (_p2_is_google_drive_location) are refused. F2: every rule is applied both to the
    lexically collapsed parent and to the kernel-order parent dirname(realpath(path)),
    so a symlink followed by '..' cannot move the write past the checks."""
    import stat as _stat
    try:
        raw = os.fspath(file_path)
    except TypeError:
        return True
    if not isinstance(raw, str) or raw == '' or '\x00' in raw:
        return True
    if not os.path.isabs(raw):  # [P2-S1 / B4f] S-02
        return True
    try:
        text = os.path.expanduser(raw)
        if not os.path.isabs(text):
            return True
        parent = os.path.dirname(os.path.abspath(text))
        real_parent = os.path.realpath(parent)
        real_text = os.path.realpath(text)
        kernel_parent = os.path.dirname(real_text)  # [P2-S1 / B4f] F2 kernel order
        for folder in (real_parent, kernel_parent):
            if not _stat.S_ISDIR(os.stat(folder).st_mode):
                return True
        for cand in (raw, text, os.path.abspath(text), parent, real_parent, real_text,
                     kernel_parent):
            if _path_is_synced(cand) or _p2_is_google_drive_location(cand):
                return True
        for start in (real_parent, kernel_parent):
            if _p2_git_entry_above(start):
                return True
            if _dest_inside_repo(start):
                return True
        return False
    except (OSError, ValueError, RuntimeError):
        return True


def _p2_git_entry_above(start):
    """[P2-S1 / B4f] The B4e '.git' lstat walk, unchanged, factored out so it can run from
    both parents: True if any ancestor of `start` (inclusive) has a '.git' entry of any
    type (dir, gitlink file, symlink, even dangling). A FileNotFoundError means absent;
    any other OSError propagates (the caller fails closed)."""
    cur = start
    while True:
        try:
            os.lstat(os.path.join(cur, '.git'))
            return True  # a .git entry (dir, gitlink file or link) exists here
        except FileNotFoundError:
            pass
        nxt = os.path.dirname(cur)
        if nxt == cur:
            return False
        cur = nxt


# [P2-S1 / B4f] F1 (SD-01, SD-02): Google Drive for desktop locations on macOS, by documented
# local convention only (no reads of Google data): the File Provider root
# .../Library/CloudStorage/GoogleDrive[-<account>]/... and the legacy mount
# /Volumes/GoogleDrive[-<id>]/... ('-<id>' is a precautionary fail-closed variant).
# Darwin FULL export only; _SYNCED_PATH_MARKERS / _path_is_synced are NOT changed.
_P2_GDRIVE_ROOT_RE = _re.compile(r'^googledrive(-.+)?$')


def _p2_is_google_drive_location(path_text):
    """[P2-S1 / B4f] True if path_text is at or below a Google Drive for desktop root.
    Compared folded (NFC + casefold), per path component. Pure; no I/O. Does not match
    OneDrive-*, Dropbox, Box-*, GoogleDriveBackupX or MyGoogleDrive."""
    c = [p for p in _p2_fold(str(path_text)).replace('\\', '/').split('/') if p]
    for i in range(len(c) - 2):
        if c[i] == 'library' and c[i + 1] == 'cloudstorage' and _P2_GDRIVE_ROOT_RE.match(c[i + 2]):
            return True
    return len(c) >= 2 and c[0] == 'volumes' and bool(_P2_GDRIVE_ROOT_RE.match(c[1]))


# [P2-S1 / B4f] F3 (user decision M2). Detection of Google Drive for desktop uses local
# metadata only: existence (lstat) of the app bundle and of the DriveFS support folder
# (never opened, listed or read), and the NAMES in ~/Library/CloudStorage and /Volumes
# (looking only for the GoogleDrive prefix). Any error other than 'does not exist' counts
# as DETECTED (fail closed). Module-level names so tests can point them at fixtures.
_P2_DRIVE_APP_PATHS = ('/Applications/Google Drive.app',)
_P2_VOLUMES_DIR = '/Volumes'
_P2_DRIVEFS_PARTS = ('Library', 'Application Support', 'Google', 'DriveFS')
_P2_CLOUDSTORAGE_PARTS = ('Library', 'CloudStorage')
# The ONE designated application-private export folder (no existing convention in the tree).
_P2_PRIVATE_EXPORT_PARTS = ('.aq_mcp_wizard', 'private_exports')
P2_PRIVATE_EXPORT_DIR_DISPLAY = '~/.aq_mcp_wizard/private_exports'
P2_FULL_EXPORT_PRIVATE_DIR_ONLY = (
    'Refusing this FULL export destination on macOS: Google Drive for desktop was detected on '
    'this Mac, so a FULL export file is written only directly inside the private export folder '
    '~/.aq_mcp_wizard/private_exports (give the full path of a new .json file in that folder). '
    'Sync of custom Google Drive folders cannot be inspected, so keep that folder out of every '
    'Drive for desktop sync setting. To use the FULL configuration elsewhere, use the separately '
    'authorized manual FULL-copy step instead (Copy FULL in Step 5, type COPY FULL).')
P2_FULL_EXPORT_PRIVATE_DIR_UNSAFE = (
    'Refusing this FULL export on macOS: Google Drive for desktop was detected on this Mac and '
    'the private export folder ~/.aq_mcp_wizard/private_exports could not be confirmed safe (it '
    'must be a real folder, not a link, owned by you with mode 0700, outside Google Drive, any '
    'Git work tree, this program folder and Quick-owned folders). No export file was written. '
    'Sync of custom Google Drive folders cannot be inspected. Use the separately authorized '
    'manual FULL-copy step instead (Copy FULL in Step 5, type COPY FULL).')


def _p2_home():
    """[P2-S1 / B4f] The home folder, via the same expansion the rest of this module uses."""
    return os.path.expanduser('~')


def _p2_present_or_uncertain(path):
    """[P2-S1 / B4f] lstat only: False only when the entry does not exist."""
    try:
        os.lstat(path)
        return True
    except FileNotFoundError:
        return False
    except (OSError, ValueError):
        return True


def _p2_has_google_drive_name(folder):
    """[P2-S1 / B4f] True if `folder` holds an entry whose NAME starts with GoogleDrive
    (folded), or if that cannot be determined. Names only; nothing is opened or read."""
    if not _p2_present_or_uncertain(folder):
        return False
    try:
        names = os.listdir(folder)
    except FileNotFoundError:
        return False
    except (OSError, ValueError):
        return True
    return any(_p2_fold(str(n)).startswith('googledrive') for n in names)


def p2_google_drive_detected():
    """[P2-S1 / B4f] F3: True when Google Drive for desktop is (or may be) installed on this
    Mac by local evidence: /Applications/Google Drive.app exists, ~/Library/Application
    Support/Google/DriveFS exists, ~/Library/CloudStorage or /Volumes holds a GoogleDrive*
    entry, or any of this cannot be determined (fail closed). No file content, plist,
    database or network is used."""
    try:
        home = _p2_home()
        if not isinstance(home, str) or not home or '\x00' in home or not os.path.isabs(home):
            return True
        for app in _P2_DRIVE_APP_PATHS:
            if _p2_present_or_uncertain(app):
                return True
        if _p2_present_or_uncertain(os.path.join(home, *_P2_DRIVEFS_PARTS)):
            return True
        if _p2_has_google_drive_name(os.path.join(home, *_P2_CLOUDSTORAGE_PARTS)):
            return True
        return _p2_has_google_drive_name(_P2_VOLUMES_DIR)
    except (OSError, ValueError, TypeError, RuntimeError):
        return True


def _p2_private_dir_component_ok(path):
    """[P2-S1 / B4f] An existing app-owned folder: a real directory (not a link), owned by
    this user, mode exactly 0700."""
    import stat as _stat
    st = os.lstat(path)
    if _stat.S_ISLNK(st.st_mode) or not _stat.S_ISDIR(st.st_mode):
        return False
    getuid = getattr(os, 'getuid', None)
    if getuid is None or st.st_uid != getuid():
        return False
    return _stat.S_IMODE(st.st_mode) == 0o700


def p2_ensure_private_export_dir(create=True):
    """[P2-S1 / B4f] F3: the ONLY code that may create the private export folder
    ~/.aq_mcp_wizard/private_exports. Returns its absolute path when it is (or has just been
    made) safe, else None. Never raises.
      (a) validates first: the home folder must be an existing absolute directory whose
          location passes the FULL-export destination rules (not Google Drive / synced,
          not inside a Git work tree or this program folder) and the folder must not be
          Quick-owned; every existing app component must be a real 0700 folder owned by
          this user (a symlink component refuses);
      (b) creates a missing component with mkdir(0o700) (mkdir never follows a link);
      (c) re-verifies type, owner and mode, that the resolved folder is exactly
          <resolved home>/.aq_mcp_wizard/private_exports, and the destination rules again.
    Any doubt -> None (the caller refuses)."""
    import stat as _stat
    try:
        home = _p2_home()
        if not isinstance(home, str) or not home or '\x00' in home or not os.path.isabs(home):
            return None
        home = os.path.normpath(home)
        if not _stat.S_ISDIR(os.stat(home).st_mode):
            return None
        target = os.path.join(home, *_P2_PRIVATE_EXPORT_PARTS)
        if p2_export_destination_refused(os.path.join(target, 'probe.json')):
            return None
        if _p2_full_export_destination_unsafe(os.path.join(home, 'probe.json')):
            return None
        cur = home
        for part in _P2_PRIVATE_EXPORT_PARTS:
            cur = os.path.join(cur, part)
            if not _p2_present_or_uncertain(cur):
                if not create:
                    return None
                os.mkdir(cur, 0o700)
                st = os.lstat(cur)
                if _stat.S_ISLNK(st.st_mode) or not _stat.S_ISDIR(st.st_mode):
                    return None
                if _stat.S_IMODE(st.st_mode) != 0o700:
                    os.chmod(cur, 0o700)  # a restrictive umask may have removed owner bits
            if not _p2_private_dir_component_ok(cur):
                return None
        if os.path.realpath(target) != os.path.join(os.path.realpath(home), *_P2_PRIVATE_EXPORT_PARTS):
            return None
        if _p2_full_export_destination_unsafe(os.path.join(target, 'probe.json')):
            return None
        return target
    except (OSError, ValueError, TypeError, RuntimeError):
        return None


def _p2_drive_private_dir_refusal(file_path):
    """[P2-S1 / B4f] F3, macOS FULL export only (called from _p2_darwin_export_guard after the
    token and Quick-owned checks). None when Google Drive for desktop is NOT detected (B4e
    behaviour plus F1/F2) or when the destination is a new .json file directly inside the
    designated private folder; otherwise a FIXED refusal text (never a path). The folder
    is created (by p2_ensure_private_export_dir) only when every other condition holds."""
    if not p2_google_drive_detected():
        return None
    try:
        raw = os.fspath(file_path)
    except TypeError:
        return P2_FULL_EXPORT_PRIVATE_DIR_ONLY
    try:
        if not isinstance(raw, str) or raw == '' or '\x00' in raw or not os.path.isabs(raw):
            return P2_FULL_EXPORT_PRIVATE_DIR_ONLY
        home = _p2_home()
        if not isinstance(home, str) or not home or '\x00' in home or not os.path.isabs(home):
            return P2_FULL_EXPORT_PRIVATE_DIR_UNSAFE
        designated = os.path.join(os.path.normpath(home), *_P2_PRIVATE_EXPORT_PARTS)
        if os.path.dirname(raw) != designated:
            return P2_FULL_EXPORT_PRIVATE_DIR_ONLY
        name = os.path.basename(raw)
        if name in ('', '.', '..') or not name.lower().endswith('.json'):
            return P2_FULL_EXPORT_PRIVATE_DIR_ONLY
        folder = p2_ensure_private_export_dir(create=True)
        if folder is None:
            return P2_FULL_EXPORT_PRIVATE_DIR_UNSAFE
        if os.path.dirname(os.path.realpath(raw)) != os.path.realpath(folder):
            return P2_FULL_EXPORT_PRIVATE_DIR_ONLY
        return None
    except (OSError, ValueError, TypeError, RuntimeError):
        return P2_FULL_EXPORT_PRIVATE_DIR_UNSAFE


# ---------------------------------------------------------------------------
# [P2-S1 / B4g] macOS only (every caller is behind a darwin check). D1/G1-G7: the Wizard
# FULL *file* export opens its save dialog inside the private export folder when Google
# Drive for desktop is detected (folder validated BEFORE it is created, created only by
# p2_ensure_private_export_dir, re-verified after), and the path the dialog RETURNS is
# validated again before anything is written. D2/P1: the macOS --plan-file gets the same
# destination policy. All texts are fixed literals (no path, user, host or error text).
# Nothing here runs at import time.
# ---------------------------------------------------------------------------
P2_FULL_EXPORT_GUI_FOLDER_UNSAFE = (
    'Refusing this FULL export on macOS: Google Drive for desktop was detected on this Mac and '
    'the private export folder ~/.aq_mcp_wizard/private_exports could not be set up safely (it '
    'must be a real folder, not a link, owned by you with mode 0700, outside Google Drive, any '
    'Git work tree, this program folder and Quick-owned folders, and your home folder must not '
    'be reached through a link). The save dialog was not opened and no export file was written. '
    'Sync of custom Google Drive folders cannot be inspected. Use the separately authorized '
    'manual FULL-copy step instead (Copy FULL in Step 5, type COPY FULL).')
P2_FULL_EXPORT_RETURNED_PATH_REFUSED = (
    'Refusing the location chosen in the save dialog on macOS: a FULL export file must be a new '
    '.json file given by its full path, outside Google Drive, any Git work tree, any synced '
    'folder, this program folder and Quick-owned folders, and - when Google Drive for desktop '
    'is detected - directly inside the private export folder ~/.aq_mcp_wizard/private_exports. '
    'Nothing was written. Sync of custom Google Drive folders cannot be inspected. To use the '
    'FULL configuration elsewhere, use Copy FULL in Step 5 (type COPY FULL).')
P2_PLAN_FILE_DEST_REFUSED = (
    'Refusing this --plan-file destination on macOS: the plan file contains your real login and '
    'host, and it is inside a git work tree, this program folder, Google Drive or a cloud-synced '
    'folder, is not given as a full path, or its location could not be confirmed safe. Nothing '
    'was written or printed. Choose a private local folder (full path) outside any repository '
    'or synced folder.')
P2_PLAN_FILE_PRIVATE_DIR_ONLY = (
    'Refusing this --plan-file destination on macOS: Google Drive for desktop was detected on '
    'this Mac, so the plan file (it contains your real login and host) is written only directly '
    'inside the existing private export folder ~/.aq_mcp_wizard/private_exports. That folder is '
    'created only by an authorized FULL export (EXPORT FULL); this command does not create it. '
    'Sync of custom Google Drive folders cannot be inspected. Nothing was written or printed.')


def _p2_private_dir_prevalidate():
    """[P2-S1 / B4g] G3: checks the PROSPECTIVE private folder and its ancestors BEFORE
    anything is created. True only if: the home folder is an absolute, existing real
    directory reached without any link (realpath(home) == home, so no ancestor is a link);
    its location passes the FULL-export destination rules (not Google Drive / synced / Git /
    program folder); the prospective folder is not Quick-owned and not lexically a Drive or
    synced location; and every app component that already exists is a real 0700 folder
    owned by this user (an unsafe existing component refuses). Creates nothing; never
    raises."""
    import stat as _stat
    try:
        home = _p2_home()
        if not isinstance(home, str) or not home or '\x00' in home or not os.path.isabs(home):
            return False
        home = os.path.normpath(home)
        st = os.lstat(home)
        if _stat.S_ISLNK(st.st_mode) or not _stat.S_ISDIR(st.st_mode):
            return False
        if os.path.realpath(home) != home:
            return False
        target = os.path.join(home, *_P2_PRIVATE_EXPORT_PARTS)
        if p2_export_destination_refused(os.path.join(target, 'probe.json')):
            return False
        if _path_is_synced(target) or _p2_is_google_drive_location(target):
            return False
        if _p2_full_export_destination_unsafe(os.path.join(home, 'probe.json')):
            return False
        cur = home
        for part in _P2_PRIVATE_EXPORT_PARTS:
            cur = os.path.join(cur, part)
            try:
                os.lstat(cur)
            except FileNotFoundError:
                break  # this and every later component are missing: nothing more to check
            if not _p2_private_dir_component_ok(cur):
                return False
        return True
    except (OSError, ValueError, TypeError, RuntimeError):
        return False


def p2_full_export_dialog_folder():
    """[P2-S1 / B4g] D1/G3/G4: the folder the macOS Wizard FULL-export save dialog must open
    in. Call ONLY after the EXPORT FULL token was accepted. Returns (folder, refusal):
      (None, None)   Google Drive for desktop NOT detected: B4f behaviour (no folder, no
                     initialdir, nothing created);
      (path, None)   detected and the private folder is (now) safe: validated first
                     (_p2_private_dir_prevalidate), created if missing by the validated
                     creator p2_ensure_private_export_dir, then re-verified;
      (None, text)   detected but the folder cannot be established safely: a FIXED refusal;
                     the caller must NOT open a dialog.
    Never raises."""
    try:
        if not p2_google_drive_detected():
            return None, None
        if not _p2_private_dir_prevalidate():
            return None, P2_FULL_EXPORT_GUI_FOLDER_UNSAFE
        folder = p2_ensure_private_export_dir(create=True)
        if folder is None:
            return None, P2_FULL_EXPORT_GUI_FOLDER_UNSAFE
        if p2_ensure_private_export_dir(create=False) != folder or not _p2_private_dir_prevalidate():
            return None, P2_FULL_EXPORT_GUI_FOLDER_UNSAFE
        return folder, None
    except Exception:  # noqa: BLE001 - fail closed with the fixed text
        return None, P2_FULL_EXPORT_GUI_FOLDER_UNSAFE


def _p2_has_dot_component(raw):
    return any(part in ('.', '..') for part in raw.replace('\\', '/').split('/'))


def p2_full_export_returned_path_refusal(file_path, folder):
    """[P2-S1 / B4g] G5: validates the path the save dialog RETURNED (the user may have
    navigated anywhere). `folder` is what p2_full_export_dialog_folder returned (None when
    Drive was not detected). Returns None when the path may be written, else a FIXED
    refusal text. Refuses: a non-str/empty/NUL value; a path that is not absolute AS GIVEN
    ('~' or relative); any '.' or '..' component; a name that does not end in .json (the
    B4f rule of write_quick_config, applied here BEFORE the writer); Drive detected (now, or
    when the dialog was opened) and the file not DIRECTLY inside the designated folder
    (lexically and resolved) or the folder no longer verifiable; and in every case the full
    FULL-export destination classification (_p2_full_export_destination_unsafe: Google
    Drive F1, kernel order F2, git walk, synced markers, program folder). Creates nothing;
    never raises."""
    try:
        raw = os.fspath(file_path)
        if not isinstance(raw, str) or raw == '' or '\x00' in raw or not os.path.isabs(raw):
            return P2_FULL_EXPORT_RETURNED_PATH_REFUSED
        if _p2_has_dot_component(raw):
            return P2_FULL_EXPORT_RETURNED_PATH_REFUSED
        name = os.path.basename(raw)
        if not name or not name.lower().endswith('.json'):
            return P2_FULL_EXPORT_RETURNED_PATH_REFUSED
        if folder is None and p2_google_drive_detected():
            return P2_FULL_EXPORT_RETURNED_PATH_REFUSED
        if folder is not None:
            if p2_ensure_private_export_dir(create=False) != folder:
                return P2_FULL_EXPORT_RETURNED_PATH_REFUSED
            if os.path.dirname(raw) != folder:
                return P2_FULL_EXPORT_RETURNED_PATH_REFUSED
            if os.path.dirname(os.path.realpath(raw)) != os.path.realpath(folder):
                return P2_FULL_EXPORT_RETURNED_PATH_REFUSED
        if _p2_full_export_destination_unsafe(raw):
            return P2_FULL_EXPORT_RETURNED_PATH_REFUSED
        return None
    except Exception:  # noqa: BLE001 - fail closed with the fixed text
        return P2_FULL_EXPORT_RETURNED_PATH_REFUSED


def p2_plan_file_destination_refusal(file_path):
    """[P2-S1 / B4g] D2/P1, macOS --plan-file only (called from cli._darwin_remote BEFORE the
    plan is built, printed or written). None = may be written (still create-only, 0600, no
    overwrite, no link follow by model.secure_open); else a FIXED refusal text.
      * not absolute AS GIVEN, or a non-str/empty/NUL value -> refused;
      * Google Drive for desktop detected -> the file must be directly inside the EXISTING
        designated private folder (lexically and resolved; the folder is verified with
        p2_ensure_private_export_dir(create=False) - this command never creates it). The
        name is NOT forced to end in .json: the plan file has no suffix rule on any
        platform and the M2 rule is about location (documented decision);
      * always: the FULL-export destination classification (Drive F1, kernel order F2,
        git walk incl. a .git FILE, synced markers, program folder; fails closed).
    One narrow exception keeps B4f behaviour: when NEITHER the lexical parent NOR the
    kernel-order parent exists, nothing can be created there (the create-only open fails),
    so the classification is skipped and the existing fixed write-error path reports it.
    The Quick-owned check stays in cli._darwin_preflight (unchanged). Never raises."""
    try:
        raw = os.fspath(file_path)
        if not isinstance(raw, str) or raw == '' or '\x00' in raw or not os.path.isabs(raw):
            return P2_PLAN_FILE_DEST_REFUSED
        if p2_google_drive_detected():
            home = _p2_home()
            if not isinstance(home, str) or not home or '\x00' in home or not os.path.isabs(home):
                return P2_PLAN_FILE_PRIVATE_DIR_ONLY
            designated = os.path.join(os.path.normpath(home), *_P2_PRIVATE_EXPORT_PARTS)
            name = os.path.basename(raw)
            if os.path.dirname(raw) != designated or name in ('', '.', '..'):
                return P2_PLAN_FILE_PRIVATE_DIR_ONLY
            folder = p2_ensure_private_export_dir(create=False)
            if folder is None or folder != designated:
                return P2_PLAN_FILE_PRIVATE_DIR_ONLY
            if os.path.dirname(os.path.realpath(raw)) != os.path.realpath(folder):
                return P2_PLAN_FILE_PRIVATE_DIR_ONLY
        else:
            parent = os.path.dirname(os.path.abspath(raw))
            kernel_parent = os.path.dirname(os.path.realpath(raw))
            if not os.path.lexists(parent) and not os.path.lexists(kernel_parent):
                return None
        if _p2_full_export_destination_unsafe(raw):
            return P2_PLAN_FILE_DEST_REFUSED
        return None
    except Exception:  # noqa: BLE001 - fail closed with the fixed text
        return P2_PLAN_FILE_DEST_REFUSED


def find_quick_profile_configs(quick_home=None):
    """Read-only discovery of Quick's mcp_config.json files.

    Looks under <quick_home>/profiles/*/mcp_config.json plus the root-level
    <quick_home>/mcp_config.json. quick_home defaults to ~/.quickwork. Returns a
    list of existing file PATHS only - never any file content. Never writes.
    """
    if not quick_home and _p2_is_darwin():
        return []  # P2 Slice 1: never assume ~/.quickwork on macOS; same shape as not-found
    home = quick_home if quick_home else os.path.join(os.path.expanduser('~'), '.quickwork')
    found = []
    root_cfg = os.path.join(home, 'mcp_config.json')
    if os.path.isfile(root_cfg):
        found.append(root_cfg)
    profiles_dir = os.path.join(home, 'profiles')
    if os.path.isdir(profiles_dir):
        try:
            entries = sorted(os.listdir(profiles_dir))
        except OSError:
            entries = []
        for entry in entries:
            cfg = os.path.join(profiles_dir, entry, 'mcp_config.json')
            if os.path.isfile(cfg):
                found.append(cfg)
    return found


_KEY_SUFFIX_RE = _re.compile(r'-[0-9a-f]{8}$')


def _strip_key_suffix(key):
    """Remove a trailing -<8 hex> suffix Quick appends to the stored key."""
    return _KEY_SUFFIX_RE.sub('', str(key))


def _load_quick_config_servers(config_path):
    """Read-only load of mcp_config.json -> the mcpServers dict, or a sentinel.

    Returns (servers_dict, None) on success, or (None, 'UNREADABLE') for a
    missing/corrupt/oversized file, a non-object top level, a missing/!object
    'mcpServers', or a BOM-but-otherwise-valid file (BOM tolerated). NEVER raises
    on bad content and NEVER includes content in anything it returns.

    F-7: the 5 MB size cap is enforced via os.fstat on the OPEN handle rather than
    a separate os.stat/os.path.getsize before the open, closing the stat-then-open
    (TOCTOU) window. Every UNREADABLE outcome (missing, oversized, corrupt,
    non-dict, missing mcpServers, OS error) is preserved exactly, and content is
    never returned.
    """
    try:
        if not os.path.isfile(config_path):
            return None, 'UNREADABLE'
        with open(config_path, 'rb') as fh:
            # Size-cap from the already-open handle (fstat), not a pre-open stat,
            # so the file we measure is the file we read. Oversized -> UNREADABLE
            # without reading the body.
            if os.fstat(fh.fileno()).st_size > _QUICK_CONFIG_MAX_BYTES:
                return None, 'UNREADABLE'
            # Follow-up (Security cond B / F-7): bound the read itself to cap+1
            # bytes so the cap governs the bytes actually pulled into memory, not
            # just the pre-read fstat size. If the file grew between fstat and the
            # read, len(raw) > cap -> UNREADABLE, and we never return its content.
            raw = fh.read(_QUICK_CONFIG_MAX_BYTES + 1)
            if len(raw) > _QUICK_CONFIG_MAX_BYTES:
                return None, 'UNREADABLE'
    except OSError:
        return None, 'UNREADABLE'
    # Tolerate a UTF-8 BOM.
    if raw[:3] == b'\xef\xbb\xbf':
        raw = raw[3:]
    try:
        obj = json.loads(raw.decode('utf-8'))
    except (ValueError, UnicodeDecodeError):
        return None, 'UNREADABLE'
    if not isinstance(obj, dict):
        return None, 'UNREADABLE'
    servers = obj.get('mcpServers')
    if not isinstance(servers, dict):
        return None, 'UNREADABLE'
    return servers, None


def check_name_collision(name, config_path):
    """Read-only: does `name` already name a connector in config_path?

    Compares `name` against each entry's _quick.name, _quick.upstream_id, and the
    stored key with a trailing -<8hex> removed. Returns {collides: bool, count:
    int}. NEVER returns any other entry's name, args, env, or source path. A
    missing/unreadable file yields {collides: False, count: 0}.
    """
    servers, err = _load_quick_config_servers(config_path)
    if err is not None or servers is None:
        return {'collides': False, 'count': 0}
    count = 0
    for key, entry in servers.items():
        matched = False
        if _strip_key_suffix(key) == name:
            matched = True
        if not matched and isinstance(entry, dict):
            q = entry.get('_quick')
            if isinstance(q, dict):
                if q.get('name') == name or q.get('upstream_id') == name:
                    matched = True
        if matched:
            count += 1
    return {'collides': count > 0, 'count': count}


def _read_startup_timeout(entry):
    """Resolve the connector's startupTimeout from an entry, honouring the REAL
    observed storage shape where it lives inside the per-entry _quick object.

    Executed observation (2026-10-20): 11/19 real entries carried startupTimeout
    inside _quick. Older/other builds may put it at the entry top level, so we
    accept a top-level value as a fallback.

    Returns (has_startup_timeout: bool, value_or_None, location) where location is
    '_quick' when read from entry['_quick']['startupTimeout'], 'top-level' when
    read from entry['startupTimeout'], or None when absent/invalid. A valid
    timeout is a real number (int or float, NOT bool) that is strictly positive;
    a non-numeric, bool, negative or zero value is treated as 'no usable timeout'.
    """
    def _valid(v):
        return isinstance(v, (int, float)) and not isinstance(v, bool) and v > 0

    q = entry.get('_quick') if isinstance(entry.get('_quick'), dict) else None
    if q is not None and 'startupTimeout' in q:
        v = q.get('startupTimeout')
        if _valid(v):
            return True, v, '_quick'
        return False, None, None
    if 'startupTimeout' in entry:
        v = entry.get('startupTimeout')
        if _valid(v):
            return True, v, 'top-level'
        return False, None, None
    return False, None, None


def _read_auto_disabled(entry):
    """Return the boolean _quick.autoDisabled when present as a real bool, else
    None. Only this one field is read out of _quick (never any other _quick
    value). autoDisabled True means Quick itself disabled the connector."""
    q = entry.get('_quick') if isinstance(entry.get('_quick'), dict) else None
    if q is not None and isinstance(q.get('autoDisabled'), bool):
        return q.get('autoDisabled')
    return None


def verify_quick_import(name, expected_command, expected_args, config_path):
    """Read-only verification that Quick imported the connector as expected.

    Locates the entry by _quick.name == name OR _quick.upstream_id == name OR
    (stored key == name OR key matches name-<8hex>). Compares command and args
    EXACTLY against expected_command / expected_args.

    Returns a dict {status, ...flags} where status is one of:
      NOT_FOUND            - no matching entry
      FOUND_MATCH          - exactly one match, command and args both equal
      FOUND_MISMATCH_COMMAND - one match, command differs
      FOUND_MISMATCH_ARGS  - one match, command equal but args differ
      MULTIPLE_MATCHES     - more than one entry matches (count only)
      UNREADABLE           - missing/corrupt/oversized file or unexpected shape

    For a single match it also reports BOOLEAN flags {disabled, has_env,
    has_startup_timeout}. startupTimeout is read from the entry's _quick object
    first (the REAL observed location) and from a top-level startupTimeout only as
    a fallback; when present (and a positive number) the NUMBER 'startup_timeout'
    and a 'startup_timeout_location' of '_quick' or 'top-level' are included (a
    number/location is not a secret). When _quick.autoDisabled is present as a
    bool it is reported as 'auto_disabled'. NOTHING else is ever read out of
    _quick, and the function NEVER returns the stored args, env, source path, or
    any other entry's name.
    """
    servers, err = _load_quick_config_servers(config_path)
    if err is not None or servers is None:
        return {'status': 'UNREADABLE'}

    matches = []
    for key, entry in servers.items():
        if not isinstance(entry, dict):
            # A non-object entry can still match by key; keep it so we count it,
            # but comparisons below guard on isinstance.
            if _strip_key_suffix(key) == name or key == name:
                matches.append((key, entry))
            continue
        q = entry.get('_quick') if isinstance(entry.get('_quick'), dict) else {}
        if (q.get('name') == name or q.get('upstream_id') == name
                or key == name or _strip_key_suffix(key) == name):
            matches.append((key, entry))

    if not matches:
        return {'status': 'NOT_FOUND'}
    if len(matches) > 1:
        return {'status': 'MULTIPLE_MATCHES', 'count': len(matches)}

    _key, entry = matches[0]
    if not isinstance(entry, dict):
        return {'status': 'UNREADABLE'}

    stored_command = entry.get('command')
    stored_args = entry.get('args')

    disabled = bool(entry.get('disabled', False))
    has_env = isinstance(entry.get('env'), dict) and len(entry.get('env')) > 0
    has_startup_timeout, st_value, st_location = _read_startup_timeout(entry)
    auto_disabled = _read_auto_disabled(entry)

    flags = {'disabled': disabled, 'has_env': has_env,
             'has_startup_timeout': has_startup_timeout}
    if has_startup_timeout:
        flags['startup_timeout'] = st_value  # a number, not a secret
        flags['startup_timeout_location'] = st_location  # '_quick' or 'top-level'
    if auto_disabled is not None:
        flags['auto_disabled'] = auto_disabled

    # Exact comparison. command first, then args. Never echo the stored values.
    if stored_command != expected_command:
        result = {'status': 'FOUND_MISMATCH_COMMAND'}
        result.update(flags)
        return result
    if (not isinstance(stored_args, list)) or stored_args != list(expected_args):
        result = {'status': 'FOUND_MISMATCH_ARGS'}
        result.update(flags)
        return result
    result = {'status': 'FOUND_MATCH'}
    result.update(flags)
    return result


def import_instructions(settings, kind, *, import_path):
    """Plain-language numbered steps for a non-expert to import `import_path`
    into Quick, verify the connector, and set the timeout by hand.

    Grounded ONLY in what was observed. It does NOT assert that a confirmation
    prompt appears, nor a default timeout; it says 'if a confirmation prompt
    appears, read the command and confirm it matches'. The manual-registration
    fallback (quick_instructions) remains available and is referenced.

    `kind` selects the by-hand timeout the user should set after import, because
    an import file carries no timeout: lambda -> 30 s, git -> 120 s, local -> 120 s.
    """
    try:
        timeout = TIMEOUT_SECONDS.get(kind, 120)
    except Exception:
        timeout = 120
    name = ''
    if isinstance(settings, dict):
        name = settings.get('name') or settings.get('id') or ''
    lines = [
        'AMAZON QUICK \u2014 IMPORT AN MCP CONNECTOR FROM A FILE',
        '==================================================',
        'This uses Quick\'s documented Import mode. The wizard has written an import',
        'file for you; Quick reads it and creates the connector. Quick\'s own files are',
        'never written by the wizard.',
        '',
        '1. Open Amazon Quick Desktop.',
        '2. Go to Customize > Connectors.',
        '3. Click Create > Create local connector.',
        '4. Choose the Import type.',
        '5. In the Config file path field, paste or pick this path:',
        '       {}'.format(import_path),
        '6. Let Quick scan the file. BEFORE you confirm or save, take a screenshot of',
        '   what Quick shows (the command and arguments it parsed).',
        '7. If a confirmation prompt appears, read the command it shows and confirm it',
        '   matches the command you expect. (We do not know whether this build shows',
        '   such a prompt; if it does, this is your chance to check it.)',
        '8. Click Save.',
        '9. Open a NEW Quick chat and ask the connector for one harmless, read-only',
        '   action (for example: list your available tools). Confirm it responds from',
        '   the intended backend.',
        '',
        'SET THE TIMEOUT BY HAND (an import file carries no timeout):',
        '10. Open the connector you just created and edit it. Set the Timeout to',
        '    {} seconds for this connector ({} connectors: Lambda 30, Git 120,'.format(timeout, 'these'),
        '    local 120). Save.',
        '',
        'AFTER IMPORT:',
        '11. Delete the import file as soon as Quick has created the connector. It',
        '    contains your login and the gateway address. On Windows it is NOT',
        '    permission-protected - it inherits the containing folder\'s access rules,',
        '    so create it only in a PRIVATE folder, OUTSIDE any synced, shared,',
        '    cloud-backed-up or git folder, and never commit or publish it.',
        '    (The synced-folder check is a NAME-BASED heuristic: it cannot see'
        ' OneDrive Known Folder Move redirection, network shares, mapped drives'
        ' or cloud-synced folders with unusual names, so you must choose a'
        ' private local folder yourself.)',
        '',
        'If Import does not work on your build, the manual-registration steps',
        '(quick_instructions) remain available as a fallback: enter the Command,',
        'Arguments and Timeout by hand in the Local connector form.',
    ]
    if name:
        lines.insert(7, '   (The connector will be named "{}".)'.format(name))
    return '\n'.join(lines) + '\n'
