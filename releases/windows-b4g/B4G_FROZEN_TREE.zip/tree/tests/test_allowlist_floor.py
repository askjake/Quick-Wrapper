"""D-2 allow-list floor — launcher + proxy boundary tests (Rev 2).

Pure-logic tests (resolve_allowlist_policy / check_allowlist_policy / _marker_floor_on /
_validate_exception / validate_exception_fields) need no subprocess and no third-party packages:
they import aq_registry (stdlib-only) directly and load the proxy's pure functions from source
without importing botocore/mcp. Three integration tests exercise the real launcher and the real
proxy as subprocesses; they skip with a clear reason when subprocess or the gateway's third-party
deps (botocore/mcp) are unavailable on the test runner.

Rev 2 adds regression tests for every change in this round:
  P1  comma / non-string / duplicate / empty / over-length allow names (floor on = refuse;
      legacy = historical join behaviour unchanged);
  P2  trailing newline in approval_id / approved_utc, Arabic-Indic (Unicode) digits,
      calendar-invalid date, future date, reason with CR/LF and other control chars,
      reason too short / too long;
  P3  env-only 'unrestricted' on a marked gateway at the proxy (refuse), env 'unrestricted' with a
      VALID full exception set + matching digest (serve; the log line carries the approval id),
      digest mismatch (refuse), and blanks-only allow + a valid exception -> unrestricted
      (the corner the Reviewer asked to lock);
  exception on a legacy host ignored (unchanged).

resolve_allowlist_policy now returns a (mode, fields) tuple; the launcher tests read [0] for the
mode. The subprocess test classes pop ambient AQ_ALLOWLIST_MODE / AQ_TOOL_ALLOWLIST /
AQ_UNRESTRICTED_* from the child environment so they are hermetic regardless of the runner (F-9).

Runnable on Windows and Linux; CRLF-agnostic (never asserts on line-ending bytes); uses temp dirs.
Only placeholders appear here: <user>, fakeuser, 192.0.2.77, and the example Lambda URL host.
"""
import json
import os
import re
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PAYLOAD = ROOT / "bootstrap_payload"

# Import the launcher directly — its imports are stdlib-only, so this always works.
sys.path.insert(0, str(PAYLOAD))
import aq_registry  # noqa: E402


def _load_proxy_pure():
    """Load the proxy's pure D-2 functions from source WITHOUT importing botocore/mcp.

    We exec only the text between the proxy's D-2 begin/end markers in a namespace seeded with
    the few names that block references (os, json, re, hashlib, datetime, stat, a no-op log, sys,
    __file__). This keeps the pure-function tests independent of the gateway's third-party deps.
    """
    import datetime as _dt
    import hashlib as _hl
    src = (PAYLOAD / "aq_mcp_stdio.py").read_text(encoding="utf-8")
    begin = "AQ_ALLOWLIST_MODE = os.environ.get"
    end = "# --- D-2 allow-list floor: proxy-side defence in depth (end)"
    block = src[src.index(begin):src.index(end)]
    import stat as _stat_mod

    class _NoLog:
        def warning(self, *a, **k):
            pass

        def info(self, *a, **k):
            pass

    ns = {
        "os": os,
        "json": json,
        "re": re,
        "hashlib": _hl,
        "datetime": _dt,
        "_stat": _stat_mod,
        "sys": sys,
        "log": _NoLog(),
        "ALLOW": [],
        "__file__": str(PAYLOAD / "aq_mcp_stdio.py"),
    }
    exec(block, ns)  # noqa: S102 - trusted in-repo source, test harness only
    return ns


PROXY = _load_proxy_pure()

GOOD_EXC = {
    "reason": "temporary broad access during migration",
    "approval_id": "OPS-2026-10-20-abc",
    "approved_utc": "2026-10-20T14:30:00Z",
}
REMOTE_URL = "https://abc123.lambda-url.us-west-2.on.aws"


def _write_marker(dirpath, obj, name="gateway_policy.json", raw=None):
    p = Path(dirpath) / name
    if raw is not None:
        p.write_text(raw, encoding="utf-8")
    else:
        p.write_text(json.dumps(obj), encoding="utf-8")
    return str(p)


def _pop_ambient(env):
    """Make a child env hermetic (Security F-9): drop any ambient floor variables so a runner
    that already exports them cannot perturb a subprocess test."""
    for k in ("AQ_ALLOWLIST_MODE", "AQ_TOOL_ALLOWLIST", "AQ_UNRESTRICTED_REASON",
              "AQ_UNRESTRICTED_APPROVAL_ID", "AQ_UNRESTRICTED_APPROVED_UTC",
              "AQ_UNRESTRICTED_DIGEST", "AQ_TARGET_NAME"):
        env.pop(k, None)
    return env


# --------------------------------------------------------------------------------------------
# Launcher pure policy: resolve_allowlist_policy(entry, marker_present) -> (mode, fields)
# --------------------------------------------------------------------------------------------
class LauncherPolicyTests(unittest.TestCase):
    rap = staticmethod(aq_registry.resolve_allowlist_policy)
    Err = aq_registry.AllowlistFloorError

    def mode(self, entry, marker, **kw):
        return self.rap(entry, marker, **kw)[0]

    def test_missing_allow_marker_on_refuses(self):
        with self.assertRaises(self.Err):
            self.rap({"url": REMOTE_URL}, True)

    def test_empty_allow_marker_on_refuses(self):
        with self.assertRaises(self.Err):
            self.rap({"url": REMOTE_URL, "allow": []}, True)

    def test_null_allow_marker_on_refuses(self):
        with self.assertRaises(self.Err):
            self.rap({"url": REMOTE_URL, "allow": None}, True)

    def test_blanks_only_allow_marker_on_refuses(self):
        with self.assertRaises(self.Err):
            self.rap({"url": REMOTE_URL, "allow": ["   ", "", "\t"]}, True)

    def test_whitespace_only_names_are_not_counted(self):
        self.assertEqual(aq_registry._entry_allow({"allow": ["  ", "ok", ""]}), ["ok"])

    def test_nonempty_allow_marker_on_enforced(self):
        self.assertEqual(self.mode({"url": REMOTE_URL, "allow": ["read_one"]}, True),
                         aq_registry.MODE_ENFORCED)

    def test_valid_unrestricted_exception(self):
        self.assertEqual(self.mode({"url": REMOTE_URL, "allow": [],
                                    "unrestricted": dict(GOOD_EXC)}, True),
                         aq_registry.MODE_UNRESTRICTED)

    def test_unrestricted_missing_reason_refuses(self):
        exc = {k: v for k, v in GOOD_EXC.items() if k != "reason"}
        with self.assertRaises(self.Err):
            self.rap({"url": REMOTE_URL, "unrestricted": exc}, True)

    def test_unrestricted_short_reason_refuses(self):
        exc = {**GOOD_EXC, "reason": "too short"}
        with self.assertRaises(self.Err):
            self.rap({"url": REMOTE_URL, "unrestricted": exc}, True)

    def test_unrestricted_bad_approval_charset_refuses(self):
        exc = {**GOOD_EXC, "approval_id": "bad id with spaces!"}
        with self.assertRaises(self.Err):
            self.rap({"url": REMOTE_URL, "unrestricted": exc}, True)

    def test_unrestricted_bad_approved_utc_refuses(self):
        for bad in ("2026-10-20 14:30:00", "2026-10-20T14:30:00", "2026/10/20T14:30:00Z", "nope"):
            exc = {**GOOD_EXC, "approved_utc": bad}
            with self.assertRaises(self.Err):
                self.rap({"url": REMOTE_URL, "unrestricted": exc}, True)

    def test_unrestricted_plus_nonempty_allow_refuses(self):
        with self.assertRaises(self.Err):
            self.rap({"url": REMOTE_URL, "allow": ["x"], "unrestricted": dict(GOOD_EXC)}, True)

    def test_unknown_extra_key_in_exception_refuses(self):
        exc = {**GOOD_EXC, "note": "surprise"}
        with self.assertRaises(self.Err):
            self.rap({"url": REMOTE_URL, "unrestricted": exc}, True)

    def test_exception_not_object_refuses(self):
        with self.assertRaises(self.Err):
            self.rap({"url": REMOTE_URL, "unrestricted": "yes"}, True)

    def test_exception_on_legacy_host_no_marker_is_ignored(self):
        # DECISION: with no marker there is no floor to grant an exception against, so the
        # exception object is simply ignored and the launcher returns (None, None) (legacy,
        # unchanged). This preserves existing hosts byte-for-byte; honouring the exception
        # would be a migration, which the Amendment explicitly defers.
        self.assertEqual(
            self.rap({"url": REMOTE_URL, "allow": [], "unrestricted": dict(GOOD_EXC)}, False),
            (None, None))

    def test_marker_false_opt_out_returns_none(self):
        self.assertEqual(self.rap({"url": REMOTE_URL, "allow": []}, False), (None, None))

    def test_legacy_no_marker_returns_none_for_every_shape(self):
        for entry in (
            {"url": REMOTE_URL},
            {"url": REMOTE_URL, "allow": []},
            {"url": REMOTE_URL, "allow": ["x"]},
            {"url": REMOTE_URL, "allow": ["read,write"]},   # a comma name is legacy-untouched
            {"kind": "local", "server": "aq_build_artifacts_mcp.py"},
        ):
            self.assertEqual(self.rap(entry, False), (None, None))

    # ---- P2 regression: exception-field hardening (Tester D-1..D-5, Security F-4) ----
    def test_p2_trailing_newline_approval_id_refused(self):
        with self.assertRaises(self.Err):
            aq_registry._validate_exception({**GOOD_EXC, "approval_id": "OPS-ABC-123\n"})

    def test_p2_trailing_newline_approved_utc_refused(self):
        with self.assertRaises(self.Err):
            aq_registry._validate_exception({**GOOD_EXC, "approved_utc": "2026-10-20T14:30:00Z\n"})

    def test_p2_unicode_digits_in_approved_utc_refused(self):
        # Arabic-Indic digits for 2026 — must NOT pass the ASCII-only regex.
        bad = "\u0662\u0660\u0662\u0666-10-20T14:30:00Z"
        with self.assertRaises(self.Err):
            aq_registry._validate_exception({**GOOD_EXC, "approved_utc": bad})

    def test_p2_calendar_invalid_date_refused(self):
        with self.assertRaises(self.Err):
            aq_registry._validate_exception({**GOOD_EXC, "approved_utc": "2026-13-45T99:99:99Z"})

    def test_p2_future_date_refused(self):
        with self.assertRaises(self.Err):
            aq_registry._validate_exception({**GOOD_EXC, "approved_utc": "2999-01-01T00:00:00Z"})

    def test_p2_near_future_within_skew_ok(self):
        import datetime as _dt
        now = _dt.datetime(2026, 10, 20, 12, 0, 0)
        exc = {**GOOD_EXC, "approved_utc": "2026-10-21T10:00:00Z"}  # ~22h ahead
        self.assertEqual(aq_registry._validate_exception(exc, now=now)["approved_utc"],
                         "2026-10-21T10:00:00Z")

    def test_p2_reason_with_crlf_refused(self):
        with self.assertRaises(self.Err):
            aq_registry._validate_exception({**GOOD_EXC, "reason": "valid reason text\r\nINJECT"})

    def test_p2_reason_with_control_char_refused(self):
        with self.assertRaises(self.Err):
            aq_registry._validate_exception({**GOOD_EXC, "reason": "valid reason text\x01more"})

    def test_p2_reason_too_long_refused(self):
        with self.assertRaises(self.Err):
            aq_registry._validate_exception({**GOOD_EXC, "reason": "x" * 501})

    def test_p2_approval_id_too_long_refused(self):
        with self.assertRaises(self.Err):
            aq_registry._validate_exception({**GOOD_EXC, "approval_id": "A" * 129})

    def test_p2_approval_id_too_short_refused(self):
        with self.assertRaises(self.Err):
            aq_registry._validate_exception({**GOOD_EXC, "approval_id": "short1"})

    def test_p2_validate_returns_normalised_fields(self):
        f = aq_registry._validate_exception({**GOOD_EXC, "reason": "  " + GOOD_EXC["reason"] + "  "})
        self.assertEqual(f["reason"], GOOD_EXC["reason"])

    # ---- P1 regression: strict allow-list names under the floor ----
    def test_p1_comma_name_under_floor_refuses(self):
        with self.assertRaises(self.Err):
            self.rap({"url": REMOTE_URL, "allow": ["read,write"]}, True)

    def test_p1_non_string_name_under_floor_refuses(self):
        with self.assertRaises(self.Err):
            self.rap({"url": REMOTE_URL, "allow": [123]}, True)

    def test_p1_duplicate_name_under_floor_refuses(self):
        with self.assertRaises(self.Err):
            self.rap({"url": REMOTE_URL, "allow": ["a", "a"]}, True)

    def test_p1_over_length_name_under_floor_refuses(self):
        with self.assertRaises(self.Err):
            self.rap({"url": REMOTE_URL, "allow": ["x" * 129]}, True)

    def test_p1_internal_whitespace_name_under_floor_refuses(self):
        with self.assertRaises(self.Err):
            self.rap({"url": REMOTE_URL, "allow": ["read tool"]}, True)

    def test_p1_good_names_normalised(self):
        self.assertEqual(aq_registry._entry_allow_strict({"allow": [" a ", "b"]}), ["a", "b"])

    def test_p1_floor_on_serialises_normalised(self):
        self.assertEqual(aq_registry._allowlist_for_env({"allow": [" a ", "b"]}, True), "a,b")

    def test_p1_legacy_serialises_historical_join_unchanged(self):
        # On a legacy host the comma name is NOT refused and NOT normalised — byte-identical join.
        self.assertEqual(
            aq_registry._allowlist_for_env({"allow": ["read,write", "x"]}, False),
            "read,write,x")

    def test_p1_legacy_none_allow_serialises_empty(self):
        self.assertEqual(aq_registry._allowlist_for_env({"allow": None}, False), "")

    # ---- Reviewer locked corner: blanks-only allow + a valid exception -> UNRESTRICTED ----
    def test_blanks_only_allow_plus_exception_is_unrestricted(self):
        self.assertEqual(
            self.mode({"url": REMOTE_URL, "allow": ["  ", ""], "unrestricted": dict(GOOD_EXC)}, True),
            aq_registry.MODE_UNRESTRICTED)

    # ---- CHANGE 1 (T-1) battery: exception x allow-list shape -> mode / refuse ----
    # DECISION (Reviewer KEEP, user requirement 3): an allow-list that contains ONLY blank
    # members is EMPTY, so exception + blanks-only -> UNRESTRICTED; an allow-list with at least
    # one real member alongside an exception stays AMBIGUOUS and is refused; a non-list allow
    # value beside an exception is a type error and is refused. The non-exception path is
    # unchanged (still _entry_allow_strict, still fails closed on a blank member).
    def test_t1_single_blank_plus_exception_is_unrestricted(self):
        self.assertEqual(
            self.mode({"url": REMOTE_URL, "allow": [""], "unrestricted": dict(GOOD_EXC)}, True),
            aq_registry.MODE_UNRESTRICTED)

    def test_t1_empty_list_plus_exception_is_unrestricted(self):
        self.assertEqual(
            self.mode({"url": REMOTE_URL, "allow": [], "unrestricted": dict(GOOD_EXC)}, True),
            aq_registry.MODE_UNRESTRICTED)

    def test_t1_null_allow_plus_exception_is_unrestricted(self):
        self.assertEqual(
            self.mode({"url": REMOTE_URL, "allow": None, "unrestricted": dict(GOOD_EXC)}, True),
            aq_registry.MODE_UNRESTRICTED)

    def test_t1_no_allow_key_plus_exception_is_unrestricted(self):
        self.assertEqual(
            self.mode({"url": REMOTE_URL, "unrestricted": dict(GOOD_EXC)}, True),
            aq_registry.MODE_UNRESTRICTED)

    def test_t1_real_member_and_blank_plus_exception_refuses(self):
        # ['a', ''] has a real member -> ambiguous -> refuse.
        with self.assertRaises(self.Err):
            self.rap({"url": REMOTE_URL, "allow": ["a", ""], "unrestricted": dict(GOOD_EXC)}, True)

    def test_t1_blank_then_real_plus_exception_refuses(self):
        with self.assertRaises(self.Err):
            self.rap({"url": REMOTE_URL, "allow": ["  ", "x"], "unrestricted": dict(GOOD_EXC)}, True)

    def test_t1_string_allow_plus_exception_refuses_type_error(self):
        # 'abc' is a string, not a JSON array -> type error -> refuse.
        with self.assertRaises(self.Err):
            self.rap({"url": REMOTE_URL, "allow": "abc", "unrestricted": dict(GOOD_EXC)}, True)

    def test_t1_int_allow_plus_exception_refuses_type_error(self):
        with self.assertRaises(self.Err):
            self.rap({"url": REMOTE_URL, "allow": 5, "unrestricted": dict(GOOD_EXC)}, True)

    def test_t1_blanks_only_without_exception_under_floor_refuses(self):
        # Unchanged non-exception path: blanks-only with NO exception under the floor -> refuse
        # (via _entry_allow_strict, which raises on a blank member).
        with self.assertRaises(self.Err):
            self.rap({"url": REMOTE_URL, "allow": ["  ", ""]}, True)

    def test_t1_legacy_no_marker_all_shapes_none_none(self):
        # On a legacy host (no marker) every one of these shapes is (None, None), unchanged.
        for allow in ([""], [], None, ["a", ""], ["  ", "x"], "abc", 5):
            self.assertEqual(
                self.rap({"url": REMOTE_URL, "allow": allow, "unrestricted": dict(GOOD_EXC)}, False),
                (None, None))

    def test_t1_has_real_allow_member_helper(self):
        h = aq_registry._has_real_allow_member
        self.assertFalse(h({"allow": []}))
        self.assertFalse(h({"allow": None}))
        self.assertFalse(h({"allow": [""]}))
        self.assertFalse(h({"allow": ["  ", ""]}))
        self.assertFalse(h({"allow": "abc"}))     # non-list is not a real member
        self.assertFalse(h({"allow": 5}))
        self.assertFalse(h({"allow": [123]}))     # non-str member is not a real member
        self.assertFalse(h({}))                   # no allow key
        self.assertTrue(h({"allow": ["a", ""]}))
        self.assertTrue(h({"allow": ["  ", "x"]}))
        self.assertTrue(h({"allow": ["read_one"]}))
        self.assertTrue(h({"allow": [123, "x"]}))

    def test_t1_unrestricted_blanks_only_serialises_empty_allowlist(self):
        # The UNRESTRICTED launch path must hand the proxy an EMPTY AQ_TOOL_ALLOWLIST whatever
        # blank members were in the registry entry (the proxy refuses unrestricted + non-empty).
        for allow in ([""], ["  ", ""], [], None):
            self.assertEqual(
                aq_registry._allowlist_for_env({"allow": allow}, True,
                                               aq_registry.MODE_UNRESTRICTED),
                "")

    def test_t1_enforced_mode_still_serialises_strict(self):
        self.assertEqual(
            aq_registry._allowlist_for_env({"allow": [" a ", "b"]}, True,
                                           aq_registry.MODE_ENFORCED),
            "a,b")

    # ---- R3-M1 (Rev 4): a non-string / non-empty allow member beside a valid exception is
    # REFUSED (parity with the enforced path; "never silently widen"). The Rev 3 corner
    # (blanks-only / [] / None / missing + exception -> UNRESTRICTED) is UNCHANGED and is still
    # covered by the test_t1_*_is_unrestricted cases above; these add the REFUSE side. ----
    def test_r3m1_exc_plus_int_member_refuses(self):
        with self.assertRaises(self.Err):
            self.rap({"url": REMOTE_URL, "allow": [123], "unrestricted": dict(GOOD_EXC)}, True)

    def test_r3m1_exc_plus_int_and_none_member_refuses(self):
        # The headline R3-M1 case: [1, None] resolved UNRESTRICTED in Rev 3; now REFUSED.
        with self.assertRaises(self.Err):
            self.rap({"url": REMOTE_URL, "allow": [1, None], "unrestricted": dict(GOOD_EXC)}, True)

    def test_r3m1_exc_plus_none_member_refuses(self):
        with self.assertRaises(self.Err):
            self.rap({"url": REMOTE_URL, "allow": [None], "unrestricted": dict(GOOD_EXC)}, True)

    def test_r3m1_exc_plus_nested_list_member_refuses(self):
        with self.assertRaises(self.Err):
            self.rap({"url": REMOTE_URL, "allow": [["x"]], "unrestricted": dict(GOOD_EXC)}, True)

    def test_r3m1_exc_plus_dict_member_refuses(self):
        with self.assertRaises(self.Err):
            self.rap({"url": REMOTE_URL, "allow": [{"a": 1}], "unrestricted": dict(GOOD_EXC)}, True)

    def test_r3m1_exc_plus_bool_member_refuses(self):
        # bool is NOT a str (isinstance(True, str) is False) -> refused as a non-string member.
        with self.assertRaises(self.Err):
            self.rap({"url": REMOTE_URL, "allow": [True], "unrestricted": dict(GOOD_EXC)}, True)

    def test_r3m1_exc_plus_real_name_refuses_ambiguous(self):
        # NOTE-1 (Tester, Rev 4): assert the SPECIFIC refusal path, not just that SOMETHING
        # raised. A real (non-blank) str member beside a valid exception is the "ambiguous policy"
        # branch of resolve_allowlist_policy (item.strip() is truthy).
        with self.assertRaisesRegex(self.Err, "ambiguous policy"):
            self.rap({"url": REMOTE_URL, "allow": ["get_a"], "unrestricted": dict(GOOD_EXC)}, True)

    def test_r3m1_exc_plus_blank_and_real_name_refuses_ambiguous(self):
        # NOTE-1: ["", "get_a"] -> the blank is skipped, the real member trips the SAME
        # "ambiguous policy" branch. Pin the message so a different refusal cannot pass silently.
        with self.assertRaisesRegex(self.Err, "ambiguous policy"):
            self.rap({"url": REMOTE_URL, "allow": ["", "get_a"], "unrestricted": dict(GOOD_EXC)}, True)

    def test_r3m1_exc_plus_string_allow_refuses_type_error(self):
        # NOTE-1: a str allow value is NOT a list -> the "must be a JSON array" type-error branch.
        with self.assertRaisesRegex(self.Err, "must be a JSON array"):
            self.rap({"url": REMOTE_URL, "allow": "get_a", "unrestricted": dict(GOOD_EXC)}, True)

    def test_r3m1_exc_plus_int_allow_refuses_type_error(self):
        # NOTE-1: an int allow value is NOT a list -> the "must be a JSON array" type-error branch.
        with self.assertRaisesRegex(self.Err, "must be a JSON array"):
            self.rap({"url": REMOTE_URL, "allow": 5, "unrestricted": dict(GOOD_EXC)}, True)

    def test_r3m1_exc_plus_dict_allow_refuses_type_error(self):
        # NOTE-1: a dict allow value is NOT a list -> the "must be a JSON array" type-error branch.
        with self.assertRaisesRegex(self.Err, "must be a JSON array"):
            self.rap({"url": REMOTE_URL, "allow": {}, "unrestricted": dict(GOOD_EXC)}, True)

    def test_r3m1_exc_plus_tuple_allow_refuses_type_error(self):
        # A tuple is not a JSON array type here (JSON has no tuples); refused as a type error,
        # matching _entry_allow_strict's isinstance(..., list) guard on the enforced path.
        # NOTE-1: pin the "must be a JSON array" branch (a tuple is not a list).
        with self.assertRaisesRegex(self.Err, "must be a JSON array"):
            self.rap({"url": REMOTE_URL, "allow": ("a",), "unrestricted": dict(GOOD_EXC)}, True)

    def test_r3m1_blanks_only_and_empty_and_null_still_unrestricted(self):
        # Explicit re-assertion that the Rev 3 T-1 corner is preserved by the Rev 4 rule.
        for allow in ([], None, [""], ["  ", ""], ["\t"]):
            self.assertEqual(
                self.mode({"url": REMOTE_URL, "allow": allow, "unrestricted": dict(GOOD_EXC)}, True),
                aq_registry.MODE_UNRESTRICTED)
        # allow key absent entirely + exception -> UNRESTRICTED
        self.assertEqual(
            self.mode({"url": REMOTE_URL, "unrestricted": dict(GOOD_EXC)}, True),
            aq_registry.MODE_UNRESTRICTED)

    # ---- L-1 (Security, Rev 4): Unicode / zero-width / NUL members beside a valid exception.
    # The RATIFIED rule is: "blank" == Python str.strip()/str.isspace() ONLY. A member that
    # str.strip()s to '' is treated as empty (so an all-whitespace list beside a valid exception
    # resolves UNRESTRICTED, Rev 3 T-1 corner); a member whose strip() is non-empty is a REAL
    # member and, beside an exception, is REFUSED with "ambiguous policy". The danger set is the
    # zero-width / NUL family: ZWSP (U+200B), NUL (U+0000), BOM/ZWNBSP (U+FEFF), word-joiner
    # (U+2060), ZWNJ (U+200C) are NOT Python whitespace, so they are REAL members and MUST be
    # refused -- they must never slip a target to UNRESTRICTED. NBSP (U+00A0), ideographic space
    # (U+3000), narrow NBSP (U+202F), em-space (U+2003), line-separator (U+2028), TAB, NEWLINE and
    # SPACE DO strip to '' on CPython and therefore COUNT AS BLANK. All odd characters below are
    # written ONLY as Python \u / \x / \t / \n escapes (never as literal glyphs in the source).
    # U+180E is deliberately NOT tested (its whitespace status changed across Unicode versions,
    # so it is not a stable pin).

    # NOT blank -> a real member beside an exception -> REFUSED ("ambiguous policy"). One per char.
    def test_l1_zwsp_u200b_alone_refuses_ambiguous(self):
        with self.assertRaisesRegex(self.Err, "ambiguous policy"):
            self.rap({"url": REMOTE_URL, "allow": ["\u200b"], "unrestricted": dict(GOOD_EXC)}, True)

    def test_l1_nul_u0000_alone_refuses_ambiguous(self):
        with self.assertRaisesRegex(self.Err, "ambiguous policy"):
            self.rap({"url": REMOTE_URL, "allow": ["\u0000"], "unrestricted": dict(GOOD_EXC)}, True)

    def test_l1_bom_ufeff_alone_refuses_ambiguous(self):
        with self.assertRaisesRegex(self.Err, "ambiguous policy"):
            self.rap({"url": REMOTE_URL, "allow": ["\ufeff"], "unrestricted": dict(GOOD_EXC)}, True)

    def test_l1_word_joiner_u2060_alone_refuses_ambiguous(self):
        with self.assertRaisesRegex(self.Err, "ambiguous policy"):
            self.rap({"url": REMOTE_URL, "allow": ["\u2060"], "unrestricted": dict(GOOD_EXC)}, True)

    def test_l1_zwnj_u200c_alone_refuses_ambiguous(self):
        with self.assertRaisesRegex(self.Err, "ambiguous policy"):
            self.rap({"url": REMOTE_URL, "allow": ["\u200c"], "unrestricted": dict(GOOD_EXC)}, True)

    # BLANK (str.strip() == '') -> blanks-only list beside an exception -> UNRESTRICTED. One per char.
    def test_l1_nbsp_u00a0_alone_is_unrestricted(self):
        self.assertEqual(
            self.mode({"url": REMOTE_URL, "allow": ["\u00a0"], "unrestricted": dict(GOOD_EXC)}, True),
            aq_registry.MODE_UNRESTRICTED)

    def test_l1_ideographic_space_u3000_alone_is_unrestricted(self):
        self.assertEqual(
            self.mode({"url": REMOTE_URL, "allow": ["\u3000"], "unrestricted": dict(GOOD_EXC)}, True),
            aq_registry.MODE_UNRESTRICTED)

    def test_l1_tab_alone_is_unrestricted(self):
        self.assertEqual(
            self.mode({"url": REMOTE_URL, "allow": ["\t"], "unrestricted": dict(GOOD_EXC)}, True),
            aq_registry.MODE_UNRESTRICTED)

    def test_l1_newline_alone_is_unrestricted(self):
        self.assertEqual(
            self.mode({"url": REMOTE_URL, "allow": ["\n"], "unrestricted": dict(GOOD_EXC)}, True),
            aq_registry.MODE_UNRESTRICTED)

    def test_l1_space_alone_is_unrestricted(self):
        self.assertEqual(
            self.mode({"url": REMOTE_URL, "allow": [" "], "unrestricted": dict(GOOD_EXC)}, True),
            aq_registry.MODE_UNRESTRICTED)

    def test_l1_narrow_nbsp_u202f_alone_is_unrestricted(self):
        self.assertEqual(
            self.mode({"url": REMOTE_URL, "allow": ["\u202f"], "unrestricted": dict(GOOD_EXC)}, True),
            aq_registry.MODE_UNRESTRICTED)

    def test_l1_line_separator_u2028_alone_is_unrestricted(self):
        self.assertEqual(
            self.mode({"url": REMOTE_URL, "allow": ["\u2028"], "unrestricted": dict(GOOD_EXC)}, True),
            aq_registry.MODE_UNRESTRICTED)

    def test_l1_em_space_u2003_alone_is_unrestricted(self):
        self.assertEqual(
            self.mode({"url": REMOTE_URL, "allow": ["\u2003"], "unrestricted": dict(GOOD_EXC)}, True),
            aq_registry.MODE_UNRESTRICTED)

    # Mixed lists
    def test_l1_mixed_space_and_zwsp_refuses_ambiguous(self):
        # [' ', ZWSP]: the space is blank but the ZWSP is a REAL member -> ambiguous -> refuse.
        with self.assertRaisesRegex(self.Err, "ambiguous policy"):
            self.rap({"url": REMOTE_URL, "allow": [" ", "\u200b"], "unrestricted": dict(GOOD_EXC)},
                     True)

    def test_l1_mixed_all_blank_space_nbsp_tab_is_unrestricted(self):
        # [' ', NBSP, TAB]: every member strips to '' -> blanks-only -> UNRESTRICTED.
        self.assertEqual(
            self.mode({"url": REMOTE_URL, "allow": [" ", "\u00a0", "\t"],
                       "unrestricted": dict(GOOD_EXC)}, True),
            aq_registry.MODE_UNRESTRICTED)

    # Scale: a very large blanks-only list, and the same list with one real member appended.
    def test_l1_ten_thousand_empty_strings_is_unrestricted(self):
        allow = [""] * 10000
        self.assertEqual(
            self.mode({"url": REMOTE_URL, "allow": allow, "unrestricted": dict(GOOD_EXC)}, True),
            aq_registry.MODE_UNRESTRICTED)

    def test_l1_ten_thousand_empty_strings_plus_real_refuses_ambiguous(self):
        allow = [""] * 10000 + ["real_tool"]
        with self.assertRaisesRegex(self.Err, "ambiguous policy"):
            self.rap({"url": REMOTE_URL, "allow": allow, "unrestricted": dict(GOOD_EXC)}, True)

    # Derived expectation: loop EVERY character and assert UNRESTRICTED iff ch.strip() == '',
    # else a refusal. This test derives its own expectation from str.strip(), so it tracks the
    # launcher's actual rule on whatever Python runs it (it never hard-codes a per-char verdict).
    L1_CHARS = [
        "\u200b", "\u0000", "\ufeff", "\u2060", "\u200c",   # NOT blank (zero-width / NUL)
        "\u00a0", "\u3000", "\t", "\n", " ",                # blank
        "\u202f", "\u2028", "\u2003",                       # blank
    ]

    def test_l1_derived_strip_matches_launcher_verdict(self):
        for ch in self.L1_CHARS:
            with self.subTest(codepoint="U+%04X" % ord(ch)):
                entry = {"url": REMOTE_URL, "allow": [ch], "unrestricted": dict(GOOD_EXC)}
                if ch.strip() == "":
                    # blank member -> blanks-only list -> UNRESTRICTED
                    self.assertEqual(self.mode(entry, True), aq_registry.MODE_UNRESTRICTED)
                else:
                    # real member -> ambiguous -> refuse
                    with self.assertRaisesRegex(self.Err, "ambiguous policy"):
                        self.rap(entry, True)

    # Pinned core: a STABLE classification that a different Python's str.strip() cannot silently
    # flip (so the derived test above can never pass vacuously). These pins hold on CPython 3.12.8
    # (the Executive-measured reference) and on every current CPython: the blank set strips to '',
    # the not-blank set does not. If a runtime disagrees, THIS test fails loudly.
    def test_l1_pinned_core_blank_classification(self):
        blank = ["\u00a0", "\u3000", "\t", "\n", " "]       # must strip() to ''
        not_blank = ["\u200b", "\u0000", "\ufeff", "\u2060"]  # must NOT strip() to ''
        for ch in blank:
            with self.subTest(kind="blank", codepoint="U+%04X" % ord(ch)):
                self.assertEqual(ch.strip(), "",
                                 "expected U+%04X to be blank on this runtime" % ord(ch))
        for ch in not_blank:
            with self.subTest(kind="not_blank", codepoint="U+%04X" % ord(ch)):
                self.assertNotEqual(ch.strip(), "",
                                    "expected U+%04X to be NON-blank on this runtime" % ord(ch))

    # ---- R3-L1 (Rev 4): falsy / null 'unrestricted' values under the floor ----
    def test_r3l1_unrestricted_null_no_marker_is_legacy(self):
        # JSON null -> Python None: entry.get("unrestricted") is None -> the exception branch is
        # skipped. With NO marker the launcher returns (None, None) (legacy, unchanged).
        self.assertEqual(
            self.rap({"url": REMOTE_URL, "allow": [], "unrestricted": None}, False),
            (None, None))

    def test_r3l1_unrestricted_null_with_marker_no_allow_refuses(self):
        # With the marker on and no usable allow-list, null 'unrestricted' falls through to the
        # enforced path, which refuses (no allow-list, no exception).
        with self.assertRaises(self.Err):
            self.rap({"url": REMOTE_URL, "unrestricted": None}, True)

    def test_r3l1_unrestricted_null_with_marker_and_allow_is_enforced(self):
        # null 'unrestricted' + a real allow-list under the floor -> ENFORCED (no exception).
        self.assertEqual(
            self.mode({"url": REMOTE_URL, "allow": ["read_one"], "unrestricted": None}, True),
            aq_registry.MODE_ENFORCED)

    def test_r3l1_unrestricted_falsy_present_values_with_floor_refuse(self):
        # {} / False / 0 / "" / [] are PRESENT (is not None) so they enter the exception branch
        # and _validate_exception refuses each (not a well-formed exception object).
        for bad in ({}, False, 0, "", []):
            with self.assertRaises(self.Err):
                self.rap({"url": REMOTE_URL, "allow": ["read_one"], "unrestricted": bad}, True)


# --------------------------------------------------------------------------------------------
# Proxy pure policy: check_allowlist_policy(allow_list, env_mode, marker_present, exc_env, name)
# --------------------------------------------------------------------------------------------
class ProxyPolicyTests(unittest.TestCase):
    cap = staticmethod(PROXY["check_allowlist_policy"])
    Err = PROXY["AllowlistFloorError"]

    def _good_env(self, target="example"):
        fields = aq_registry._validate_exception(dict(GOOD_EXC))
        digest = PROXY["unrestricted_digest"](target, fields)
        return {"reason": fields["reason"], "approval_id": fields["approval_id"],
                "approved_utc": fields["approved_utc"], "digest": digest}

    def test_inactive_legacy_empty(self):
        self.assertIsNone(self.cap([], None, False))

    def test_inactive_legacy_nonempty(self):
        self.assertIsNone(self.cap(["a"], None, False))

    def test_enforced_empty_allow_refuses(self):
        with self.assertRaises(self.Err):
            self.cap([], "enforced", False)

    def test_enforced_nonempty_ok(self):
        self.assertEqual(self.cap(["a"], "enforced", False), "enforced")

    def test_unrestricted_nonempty_allow_refuses(self):
        with self.assertRaises(self.Err):
            self.cap(["a"], "unrestricted", True, exc_env=self._good_env(), target_name="example")

    def test_unknown_mode_refuses(self):
        with self.assertRaises(self.Err):
            self.cap([], "something-else", False)

    def test_marker_present_no_mode_empty_refuses(self):
        with self.assertRaises(self.Err):
            self.cap([], None, True)

    def test_marker_present_no_mode_nonempty_ok(self):
        self.assertEqual(self.cap(["a"], None, True), "enforced")

    # ---- P3: env-only 'unrestricted' must NOT be enough on a marked gateway ----
    def test_p3_env_only_unrestricted_no_fields_refuses(self):
        with self.assertRaises(self.Err):
            self.cap([], "unrestricted", True, exc_env=None, target_name="example")

    def test_p3_env_only_unrestricted_empty_fields_refuses(self):
        with self.assertRaises(self.Err):
            self.cap([], "unrestricted", True, exc_env={}, target_name="example")

    def test_p3_valid_full_set_and_digest_serves(self):
        self.assertEqual(
            self.cap([], "unrestricted", True, exc_env=self._good_env("example"),
                     target_name="example"),
            "unrestricted")

    def test_p3_digest_mismatch_wrong_target_refuses(self):
        env = self._good_env("example")  # digest bound to "example"
        with self.assertRaises(self.Err):
            self.cap([], "unrestricted", True, exc_env=env, target_name="different")

    def test_p3_missing_digest_refuses(self):
        env = self._good_env("example")
        env["digest"] = None
        with self.assertRaises(self.Err):
            self.cap([], "unrestricted", True, exc_env=env, target_name="example")

    def test_p3_tampered_field_breaks_digest_refuses(self):
        env = self._good_env("example")
        env["reason"] = "a completely different but valid length reason"
        with self.assertRaises(self.Err):
            self.cap([], "unrestricted", True, exc_env=env, target_name="example")


# --------------------------------------------------------------------------------------------
# Proxy raw allow-list re-validation (P1): a comma/control/duplicate name is refused under floor.
# --------------------------------------------------------------------------------------------
class ProxyRawAllowTests(unittest.TestCase):
    var = staticmethod(PROXY["_validate_allow_raw"])
    Err = PROXY["AllowlistFloorError"]

    def test_normal_names_ok(self):
        self.assertEqual(self.var("list_issues,get_issue"), ["list_issues", "get_issue"])

    def test_blanks_dropped(self):
        self.assertEqual(self.var("a, ,b,"), ["a", "b"])

    def test_duplicate_refused(self):
        with self.assertRaises(self.Err):
            self.var("a,a")

    def test_control_char_refused(self):
        with self.assertRaises(self.Err):
            self.var("a,\x01b")

    def test_over_length_refused(self):
        with self.assertRaises(self.Err):
            self.var("a," + "x" * 129)


# --------------------------------------------------------------------------------------------
# CHANGE 3 (parity guard): the exception + allow-name validators are DUPLICATED across the two
# payload files (they must stay standalone -- the proxy cannot import the launcher). This class
# is made LOAD-BEARING: a table-driven battery asserts the launcher and the proxy return the SAME
# verdict (accept/refuse) and the SAME normalised fields on accept, for a wide range of inputs.
#
# LEGITIMATE DIFFERENCES (asserted on the launcher only, documented here, NOT in the parity table):
#   * The launcher's _validate_exception owns the JSON-OBJECT shape, so it additionally rejects a
#     non-dict exception and unknown/missing keys. The proxy's validate_exception_fields takes the
#     three already-separated env strings, so "unknown key" / "non-dict" cannot occur there. Those
#     object-shape cases live in LauncherPolicyTests, not in this field-level parity table.
#   * Refusal MESSAGE WORDING differs by design (the proxy uses shorter "... is missing or
#     malformed" strings); this table compares the VERDICT CLASS (accept vs refuse) and the
#     normalised fields on accept, never the message text.
#   * For the raw allow-NAME table: the proxy's _validate_allow_raw tolerates empty comma segments
#     in a raw env string (the legacy split drops them), whereas the launcher validates a JSON
#     array member-by-member. The table below feeds the SAME single token to _bad_allow_name on
#     both sides (the shared per-name predicate), which IS byte-identical; the empty-segment
#     tolerance is a property of the string parser, exercised separately in ProxyRawAllowTests.
#
# R3-M1 / Rev 4 SCOPE NOTE: this Rev 4 patch changes ONLY the launcher's resolve_allowlist_policy
# list rule; it does NOT touch _validate_exception, validate_exception_fields, _bad_allow_name, or
# the proxy. The launcher<->proxy parity covered here is over exception FIELDS and allow NAMES,
# NOT over the "exception + list of junk" resolve rule (which is a launcher-only policy — the
# launcher serialises an empty AQ_TOOL_ALLOWLIST on the unrestricted path, so the proxy never
# sees such a list). These parity tables therefore still pass unchanged.
# --------------------------------------------------------------------------------------------
def _exc(reason=None, approval_id=None, approved_utc=None):
    return {"reason": reason, "approval_id": approval_id, "approved_utc": approved_utc}


# Fixed clock so future-skew cases are deterministic on both sides.
PARITY_NOW = __import__("datetime").datetime(2026, 10, 20, 12, 0, 0)

# >=30 exception inputs: (label, reason, approval_id, approved_utc). Mix of valid and every
# invalid class already tested, plus boundary lengths and calendar/skew edges.
_R12 = "x" * 12            # reason min boundary (valid)
_R11 = "y" * 11            # just under min (invalid)
_R500 = "z" * 500          # reason max boundary (valid)
_R501 = "w" * 501          # just over max (invalid)
_A8 = "A" * 8              # approval min boundary (valid)
_A7 = "B" * 7              # just under min (invalid)
_A128 = "C" * 128          # approval max boundary (valid)
_A129 = "D" * 129          # just over max (invalid)
EXC_PARITY_CASES = [
    ("valid_canonical", GOOD_EXC["reason"], GOOD_EXC["approval_id"], "2026-10-20T14:30:00Z"),
    ("valid_reason_min_12", _R12, "OPS-123456", "2026-10-20T00:00:00Z"),
    ("valid_reason_max_500", _R500, "OPS-123456", "2026-10-20T00:00:00Z"),
    ("valid_approval_min_8", "reason enough chars", _A8, "2026-10-20T00:00:00Z"),
    ("valid_approval_max_128", "reason enough chars", _A128, "2026-10-20T00:00:00Z"),
    ("valid_approval_punct", "reason enough chars", "a.b_c:d-e", "2026-10-20T00:00:00Z"),
    ("valid_skew_exactly_24h", "reason enough chars", "OPS-123456", "2026-10-21T12:00:00Z"),
    ("valid_past_date", "reason enough chars", "OPS-123456", "2020-01-01T00:00:00Z"),
    ("valid_leap_day", "reason enough chars", "OPS-123456", "2024-02-29T00:00:00Z"),
    ("bad_reason_too_short_11", _R11, "OPS-123456", "2026-10-20T00:00:00Z"),
    ("bad_reason_too_long_501", _R501, "OPS-123456", "2026-10-20T00:00:00Z"),
    ("bad_reason_blank_only", "            ", "OPS-123456", "2026-10-20T00:00:00Z"),
    ("bad_reason_not_str", 12345678901234, "OPS-123456", "2026-10-20T00:00:00Z"),
    ("bad_reason_crlf", "valid reason text\r\nINJECT", "OPS-123456", "2026-10-20T00:00:00Z"),
    ("bad_reason_tab", "valid reason\ttext here", "OPS-123456", "2026-10-20T00:00:00Z"),
    ("bad_reason_nul", "valid reason\x00text", "OPS-123456", "2026-10-20T00:00:00Z"),
    ("bad_reason_unit_sep_1f", "valid reason\x1ftext", "OPS-123456", "2026-10-20T00:00:00Z"),
    ("bad_approval_too_short_7", "reason enough chars", _A7, "2026-10-20T00:00:00Z"),
    ("bad_approval_too_long_129", "reason enough chars", _A129, "2026-10-20T00:00:00Z"),
    ("bad_approval_space", "reason enough chars", "bad id with spaces!", "2026-10-20T00:00:00Z"),
    ("bad_approval_trailing_nl", "reason enough chars", "OPS-ABC-123\n", "2026-10-20T00:00:00Z"),
    ("bad_approval_not_str", "reason enough chars", 99999999, "2026-10-20T00:00:00Z"),
    ("bad_approval_slash", "reason enough chars", "OPS/123456", "2026-10-20T00:00:00Z"),
    ("bad_utc_no_z", "reason enough chars", "OPS-123456", "2026-10-20T14:30:00"),
    ("bad_utc_space_sep", "reason enough chars", "OPS-123456", "2026-10-20 14:30:00Z"),
    ("bad_utc_slashes", "reason enough chars", "OPS-123456", "2026/10/20T14:30:00Z"),
    ("bad_utc_trailing_nl", "reason enough chars", "OPS-123456", "2026-10-20T14:30:00Z\n"),
    ("bad_utc_unicode_digits", "reason enough chars", "OPS-123456", "\u0662\u0660\u0662\u0666-10-20T14:30:00Z"),
    ("bad_utc_calendar_month", "reason enough chars", "OPS-123456", "2026-13-45T99:99:99Z"),
    ("bad_utc_feb30", "reason enough chars", "OPS-123456", "2026-02-30T00:00:00Z"),
    ("bad_utc_not_str", "reason enough chars", "OPS-123456", 20261020),
    ("bad_future_plus_1s_over_24h", "reason enough chars", "OPS-123456", "2026-10-21T12:00:01Z"),
    ("bad_future_far", "reason enough chars", "OPS-123456", "2999-01-01T00:00:00Z"),
]


class ExceptionParityTests(unittest.TestCase):
    L = staticmethod(aq_registry._validate_exception)
    P = staticmethod(PROXY["validate_exception_fields"])
    LErr = aq_registry.AllowlistFloorError
    PErr = PROXY["AllowlistFloorError"]

    def _launcher_verdict(self, reason, approval_id, approved_utc):
        try:
            return ("accept", self.L(_exc(reason, approval_id, approved_utc), now=PARITY_NOW))
        except self.LErr:
            return ("refuse", None)

    def _proxy_verdict(self, reason, approval_id, approved_utc):
        try:
            return ("accept", self.P(reason, approval_id, approved_utc, now=PARITY_NOW))
        except self.PErr:
            return ("refuse", None)

    def test_exception_validator_parity_table(self):
        self.assertGreaterEqual(len(EXC_PARITY_CASES), 30)
        for label, reason, approval_id, approved_utc in EXC_PARITY_CASES:
            lv, lf = self._launcher_verdict(reason, approval_id, approved_utc)
            pv, pf = self._proxy_verdict(reason, approval_id, approved_utc)
            self.assertEqual(lv, pv, "verdict disagreement for %s: launcher=%s proxy=%s"
                             % (label, lv, pv))
            if lv == "accept":
                self.assertEqual(lf, pf, "normalised-field disagreement on accept for %s" % label)
                # And the digests over identical normalised fields must agree too.
                self.assertEqual(aq_registry.unrestricted_digest("example", lf),
                                 PROXY["unrestricted_digest"]("example", pf),
                                 "digest disagreement for %s" % label)

    def test_exception_parity_has_valid_and_invalid(self):
        verdicts = {self._launcher_verdict(r, a, u)[0] for _, r, a, u in EXC_PARITY_CASES}
        self.assertEqual(verdicts, {"accept", "refuse"})  # the table exercises both outcomes

    # ---- allow-NAME parity: the shared per-name predicate _bad_allow_name, >=20 names ----
    ALLOW_NAME_CASES = [
        "read_one", "get-issue", "tool.name", "a", "C" * 128,      # accepted on both
        "read,write",                                              # comma -> split hazard
        "read write", "read\ttool", "line\nname",                  # whitespace variants
        "null\x00name", "ctl\x01name", "del\x7fname", "us\x1fsep", # control chars
        "D" * 129,                                                 # over length
        "   ", "",                                                 # blank / empty
        "caf\u00e9", "\u00fcmlaut",                                # unicode letters (no ws/comma)
        "dup", "dup",                                              # duplicate token (same verdict)
        "tool;semicolon", "tool:colon",                            # punctuation that IS allowed
        12345,                                                     # non-str
    ]

    def test_allow_name_validator_parity_table(self):
        self.assertGreaterEqual(len(self.ALLOW_NAME_CASES), 20)
        lbad = aq_registry._bad_allow_name
        pbad = PROXY["_bad_allow_name"]
        for name in self.ALLOW_NAME_CASES:
            lr = lbad(name)
            pr = pbad(name)
            # Same verdict (both None = accept, or both a non-None reason = refuse) AND, because
            # the two predicates are intended to be byte-identical, the SAME reason string.
            self.assertEqual(lr, pr, "allow-name verdict/string disagreement for %r" % (name,))

    def test_digests_agree(self):
        fields = aq_registry._validate_exception(dict(GOOD_EXC))
        self.assertEqual(aq_registry.unrestricted_digest("example", fields),
                         PROXY["unrestricted_digest"]("example", fields))


# --------------------------------------------------------------------------------------------
# CHANGE 1 (T-1) end-to-end: the env the launcher builds for a blanks-only + exception target is
# accepted by the proxy's check_allowlist_policy with the matching digest (empty allow-list,
# mode unrestricted). Proves the launcher<->proxy handoff is consistent, not just each half.
# --------------------------------------------------------------------------------------------
class LauncherProxyUnrestrictedE2ETests(unittest.TestCase):
    def test_blanks_only_exception_launcher_env_accepted_by_proxy(self):
        name = "example"
        entry = {"url": REMOTE_URL, "allow": ["  ", ""], "unrestricted": dict(GOOD_EXC)}
        mode, fields = aq_registry.resolve_allowlist_policy(entry, True)
        self.assertEqual(mode, aq_registry.MODE_UNRESTRICTED)
        # The launcher serialises an EMPTY allow-list for the proxy on this path.
        allow_env = aq_registry._allowlist_for_env(entry, True, mode)
        self.assertEqual(allow_env, "")
        # Build exactly what main() would hand the proxy.
        exc_env = {
            "reason": fields["reason"],
            "approval_id": fields["approval_id"],
            "approved_utc": fields["approved_utc"],
            "digest": aq_registry.unrestricted_digest(name, fields),
        }
        allow_list = PROXY["_validate_allow_raw"](allow_env)   # proxy re-parses the raw env string
        self.assertEqual(allow_list, [])
        verdict = PROXY["check_allowlist_policy"](allow_list, mode, True,
                                                  exc_env=exc_env, target_name=name)
        self.assertEqual(verdict, "unrestricted")

    def test_e2e_wrong_target_digest_refused_by_proxy(self):
        name = "example"
        entry = {"url": REMOTE_URL, "allow": [""], "unrestricted": dict(GOOD_EXC)}
        mode, fields = aq_registry.resolve_allowlist_policy(entry, True)
        exc_env = {
            "reason": fields["reason"],
            "approval_id": fields["approval_id"],
            "approved_utc": fields["approved_utc"],
            "digest": aq_registry.unrestricted_digest(name, fields),   # bound to "example"
        }
        with self.assertRaises(PROXY["AllowlistFloorError"]):
            PROXY["check_allowlist_policy"]([], mode, True, exc_env=exc_env, target_name="other")


# --------------------------------------------------------------------------------------------
# CHANGE 2 (T-2): the default clock must be warning-free (no DeprecationWarning) on 3.12/3.13 and
# the validators must still accept a naive injected now.
# --------------------------------------------------------------------------------------------
class ClockDeprecationTests(unittest.TestCase):
    def test_launcher_default_clock_no_deprecation_warning(self):
        import warnings
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            aq_registry._validate_exception(dict(GOOD_EXC))     # now=None -> default clock
        self.assertEqual([w for w in caught if issubclass(w.category, DeprecationWarning)], [])

    def test_proxy_default_clock_no_deprecation_warning(self):
        import warnings
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            PROXY["validate_exception_fields"](GOOD_EXC["reason"], GOOD_EXC["approval_id"],
                                               GOOD_EXC["approved_utc"])
        self.assertEqual([w for w in caught if issubclass(w.category, DeprecationWarning)], [])

    def test_launcher_accepts_naive_now(self):
        import datetime as _dt
        now = _dt.datetime(2026, 10, 20, 12, 0, 0)
        f = aq_registry._validate_exception(
            {**GOOD_EXC, "approved_utc": "2026-10-21T10:00:00Z"}, now=now)
        self.assertEqual(f["approved_utc"], "2026-10-21T10:00:00Z")

    def test_proxy_accepts_naive_now(self):
        import datetime as _dt
        now = _dt.datetime(2026, 10, 20, 12, 0, 0)
        f = PROXY["validate_exception_fields"](
            GOOD_EXC["reason"], GOOD_EXC["approval_id"], "2026-10-21T10:00:00Z", now=now)
        self.assertEqual(f["approved_utc"], "2026-10-21T10:00:00Z")


# --------------------------------------------------------------------------------------------
# Marker reader (identical logic in launcher and proxy). Fail CLOSED on any present-but-unsafe.
# --------------------------------------------------------------------------------------------
class MarkerReaderTests(unittest.TestCase):
    readers = (aq_registry._marker_floor_on, PROXY["_marker_floor_on"])

    def _assert_both(self, path, expected):
        for fn in self.readers:
            self.assertEqual(fn(path), expected, "%s on %s" % (fn, path))

    def test_absent_is_legacy(self):
        with tempfile.TemporaryDirectory() as d:
            self._assert_both(os.path.join(d, "nope.json"), False)

    def test_valid_true_floor_on(self):
        with tempfile.TemporaryDirectory() as d:
            p = _write_marker(d, {"schema": "v1", "allowlist_floor": True,
                                  "created_by": "fakeuser", "created_utc": "2026-10-20T00:00:00Z"})
            self._assert_both(p, True)

    def test_opt_out_false_floor_off(self):
        with tempfile.TemporaryDirectory() as d:
            p = _write_marker(d, {"schema": "v1", "allowlist_floor": False})
            self._assert_both(p, False)

    def test_corrupt_json_fails_closed(self):
        with tempfile.TemporaryDirectory() as d:
            p = _write_marker(d, None, raw="{ this is not json")
            self._assert_both(p, True)

    def test_non_object_fails_closed(self):
        with tempfile.TemporaryDirectory() as d:
            p = _write_marker(d, [1, 2, 3])
            self._assert_both(p, True)

    def test_missing_field_fails_closed(self):
        with tempfile.TemporaryDirectory() as d:
            p = _write_marker(d, {"schema": "v1"})
            self._assert_both(p, True)

    def test_nonbool_floor_fails_closed(self):
        with tempfile.TemporaryDirectory() as d:
            p = _write_marker(d, {"allowlist_floor": "true"})
            self._assert_both(p, True)

    def test_oversize_fails_closed(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "gateway_policy.json")
            with open(p, "w", encoding="utf-8") as f:
                f.write('{"allowlist_floor":true,"pad":"' + ("x" * 70000) + '"}')
            self._assert_both(p, True)

    def test_symlink_refused_fails_closed(self):
        with tempfile.TemporaryDirectory() as d:
            real = _write_marker(d, {"allowlist_floor": True}, name="real.json")
            link = os.path.join(d, "gateway_policy.json")
            try:
                os.symlink(real, link)
            except (OSError, NotImplementedError, AttributeError) as e:
                self.skipTest("cannot create symlink on this OS/user: %r" % (e,))
            self._assert_both(link, True)


# --------------------------------------------------------------------------------------------
# No-secret-echo: refusal messages must not contain env values / tokens / paths.
# --------------------------------------------------------------------------------------------
class NoSecretEchoTests(unittest.TestCase):
    def test_launcher_refusal_message_has_no_values(self):
        try:
            aq_registry.resolve_allowlist_policy({"url": REMOTE_URL, "allow": []}, True)
            self.fail("should have refused")
        except aq_registry.AllowlistFloorError as e:
            msg = str(e)
            self.assertNotIn(REMOTE_URL, msg)
            self.assertNotIn("abc123", msg)

    def test_proxy_refusal_message_has_no_mode_value_leak(self):
        cap = PROXY["check_allowlist_policy"]
        Err = PROXY["AllowlistFloorError"]
        try:
            cap(["secret_tool_name"], "unrestricted", False)
            self.fail("should have refused")
        except Err as e:
            self.assertNotIn("secret_tool_name", str(e))


# --------------------------------------------------------------------------------------------
# Integration: real launcher refuses under a marker with no allow-list (never launches proxy).
# --------------------------------------------------------------------------------------------
class LauncherSubprocessTests(unittest.TestCase):
    def setUp(self):
        self._skip_if_no_subprocess()

    def _skip_if_no_subprocess(self):
        try:
            subprocess.run([sys.executable, "-c", "pass"], capture_output=True, timeout=15)
        except Exception as e:  # pragma: no cover - environment dependent
            self.skipTest("subprocess unavailable: %r" % (e,))

    def _stage(self, dirpath, entry, marker=True):
        import shutil
        r = Path(dirpath)
        shutil.copyfile(PAYLOAD / "aq_registry.py", r / "aq_registry.py")
        (r / "targets.json").write_text(json.dumps({"targets": {"example": entry}}), encoding="utf-8")
        if marker:
            _write_marker(dirpath, {"schema": "v1", "allowlist_floor": True,
                                    "created_by": "fakeuser", "created_utc": "2026-10-20T00:00:00Z"})
        # A sentinel proxy that would write a file if it were ever launched (it must NOT be).
        (r / "aq_mcp_stdio.py").write_text(
            "import pathlib; pathlib.Path(__file__).with_name('LAUNCHED').write_text('x')\n",
            encoding="utf-8")
        return r

    def test_launcher_refuses_marker_no_allow(self):
        with tempfile.TemporaryDirectory() as d:
            r = self._stage(d, {"url": REMOTE_URL})  # no allow, marker present
            env = _pop_ambient(dict(os.environ, AQ_STDIO_SCRIPT=str(r / "aq_mcp_stdio.py")))
            p = subprocess.run([sys.executable, str(r / "aq_registry.py"), "run", "example"],
                               capture_output=True, text=True, env=env, timeout=30)
            self.assertNotEqual(p.returncode, 0, "launcher should refuse")
            self.assertFalse((r / "LAUNCHED").exists(), "proxy must never be launched after refusal")
            self.assertNotIn(REMOTE_URL, p.stderr)
            # P4: a plain remedy line is present.
            self.assertIn("Fix:", p.stderr)

    def test_launcher_sets_enforced_mode_when_allow_present(self):
        with tempfile.TemporaryDirectory() as d:
            r = self._stage(d, {"url": REMOTE_URL, "allow": ["read_one"]})
            (r / "aq_mcp_stdio.py").write_text(
                "import os, pathlib; "
                "pathlib.Path(__file__).with_name('MODE').write_text("
                "os.environ.get('AQ_ALLOWLIST_MODE','<unset>'))\n",
                encoding="utf-8")
            env = _pop_ambient(dict(os.environ, AQ_STDIO_SCRIPT=str(r / "aq_mcp_stdio.py")))
            p = subprocess.run([sys.executable, str(r / "aq_registry.py"), "run", "example"],
                               capture_output=True, text=True, env=env, timeout=30)
            self.assertEqual(p.returncode, 0, p.stderr)
            self.assertEqual((r / "MODE").read_text(encoding="utf-8"), "enforced")


# --------------------------------------------------------------------------------------------
# Integration: DIRECT proxy invocation with a marker present and no/empty allow-list -> refuse.
# Requires botocore+mcp (gateway venv); skips with a clear reason otherwise.
# --------------------------------------------------------------------------------------------
class ProxySubprocessTests(unittest.TestCase):
    def setUp(self):
        try:
            subprocess.run([sys.executable, "-c", "pass"], capture_output=True, timeout=15)
        except Exception as e:  # pragma: no cover
            self.skipTest("subprocess unavailable: %r" % (e,))
        probe = subprocess.run(
            [sys.executable, "-c", "import botocore, mcp"], capture_output=True, text=True, timeout=30)
        if probe.returncode != 0:
            self.skipTest("gateway deps (botocore/mcp) not importable on this runner")

    def test_direct_proxy_refuses_with_marker_and_empty_allow(self):
        import shutil
        with tempfile.TemporaryDirectory() as d:
            r = Path(d)
            shutil.copyfile(PAYLOAD / "aq_mcp_stdio.py", r / "aq_mcp_stdio.py")
            _write_marker(d, {"schema": "v1", "allowlist_floor": True,
                              "created_by": "fakeuser", "created_utc": "2026-10-20T00:00:00Z"})
            env = _pop_ambient(dict(os.environ,
                                    AQ_TARGET_URL=REMOTE_URL + "/mcp",
                                    AQ_LOG_FILE=str(r / "aq-mcp.log")))
            msgs = "\n".join(json.dumps(m) for m in (
                {"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {}},
                {"jsonrpc": "2.0", "method": "notifications/initialized"},
                {"jsonrpc": "2.0", "id": 2, "method": "tools/call",
                 "params": {"name": "whatever", "arguments": {}}},
            )) + "\n"
            p = subprocess.run([sys.executable, str(r / "aq_mcp_stdio.py")],
                               input=msgs, capture_output=True, text=True, env=env, timeout=45)
            self.assertNotEqual(p.returncode, 0, "proxy should refuse to serve")
            self.assertNotIn('"id": 2', p.stdout.replace(" ", "").replace('"id":2', '"id": 2'))


if __name__ == "__main__":
    unittest.main()
