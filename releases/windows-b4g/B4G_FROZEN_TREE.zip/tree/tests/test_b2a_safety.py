"""B2a user-facing safety items (S2 / S4 / S5).

S2  Git and Local are refused on a host THIS wizard bootstrapped (Lambda lane only),
    decided only from a wizard-held bootstrap receipt, never from a remote guess.
S4  cli.py apply has the GUI's mutating-tool confirmation parity: explicit flag OR an
    interactive typed 'yes'; default refuses; non-interactive without the flag refuses.
S5  A plain-language plan summary is produced for the GUI and CLI before any confirm.

These are pure-logic tests: no subprocess, tkinter, paramiko, SSH, Lambda or GUI.
"""
import io
import sys
import unittest
from pathlib import Path
from unittest import mock
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import cli
import model
from deploy_lib import ConnectorDeployer, DeploymentError
from model import (validate_spec_for_host, host_is_wizard_lambda_only, ValidationError,
                   LAMBDA_ONLY_REFUSAL, plain_language_summary, mutating_confirm_text, plan)

LAMBDA_SPEC = {'host': 'jump.example.internal', 'user': 'engineer', 'kind': 'lambda',
               'target': 'epg-demo', 'display_name': 'AQ EPG Demo',
               'url': 'https://abc.lambda-url.us-west-2.on.aws/mcp',
               'allow': ['count_alerts', 'submit_receivers_export']}
GIT_SPEC = {'host': 'jump.example.internal', 'user': 'engineer', 'kind': 'git',
            'target': 'github-ghes', 'display_name': 'GH'}
LOCAL_SPEC = {'host': 'jump.example.internal', 'user': 'engineer', 'kind': 'local',
              'target': 'build-artifacts', 'display_name': 'BA',
              'server': 'aq_build_artifacts_mcp.py'}
# Exactly the receipt remote_agent.bootstrap returns on a successful fresh install.
BOOT_RECEIPT = {'status': 'BOOTSTRAPPED', 'installed': True, 'state': 'READY',
                'gateway_root': '~/aq-mcp', 'registry_targets': 0, 'bundle_sha256': 'a' * 64,
                'aws_credentials': 'NOT_INSTALLED', 'quick_registration': 'MANUAL_REQUIRED'}


class FakeGateway:
    """Minimal in-memory gateway for prepare()/deploy() replay (no SSH)."""
    def __init__(self):
        self.calls = []
        self.deployed = False
    def run(self, q, timeout=65):
        self.calls.append(q)
        if q['op'] == 'inspect':
            return {'state': 'READY', 'installed': True, 'sha256': 'a' * 64,
                    'target_names': ['build-artifacts', 'epg', 'rtr'], 'kinds': {'build-artifacts': 'local'},
                    'git_targets': ['github-ghes']}
        if q['op'] == 'discover':
            return {'tools': [{'name': 'count_alerts', 'description': 'r'},
                              {'name': 'submit_receivers_export', 'description': 'w'}],
                    'count': 2, 'truncated': False}
        if q['op'] == 'apply':
            self.deployed = True
            return {'status': 'DEPLOYED_PENDING_CHECK', 'target': q['target'], 'before': 'a' * 64,
                    'after': 'b' * 64, 'backup_name': 'targets-1234567890-abcdef123456-aaaaaaaaaaaa.json'}
        if q['op'] == 'check':
            return {'ok': True}
        raise AssertionError(q)


class S2WizardLambdaOnly(unittest.TestCase):
    def test_classifier_true_only_for_real_bootstrap_receipt(self):
        self.assertTrue(host_is_wizard_lambda_only(BOOT_RECEIPT))

    def test_classifier_false_for_non_bootstrap_state(self):
        for bad in [None, {}, 'BOOTSTRAPPED', 42,
                    {'status': 'GATEWAY_VERIFIED', 'state': 'READY', 'gateway_root': '~/aq-mcp'},
                    {'status': 'BOOTSTRAPPED', 'state': 'MISSING', 'gateway_root': '~/aq-mcp'},
                    {'status': 'BOOTSTRAPPED', 'state': 'READY', 'gateway_root': '/opt/other'}]:
            with self.subTest(bad=bad):
                self.assertFalse(host_is_wizard_lambda_only(bad))

    def test_git_and_local_refused_on_bootstrapped_host_with_exact_message(self):
        for spec in (GIT_SPEC, LOCAL_SPEC):
            with self.subTest(kind=spec['kind']):
                with self.assertRaises(ValidationError) as ctx:
                    validate_spec_for_host(spec, BOOT_RECEIPT)
                self.assertEqual(str(ctx.exception), LAMBDA_ONLY_REFUSAL)
                self.assertEqual(str(ctx.exception),
                    'This host was bootstrapped by the wizard with the Lambda lane only; '
                    'the Git and Build Artifacts launchers are not installed.')

    def test_lambda_allowed_on_bootstrapped_host(self):
        self.assertIs(validate_spec_for_host(LAMBDA_SPEC, BOOT_RECEIPT), LAMBDA_SPEC)

    def test_no_receipt_is_unchanged_behaviour(self):
        # No state held: git/local pass exactly as before (existing full gateway).
        validate_spec_for_host(GIT_SPEC)
        validate_spec_for_host(GIT_SPEC, None)
        validate_spec_for_host(LOCAL_SPEC, None)

    def test_non_bootstrap_receipt_does_not_trigger_refusal(self):
        # A deploy receipt (not a bootstrap) must NOT be treated as wizard-lambda-only.
        deploy_receipt = {'status': 'GATEWAY_VERIFIED', 'target': 'epg-demo'}
        validate_spec_for_host(GIT_SPEC, deploy_receipt)

    def test_validate_spec_for_host_without_receipt_equals_validate_spec(self):
        # Same acceptance for a valid lambda spec; same rejection for an invalid one.
        validate_spec_for_host(LAMBDA_SPEC)
        with self.assertRaises(ValidationError):
            validate_spec_for_host(dict(LAMBDA_SPEC, target='Bad/Name'))


class S4CliApplyConfirmation(unittest.TestCase):
    def test_mutating_confirm_text_matches_shared_wording(self):
        text = mutating_confirm_text(['submit_x', 'delete_y'])
        self.assertIn('Potentially MUTATING tool names were selected:', text)
        self.assertIn('submit_x, delete_y', text)
        self.assertIn('Name heuristics are NOT a safety verdict', text)

    def test_confirm_apply_flag_approves_non_interactively(self):
        with mock.patch.object(cli.sys.stdin, 'isatty', return_value=False):
            self.assertTrue(cli.confirm_apply(True, 'epg-demo'))

    def test_confirm_apply_non_interactive_without_flag_refuses(self):
        with mock.patch.object(cli.sys.stdin, 'isatty', return_value=False):
            self.assertFalse(cli.confirm_apply(False, 'epg-demo'))

    def test_confirm_apply_interactive_typed_yes_approves(self):
        with mock.patch.object(cli.sys.stdin, 'isatty', return_value=True), \
             mock.patch.object(cli, 'input', create=True, return_value='  YES '):
            self.assertTrue(cli.confirm_apply(False, 'epg-demo'))

    def test_confirm_apply_interactive_typed_no_refuses(self):
        with mock.patch.object(cli.sys.stdin, 'isatty', return_value=True), \
             mock.patch.object(cli, 'input', create=True, return_value='no'):
            self.assertFalse(cli.confirm_apply(False, 'epg-demo'))

    def test_confirm_apply_interactive_eof_refuses(self):
        def boom(prompt=''):
            raise EOFError()
        with mock.patch.object(cli.sys.stdin, 'isatty', return_value=True), \
             mock.patch.object(cli, 'input', create=True, side_effect=boom):
            self.assertFalse(cli.confirm_apply(False, 'epg-demo'))

    def _run_apply(self, extra, confirm_return):
        """Drive cli.main('apply', ...) with deploy_lib and IO stubbed. Returns
        (system_exit_raised, deployed_flag)."""
        gw = FakeGateway()
        prepared = ConnectorDeployer(gw).prepare(LAMBDA_SPEC)
        files = {'man.json': LAMBDA_SPEC, 'plan.json': prepared}
        argv = ['apply', 'man.json', '--plan-file', 'plan.json',
                '--receipt-file', 'rec.json', '--approve-target', 'epg-demo'] + extra
        deployer = ConnectorDeployer(gw)
        se = False
        with mock.patch.object(cli, 'read_json', side_effect=lambda p: files[p]), \
             mock.patch.object(cli, 'write_new_json'), \
             mock.patch.object(cli, 'ConnectorDeployer', return_value=deployer), \
             mock.patch.object(cli, 'SSHG', return_value=None), \
             mock.patch.object(cli, 'confirm_apply', return_value=confirm_return), \
             mock.patch('sys.stderr', new=io.StringIO()), \
             mock.patch('sys.stdout', new=io.StringIO()):
            try:
                cli.main(argv)
            except SystemExit:
                se = True
        return se, gw.deployed

    def test_apply_deploys_when_confirmed(self):
        se, deployed = self._run_apply(['--approve-apply'], confirm_return=True)
        self.assertFalse(se)
        self.assertTrue(deployed)

    def test_apply_refuses_and_does_not_deploy_when_not_confirmed(self):
        se, deployed = self._run_apply([], confirm_return=False)
        self.assertTrue(se)          # p.error -> SystemExit
        self.assertFalse(deployed)   # nothing written to the gateway


class S5PlainLanguageSummary(unittest.TestCase):
    def _lambda_plan(self, allow):
        gw = FakeGateway()
        return ConnectorDeployer(gw).prepare(dict(LAMBDA_SPEC, allow=allow))

    def test_lambda_summary_has_all_required_lines(self):
        prepared = self._lambda_plan(['count_alerts', 'submit_receivers_export'])
        text = plain_language_summary(LAMBDA_SPEC, prepared, discovered_count=2)
        self.assertIn('a new connector target named "epg-demo" in region us-west-2', text)
        self.assertIn('Tools allowed: 2 tool(s) out of 2 tool(s) the backend offered', text)
        # 3 existing targets from FakeGateway inspect (build-artifacts, epg, rtr).
        self.assertIn('3 existing target(s) will be left unchanged, 1 added.', text)
        self.assertIn('Backup:', text)
        self.assertIn('How to roll back:', text)

    def test_summary_flags_mutating_tools_by_name(self):
        prepared = self._lambda_plan(['count_alerts', 'submit_receivers_export'])
        text = plain_language_summary(LAMBDA_SPEC, prepared)
        self.assertIn('Tools that LOOK like they can change things', text)
        self.assertIn('submit_receivers_export', text)

    def test_summary_says_it_cannot_tell_when_no_mutators(self):
        prepared = self._lambda_plan(['count_alerts'])
        text = plain_language_summary(dict(LAMBDA_SPEC, allow=['count_alerts']), prepared)
        self.assertIn('none by name', text)
        self.assertIn('you must still read each tool name yourself', text)

    def test_summary_unknown_discovered_count_notes_rediscovery(self):
        prepared = self._lambda_plan(['count_alerts'])
        text = plain_language_summary(dict(LAMBDA_SPEC, allow=['count_alerts']), prepared)
        self.assertIn('re-discovered', text)

    def test_git_summary_says_nothing_is_added(self):
        prepared = plan(GIT_SPEC, 'a' * 64)
        text = plain_language_summary(GIT_SPEC, prepared)
        self.assertIn('Nothing is added to or changed in the gateway registry.', text)
        self.assertIn('there is nothing to roll back', text)


if __name__ == '__main__':
    unittest.main()
