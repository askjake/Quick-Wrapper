"""B2b hardening items (S7 export/receipt safety + S2 receipt persistence + cosmetic).

S7  Redaction of the real login/host/home for SHARED output (default Copy/Export), a
    clearly labelled FULL variant, and owner-only (0600) creation of every file the
    wizard writes for the user.
S2  'Save bootstrap receipt' persists the wizard-held receipt; it round-trips through
    host_is_wizard_lambda_only so Git/Local stay disabled next session.
Cosmetic  model.mutating_confirm_text([]) returns neutral text (no empty header); the
    non-empty text is byte-for-byte unchanged.

Pure-logic tests: no subprocess, tkinter, paramiko, SSH, Lambda or GUI. The real 0600
file-creation path is exercised on POSIX with a tempfile; the control flow (flags + mode
+ create-only) is also asserted with os.open stubbed so it runs on every platform.
"""
import json
import os
import stat
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import model
import quick_reg
from model import (redact_identity, secure_open, secure_write_text, secure_write_json,
                   mutating_confirm_text, host_is_wizard_lambda_only, REDACTED_USER,
                   REDACTED_HOST, FULL_VARIANT_WARNING)

USER = 'fakeuser'
HOST = '192.0.2.77'
LAMBDA_SPEC = {'host': HOST, 'user': USER, 'kind': 'lambda', 'target': 'epg-demo',
               'display_name': 'AQ EPG Demo',
               'url': 'https://abc.lambda-url.us-west-2.on.aws/mcp',
               'allow': ['count_alerts', 'submit_receivers_export']}
# Exactly the receipt remote_agent.bootstrap returns on a successful fresh install.
BOOT_RECEIPT = {'status': 'BOOTSTRAPPED', 'installed': True, 'state': 'READY',
                'gateway_root': '~/aq-mcp', 'registry_targets': 0, 'bundle_sha256': 'a' * 64,
                'aws_credentials': 'NOT_INSTALLED', 'quick_registration': 'MANUAL_REQUIRED'}


class S7Redaction(unittest.TestCase):
    def test_command_redaction_removes_login_host_and_home(self):
        text = 'ssh -T -q {}@{} /home/{}/aq-mcp/aq-run.sh epg'.format(USER, HOST, USER)
        red = redact_identity(text, USER, HOST)
        self.assertNotIn(USER, red)
        self.assertNotIn(HOST, red)
        self.assertNotIn('/home/' + USER, red)
        self.assertIn(REDACTED_USER + '@' + REDACTED_HOST, red)
        self.assertIn('/home/' + REDACTED_USER + '/aq-mcp', red)

    def test_redaction_leaves_no_original_value_anywhere(self):
        # A blob mixing the composite, the bare host and a home path under the user.
        text = ('login {u}@{h}; host {h}; home /home/{u}/aq-mcp/x; '
                'and a stray {u} token').format(u=USER, h=HOST)
        red = redact_identity(text, USER, HOST)
        self.assertNotIn(USER, red)
        self.assertNotIn(HOST, red)

    def test_full_instructions_keep_real_values_redacted_do_not(self):
        full = quick_reg.quick_instructions(LAMBDA_SPEC, redacted=False)
        red = quick_reg.quick_instructions(LAMBDA_SPEC, redacted=True)
        self.assertIn('{}@{}'.format(USER, HOST), full)
        self.assertNotIn(USER, red)
        self.assertNotIn(HOST, red)

    def test_default_quick_instructions_is_full_backcompat(self):
        # Existing callers that pass no flag still get the runnable (full) text.
        self.assertIn('{}@{}'.format(USER, HOST), quick_reg.quick_instructions(LAMBDA_SPEC))

    def test_config_export_variants(self):
        red = quick_reg.config_export_text(LAMBDA_SPEC, redacted=True)
        full = quick_reg.config_export_text(LAMBDA_SPEC, redacted=False)
        self.assertNotIn(USER, red)
        self.assertNotIn(HOST, red)
        self.assertIn('{}@{}'.format(USER, HOST), full)

    def test_variants_helper_labels_the_full_text(self):
        v = quick_reg.quick_instructions_variants(LAMBDA_SPEC)
        self.assertNotIn(USER, v['redacted'])
        self.assertIn('{}@{}'.format(USER, HOST), v['full'])
        self.assertTrue(v['full_labeled'].startswith(FULL_VARIANT_WARNING))
        self.assertIn('{}@{}'.format(USER, HOST), v['full_labeled'])

    def test_redact_identity_handles_none(self):
        self.assertIsNone(redact_identity(None, USER, HOST))


class S7FileMode(unittest.TestCase):
    @unittest.skipIf(os.name == 'nt', 'POSIX mode bits; Windows chmod only toggles read-only')
    def test_secure_write_text_creates_owner_only_file(self):
        d = tempfile.mkdtemp()
        p = os.path.join(d, 'r.json')
        secure_write_text(p, '{"a": 1}')
        mode = stat.S_IMODE(os.stat(p).st_mode)
        self.assertEqual(mode, 0o600)
        self.assertEqual(Path(p).read_text().strip(), '{"a": 1}')

    @unittest.skipIf(os.name == 'nt', 'POSIX create-only semantics tested here')
    def test_secure_write_text_never_overwrites(self):
        d = tempfile.mkdtemp()
        p = os.path.join(d, 'r.json')
        secure_write_text(p, 'first')
        with self.assertRaises(FileExistsError):
            secure_write_text(p, 'second')
        self.assertEqual(Path(p).read_text().strip(), 'first')

    @unittest.skipIf(os.name == 'nt', 'POSIX json write path')
    def test_secure_write_json_round_trips(self):
        d = tempfile.mkdtemp()
        p = os.path.join(d, 'rec.json')
        secure_write_json(p, BOOT_RECEIPT)
        self.assertEqual(json.loads(Path(p).read_text()), BOOT_RECEIPT)
        self.assertEqual(stat.S_IMODE(os.stat(p).st_mode), 0o600)

    def test_secure_open_requests_create_only_and_owner_only_mode(self):
        """Platform-independent: stub os.open to assert the flags and mode we request,
        so the intent is checked even where real O_CREAT is unavailable."""
        seen = {}

        def fake_open(path, flags, mode=0o777):
            seen['flags'] = flags
            seen['mode'] = mode
            return 99

        with mock.patch.object(model.os, 'open', side_effect=fake_open), \
             mock.patch.object(model.os, 'fchmod', create=True), \
             mock.patch.object(model.os, 'fstat', return_value=mock.Mock(st_mode=0o100600)), \
             mock.patch.object(model, '_is_windows', return_value=False):
            fd = secure_open('/tmp/whatever.json')
        self.assertEqual(fd, 99)
        self.assertTrue(seen['flags'] & os.O_CREAT)
        self.assertTrue(seen['flags'] & os.O_EXCL)   # create-only (never overwrite)
        self.assertTrue(seen['flags'] & os.O_WRONLY)
        self.assertEqual(seen['mode'], 0o600)

    def test_secure_open_refuses_group_world_accessible_result(self):
        """If the created file ends up group/other-accessible, secure_open removes it and raises."""
        unlinked = {}

        with mock.patch.object(model.os, 'open', return_value=5), \
             mock.patch.object(model.os, 'fchmod', create=True), \
             mock.patch.object(model.os, 'fstat', return_value=mock.Mock(st_mode=0o100644)), \
             mock.patch.object(model.os, 'close'), \
             mock.patch.object(model.os, 'unlink', side_effect=lambda p: unlinked.setdefault('p', p)), \
             mock.patch.object(model, '_is_windows', return_value=False):
            with self.assertRaises(OSError):
                secure_open('/tmp/bad.json')
        self.assertIn('p', unlinked)   # the unsafe file was removed


class S2SaveBootstrapReceipt(unittest.TestCase):
    @unittest.skipIf(os.name == 'nt', 'POSIX secure write for the round-trip')
    def test_saved_receipt_round_trips_through_classifier(self):
        d = tempfile.mkdtemp()
        p = os.path.join(d, 'boot.json')
        # Save exactly what the GUI/CLI would persist.
        secure_write_json(p, BOOT_RECEIPT)
        reloaded = json.loads(Path(p).read_text())
        # Reloading it next session must still mark the host Lambda-only.
        self.assertTrue(host_is_wizard_lambda_only(reloaded))
        self.assertEqual(stat.S_IMODE(os.stat(p).st_mode), 0o600)

    def test_only_a_real_bootstrap_receipt_is_lambda_only(self):
        self.assertTrue(host_is_wizard_lambda_only(BOOT_RECEIPT))
        for bad in [None, {}, {'status': 'GATEWAY_VERIFIED', 'state': 'READY', 'gateway_root': '~/aq-mcp'},
                    {'status': 'BOOTSTRAPPED', 'state': 'MISSING', 'gateway_root': '~/aq-mcp'}]:
            with self.subTest(bad=bad):
                self.assertFalse(host_is_wizard_lambda_only(bad))


class CosmeticMutatingConfirmText(unittest.TestCase):
    def test_empty_list_has_neutral_text_without_dangling_header(self):
        txt = mutating_confirm_text([])
        self.assertNotIn('Potentially MUTATING tool names were selected:', txt)
        self.assertIn('No tool names were name-flagged', txt)
        self.assertIn('NOT a safety verdict', txt)

    def test_non_empty_text_is_byte_for_byte_unchanged(self):
        expected = ('Potentially MUTATING tool names were selected:\n'
                    + 'submit_x, delete_y'
                    + '\n\nName heuristics are NOT a safety verdict. Did you inspect each tool '
                      'and intentionally approve exposing these actions?')
        self.assertEqual(mutating_confirm_text(['submit_x', 'delete_y']), expected)

    def test_non_empty_truncates_to_fourteen_like_before(self):
        names = ['t{}'.format(i) for i in range(20)]
        txt = mutating_confirm_text(names)
        self.assertIn(', '.join(names[:14]), txt)
        self.assertNotIn('t14', txt.split('\n\n')[0])


if __name__ == '__main__':
    unittest.main()
