import json
import os
import sys
import tempfile
import unittest
from unittest.mock import patch
from pathlib import Path
import base64, hashlib, io, zipfile
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import bootstrap_lib
import remote_agent
from deploy_lib import ConnectorDeployer, DeploymentError


def _bundle_with_valid_dummy_lock():
    """make_bundle(), but with requirements-gateway.lock replaced by a well-formed
    synthetic-hash lock so POSIX bootstrap tests can exercise the staging path. The
    shipped lock is a deliberate template that bootstrap() correctly refuses; these
    tests are about the create-only/staging logic, not the H-2 refusal (covered by
    TestGatewayLock)."""
    import base64 as _b64, io as _io, zipfile as _zip
    dummy=(b"# test-only synthetic lock\n"
           b"mcp==2.3.0 --hash=sha256:" + b"a"*64 + b"\n"
           b"botocore==1.43.113 --hash=sha256:" + b"b"*64 + b"\n"
           b"httpx2==2.13.1 --hash=sha256:" + b"c"*64 + b"\n")
    raw=_b64.b64decode(bootstrap_lib.make_bundle()['bundle_b64'])
    out=_io.BytesIO()
    zin=_zip.ZipFile(_io.BytesIO(raw))
    with _zip.ZipFile(out,'w',compression=_zip.ZIP_DEFLATED) as zf:
        for info in zin.infolist():
            data=dummy if info.filename=='requirements-gateway.lock' else zin.read(info.filename)
            zf.writestr(info, data)
    blob=out.getvalue()
    return {'bundle_b64':_b64.b64encode(blob).decode('ascii'),
            'bundle_sha256':hashlib.sha256(blob).hexdigest()}


class TestBundle(unittest.TestCase):
    def test_curated_payload_and_determinism(self):
        a=bootstrap_lib.make_bundle()
        b=bootstrap_lib.make_bundle()
        self.assertEqual(a['bundle_sha256'],b['bundle_sha256'])
        import base64,zipfile,io
        z=zipfile.ZipFile(io.BytesIO(base64.b64decode(a['bundle_b64'])))
        self.assertEqual(sorted(z.namelist()),sorted(bootstrap_lib.FILES))
        self.assertFalse(any('secret' in name or 'git_targets' in name or 'backup' in name for name in z.namelist()))


class FakeGateway:
    def __init__(self,state='MISSING'):
        self.state=state
        self.calls=[]
    def run(self,payload,timeout=65):
        self.calls.append(payload['op'])
        if payload['op']=='inspect':return {'state':self.state, 'installed':self.state!='MISSING'}
        if payload['op']=='bootstrap':
            self.state='READY';return {'status':'BOOTSTRAPPED'}
        if payload['op']=='repair_permissions':
            self.state='READY';return {'status':'PERMISSIONS_REPAIRED'}
        raise AssertionError(payload)


class TestBootstrapTransport(unittest.TestCase):
    def test_no_approval_is_read_only(self):
        g=FakeGateway()
        with self.assertRaises(DeploymentError):ConnectorDeployer(g).bootstrap()
        self.assertEqual(g.calls,[])
    def test_create_only_and_second_attempt_fails(self):
        g=FakeGateway()
        self.assertEqual(ConnectorDeployer(g).bootstrap(True)['status'],'BOOTSTRAPPED')
        self.assertEqual(g.calls,['inspect','bootstrap','inspect'])
        with self.assertRaises(DeploymentError):ConnectorDeployer(g).bootstrap(True)
        self.assertEqual(g.calls[-1],'inspect')
    def test_missing_is_not_permission_repair(self):
        g=FakeGateway()
        with self.assertRaises(DeploymentError):ConnectorDeployer(g).repair_permissions({'state':'MISSING'},True)
        self.assertEqual(g.calls,[])


class TestLineEndings(unittest.TestCase):
    """F1: the bundle must be LF even when the repo checkout is CRLF, and the
    gateway worker must refuse any CR in the shell entrypoint or a .py member."""
    def _bundle_members(self):
        z=zipfile.ZipFile(io.BytesIO(base64.b64decode(bootstrap_lib.make_bundle()['bundle_b64'])))
        return {n:z.read(n) for n in z.namelist()}

    def test_bundle_has_no_cr_for_any_member(self):
        for name,data in self._bundle_members().items():
            with self.subTest(member=name):
                self.assertNotIn(b'\r',data)

    def test_bundle_from_crlf_input_is_still_lf(self):
        # Feed make_bundle a CRLF payload tree and prove every member is LF-clean.
        with tempfile.TemporaryDirectory() as d:
            payload=Path(d)/'bootstrap_payload';payload.mkdir()
            members={'aq_registry.py':b"import sys\r\nx=1\r\n",
                     'aq-run.sh':b"#!/bin/bash\r\nexec echo\r\n",
                     'aq_mcp_stdio.py':b"y=2\r\n",'aq_check.py':b"z=3\r\n",
                     'requirements-gateway.txt':b"# h\r\nmcp==2.3.0\r\nbotocore==1.43.113\r\nhttpx2==2.13.1\r\n",
                     'requirements-gateway.lock':b"# lock\r\nmcp==2.3.0 --hash=sha256:" + b"a"*64 + b"\r\n"}
            for n,b in members.items():(payload/n).write_bytes(b)
            old=bootstrap_lib.PAYLOAD
            bootstrap_lib.PAYLOAD=payload
            try:
                z=zipfile.ZipFile(io.BytesIO(base64.b64decode(bootstrap_lib.make_bundle()['bundle_b64'])))
                for n in z.namelist():
                    self.assertNotIn(b'\r',z.read(n),n)
                # the pinned-deps gate (Security H-1) now matches on LF bytes
                self.assertIn(b'mcp==2.3.0\nbotocore==1.43.113\nhttpx2==2.13.1',
                              z.read('requirements-gateway.txt'))
            finally:
                bootstrap_lib.PAYLOAD=old

    def test_aq_run_shebang_is_exact_bin_bash(self):
        data=self._bundle_members()['aq-run.sh']
        self.assertEqual(data.split(b'\n',1)[0],b'#!/bin/bash')

    @unittest.skipUnless(os.name=='posix','Bootstrap worker is POSIX-only')
    def test_remote_bootstrap_refuses_cr_member(self):
        # Craft a bundle whose aq-run.sh contains CR (bypassing make_bundle's
        # normalisation) and prove bootstrap() refuses it before any install work.
        buf=io.BytesIO()
        payload={'aq_registry.py':b"x=1\n",'aq-run.sh':b"#!/bin/bash\r\nexec echo\r\n",
                 'aq_mcp_stdio.py':b"y=2\n",'aq_check.py':b"z=3\n",
                 'requirements-gateway.txt':b"mcp==2.3.0\nbotocore==1.43.113\nhttpx2==2.13.1\n",
                 'requirements-gateway.lock':b"mcp==2.3.0 --hash=sha256:" + b"a"*64 + b"\n"}
        with zipfile.ZipFile(buf,'w') as zf:
            for n,b in payload.items():zf.writestr(n,b)
        raw=buf.getvalue()
        req=dict(op='bootstrap',confirm='CREATE_FRESH_GATEWAY',install_dependencies=True,
                 bundle_b64=base64.b64encode(raw).decode('ascii'),
                 bundle_sha256=hashlib.sha256(raw).hexdigest())
        with tempfile.TemporaryDirectory() as home:
            old=(remote_agent.ROOT,remote_agent.REG,remote_agent.LOCK,remote_agent.BACKUPS)
            remote_agent.ROOT=Path(home)/'aq-mcp'
            remote_agent.REG=remote_agent.ROOT/'targets.json'
            remote_agent.LOCK=remote_agent.ROOT/'.aq-wizard.lock'
            remote_agent.BACKUPS=remote_agent.ROOT/'.wizard-backups'
            try:
                with self.assertRaisesRegex(ValueError,'CRLF|CR in gateway member'):
                    remote_agent.bootstrap(req)
                self.assertFalse(remote_agent.ROOT.exists())
            finally:
                remote_agent.ROOT,remote_agent.REG,remote_agent.LOCK,remote_agent.BACKUPS=old


@unittest.skipUnless(os.name=='posix','Remote filesystem/permissions are POSIX-only')
class TestRemoteBootstrap(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.home=Path(self.tmp.name)
        self.old=(remote_agent.ROOT,remote_agent.REG,remote_agent.LOCK,remote_agent.BACKUPS)
        remote_agent.ROOT=self.home/'aq-mcp'
        remote_agent.REG=remote_agent.ROOT/'targets.json'
        remote_agent.LOCK=remote_agent.ROOT/'.aq-wizard.lock'
        remote_agent.BACKUPS=remote_agent.ROOT/'.wizard-backups'
    def tearDown(self):
        remote_agent.ROOT,remote_agent.REG,remote_agent.LOCK,remote_agent.BACKUPS=self.old
        self.tmp.cleanup()
    def mock_proc(self,args,**kwargs):
        if len(args)>2 and args[1:3]==['-m','venv']:
            v=Path(args[3]);(v/'bin').mkdir(parents=True)
            (v/'bin/python').symlink_to(sys.executable)
        class Result:returncode=0
        return Result()
    def test_missing_gateway_read_only_inspect(self):
        self.assertEqual(remote_agent.safe_info()['state'],'MISSING')
        self.assertFalse(remote_agent.ROOT.exists())
    def test_new_installer_staged_and_create_only(self):
        req=dict(op='bootstrap',confirm='CREATE_FRESH_GATEWAY',install_dependencies=True,**_bundle_with_valid_dummy_lock())
        with patch.object(remote_agent.subprocess,'run',side_effect=self.mock_proc):
            r=remote_agent.bootstrap(req)
        self.assertEqual(r['status'],'BOOTSTRAPPED')
        self.assertEqual(remote_agent.gateway_state()['state'],'READY')
        self.assertEqual(json.loads(remote_agent.REG.read_text()),{'targets':{}})
        self.assertEqual(remote_agent.ROOT.stat().st_mode & 0o777,0o700)
        self.assertEqual(remote_agent.REG.stat().st_mode & 0o777,0o600)
        with self.assertRaisesRegex(ValueError,'exists'):
            remote_agent.bootstrap(req)
    def test_bootstrap_requires_approval_and_integrity(self):
        req=dict(confirm='NO',install_dependencies=True,**bootstrap_lib.make_bundle())
        with self.assertRaisesRegex(ValueError,'approval'): remote_agent.bootstrap(req)
        req['confirm']='CREATE_FRESH_GATEWAY'
        req['bundle_sha256']='0'*64
        with self.assertRaisesRegex(ValueError,'checksum'): remote_agent.bootstrap(req)
        self.assertFalse(remote_agent.ROOT.exists())
    def test_existing_group_writable_inspect_then_repair(self):
        root=remote_agent.ROOT
        root.mkdir(mode=0o755)
        for n in ('aq_registry.py','aq-run.sh','aq_mcp_stdio.py','aq_check.py','targets.json'):
            (root/n).write_text('{}' if n=='targets.json' else 'x')
        v=root/'venv/bin';v.mkdir(parents=True)
        (v/'python').symlink_to(sys.executable)
        remote_agent.REG.write_text('{"targets":{}}')
        os.chmod(root,0o775)
        os.chmod(remote_agent.REG,0o664)
        before=remote_agent.safe_info()
        self.assertEqual(before['state'],'PERMISSIONS_NEED_REPAIR')
        with self.assertRaisesRegex(ValueError,'approval'):
            remote_agent.repair_permissions({'mode_issues':before['mode_issues']})
        with self.assertRaisesRegex(ValueError,'unsafe write permissions'):
            remote_agent.good_root()
        result=remote_agent.repair_permissions({'confirm':'REPAIR_OWNED_CORE_PERMISSIONS','mode_issues':before['mode_issues']})
        self.assertEqual(result['state'],'READY')
        remote_agent.good_root()


class TestGatewayLock(unittest.TestCase):
    """F4 (Security H-2): the hash-pinned gateway lock is bundled, CR-free, and the
    remote agent's validator fails closed on a template or malformed lock and accepts
    a well-formed (synthetic-hash) lock."""
    DUMMY = 'a' * 64  # obviously-synthetic 64-hex sha256, test-only

    def _lock(self, body):
        return body.encode('utf-8') if isinstance(body, str) else body

    def test_lock_is_in_the_bundle_and_cr_free(self):
        z = zipfile.ZipFile(io.BytesIO(base64.b64decode(bootstrap_lib.make_bundle()['bundle_b64'])))
        self.assertIn('requirements-gateway.lock', z.namelist())
        self.assertNotIn(b'\r', z.read('requirements-gateway.lock'))
        # ships as a template until the user regenerates it
        self.assertIn(b'REPLACE_WITH_REAL_HASH', z.read('requirements-gateway.lock'))

    def test_lock_is_in_the_member_allowlist(self):
        self.assertIn('requirements-gateway.lock', bootstrap_lib.FILES)
        self.assertIn('requirements-gateway.lock', bootstrap_lib.LF_NORMALISE)
        self.assertIn('requirements-gateway.lock', remote_agent.BOOTSTRAP_FILES)

    def test_agent_accepts_wellformed_dummy_lock(self):
        body = ('# lock\n'
                'mcp==2.3.0 --hash=sha256:' + self.DUMMY + '\n'
                'botocore==1.43.113 --hash=sha256:' + ('b' * 64) + '\n'
                'httpx2==2.13.1 --hash=sha256:' + ('c' * 64) + '\n')
        # Must not raise.
        remote_agent.validate_gateway_lock(self._lock(body))

    def test_agent_accepts_multi_hash_continuation(self):
        body = ('mcp==2.3.0 \\\n    --hash=sha256:' + self.DUMMY +
                ' \\\n    --hash=sha256:' + ('d' * 64) + '\n')
        remote_agent.validate_gateway_lock(self._lock(body))

    def test_agent_refuses_placeholder_lock(self):
        body = 'mcp==2.3.0 --hash=sha256:REPLACE_WITH_REAL_HASH\n'
        with self.assertRaisesRegex(ValueError, 'template|REPLACE_WITH_REAL_HASH'):
            remote_agent.validate_gateway_lock(self._lock(body))

    def test_agent_refuses_missing_hash(self):
        with self.assertRaisesRegex(ValueError, 'no --hash'):
            remote_agent.validate_gateway_lock(self._lock('mcp==2.3.0\n'))

    def test_agent_refuses_short_hash(self):
        body = 'mcp==2.3.0 --hash=sha256:' + ('a' * 63) + '\n'
        with self.assertRaises(ValueError):
            remote_agent.validate_gateway_lock(self._lock(body))

    def test_agent_refuses_non_hex_hash(self):
        body = 'mcp==2.3.0 --hash=sha256:' + ('g' * 64) + '\n'
        with self.assertRaisesRegex(ValueError, 'malformed'):
            remote_agent.validate_gateway_lock(self._lock(body))

    def test_agent_refuses_empty_lock(self):
        with self.assertRaisesRegex(ValueError, 'empty'):
            remote_agent.validate_gateway_lock(self._lock('# only a comment\n\n'))


class TestMakeGatewayLock(unittest.TestCase):
    """F4 (tooling): tools/make_gateway_lock.py turns a directory of downloaded wheels
    (the FULL transitive closure, since the gateway installs with --no-deps) into the
    hash-pinned lock. Stdlib only, no network. These exercise build_lock_text directly.

    build_lock_text(pins, wheel_dir) returns (text, closure) where closure is a sorted
    list of (display_name, version)."""
    def setUp(self):
        import importlib
        sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tools'))
        self.mg = importlib.import_module('make_gateway_lock')
        self.pins = self.mg.parse_pins('mcp==2.3.0\nbotocore==1.43.113\nhttpx2==2.13.1\n')

    def _closure_wheels(self):
        # 3 top-level pins + 2 transitive deps = the realistic closure for --no-deps.
        return {'mcp-2.3.0-py3-none-any.whl': b'wheel-mcp',
                'botocore-1.43.113-py3-none-any.whl': b'wheel-botocore',
                'httpx2-2.13.1-py3-none-any.whl': b'wheel-httpx2',
                'anyio-4.4.0-py3-none-any.whl': b'wheel-anyio',
                'certifi-2024.8.30-py3-none-any.whl': b'wheel-certifi'}

    def _populate(self, d, files):
        for name, body in files.items():
            (Path(d) / name).write_bytes(body)

    def test_generates_full_closure_including_transitive_deps(self):
        with tempfile.TemporaryDirectory() as d:
            self._populate(d, self._closure_wheels())
            text, closure = self.mg.build_lock_text(self.pins, d)
        # one --hash token per wheel (5), one line per distinct name (5)
        self.assertEqual(text.count('--hash=sha256:'), 5)
        names = {n for n, _ in closure}
        self.assertEqual(names, {'mcp', 'botocore', 'httpx2', 'anyio', 'certifi'})
        for pin in ('mcp==2.3.0', 'botocore==1.43.113', 'httpx2==2.13.1',
                    'anyio==4.4.0', 'certifi==2024.8.30'):
            self.assertIn(pin + ' --hash=sha256:', text)
        # a generated lock must satisfy the remote agent's validator
        remote_agent.validate_gateway_lock(text.encode('utf-8'))

    def test_multiple_wheels_same_name_version_become_multiple_hashes(self):
        files = dict(self._closure_wheels())
        # a second compatible wheel for mcp at the SAME version
        files['mcp-2.3.0-cp310-cp310-manylinux2014_x86_64.whl'] = b'wheel-mcp-manylinux'
        with tempfile.TemporaryDirectory() as d:
            self._populate(d, files)
            text, closure = self.mg.build_lock_text(self.pins, d)
        mcp_line = [ln for ln in text.splitlines() if ln.startswith('mcp==2.3.0 ')][0]
        self.assertEqual(mcp_line.count('--hash=sha256:'), 2)
        # still one closure entry for mcp
        self.assertEqual(sum(1 for n, _ in closure if n == 'mcp'), 1)

    def test_hash_matches_sha256_of_file_bytes(self):
        with tempfile.TemporaryDirectory() as d:
            self._populate(d, self._closure_wheels())
            text, _ = self.mg.build_lock_text(self.pins, d)
            expected = hashlib.sha256((Path(d) / 'anyio-4.4.0-py3-none-any.whl').read_bytes()).hexdigest()
        self.assertIn('anyio==4.4.0 --hash=sha256:' + expected, text)

    def test_refuses_missing_top_level_pin(self):
        files = dict(self._closure_wheels())
        del files['httpx2-2.13.1-py3-none-any.whl']
        with tempfile.TemporaryDirectory() as d:
            self._populate(d, files)
            with self.assertRaisesRegex(ValueError, 'Top-level pin'):
                self.mg.build_lock_text(self.pins, d)

    def test_refuses_version_conflict(self):
        files = dict(self._closure_wheels())
        # anyio at two versions -> ambiguous under --no-deps -> refuse
        files['anyio-4.5.0-py3-none-any.whl'] = b'wheel-anyio-newer'
        with tempfile.TemporaryDirectory() as d:
            self._populate(d, files)
            with self.assertRaisesRegex(ValueError, 'two versions'):
                self.mg.build_lock_text(self.pins, d)

    def test_refuses_non_wheel_file(self):
        files = dict(self._closure_wheels())
        files['httpx2-2.13.1.tar.gz'] = b'sdist-not-allowed'
        with tempfile.TemporaryDirectory() as d:
            self._populate(d, files)
            with self.assertRaisesRegex(ValueError, 'Non-wheel file'):
                self.mg.build_lock_text(self.pins, d)

    def test_allows_optional_readme(self):
        files = dict(self._closure_wheels())
        files['README.txt'] = b'how these wheels were obtained'
        with tempfile.TemporaryDirectory() as d:
            self._populate(d, files)
            text, closure = self.mg.build_lock_text(self.pins, d)
        # README ignored; closure still the 5 wheels
        self.assertEqual(len(closure), 5)
        self.assertEqual(text.count('--hash=sha256:'), 5)

    def test_refuses_empty_wheel_dir(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaisesRegex(ValueError, 'no wheels|Top-level pin'):
                self.mg.build_lock_text(self.pins, d)

    def test_canonical_name_normalisation(self):
        # underscores / dots / case in a wheel filename normalise to the pin's canonical name
        self.assertEqual(self.mg.canonical('Foo_Bar.Baz'), 'foo-bar-baz')
        cname, display, version = self.mg.wheel_name_version('Foo_Bar-1.2.3-py3-none-any.whl')
        self.assertEqual(cname, 'foo-bar')
        self.assertEqual(version, '1.2.3')


class TestLogFilePermissions(unittest.TestCase):
    """S8: the proxy's log file (aq-mcp.log by default) must be created 0600 and an
    existing over-open log must be repaired to 0600. We extract _secure_log_file from
    the shipped aq_mcp_stdio.py source and exec it in isolation, because the module
    itself imports botocore/mcp which are not installed in the test environment."""
    def _load_secure_log_file(self):
        src_path = (Path(__file__).resolve().parents[1]
                    / 'bootstrap_payload' / 'aq_mcp_stdio.py')
        text = src_path.read_text(encoding='utf-8')
        start = text.index('def _secure_log_file(')
        # the function ends right before the module-level 'try:' that installs the handler
        end = text.index('\ntry:', start)
        func_src = text[start:end]
        ns = {'os': os}
        exec(compile(func_src, str(src_path), 'exec'), ns)
        return ns['_secure_log_file']

    @unittest.skipUnless(os.name == 'posix', 'File-mode enforcement is POSIX-only')
    def test_new_log_is_created_0600_despite_umask(self):
        fn = self._load_secure_log_file()
        old_umask = os.umask(0o022)
        try:
            with tempfile.TemporaryDirectory() as d:
                p = os.path.join(d, 'aq-mcp.log')
                stream = fn(p)
                try:
                    stream.write('hello\n'); stream.flush()
                finally:
                    stream.close()
                self.assertEqual(os.stat(p).st_mode & 0o777, 0o600)
        finally:
            os.umask(old_umask)

    @unittest.skipUnless(os.name == 'posix', 'File-mode enforcement is POSIX-only')
    def test_existing_overopen_log_is_repaired_to_0600(self):
        fn = self._load_secure_log_file()
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'aq-mcp.log')
            with open(p, 'w', encoding='utf-8') as fh:
                fh.write('old\n')
            os.chmod(p, 0o644)
            stream = fn(p)
            try:
                stream.write('more\n'); stream.flush()
            finally:
                stream.close()
            self.assertEqual(os.stat(p).st_mode & 0o777, 0o600)
            # append semantics: original content preserved
            self.assertIn('old', open(p, encoding='utf-8').read())
