"""CLI tests for the stage-2a Quick Import subcommands in cli.py.

Stdlib unittest only. Temp dirs; runnable on Windows and Linux. LF endings. No
network, no subprocess, no Quick UI. Each test drives cli.main([...]) IN-PROCESS
and captures stdout/stderr, asserting exit codes, printed lines, refusals and the
NO-LEAK guarantee (a sentinel placed in args/env/source/other-connector names, and
the import file content, must never appear in stdout/stderr of the read commands).

The specs below are linux-ssh Lambda specs with placeholder identity (fakeuser,
gateway.example.com) so quick_connector() builds a connector with no filesystem or
network access: command='ssh', id='aq-<target>', args re-derived from the spec.
"""
import contextlib
import io
import json
import os
import sys
import tempfile
import unittest
from unittest import mock

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import cli
import quick_reg

# A valid linux-ssh Lambda spec (placeholders only; no real identity).
SPEC = {'transport': 'linux-ssh', 'host': 'gateway.example.com', 'user': 'fakeuser',
        'kind': 'lambda', 'target': 'rtr-demo', 'display_name': 'rtr demo',
        'url': 'https://abc123.lambda-url.us-east-1.on.aws/mcp',
        'allow': ['get_rating_mappings']}

# The connector name an import of SPEC uses (stable id) and the re-derived wire.
NAME = 'aq-rtr-demo'
COMMAND = 'ssh'
ARGS = ['-T', '-q', 'fakeuser@gateway.example.com',
        '/home/fakeuser/aq-mcp/aq-run.sh', 'rtr-demo']

SENTINEL = 'SENTINEL-DO-NOT-LEAK-7f3a9c'


def run_cli(argv):
    """Run cli.main(argv) in-process, mirroring the real __main__ wrapper:
    argparse p.error raises SystemExit(2); any other exception is mapped to
    exit 1 with an 'ERROR: ...' line on stderr (as cli.__main__ does)."""
    out, err = io.StringIO(), io.StringIO()
    code = None
    with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
        try:
            code = cli.main(argv)
        except SystemExit as e:
            code = e.code if isinstance(e.code, int) else 2
        except Exception as e:  # cli.__main__ prints ERROR and exits 1
            print('ERROR: ' + str(e), file=sys.stderr)
            code = 1
    return code, out.getvalue(), err.getvalue()


def write_manifest(path, spec=SPEC):
    with open(path, 'w', encoding='utf-8', newline='\n') as f:
        f.write(json.dumps(spec))
    return path


def write_config(path, servers):
    with open(path, 'w', encoding='utf-8', newline='\n') as f:
        f.write(json.dumps({'mcpServers': servers}, indent=2))
    return path


def observed_entry(name, command, args, suffix='ebb7602a',
                   startup=None, auto_disabled=None, env=None, disabled=None,
                   source='C:/Users/<user>/imp/x.json'):
    entry = {'command': command, 'args': list(args),
             '_quick': {'name': name, 'source': source, 'upstream_id': name}}
    if startup is not None:
        entry['_quick']['startupTimeout'] = startup
    if auto_disabled is not None:
        entry['_quick']['autoDisabled'] = auto_disabled
    if env is not None:
        entry['env'] = env
    if disabled is not None:
        entry['disabled'] = disabled
    return {name + '-' + suffix: entry}


class ImportFileCmd(unittest.TestCase):
    def setUp(self):
        self.root = tempfile.mkdtemp()
        self.manifest = write_manifest(os.path.join(self.root, 'spec.json'))
        self.out = tempfile.mkdtemp()  # a plain non-repo, non-synced dir

    def test_happy_path_prints_metadata_and_warning(self):
        code, out, err = run_cli(['import-file', self.manifest, '--out-dir', self.out])
        self.assertEqual(code, 0)
        self.assertIn('path', out)
        self.assertIn('sha256', out)
        self.assertIn('bytes', out)
        self.assertIn(NAME, out)                      # the connector name is printed
        self.assertIn('WARNING', out)                 # loud login/host warning
        self.assertIn('delete', out.lower())
        self.assertIn('Import', out)                  # import_instructions text
        # exactly one file was written into out-dir
        files = [f for f in os.listdir(self.out) if f.endswith('.json')]
        self.assertEqual(len(files), 1)

    def test_warning_says_not_protected_on_windows(self):
        # F-1: the loud warning must plainly state the file is NOT
        # permission-protected on Windows and name login + gateway address.
        code, out, err = run_cli(['import-file', self.manifest, '--out-dir', self.out])
        self.assertEqual(code, 0)
        low = out.lower()
        self.assertIn('not permission-protected', low)
        self.assertIn('login', low)
        self.assertIn('gateway address', low)
        self.assertNotIn('acl', low)                   # no ACL-protection claim

    def test_output_does_not_contain_file_content(self):
        # The import file content (the connector command/args values) must not be
        # echoed. We assert the full arg strings (content values) are absent.
        code, out, err = run_cli(['import-file', self.manifest, '--out-dir', self.out])
        self.assertEqual(code, 0)
        self.assertNotIn('/home/fakeuser/aq-mcp/aq-run.sh', out)
        self.assertNotIn('fakeuser@gateway.example.com', out)

    def test_missing_out_dir_errors(self):
        code, out, err = run_cli(['import-file', self.manifest])
        self.assertEqual(code, 2)
        self.assertIn('out-dir', err)

    def test_missing_manifest_errors(self):
        code, out, err = run_cli(['import-file', '--out-dir', self.out])
        self.assertEqual(code, 2)

    def test_refuses_synced_out_dir(self):
        synced = os.path.join(self.root, 'OneDrive', 'cfg')
        os.makedirs(synced)
        code, out, err = run_cli(['import-file', self.manifest, '--out-dir', synced])
        self.assertEqual(code, 2)
        self.assertIn('synced', err.lower())

    def test_allow_synced_override(self):
        synced = os.path.join(self.root, 'OneDrive', 'cfg')
        os.makedirs(synced)
        code, out, err = run_cli(['import-file', self.manifest,
                                  '--out-dir', synced, '--allow-synced'])
        self.assertEqual(code, 0)

    def test_refuses_git_work_tree_out_dir(self):
        repo = os.path.join(self.root, 'repo')
        os.makedirs(os.path.join(repo, '.git'))
        dest = os.path.join(repo, 'cfg')
        os.makedirs(dest)
        code, out, err = run_cli(['import-file', self.manifest, '--out-dir', dest])
        self.assertEqual(code, 2)
        self.assertIn('REFUSED', err)

    def test_bad_name_spec_refused(self):
        # An invalid target (uppercase/underscore) makes validate_spec_for_host
        # raise ValidationError BEFORE the import path; the __main__ wrapper maps
        # that to exit 1 with an ERROR line.
        bad = dict(SPEC); bad['target'] = 'Bad_Target'
        m = write_manifest(os.path.join(self.root, 'bad.json'), bad)
        code, out, err = run_cli(['import-file', m, '--out-dir', self.out])
        self.assertEqual(code, 1)
        self.assertIn('ERROR', err)


class ImportCheckCmd(unittest.TestCase):
    def setUp(self):
        self.root = tempfile.mkdtemp()
        # a fake Quick home with one profile config
        self.home = os.path.join(self.root, '.quickwork')
        prof = os.path.join(self.home, 'profiles', 'acctA')
        os.makedirs(prof)
        self.cfg = os.path.join(prof, 'mcp_config.json')

    def test_no_collision(self):
        write_config(self.cfg, observed_entry('epg', 'ssh', ['x']))
        code, out, err = run_cli(['import-check', '--name', NAME,
                                  '--profile-dir', self.home])
        self.assertEqual(code, 0)
        self.assertIn('NO_COLLISION', out)

    def test_collision(self):
        write_config(self.cfg, observed_entry(NAME, 'ssh', ['x']))
        code, out, err = run_cli(['import-check', '--name', NAME,
                                  '--profile-dir', self.home])
        self.assertEqual(code, 0)
        self.assertIn('COLLISION', out)
        self.assertIn('collisions: 1', out)

    def test_empty_home_no_collision(self):
        empty = tempfile.mkdtemp()
        code, out, err = run_cli(['import-check', '--name', NAME,
                                  '--profile-dir', empty])
        self.assertEqual(code, 0)
        self.assertIn('NO_COLLISION', out)

    def test_missing_name_errors(self):
        code, out, err = run_cli(['import-check', '--profile-dir', self.home])
        self.assertEqual(code, 2)
        self.assertIn('name', err)

    def test_no_leak_other_connector(self):
        # The matching entry plus a DIFFERENT entry whose name/args/env/source all
        # carry the sentinel. import-check must not echo it.
        servers = observed_entry(NAME, 'ssh', ['x'])
        servers['other-99999999'] = {'command': SENTINEL, 'args': [SENTINEL],
                                     'env': {SENTINEL: SENTINEL},
                                     '_quick': {'name': SENTINEL, 'source': SENTINEL,
                                                'upstream_id': SENTINEL}}
        write_config(self.cfg, servers)
        code, out, err = run_cli(['import-check', '--name', NAME,
                                  '--profile-dir', self.home])
        self.assertEqual(code, 0)
        self.assertNotIn(SENTINEL, out)
        self.assertNotIn(SENTINEL, err)


class ImportVerifyCmd(unittest.TestCase):
    def setUp(self):
        self.root = tempfile.mkdtemp()
        self.manifest = write_manifest(os.path.join(self.root, 'spec.json'))
        self.cfg = os.path.join(self.root, 'mcp_config.json')

    def test_found_match_exit_0(self):
        write_config(self.cfg, observed_entry(NAME, COMMAND, ARGS))
        code, out, err = run_cli(['import-verify', self.manifest, '--name', NAME,
                                  '--config-path', self.cfg])
        self.assertEqual(code, 0)
        self.assertIn('FOUND_MATCH', out)
        self.assertIn('has_startup_timeout', out)
        self.assertIn('next:', out)

    def test_found_match_timeout_in_quick(self):
        write_config(self.cfg, observed_entry(NAME, COMMAND, ARGS, startup=30))
        code, out, err = run_cli(['import-verify', self.manifest, '--name', NAME,
                                  '--config-path', self.cfg])
        self.assertEqual(code, 0)
        self.assertIn('FOUND_MATCH', out)
        self.assertIn('startup_timeout     : 30', out)
        self.assertIn('startup_timeout_at  : _quick', out)

    def test_not_found_exit_2(self):
        write_config(self.cfg, observed_entry('epg', COMMAND, ARGS))
        code, out, err = run_cli(['import-verify', self.manifest, '--name', NAME,
                                  '--config-path', self.cfg])
        self.assertEqual(code, 2)
        self.assertIn('NOT_FOUND', out)
        self.assertIn('next:', out)

    def test_mismatch_args_exit_2(self):
        write_config(self.cfg, observed_entry(NAME, COMMAND, ['-T', '-q', 'x']))
        code, out, err = run_cli(['import-verify', self.manifest, '--name', NAME,
                                  '--config-path', self.cfg])
        self.assertEqual(code, 2)
        self.assertIn('FOUND_MISMATCH_ARGS', out)

    def test_missing_name_errors(self):
        code, out, err = run_cli(['import-verify', self.manifest,
                                  '--config-path', self.cfg])
        self.assertEqual(code, 2)
        self.assertIn('name', err)

    def test_missing_manifest_errors(self):
        code, out, err = run_cli(['import-verify', '--name', NAME,
                                  '--config-path', self.cfg])
        self.assertEqual(code, 2)

    def test_no_leak_other_connector_and_values(self):
        servers = observed_entry(NAME, COMMAND, ARGS)
        servers['other-99999999'] = {'command': SENTINEL, 'args': [SENTINEL],
                                     'env': {SENTINEL: SENTINEL},
                                     '_quick': {'name': SENTINEL, 'source': SENTINEL,
                                                'upstream_id': SENTINEL}}
        write_config(self.cfg, servers)
        code, out, err = run_cli(['import-verify', self.manifest, '--name', NAME,
                                  '--config-path', self.cfg])
        self.assertEqual(code, 0)
        self.assertNotIn(SENTINEL, out)
        self.assertNotIn(SENTINEL, err)

    def test_verify_does_not_print_args_or_source(self):
        write_config(self.cfg, observed_entry(NAME, COMMAND, ARGS))
        code, out, err = run_cli(['import-verify', self.manifest, '--name', NAME,
                                  '--config-path', self.cfg])
        # stored args / source path must not appear in the output.
        self.assertNotIn('/home/fakeuser/aq-mcp/aq-run.sh', out)
        self.assertNotIn('C:/Users/<user>/imp/x.json', out)


class SyncedMarkerSingleSource(unittest.TestCase):
    """F-2 / Tester D-1: the synced-folder marker list must be single-sourced in
    quick_reg. cli._path_looks_synced must delegate to quick_reg.path_looks_synced
    so the two can never diverge again. This test fails if they differ on ANY path
    in the table below, or if the CLI stops using the shared implementation."""

    PATHS = [
        'C:/Users/<user>/OneDrive/cfg',
        'C:/Users/<user>/OneDrive - Contoso/cfg',
        'C:/Users/<user>/Dropbox/cfg',
        'C:/Users/<user>/Google Drive/cfg',
        'C:/Users/<user>/GoogleDrive/cfg',
        'C:/Users/<user>/iCloud/cfg',
        'C:/Users/<user>/iCloud Drive/cfg',          # library-only marker pre-fix
        'C:/Users/<user>/iCloudrive/cfg',            # library-only marker pre-fix
        'C:/Users/<user>/Documents/cfg',             # not synced
        'C:/Users/<user>/MyDrive/cfg',               # not a known marker
        '/home/<user>/Dropbox/x',
        '/home/<user>/plain/x',
    ]

    def test_cli_and_lib_agree_on_every_path(self):
        for p in self.PATHS:
            self.assertEqual(
                cli._path_looks_synced(p), quick_reg.path_looks_synced(p),
                'divergence on %r: cli=%r lib=%r' % (
                    p, cli._path_looks_synced(p), quick_reg.path_looks_synced(p)))

    def test_icloud_drive_is_caught_by_both(self):
        # The exact marker that used to be in the library list but NOT the CLI's.
        p = 'C:/Users/<user>/iCloud Drive/cfg'
        self.assertTrue(quick_reg.path_looks_synced(p))
        self.assertTrue(cli._path_looks_synced(p))

    def test_case_insensitive_component_match(self):
        self.assertTrue(cli._path_looks_synced('C:/Users/<user>/onedrive/cfg'))
        self.assertTrue(cli._path_looks_synced('C:/Users/<user>/ONEDRIVE/cfg'))

    def test_shared_marker_object_single_source(self):
        # The emitter's marker list and the public alias are the SAME object; the
        # CLI delegates to the public helper, so no second copy exists in cli.
        self.assertIs(quick_reg.SYNCED_PATH_MARKERS, quick_reg._SYNCED_PATH_MARKERS)
        self.assertIs(cli.path_looks_synced, quick_reg.path_looks_synced)


class RegressionOldCommandsParse(unittest.TestCase):
    """The argument parser must still accept the pre-existing commands unchanged.
    We only assert the PARSER/dispatch still routes them (not full execution),
    using argument errors / early p.error paths that do not require a gateway."""

    def test_operation_choices_unchanged(self):
        # Each legacy op must still be a valid choice: a known op with missing
        # required args exits 2 (argparse p.error), and NEVER 'invalid choice'.
        legacy = ['inspect', 'discover', 'plan', 'apply', 'export', 'rollback',
                  'bootstrap', 'repair-permissions', 'save-bootstrap-receipt']
        for op in legacy:
            code, out, err = run_cli([op])  # missing required args
            self.assertEqual(code, 2, '%s should p.error (exit 2), got %s' % (op, code))
            self.assertNotIn('invalid choice', err, '%s must remain a valid op' % op)

    def test_unknown_operation_rejected(self):
        code, out, err = run_cli(['not-a-real-op'])
        self.assertEqual(code, 2)
        self.assertIn('invalid choice', err)

    def test_export_requires_output_file(self):
        root = tempfile.mkdtemp()
        m = write_manifest(os.path.join(root, 'spec.json'))
        code, out, err = run_cli(['export', m])
        self.assertEqual(code, 2)
        self.assertIn('output-file', err)

    def test_new_ops_are_choices(self):
        for op in ('import-file', 'import-check', 'import-verify'):
            code, out, err = run_cli([op])
            self.assertEqual(code, 2)
            self.assertNotIn('invalid choice', err)


class FollowupCautionBeforeEmit(unittest.TestCase):
    """Security cond A / F-1 timing: the import-file command must write a placement
    CAUTION to stderr BEFORE emit_quick_import_file() creates the file, and must
    still print that caution for a REFUSED destination (which returns before emit).

    Call-order is proven with two spies: a recording stderr whose write() appends
    'stderr-caution' the first time it sees the word CAUTION, and a wrapper around
    cli.emit_quick_import_file that appends 'emit' when called. We assert the
    stderr caution event is recorded and precedes the emit event."""

    def setUp(self):
        self.root = tempfile.mkdtemp()
        self.manifest = write_manifest(os.path.join(self.root, 'spec.json'))
        self.out = tempfile.mkdtemp()  # plain non-repo, non-synced dir

    def _run_with_order_spies(self, out_dir, extra_args=None, want_stdout=False):
        events = []

        class RecordingStderr:
            def write(self_inner, s):
                if 'CAUTION' in s and 'stderr-caution' not in events:
                    events.append('stderr-caution')
                return len(s)
            def flush(self_inner):
                pass

        real_emit = cli.emit_quick_import_file

        def spy_emit(*a, **k):
            events.append('emit')
            return real_emit(*a, **k)

        argv = ['import-file', self.manifest, '--out-dir', out_dir] + (extra_args or [])
        # Patch cli.sys.stderr (the handler prints with file=sys.stderr) and the
        # emitter the handler calls. Capture stdout separately so it is not noisy.
        import io as _io
        out_buf = _io.StringIO()
        with mock.patch.object(cli.sys, 'stderr', RecordingStderr()), \
             mock.patch.object(cli, 'emit_quick_import_file', spy_emit), \
             mock.patch.object(cli.sys, 'stdout', out_buf):
            try:
                code = cli.main(argv)
            except SystemExit as e:
                code = e.code if isinstance(e.code, int) else 2
        if want_stdout:
            return code, events, out_buf.getvalue()
        return code, events

    def test_caution_printed_before_emit_on_success(self):
        code, events = self._run_with_order_spies(self.out)
        self.assertEqual(code, 0)
        self.assertIn('stderr-caution', events)
        self.assertIn('emit', events)
        self.assertLess(events.index('stderr-caution'), events.index('emit'),
                        'caution must be written to stderr BEFORE emit runs; '
                        'events=%r' % (events,))

    def test_refused_synced_dest_still_prints_caution_and_no_success(self):
        # A synced destination is refused BEFORE emit (returns 2). The upfront
        # caution must still have been printed, and emit must NOT have run.
        synced = os.path.join(self.root, 'OneDrive', 'cfg')
        os.makedirs(synced)
        code, events = self._run_with_order_spies(synced)
        self.assertEqual(code, 2)                    # refused
        self.assertIn('stderr-caution', events)      # caution still printed
        self.assertNotIn('emit', events)             # and no file was written

    def test_refused_git_tree_dest_still_prints_caution(self):
        # NOTE: unlike the synced pre-check, the git-tree refusal happens INSIDE
        # emit_quick_import_file (via _dest_inside_repo), so emit IS entered here
        # and then raises ImportFileError -> handler returns 2. We therefore assert
        # (a) the upfront caution was printed, (b) it preceded the emit call, and
        # (c) no success line ('Import file written') reached stdout. We do NOT
        # assert emit was skipped (it is the refusing layer for this case).
        repo = os.path.join(self.root, 'repo')
        os.makedirs(os.path.join(repo, '.git'))
        dest = os.path.join(repo, 'cfg')
        os.makedirs(dest)
        code, events, out = self._run_with_order_spies(dest, want_stdout=True)
        self.assertEqual(code, 2)                    # refused inside git tree
        self.assertIn('stderr-caution', events)      # caution still printed
        self.assertLess(events.index('stderr-caution'), events.index('emit'))
        self.assertNotIn('Import file written', out)  # no success message


if __name__ == '__main__':
    unittest.main(verbosity=2)
