"""D-2 allow-list floor marker — bootstrap-side tests (piece 2a).

These tests prove that the wizard's bootstrap creates the policy marker
(gateway_policy.json) correctly and that the marker it writes is accepted as floor-ON
by BOTH payload readers (the launcher aq_registry._marker_floor_on and the proxy
aq_mcp_stdio._marker_floor_on). They are stdlib-only, use temp dirs, run on Windows and
Linux, make no network calls and start no real paramiko/ssh.

The single definition of the marker bytes lives in remote_agent.build_floor_marker /
marker_sha256 / write_floor_marker; native_gateway reuses it. One parity test asserts both
bootstraps and these tests share that one definition.

Coverage (maps to the brief's (a)-(g)):
  (a) build_floor_marker output is accepted as floor ON by BOTH readers;
  (b) marker content has exactly the expected keys, size under the cap, no secrets/paths,
      and equals an exact GOLDEN byte literal for a fixed `now` (micro-patch Stage 3);
  (c) native bootstrap writes the marker create-only (second call refuses; an existing
      marker is never overwritten; a symlink target is refused where the OS can make one) --
      only the venv/pip subprocess calls are mocked;
  (d) marker_sha256 in the returned receipt equals the sha256 of the bytes on disk;
  (e) bootstrap_lib.FILES does not contain the marker and make_bundle() has no member for it;
  (f) an EXISTING gateway directory WITHOUT a marker is untouched by inspect and by every
      code path exercised here (no marker is ever created on an existing gateway);
  (g) a marker write failure => INCOMPLETE and never a READY gateway without a marker.

Micro-patch (2026-10-20) additions:
  - WriteFloorMarkerTests gains three fd-hygiene tests (T-1 / Security A-F3 / B): a
    write/fsync failure leaves NO marker on disk, propagates the original exception, and does
    NOT close the fd a second time; an os.fdopen failure closes the fd exactly once; a
    pre-existing dest is refused by O_EXCL and is NOT unlinked by the failure path.
  - NativeBootstrapMarkerTests.test_c_marker_written_before_venv_step now PROVES ordering:
    the _FakeRun stub records whether the marker already existed at the moment `-m venv` was
    called, and the test fails if venv ran before the marker was written (T-2 / B-F3).

Only placeholders appear here: <user>, fakeuser, 192.0.2.77, gateway.example.com, and the
example Lambda URL host. No real login, host, IP, account id, token or Windows profile name.
"""
import ast
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PAYLOAD = ROOT / "bootstrap_payload"

sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(PAYLOAD))

import remote_agent  # stdlib-only  # noqa: E402
import bootstrap_lib  # stdlib-only  # noqa: E402

MARKER_NAME = "gateway_policy.json"
EXPECTED_KEYS = {"schema", "allowlist_floor", "created_by", "created_utc"}
# Mirror of the payload readers' size cap (both use 65536). Kept as a local literal so a
# drift in the payload is caught by test (a) failing, not silently.
MARKER_MAX = 65536


# --------------------------------------------------------------------------------------------
# Load BOTH _marker_floor_on readers without importing the proxy's third-party deps.
# The launcher (aq_registry) is stdlib-only and imports directly. The proxy imports
# botocore/mcp at the top, so we extract its _marker_floor_on function source with ast and
# exec ONLY that function in a seeded namespace (same technique as test_allowlist_floor.py).
# --------------------------------------------------------------------------------------------
import aq_registry  # noqa: E402  (stdlib-only launcher)


def _extract_proxy_marker_reader():
    src = (PAYLOAD / "aq_mcp_stdio.py").read_text(encoding="utf-8")
    tree = ast.parse(src)
    func_src = None
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == "_marker_floor_on":
            func_src = ast.get_source_segment(src, node)
            break
    if func_src is None:
        raise RuntimeError("could not find proxy _marker_floor_on in aq_mcp_stdio.py")
    # The function imports `stat as _st` and references os/json/_MARKER_MAX/_POLICY_MARKER.
    ns = {"os": os, "json": json, "_MARKER_MAX": MARKER_MAX, "_POLICY_MARKER": None}
    exec(compile(func_src, "<proxy_marker_reader>", "exec"), ns)  # noqa: S102 - in-repo source
    return ns["_marker_floor_on"]


PROXY_MARKER_FLOOR_ON = _extract_proxy_marker_reader()
LAUNCHER_MARKER_FLOOR_ON = aq_registry._marker_floor_on


def _both_say_floor_on(path):
    return (LAUNCHER_MARKER_FLOOR_ON(str(path)), PROXY_MARKER_FLOOR_ON(str(path)))


# --------------------------------------------------------------------------------------------
class MarkerBytesTests(unittest.TestCase):
    """(a) + (b): the marker bytes are accepted by both readers and have the right shape."""

    def test_a_both_readers_accept_the_marker_as_floor_on(self):
        data = remote_agent.build_floor_marker()
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / MARKER_NAME
            p.write_bytes(data)
            launcher, proxy = _both_say_floor_on(p)
        self.assertTrue(launcher, "launcher reader must report floor ON for the written marker")
        self.assertTrue(proxy, "proxy reader must report floor ON for the written marker")

    def test_a_injected_now_is_deterministic(self):
        import datetime
        fixed = datetime.datetime(2026, 10, 20, 15, 30, 0, tzinfo=datetime.timezone.utc)
        data = remote_agent.build_floor_marker(now=fixed)
        obj = json.loads(data.decode("utf-8"))
        self.assertEqual(obj["created_utc"], "2026-10-20T15:30:00Z")

    def test_golden_bytes_pins_exact_marker(self):
        # (b) GOLDEN-BYTES content pin (micro-patch Stage 3 / Security B-F1,F-2): the marker
        # for a fixed `now` must equal this EXACT byte string. This is the one assertion that
        # fails loudly on ANY drift in separators / key order / schema / trailing newline --
        # unlike the readers, which fail CLOSED (floor ON) on a malformed-but-present marker
        # and so would MASK such a drift. The literal below was produced by exec-replaying the
        # real build_floor_marker(now=2026-01-02T03:04:05Z): compact separators (',',':'),
        # sorted keys, schema 1, allowlist_floor true, created_by aq-mcp-wizard, trailing LF.
        import datetime
        fixed = datetime.datetime(2026, 1, 2, 3, 4, 5, tzinfo=datetime.timezone.utc)
        expected = (
            b'{"allowlist_floor":true,"created_by":"aq-mcp-wizard",'
            b'"created_utc":"2026-01-02T03:04:05Z","schema":1}\n'
        )
        self.assertEqual(remote_agent.build_floor_marker(now=fixed), expected)

    def test_b_exact_keys_types_and_values(self):
        obj = json.loads(remote_agent.build_floor_marker().decode("utf-8"))
        self.assertEqual(set(obj), EXPECTED_KEYS, "marker must have EXACTLY the four keys")
        self.assertIs(obj["allowlist_floor"], True)
        self.assertEqual(obj["schema"], 1)
        self.assertEqual(obj["created_by"], "aq-mcp-wizard")
        self.assertRegex(obj["created_utc"], r"\A[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z\Z")

    def test_b_size_under_cap(self):
        self.assertLess(len(remote_agent.build_floor_marker()), MARKER_MAX)

    def test_b_no_secrets_or_paths(self):
        data = remote_agent.build_floor_marker().decode("utf-8").lower()
        for banned in ("/", "\\", "c:", "http", "token", "secret", "password",
                       "lambda-url", "aws", "@", "192.", "home", "users"):
            self.assertNotIn(banned, data, "marker must not contain paths/hosts/secrets: " + banned)

    def test_b_valid_utf8_json_object(self):
        obj = json.loads(remote_agent.build_floor_marker().decode("utf-8"))
        self.assertIsInstance(obj, dict)

    def test_marker_sha256_matches_bytes(self):
        data = remote_agent.build_floor_marker()
        import hashlib
        self.assertEqual(remote_agent.marker_sha256(data), hashlib.sha256(data).hexdigest())


# --------------------------------------------------------------------------------------------
class WriteFloorMarkerTests(unittest.TestCase):
    """write_floor_marker is create-only, returns the on-disk sha, refuses a symlink target,
    and (micro-patch) is fd-hygienic: a write/fsync failure leaves no partial marker and never
    closes the fd twice, an os.fdopen failure closes the fd exactly once, and a pre-existing
    file is refused by O_EXCL and NOT unlinked by the failure path."""

    def test_create_only_second_call_refuses(self):
        with tempfile.TemporaryDirectory() as d:
            dest = Path(d) / MARKER_NAME
            sha1 = remote_agent.write_floor_marker(dest)
            self.assertTrue(dest.is_file())
            with self.assertRaises(Exception):
                remote_agent.write_floor_marker(dest)  # O_EXCL must refuse the overwrite
            # The original bytes are untouched.
            self.assertEqual(remote_agent.marker_sha256(dest.read_bytes()), sha1)

    def test_returned_sha_equals_disk_sha(self):
        with tempfile.TemporaryDirectory() as d:
            dest = Path(d) / MARKER_NAME
            sha = remote_agent.write_floor_marker(dest)
            self.assertEqual(sha, remote_agent.marker_sha256(dest.read_bytes()))

    def test_existing_marker_never_overwritten(self):
        with tempfile.TemporaryDirectory() as d:
            dest = Path(d) / MARKER_NAME
            dest.write_bytes(b'{"pre-existing":true}\n')
            before = dest.read_bytes()
            with self.assertRaises(Exception):
                remote_agent.write_floor_marker(dest)
            self.assertEqual(dest.read_bytes(), before)

    @unittest.skipUnless(hasattr(os, "symlink"), "platform cannot create symlinks")
    def test_symlink_target_refused(self):
        with tempfile.TemporaryDirectory() as d:
            real = Path(d) / "real_target"
            real.write_bytes(b"x")
            link = Path(d) / MARKER_NAME
            try:
                os.symlink(str(real), str(link))
            except (OSError, NotImplementedError):
                self.skipTest("OS refused to create a symlink (e.g. Windows without privilege)")
            with self.assertRaises(Exception):
                remote_agent.write_floor_marker(link)
            # The symlink's real target is unchanged (never written through).
            self.assertEqual(real.read_bytes(), b"x")

    def test_mode_0600_where_supported(self):
        if os.name == "nt":
            self.skipTest("POSIX mode bits not meaningful on Windows")
        with tempfile.TemporaryDirectory() as d:
            dest = Path(d) / MARKER_NAME
            remote_agent.write_floor_marker(dest)
            self.assertEqual(dest.stat().st_mode & 0o777, 0o600)

    # ---- micro-patch fd-hygiene tests (T-1 / Security A-F3 / B) ----

    def _count_closes_patcher(self):
        """Return (install, uninstall, counts). install() wraps os.close so we can count how
        many times each fd value is closed; a correctly-written write_floor_marker closes any
        given fd AT MOST ONCE. uninstall() restores the real os.close."""
        counts = {}
        real_close = os.close

        def counting_close(fd):
            counts[fd] = counts.get(fd, 0) + 1
            return real_close(fd)

        def install():
            os.close = counting_close

        def uninstall():
            os.close = real_close

        return install, uninstall, counts

    def test_write_failure_leaves_no_marker_and_no_double_close(self):
        # Force os.fsync to raise AFTER the file was created and written: the with-block closes
        # the fd exactly once on its way out, so write_floor_marker must NOT os.close it again,
        # must os.unlink the partial marker, and must re-raise the ORIGINAL exception.
        import remote_agent as ra
        real_fsync = os.fsync

        def boom_fsync(fd):
            raise OSError("simulated fsync failure")

        install, uninstall, counts = self._count_closes_patcher()
        with tempfile.TemporaryDirectory() as d:
            dest = Path(d) / MARKER_NAME
            os.fsync = boom_fsync
            install()
            try:
                with self.assertRaises(OSError) as ctx:
                    ra.write_floor_marker(dest)
                self.assertIn("simulated fsync failure", str(ctx.exception))
            finally:
                uninstall()
                os.fsync = real_fsync
            # No partial marker is left on disk.
            self.assertFalse(dest.exists(), "a failed write must leave no marker file")
            # No fd was closed more than once (the double-close bug would show a count of 2).
            doubles = {fd: n for fd, n in counts.items() if n > 1}
            self.assertEqual(doubles, {}, "write_floor_marker must not close any fd twice")

    def test_fdopen_failure_closes_fd_once(self):
        # If os.fdopen itself raises, ownership of the fd never transferred, so write_floor_marker
        # must close the fd exactly once (and unlink the just-created file) and re-raise.
        import remote_agent as ra
        real_fdopen = os.fdopen

        def boom_fdopen(fd, *a, **k):
            raise OSError("simulated fdopen failure")

        install, uninstall, counts = self._count_closes_patcher()
        with tempfile.TemporaryDirectory() as d:
            dest = Path(d) / MARKER_NAME
            os.fdopen = boom_fdopen
            install()
            try:
                with self.assertRaises(OSError) as ctx:
                    ra.write_floor_marker(dest)
                self.assertIn("simulated fdopen failure", str(ctx.exception))
            finally:
                uninstall()
                os.fdopen = real_fdopen
            # The partial (zero-byte) file this call created is removed.
            self.assertFalse(dest.exists(), "an fdopen failure must leave no marker file")
            # Exactly one close happened, and no fd was closed more than once.
            self.assertGreaterEqual(sum(counts.values()), 1, "the fd must be closed once on fdopen failure")
            doubles = {fd: n for fd, n in counts.items() if n > 1}
            self.assertEqual(doubles, {}, "the fd must be closed exactly once, never twice")

    def test_existing_file_refused_and_not_unlinked_by_failure_path(self):
        # A pre-existing dest (that THIS call did not create) must be refused by O_EXCL
        # (FileExistsError raised at os.open, before `created` becomes True) and must NEVER be
        # unlinked by the failure path -- the unlink only ever removes a file this call made.
        import remote_agent as ra
        with tempfile.TemporaryDirectory() as d:
            dest = Path(d) / MARKER_NAME
            sentinel = b'{"someone-elses-file":true}\n'
            dest.write_bytes(sentinel)
            with self.assertRaises(FileExistsError):
                ra.write_floor_marker(dest)
            # The pre-existing file is intact: still present and byte-for-byte unchanged.
            self.assertTrue(dest.exists(), "O_EXCL refusal must NOT delete the pre-existing file")
            self.assertEqual(dest.read_bytes(), sentinel)


# --------------------------------------------------------------------------------------------
# Native bootstrap tests. We mock ONLY the venv/pip/import subprocess calls (stated clearly):
# native_gateway.bootstrap() shells out three times (venv, pip install, import check); we
# replace native_gateway.subprocess.run with a stub that also fakes the venv python so that
# inspect() reports READY. No real subprocess, no network. The marker write is the REAL code.
# --------------------------------------------------------------------------------------------
import native_gateway  # noqa: E402


class _FakeRun:
    """Stub for subprocess.run that fakes `-m venv` by creating the venv python file,
    and succeeds for pip install / import check. Mocks ONLY venv/pip; the marker write and
    all filesystem/create-only logic under test run for real.

    Ordering instrumentation (micro-patch, T-2 / Security B-F3): the stub is told the gateway
    root and the marker name; at the moment a `-m venv` call arrives it records whether the
    marker file already existed on disk (`marker_present_at_first_venv`) and the ordered list
    of events, so a test can PROVE the marker was written strictly before the venv step rather
    than merely confirming both exist afterwards."""

    def __init__(self, root=None, marker_name=MARKER_NAME):
        self.calls = []
        self.events = []
        self.root = Path(root) if root is not None else None
        self.marker_name = marker_name
        self.marker_present_at_first_venv = None

    def __call__(self, cmd, *a, **k):
        self.calls.append(list(cmd))
        # Emulate `python -m venv <dir>` by creating the venv python executable.
        if len(cmd) >= 3 and cmd[1] == "-m" and cmd[2] == "venv":
            if self.root is not None and self.marker_present_at_first_venv is None:
                # Record ordering exactly once, at the FIRST venv call.
                self.marker_present_at_first_venv = (self.root / self.marker_name).is_file()
            self.events.append("venv")
            vdir = Path(cmd[3])
            sub = "Scripts" if os.name == "nt" else "bin"
            exe = "python.exe" if os.name == "nt" else "python"
            (vdir / sub).mkdir(parents=True, exist_ok=True)
            (vdir / sub / exe).write_text("#!stub\n", encoding="utf-8")
        else:
            self.events.append("subprocess")

        class _P:
            returncode = 0
        return _P()


class NativeBootstrapMarkerTests(unittest.TestCase):
    def setUp(self):
        self._real_run = native_gateway.subprocess.run
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name) / "AQ-MCP-Gateway"
        # The stub is root-aware so it can observe marker-vs-venv ordering at call time.
        self.fake = _FakeRun(root=self.root)
        native_gateway.subprocess.run = self.fake

    def tearDown(self):
        native_gateway.subprocess.run = self._real_run
        self.tmp.cleanup()

    def _bootstrap(self):
        gw = native_gateway.NativeGateway(root=self.root)
        return gw, gw.bootstrap(approved=True, install_dependencies=True)

    def test_c_bootstrap_writes_marker_and_d_receipt_sha_matches_disk(self):
        gw, receipt = self._bootstrap()
        marker = self.root / MARKER_NAME
        self.assertTrue(marker.is_file(), "bootstrap must create the marker")
        # (d) receipt sha equals the sha of the bytes on disk
        self.assertEqual(receipt["marker_sha256"],
                         remote_agent.marker_sha256(marker.read_bytes()))
        self.assertIs(receipt.get("marker_created"), True)
        self.assertEqual(receipt["state"], "READY")
        # (a) both readers accept the marker the native bootstrap actually wrote
        launcher, proxy = _both_say_floor_on(marker)
        self.assertTrue(launcher and proxy)

    def test_c_marker_written_before_venv_step(self):
        # PROVE ordering (micro-patch, T-2 / Security B-F3): the _FakeRun stub records, AT THE
        # MOMENT the first `-m venv` call arrives, whether the marker already existed on disk.
        # The marker MUST be written strictly before venv (so there is never a window where the
        # install started but the floor is absent). We fail the test if venv ran first.
        gw, receipt = self._bootstrap()
        self.assertTrue((self.root / MARKER_NAME).is_file(), "marker must exist after bootstrap")
        self.assertIn("venv", self.fake.events, "a venv call must have been recorded")
        self.assertIsNotNone(self.fake.marker_present_at_first_venv,
                             "the stub must have observed the first venv call")
        self.assertTrue(self.fake.marker_present_at_first_venv,
                        "the policy marker MUST exist on disk BEFORE the venv step runs")

    def test_c_create_only_bootstrap_cannot_run_twice(self):
        gw, receipt = self._bootstrap()
        # A second bootstrap on an existing (now non-MISSING) gateway is refused by the
        # create-only guard BEFORE any marker write, so the existing marker is never touched.
        before = (self.root / MARKER_NAME).read_bytes()
        with self.assertRaises(native_gateway.DeploymentError):
            native_gateway.NativeGateway(root=self.root).bootstrap(
                approved=True, install_dependencies=True)
        self.assertEqual((self.root / MARKER_NAME).read_bytes(), before)

    def test_g_marker_write_failure_gives_incomplete_and_no_ready_without_marker(self):
        # Force the marker write to fail AFTER the payload files but BEFORE venv/pip.
        real_write = remote_agent.write_floor_marker

        def boom(dest, now=None):
            raise OSError("simulated marker write failure")

        remote_agent.write_floor_marker = boom
        try:
            gw = native_gateway.NativeGateway(root=self.root)
            with self.assertRaises(native_gateway.DeploymentError):
                gw.bootstrap(approved=True, install_dependencies=True)
            # No marker was created...
            self.assertFalse((self.root / MARKER_NAME).exists())
            # ...and the gateway is NOT READY (venv step never ran, so inspect != READY).
            self.assertNotEqual(gw.inspect().get("state"), "READY")
        finally:
            remote_agent.write_floor_marker = real_write

    def test_f_existing_gateway_without_marker_untouched_by_inspect(self):
        # Build a READY-looking gateway by hand WITHOUT a marker (mimics the live 3090/3080),
        # then prove inspect() reports READY and NEVER creates a marker.
        self.root.mkdir(parents=True)
        for name in ("aq_registry.py", "aq_mcp_stdio.py", "aq_check.py",
                     "requirements-gateway.txt"):
            (self.root / name).write_text("x\n", encoding="utf-8")
        (self.root / "targets.json").write_text('{"targets": {}}\n', encoding="utf-8")
        sub = "Scripts" if os.name == "nt" else "bin"
        exe = "python.exe" if os.name == "nt" else "python"
        (self.root / "venv" / sub).mkdir(parents=True)
        (self.root / "venv" / sub / exe).write_text("#!stub\n", encoding="utf-8")
        gw = native_gateway.NativeGateway(root=self.root)
        state = gw.inspect()
        self.assertEqual(state["state"], "READY")
        self.assertFalse((self.root / MARKER_NAME).exists(),
                         "inspect must NEVER create a marker on an existing gateway")
        # Calling inspect again is still marker-free.
        gw.inspect()
        self.assertFalse((self.root / MARKER_NAME).exists())


# --------------------------------------------------------------------------------------------
class RemoteExistingGatewayTests(unittest.TestCase):
    """(f) for remote_agent: gateway_state() does not require or create a marker, so an
    existing marker-less gateway still inspects as before. POSIX-only (gateway is Linux)."""

    @unittest.skipUnless(os.name == "posix", "remote gateway_state() is POSIX/Linux-only")
    def test_f_remote_gateway_state_ignores_and_never_creates_marker(self):
        import json as _json
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        old = (remote_agent.ROOT, remote_agent.REG, remote_agent.LOCK, remote_agent.BACKUPS)
        try:
            root = Path(tmp.name) / "aq-mcp"
            root.mkdir()
            remote_agent.ROOT = root
            remote_agent.REG = root / "targets.json"
            remote_agent.LOCK = root / ".aq-wizard.lock"
            remote_agent.BACKUPS = root / ".wizard-backups"
            for f in ("aq_registry.py", "aq-run.sh", "aq_mcp_stdio.py", "aq_check.py"):
                (root / f).write_text("x\n", encoding="utf-8")
                os.chmod(root / f, 0o600)
            remote_agent.REG.write_text(_json.dumps({"targets": {}}), encoding="utf-8")
            os.chmod(remote_agent.REG, 0o600)
            (root / "venv" / "bin").mkdir(parents=True)
            (root / "venv" / "bin" / "python").write_text("#!stub\n", encoding="utf-8")
            os.chmod(root, 0o700)
            state = remote_agent.gateway_state()
            # No marker exists; the state must be a normal installed state, never dependent
            # on a marker, and gateway_state must not have created one.
            self.assertIn(state["state"], ("READY", "PERMISSIONS_NEED_REPAIR"))
            self.assertTrue(state["installed"])
            self.assertFalse((root / MARKER_NAME).exists(),
                             "gateway_state must never create a marker on an existing gateway")
            self.assertNotIn(MARKER_NAME, remote_agent.gateway_state.__code__.co_consts or (),
                             "marker name must not be wired into gateway_state required set")
        finally:
            remote_agent.ROOT, remote_agent.REG, remote_agent.LOCK, remote_agent.BACKUPS = old


# --------------------------------------------------------------------------------------------
class PayloadExclusionTests(unittest.TestCase):
    """(e) the marker is NOT shipped in the payload and make_bundle() has no member for it."""

    def test_e_bootstrap_lib_files_has_no_marker(self):
        self.assertNotIn(MARKER_NAME, bootstrap_lib.FILES)
        self.assertNotIn(MARKER_NAME, getattr(bootstrap_lib, "LF_NORMALISE", ()))

    def test_e_make_bundle_has_no_marker_member(self):
        import base64
        import io
        import zipfile
        bundle = bootstrap_lib.make_bundle()
        raw = base64.b64decode(bundle["bundle_b64"])
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            names = z.namelist()
        self.assertNotIn(MARKER_NAME, names,
                         "the policy marker must never be a bundle member")


# --------------------------------------------------------------------------------------------
class ParityTests(unittest.TestCase):
    """One definition of the marker: native_gateway reuses remote_agent's writer, and the
    bytes a direct build_floor_marker produces equal the bytes the native bootstrap writes."""

    def test_native_gateway_uses_remote_agent_definition(self):
        # native_gateway.bootstrap imports write_floor_marker/POLICY_MARKER_NAME from
        # remote_agent (checked by source), so there is no second marker definition.
        src = Path(native_gateway.__file__).read_text(encoding="utf-8")
        self.assertIn("from remote_agent import write_floor_marker", src)
        self.assertEqual(remote_agent.POLICY_MARKER_NAME, MARKER_NAME)

    def test_bytes_are_deterministic_for_same_now_only(self):
        # DETERMINISM ONLY (micro-patch rename, Security B-F2): this proves build_floor_marker
        # is pure -- the same `now` yields identical bytes on repeated calls. It deliberately
        # does NOT check the CONTENT of those bytes; that is covered by
        # MarkerBytesTests.test_golden_bytes_pins_exact_marker. Do not treat this as a content
        # check (both sides would drift together and mask a regression).
        import datetime
        fixed = datetime.datetime(2026, 10, 20, 0, 0, 0, tzinfo=datetime.timezone.utc)
        a = remote_agent.build_floor_marker(now=fixed)
        b = remote_agent.build_floor_marker(now=fixed)
        self.assertEqual(a, b)


if __name__ == "__main__":
    unittest.main(verbosity=2)
