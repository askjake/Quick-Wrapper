"""Line-ending policy + bootstrap-bundle integrity tests.

Two independent safeguards keep CRLF out of the Linux gateway payload:

  1. .gitattributes (FIRST safeguard, this repo root) normalises line endings in
     the git index so a Windows (core.autocrlf) checkout cannot smuggle CRLF into
     tracked files.
  2. bootstrap_lib.make_bundle() (SECOND safeguard) re-normalises every gateway
     payload member to LF and raises if a CR survives -- regardless of git.

This module proves BOTH, plus binary-safety, and offers an opt-in fresh-clone
check for the live working tree. It is stdlib-only, writes only to temp dirs,
opens no network sockets, and contains no secrets or real identity.

Tiers:
  * Tier 1  TestGitAttributesRules      -- pure parser + table, incl. the REAL root file
  * Tier 2  TestBundleZipBytes          -- make_bundle() ZIP-byte assertions (real + synthetic)
  * Tier 3  TestBinarySafety            -- NUL-byte / binary-pattern safety (self-tested)
  * Tier 4  TestFreshCloneWorkingTree   -- OPT-IN (AQ_FRESH_CLONE_CHECK=1); the user runs
                                           this on a FRESH clone on Windows.

NOTE on Tier 4: it asserts the WORKING TREE matches policy (no CR in LF-governed
text files, CRLF-only in .bat/.cmd). It is EXPECTED TO FAIL on an existing
core.autocrlf clone and on the intermediate work copy, because those carry CRLF
files on disk. That is not a defect -- it is exactly what the user runs on a
fresh clone of the successor branch to qualify the checkout.

This file does NOT duplicate tests in tests/test_bootstrap.py
(test_bundle_has_no_cr_for_any_member, test_bundle_from_crlf_input_is_still_lf):
it asserts a stricter, different contract (exact member order == bootstrap_lib.FILES,
exact 12-byte shebang prefix, exactly-one-trailing-LF, determinism by sha256, a
lone-CR synthetic tree, and shebang independence from .gitattributes).
"""
import base64
import hashlib
import io
import os
import re
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO_ROOT))
import bootstrap_lib  # noqa: E402


# --------------------------------------------------------------------------- #
# Minimal .gitattributes parser (git semantics subset: last matching rule wins
# per attribute; supports '*', 'dir/*', 'dir/**', '*.ext', and anchored names).
# --------------------------------------------------------------------------- #
def parse_gitattributes(text):
    """Return a list of (pattern, [attr, ...]) in file order, skipping comments/blanks."""
    rules = []
    for raw in text.split("\n"):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split()
        rules.append((parts[0], parts[1:]))
    return rules


def _pattern_matches(pattern, path):
    """git-style match for the subset we use.

    No slash in pattern -> match the basename at any depth.
    Slash in pattern    -> anchored at repo root; '**' spans directories,
                           '*' matches within a single path segment.
    """
    path = path.replace("\\", "/").lstrip("/")
    if "/" not in pattern:
        base = path.split("/")[-1]
        return _fnmatch_seg(pattern, base)
    if pattern.endswith("/**"):
        prefix = pattern[:-3]
        return path == prefix or path.startswith(prefix + "/")
    if "**" in pattern:
        rx = "^" + re.escape(pattern).replace(r"\*\*", ".*").replace(r"\*", "[^/]*") + "$"
        return re.match(rx, path) is not None
    rx = "^" + re.escape(pattern).replace(r"\*", "[^/]*") + "$"
    return re.match(rx, path) is not None


def _fnmatch_seg(pattern, segment):
    """fnmatch for a single path segment ('*' does NOT cross '/', but segment has none)."""
    rx = "^" + re.escape(pattern).replace(r"\*", "[^/]*").replace(r"\?", "[^/]") + "$"
    return re.match(rx, segment) is not None


def classify_path(gitattributes_text, path):
    """Resolve the effective text/eol/binary attributes for one path.

    Returns {'binary': bool, 'eol': 'lf'|'crlf'|None, 'text': True|False|'auto'|None}.
    The 'binary' macro expands to '-text -diff -merge'; once a file is -text, 'eol'
    no longer applies (git only converts line endings for text files).
    """
    eff = {}
    for pattern, attrs in parse_gitattributes(gitattributes_text):
        if not _pattern_matches(pattern, path):
            continue
        for a in attrs:
            if a == "binary":
                eff["text"] = False
                eff.pop("eol", None)
            elif a == "text":
                eff["text"] = True
            elif a == "-text":
                eff["text"] = False
                eff.pop("eol", None)
            elif a == "text=auto":
                eff["text"] = "auto"
            elif a.startswith("eol="):
                eff["eol"] = a.split("=", 1)[1]
                if eff.get("text") in (None, "auto", True):
                    eff.setdefault("text", True)
    is_binary = eff.get("text") is False
    return {"binary": is_binary,
            "eol": None if is_binary else eff.get("eol"),
            "text": eff.get("text")}


def read_root_gitattributes():
    p = REPO_ROOT / ".gitattributes"
    return p.read_text(encoding="utf-8") if p.is_file() else ""


# Representative sample set (names, not necessarily all present on disk).
# (expected_eol, expected_binary)
SAMPLE_PATHS = {
    "bootstrap_payload/aq-run.sh": ("lf", False),
    "bootstrap_payload/aq_registry.py": ("lf", False),
    "bootstrap_payload/aq_mcp_stdio.py": ("lf", False),
    "bootstrap_payload/aq_check.py": ("lf", False),
    "bootstrap_payload/requirements-gateway.txt": ("lf", False),
    "bootstrap_payload/requirements-gateway.lock": ("lf", False),
    "wizard.py": ("lf", False),
    "tests/test_x.py": ("lf", False),
    "README.md": ("lf", False),
    "ARCHITECTURE.mmd": ("lf", False),
    "templates/example_git_manifest.json": ("lf", False),
    "SHA256SUMS": ("lf", False),
    ".gitignore": ("lf", False),
    "setup_wizard.bat": ("crlf", False),
    "start_wizard.bat": ("crlf", False),
    "tools/x.cmd": ("crlf", False),
    "assets/logo.png": (None, True),
    "dist/a.zip": (None, True),
    "wheels/w.whl": (None, True),
    "build/x.pyc": (None, True),
    "bin/tool.exe": (None, True),
}

BINARY_EXT_PATTERNS = (
    "*.png", "*.jpg", "*.jpeg", "*.gif", "*.ico", "*.pdf", "*.zip", "*.gz",
    "*.tgz", "*.tar", "*.whl", "*.pyc", "*.exe", "*.dll", "*.so",
)


class TestGitAttributesRules(unittest.TestCase):
    """Tier 1: pure-function parse of .gitattributes and a classification table.

    Runs against (a) an inline copy of the intended ruleset and (b) the REAL
    .gitattributes at the repo root, so the committed file is actually exercised.
    """

    INLINE_RULES = (
        "* text=auto eol=lf\n"
        "*.py text eol=lf\n"
        "*.sh text eol=lf\n"
        "bootstrap_payload/** text eol=lf\n"
        "*.bat text eol=crlf\n"
        "*.cmd text eol=crlf\n"
        "*.md text eol=lf\n"
        "*.txt text eol=lf\n"
        "*.json text eol=lf\n"
        "*.mmd text eol=lf\n"
        "*.lock text eol=lf\n"
        "SHA256SUMS text eol=lf\n"
        ".gitignore text eol=lf\n"
        ".gitattributes text eol=lf\n"
        + "".join(p + " binary\n" for p in BINARY_EXT_PATTERNS)
    )

    def _run_table(self, rules_text, label):
        for path, (exp_eol, exp_bin) in SAMPLE_PATHS.items():
            with self.subTest(source=label, path=path):
                c = classify_path(rules_text, path)
                if exp_bin:
                    self.assertTrue(c["binary"], f"{path} should be binary")
                    self.assertIsNone(c["eol"], f"{path} binary must have no eol")
                else:
                    self.assertFalse(c["binary"], f"{path} must not be binary")
                    self.assertEqual(c["eol"], exp_eol, f"{path} eol")

    def test_table_against_inline_rules(self):
        self._run_table(self.INLINE_RULES, "inline")

    def test_table_against_real_root_gitattributes(self):
        text = read_root_gitattributes()
        self.assertTrue(text.strip(), "repo root .gitattributes is missing or empty")
        self._run_table(text, "repo-root")

    def test_real_file_is_lf_only_and_has_binary_block(self):
        p = REPO_ROOT / ".gitattributes"
        self.assertTrue(p.is_file(), "repo root .gitattributes must exist")
        raw = p.read_bytes()
        self.assertNotIn(b"\r", raw, ".gitattributes must itself be LF-only")
        for pat in BINARY_EXT_PATTERNS:
            self.assertIn(pat, p.read_text(encoding="utf-8"),
                          f"binary block must include {pat}")

    def test_dir_star_vs_dir_doublestar_semantics(self):
        # 'dir/*' matches only one level; 'dir/**' matches any depth.
        self.assertTrue(_pattern_matches("bootstrap_payload/**", "bootstrap_payload/a.py"))
        self.assertTrue(_pattern_matches("bootstrap_payload/**", "bootstrap_payload/sub/a.py"))
        self.assertTrue(_pattern_matches("bootstrap_payload/*", "bootstrap_payload/a.py"))
        self.assertFalse(_pattern_matches("bootstrap_payload/*", "bootstrap_payload/sub/a.py"))

    def test_bat_cmd_stay_crlf_and_py_is_lf(self):
        rules = read_root_gitattributes() or self.INLINE_RULES
        self.assertEqual(classify_path(rules, "setup_wizard.bat")["eol"], "crlf")
        self.assertEqual(classify_path(rules, "tools/x.cmd")["eol"], "crlf")
        self.assertEqual(classify_path(rules, "wizard.py")["eol"], "lf")


class TestBundleZipBytes(unittest.TestCase):
    """Tier 2: assert the ZIP bytes produced by make_bundle() from the REAL payload,
    and prove the LF safeguard works INDEPENDENTLY of .gitattributes (CRLF + lone-CR
    synthetic trees)."""

    def _members(self, result):
        z = zipfile.ZipFile(io.BytesIO(base64.b64decode(result["bundle_b64"])))
        return z, [(n, z.read(n)) for n in z.namelist()]

    def test_real_payload_bundle_bytes(self):
        res = bootstrap_lib.make_bundle()
        z, members = self._members(res)
        names = [n for n, _ in members]
        # member list equals FILES exactly (names AND order)
        self.assertEqual(tuple(names), tuple(bootstrap_lib.FILES))
        for name, data in members:
            with self.subTest(member=name):
                self.assertTrue(len(data) > 0, "member must be non-empty")
                self.assertNotIn(b"\r", data, "no CR in any member")
                self.assertIn(b"\n", data, "member must contain at least one LF")
                self.assertTrue(data.endswith(b"\n"), "member must end with LF")
                self.assertFalse(data.endswith(b"\n\n"), "member must end with exactly one LF")
                data.decode("utf-8")  # must decode as UTF-8 (raises on failure)
        sh = dict(members)["aq-run.sh"]
        self.assertTrue(sh.startswith(b"#!/bin/bash\n"))
        self.assertEqual(sh[:12], b"#!/bin/bash\n")

    def test_bundle_is_deterministic(self):
        a = bootstrap_lib.make_bundle()
        b = bootstrap_lib.make_bundle()
        self.assertEqual(a["bundle_sha256"], b["bundle_sha256"])

    def _build_tree(self, d, members):
        payload = Path(d) / "bootstrap_payload"
        payload.mkdir()
        for name, blob in members.items():
            (payload / name).write_bytes(blob)
        return payload

    def _bundle_from_tree(self, payload):
        old = bootstrap_lib.PAYLOAD
        bootstrap_lib.PAYLOAD = payload
        self.addCleanup(lambda: setattr(bootstrap_lib, "PAYLOAD", old))
        return bootstrap_lib.make_bundle()

    def _crlf_members(self, eol):
        # Minimal, valid-looking members for all bootstrap_lib.FILES, with the
        # chosen line ending. Lock uses a well-formed synthetic hash line.
        nl = eol
        return {
            "aq_registry.py": b"import sys" + nl + b"x = 1" + nl,
            "aq-run.sh": b"#!/bin/bash" + nl + b"exec echo hi" + nl,
            "aq_mcp_stdio.py": b"y = 2" + nl,
            "aq_check.py": b"z = 3" + nl,
            "requirements-gateway.txt": b"mcp==2.3.0" + nl + b"botocore==1.43.113" + nl + b"httpx2==2.13.1" + nl,
            "requirements-gateway.lock": b"mcp==2.3.0 --hash=sha256:" + b"a" * 64 + nl,
        }

    def test_safeguard_independent_of_gitattributes_crlf_tree(self):
        with tempfile.TemporaryDirectory() as d:
            payload = self._build_tree(d, self._crlf_members(b"\r\n"))
            res = self._bundle_from_tree(payload)
            z, members = self._members(res)
            self.assertEqual(tuple(n for n, _ in members), tuple(bootstrap_lib.FILES))
            for name, data in members:
                self.assertNotIn(b"\r", data, name)
            self.assertTrue(dict(members)["aq-run.sh"].startswith(b"#!/bin/bash\n"))

    def test_safeguard_independent_of_gitattributes_lone_cr_tree(self):
        with tempfile.TemporaryDirectory() as d:
            payload = self._build_tree(d, self._crlf_members(b"\r"))
            res = self._bundle_from_tree(payload)
            z, members = self._members(res)
            for name, data in members:
                self.assertNotIn(b"\r", data, name)
            self.assertTrue(dict(members)["aq-run.sh"].startswith(b"#!/bin/bash\n"))


class TestBinarySafety(unittest.TestCase):
    """Tier 3: the .gitattributes rules must never mark a binary file as text, and
    any NUL-containing file in the tree must be classified binary/-text. Today there
    are no binaries, so the tree walk passes vacuously; a self-test proves the check
    WOULD fail on a planted NUL file, and that binary extension patterns carry no
    text/eol attribute."""

    def setUp(self):
        self.rules = read_root_gitattributes()
        self.assertTrue(self.rules.strip(), "repo root .gitattributes required")

    def test_no_tracked_file_contains_nul_today(self):
        offenders = []
        for root, dirs, files in os.walk(REPO_ROOT):
            dirs[:] = [x for x in dirs if x not in (".git", "__pycache__")]
            for fn in files:
                fp = Path(root) / fn
                try:
                    chunk = fp.read_bytes()
                except OSError:
                    continue
                if b"\x00" in chunk:
                    rel = fp.relative_to(REPO_ROOT).as_posix()
                    c = classify_path(self.rules, rel)
                    if not c["binary"]:
                        offenders.append(rel)
        self.assertEqual(offenders, [], f"NUL-containing files not classed binary: {offenders}")

    def test_self_test_planted_nul_would_fail_classification(self):
        # Prove the detector is real: a rule set WITHOUT a binary block would
        # misclassify a .dat NUL file as text; our real rules would too for an
        # un-listed extension -- so the guard is "has NUL => must be binary".
        rules_no_binary = "* text=auto eol=lf\n"
        c = classify_path(rules_no_binary, "mystery.dat")
        self.assertFalse(c["binary"], "sanity: .dat is text without a binary rule")
        # With the real rules, an unknown-extension NUL file is NOT auto-binary,
        # which is why test_no_tracked_file_contains_nul_today is the real guard.
        # Demonstrate the guard fires on a planted NUL file in a temp tree copy.
        with tempfile.TemporaryDirectory() as d:
            planted = Path(d) / "planted.dat"
            planted.write_bytes(b"ok\x00ok")
            data = planted.read_bytes()
            rel = "planted.dat"
            c = classify_path(self.rules, rel)
            would_flag = (b"\x00" in data) and not c["binary"]
            self.assertTrue(would_flag,
                            "self-test: a planted NUL .dat must be flagged by the guard")

    def test_binary_patterns_have_no_text_or_eol(self):
        for pat in BINARY_EXT_PATTERNS:
            sample = "x" + pat[1:]  # '*.png' -> 'x.png'
            c = classify_path(self.rules, sample)
            with self.subTest(pattern=pat):
                self.assertTrue(c["binary"], f"{pat} must resolve to binary")
                self.assertIsNone(c["eol"], f"{pat} must have no eol")
                self.assertFalse(c["text"] is True, f"{pat} must not be text")

    def test_binary_block_present_in_file(self):
        # Parse the rules and require each binary pattern to appear as a rule whose
        # sole attribute is exactly ['binary'] (robust to column alignment).
        rule_map = {pat: attrs for pat, attrs in parse_gitattributes(self.rules)}
        for pat in BINARY_EXT_PATTERNS:
            with self.subTest(pattern=pat):
                self.assertIn(pat, rule_map, f"missing rule for {pat}")
                self.assertEqual(rule_map[pat], ["binary"],
                                 f"{pat} must have exactly the 'binary' attribute")


class TestFreshCloneWorkingTree(unittest.TestCase):
    """Tier 4 (OPT-IN): set AQ_FRESH_CLONE_CHECK=1 to run.

    Asserts the WORKING TREE matches policy: LF-governed tracked text files contain
    no CR, and .bat/.cmd files contain only CRLF pairs (no lone LF). If git is on
    PATH and this is a work tree, also runs `git ls-files --eol` (read-only) and
    asserts w/lf for LF-policy files and w/crlf for .bat.

    EXPECTED TO FAIL on an existing core.autocrlf clone and on the intermediate
    work copy (both have CRLF files on disk). The user runs this on a FRESH clone
    of the successor branch on Windows to qualify the checkout. A failure here on a
    non-fresh tree is NOT a defect.
    """

    def setUp(self):
        if os.environ.get("AQ_FRESH_CLONE_CHECK") != "1":
            self.skipTest("opt-in; set AQ_FRESH_CLONE_CHECK=1 to run on a FRESH clone")
        self.rules = read_root_gitattributes()
        self.assertTrue(self.rules.strip(), "repo root .gitattributes required")

    def _iter_text_files(self):
        for root, dirs, files in os.walk(REPO_ROOT):
            dirs[:] = [x for x in dirs if x not in (".git", "__pycache__")]
            for fn in files:
                fp = Path(root) / fn
                rel = fp.relative_to(REPO_ROOT).as_posix()
                yield rel, fp

    def test_working_tree_line_endings_match_policy(self):
        lf_offenders, bat_offenders = [], []
        for rel, fp in self._iter_text_files():
            c = classify_path(self.rules, rel)
            if c["binary"]:
                continue
            try:
                data = fp.read_bytes()
            except OSError:
                continue
            if c["eol"] == "lf":
                if b"\r" in data:
                    lf_offenders.append(rel)
            elif c["eol"] == "crlf":
                # every LF must be part of a CRLF pair (no lone LF)
                if data.replace(b"\r\n", b"").find(b"\n") != -1:
                    bat_offenders.append(rel)
        self.assertEqual(lf_offenders, [], f"CR found in LF-policy files: {lf_offenders}")
        self.assertEqual(bat_offenders, [], f"lone LF in CRLF-policy files: {bat_offenders}")

    def test_git_ls_files_eol_matches_policy(self):
        import shutil
        import subprocess
        if shutil.which("git") is None:
            self.skipTest("git not on PATH")
        if not (REPO_ROOT / ".git").exists():
            self.skipTest("not a git work tree")
        proc = subprocess.run(
            ["git", "-C", str(REPO_ROOT), "ls-files", "--eol"],
            capture_output=True, text=True, timeout=60,
        )
        if proc.returncode != 0:
            self.skipTest("git ls-files --eol failed: " + proc.stderr.strip())
        bad = []
        for line in proc.stdout.splitlines():
            # format: "i/<idx>  w/<wtree>  attr/<...>  <path>"
            m = re.match(r"\S+\s+w/(\S+)\s+\S+\s+(.+)$", line)
            if not m:
                continue
            wtree, path = m.group(1), m.group(2).strip()
            c = classify_path(self.rules, path.replace("\\", "/"))
            if c["binary"]:
                continue
            if c["eol"] == "lf" and wtree not in ("lf", "none"):
                bad.append((path, wtree, "expected lf"))
            elif c["eol"] == "crlf" and wtree not in ("crlf", "none"):
                bad.append((path, wtree, "expected crlf"))
        self.assertEqual(bad, [], f"git ls-files --eol disagrees with policy: {bad}")


if __name__ == "__main__":
    unittest.main(verbosity=2)
