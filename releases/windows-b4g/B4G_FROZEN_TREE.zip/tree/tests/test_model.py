import sys, unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from model import *
import model as model_mod
import re as _re

S={'host':'gateway.example.internal','user':'engineer','kind':'lambda',
   'target':'test-epg','display_name':'Test EPG',
   'url':'https://abc123.lambda-url.us-west-2.on.aws/mcp','allow':['get_programs','list_genres']}

class TestModel(unittest.TestCase):
    def test_valid(self):
        validate_spec(S)
        e=make_registry_entry(S)
        self.assertEqual(e['region'],'us-west-2')
        self.assertEqual(e['allow'],sorted(S['allow']))
        self.assertEqual(quick_connector(S)['arguments'][-2:],['/home/engineer/aq-mcp/aq-run.sh','test-epg'])
    def test_no_tool_policy_is_fail_closed(self):
        s=dict(S,allow=[])
        with self.assertRaises(ValidationError): validate_spec(s)
    def test_external_urls_rejected(self):
        for url in ['http://abc.lambda-url.us-west-2.on.aws','https://example.com/mcp',
                    'https://abc.lambda-url.us-west-2.on.aws/?key=sekrit',
                    'https://user:password@abc.lambda-url.us-west-2.on.aws',
                    'https://abc.lambda-url.us-west-2.on.aws:8443/mcp',
                    'https://abc.lambda-url.us-west-2.on.aws/other']:
            with self.subTest(url=url),self.assertRaises(ValidationError):validate_lambda_url(url)
    def test_bad_targets(self):
        for target in ['Feature/x','feature/../main','main\nhello','-foo','']:
            with self.subTest(target=target),self.assertRaises(ValidationError):validate_spec(dict(S,target=target))
    def test_git_existing_only(self):
        g=dict(S,kind='git',target='github-ghes',allow=[])
        validate_spec(g)
        self.assertEqual(len(quick_connector(g)['arguments']),6)
        with self.assertRaises(ValidationError):validate_spec(dict(g,target='unknown-git'))
    def test_quick_config(self):
        payload=json.loads(config_export(S))
        self.assertEqual(payload['mcpServers']['aq-test-epg']['command'],'ssh')

    # --- F3: per-kind connector timeout (D2). Lambda=30 (live Epg), git/local=120. ---
    def test_lambda_connector_timeout_is_30(self):
        self.assertEqual(quick_connector(S)['timeout_seconds'],30)
    def test_git_connector_timeout_is_120(self):
        g=dict(S,kind='git',target='github-ghes',allow=[])
        self.assertEqual(quick_connector(g)['timeout_seconds'],120)
    def test_local_connector_timeout_is_120(self):
        l=dict(S,kind='local',target='buildartifacts',allow=[])
        self.assertEqual(quick_connector(l)['timeout_seconds'],120)

    # --- S6: model.LAMBDA validation and the stored entry URL must agree with the
    # gateway's stricter remote_agent.URL (lowercase-only id) on a shared sample. ---
    def test_lambda_url_parity_with_remote_agent(self):
        try:
            import remote_agent
            remote_url=remote_agent.URL
        except Exception:
            remote_url=_re.compile(r'^https://[a-z0-9]+\.lambda-url\.([a-z0-9-]+)\.on\.aws(?:/mcp|/)?$')
        samples=['https://abc123.lambda-url.us-west-2.on.aws/mcp',
                 'https://ABC123.lambda-url.us-west-2.on.aws/mcp',  # uppercase id (M-1)
                 'https://abc123.lambda-url.us-west-2.on.aws',
                 'https://abc123.lambda-url.us-west-2.on.aws/',
                 'https://abc.lambda-url.us-west-2.on.aws.evil.com/mcp',
                 'http://abc.lambda-url.us-west-2.on.aws/mcp',
                 'https://abc.lambda-url.us-west-2.on.aws:8443/mcp',
                 'https://abc.lambda-url.us-west-2.on.aws/other']
        for url in samples:
            with self.subTest(url=url):
                try:
                    entry=make_registry_entry(dict(S,url=url,allow=['x']))
                    accepted=True
                except ValidationError:
                    accepted=False
                # If model accepts the URL, the stored entry URL MUST pass the gateway regex.
                if accepted:
                    self.assertTrue(remote_url.fullmatch(entry['url']),
                                    'model accepted %r but remote_agent.URL rejects stored %r'%(url,entry['url']))
    def test_uppercase_id_is_normalised_lowercase(self):
        e=make_registry_entry(dict(S,url='https://ABC123.lambda-url.us-west-2.on.aws/mcp',allow=['x']))
        self.assertEqual(e['url'],'https://abc123.lambda-url.us-west-2.on.aws/mcp')
