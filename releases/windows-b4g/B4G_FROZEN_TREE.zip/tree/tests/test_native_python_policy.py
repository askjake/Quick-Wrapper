"""Offline tests for the enforced native-Windows supported-interpreter gate.

No subprocess, no network, temp dirs only. Covers:
  - the table has exactly one row today (CPython 3.13 win_amd64);
  - check_interpreter: 3.13 win_amd64 CPython -> ok; 3.12/3.14/3.10/3.9/3.15,
    PyPy, win32 (32-bit), arm64, and garbage inputs -> refused, never raising;
  - ABI guards: free-threaded (gil_disabled), debug_build, and pre-release
    (releaselevel) builds that otherwise match the table are refused;
  - Cygwin/MSYS bootstrap is refused fail-closed before anything is created;
  - bootstrap under an unsupported interpreter creates NO dir, NO marker and does
    NOT call subprocess.run (spy);
  - bootstrap under a supported interpreter reaches the existing flow unchanged
    (subprocess mocked exactly like test_native_gateway.py);
  - an existing-gateway inspect result has identical READY/not-READY state whether
    or not the new informational fields are present;
  - read_gateway_venv_version: plain-text, read-only, never-raising pyvenv.cfg parse
    reporting ONLY a version string, never a path/identity.

The gate governs native Windows only. The suite forces os.name == 'nt' where it
must exercise the gate, and drives check_interpreter with explicit arguments so
the result does not depend on the interpreter actually running these tests.
"""
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import native_gateway
from deploy_lib import DeploymentError

# A win_amd64 argument bundle that matches the single supported row. Passed
# explicitly so the outcome never depends on the host running the tests. The ABI
# guards are passed explicitly too so a free-threaded/debug/pre-release host does
# not flip the default result.
WIN_AMD64 = dict(machine='AMD64', platform='win32', pointer_bits=64,
                 gil_disabled=False, debug_build=False, releaselevel='final')


class SupportedTableTests(unittest.TestCase):
    def test_table_has_exactly_one_row_today(self):
        self.assertEqual(len(native_gateway.SUPPORTED_WINDOWS_INTERPRETERS), 1)
        self.assertEqual(native_gateway.SUPPORTED_WINDOWS_INTERPRETERS[0],
                         ('CPython', (3, 13), 'win_amd64'))


class CheckInterpreterTests(unittest.TestCase):
    def _check(self, version, impl='CPython', **plat):
        kw = dict(WIN_AMD64)
        kw.update(plat)
        return native_gateway.check_interpreter(
            version_info=version, implementation=impl, **kw)

    def test_supported_3_13_win_amd64_cpython_ok(self):
        r = self._check((3, 13, 7))
        self.assertTrue(r['ok'])
        self.assertEqual(r['running'], 'CPython 3.13.7 win_amd64')
        # Running description must never leak a path or identity.
        self.assertNotIn('/', r['running'])
        self.assertNotIn('\\', r['running'])

    def test_minor_versions_refused(self):
        for minor in (12, 14, 10, 9, 15):
            r = self._check((3, minor, 0))
            self.assertFalse(r['ok'], 'expected refusal for 3.%d' % minor)
            self.assertIn('3.%d' % minor, r['running'])
            self.assertIn('supported interpreter', r['reason'])

    def test_pypy_refused(self):
        r = self._check((3, 13, 0), impl='PyPy')
        self.assertFalse(r['ok'])
        self.assertIn('PyPy', r['running'])

    def test_win32_32bit_refused(self):
        r = self._check((3, 13, 0), platform='win32', machine='x86', pointer_bits=32)
        self.assertFalse(r['ok'])
        self.assertIn('win32', r['running'])

    def test_arm64_refused(self):
        r = self._check((3, 13, 0), platform='win32', machine='ARM64', pointer_bits=64)
        self.assertFalse(r['ok'])
        self.assertIn('win_arm64', r['running'])

    def test_garbage_inputs_refused_without_raising(self):
        garbage = [
            dict(version_info=None, implementation=None, machine=None,
                 platform=None, pointer_bits=None),
            dict(version_info='not-a-tuple', implementation=123,
                 machine=object(), platform=['x'], pointer_bits='eight'),
            dict(version_info=(-1, -5), implementation='', machine='',
                 platform='', pointer_bits=-64),
            dict(version_info=(3,), implementation='CPython',
                 machine='AMD64', platform='win32', pointer_bits=64),
            dict(version_info=(), implementation=None, machine=None,
                 platform='win32', pointer_bits=None),
        ]
        for kw in garbage:
            try:
                r = native_gateway.check_interpreter(**kw)
            except Exception as exc:  # pragma: no cover - must never happen
                self.fail('check_interpreter raised on %r: %r' % (kw, exc))
            self.assertIn('ok', r)
            self.assertFalse(r['ok'])
            self.assertIn('running', r)
            self.assertIn('reason', r)

    def test_reason_names_running_and_supported_row(self):
        r = self._check((3, 14, 0))
        self.assertIn('3.14', r['reason'])
        self.assertIn('CPython 3.13 win_amd64', r['reason'])
        self.assertIn('will not switch interpreters', r['reason'])


class AbiGuardTests(unittest.TestCase):
    """Free-threaded / debug / pre-release builds that otherwise match -> refused.

    Each case passes the win_amd64 3.13 CPython bundle (which matches the table)
    and flips exactly one ABI guard; the result must be ok=False with a plain,
    path-free reason, and the 'running' description must name the condition.
    The defaults path (no ABI params given) is NOT driven here -- it is exercised
    by the live informational test (LiveInterpreterInfoTest) and by garbage inputs.
    """
    def _supported_bundle(self, **override):
        kw = dict(version_info=(3, 13, 1), implementation='CPython',
                  machine='AMD64', platform='win32', pointer_bits=64,
                  gil_disabled=False, debug_build=False, releaselevel='final')
        kw.update(override)
        return native_gateway.check_interpreter(**kw)

    def test_baseline_bundle_ok(self):
        # Sanity: the exact bundle these tests start from is accepted.
        self.assertTrue(self._supported_bundle()['ok'])

    def test_free_threaded_refused(self):
        r = self._supported_bundle(gil_disabled=True)
        self.assertFalse(r['ok'])
        self.assertIn('free-threaded', r['reason'].lower())
        self.assertIn('free-threaded', r['running'])
        self.assertIn('different ABI', r['reason'])
        self.assertNotIn('/', r['running'])
        self.assertNotIn('\\', r['running'])

    def test_debug_build_refused(self):
        r = self._supported_bundle(debug_build=True)
        self.assertFalse(r['ok'])
        self.assertIn('debug', r['reason'].lower())
        self.assertIn('debug', r['running'])

    def test_prerelease_refused(self):
        for level in ('alpha', 'beta', 'candidate'):
            r = self._supported_bundle(releaselevel=level)
            self.assertFalse(r['ok'], 'expected refusal for releaselevel %s' % level)
            self.assertIn('pre-release', r['running'])
            self.assertIn('pre-release', r['reason'].lower())

    def test_final_release_ok(self):
        self.assertTrue(self._supported_bundle(releaselevel='final')['ok'])

    def test_abi_guards_default_from_version_info_tuple(self):
        # When releaselevel is NOT passed, it is derived from version_info[3].
        rc = native_gateway.check_interpreter(
            version_info=(3, 13, 0, 'candidate', 1), implementation='CPython',
            machine='AMD64', platform='win32', pointer_bits=64,
            gil_disabled=False, debug_build=False)
        self.assertFalse(rc['ok'])
        self.assertIn('pre-release', rc['running'])
        final = native_gateway.check_interpreter(
            version_info=(3, 13, 1, 'final', 0), implementation='CPython',
            machine='AMD64', platform='win32', pointer_bits=64,
            gil_disabled=False, debug_build=False)
        self.assertTrue(final['ok'])

    def test_malformed_abi_flags_fail_closed(self):
        # Tester MINOR-A / Stage 3: gil_disabled and debug_build accept True/False/
        # None ONLY. A malformed flag of any OTHER type (truthy string, int, list)
        # is treated as present -> REFUSE (fail closed). Each case starts from the
        # exact supported win_amd64 3.13 final bundle and flips ONE flag to a bad
        # value; the result must be ok=False.
        #   MUTATION reasoned: if the code reverted to `gil = bool(gil_disabled)`,
        #   then gil_disabled=0 or '' (falsy) would read as NOT free-threaded; and
        #   more importantly, if it dropped the coercion entirely (gil = False for
        #   non-bool) these malformed-but-truthy flags would WRONGLY pass -> this
        #   test would FAIL. So the test is non-vacuous and guards the fail-closed
        #   contract specifically.
        for bad in ('truthy-string', 7, ['x']):
            r_gil = self._supported_bundle(gil_disabled=bad)
            self.assertFalse(r_gil['ok'],
                             'gil_disabled=%r must fail closed' % (bad,))
            r_dbg = self._supported_bundle(debug_build=bad)
            self.assertFalse(r_dbg['ok'],
                             'debug_build=%r must fail closed' % (bad,))

    def test_none_abi_flags_fall_back_to_live_detection(self):
        # None means "detect from the live interpreter" (production path). Passing
        # None for both flags must NOT force a refusal by itself: on this ordinary
        # (non-free-threaded, non-debug) test interpreter the supported win_amd64
        # 3.13 final bundle must still be accepted.
        #   MUTATION reasoned: if None were coerced to True (instead of triggering
        #   live detection) this bundle would be refused -> this test would FAIL.
        r = self._supported_bundle(gil_disabled=None, debug_build=None)
        self.assertTrue(r['ok'])

    def test_running_text_never_leaks_slash_for_hostile_platform(self):
        # Tester MINOR-B / Stage 2: the 'running' description is built only from
        # sanitised pieces, so a hostile platform/implementation argument can never
        # put a path separator (or an echoed repr) into it. Each case is refused and
        # the running text contains neither '/' nor '\\'.
        #   MUTATION reasoned: if the display tag reverted to 'non-windows:'+plat
        #   with no filter, platform='a/b' would yield 'non-windows:a/b' and the
        #   assertNotIn('/') below would FAIL. Non-vacuous.
        hostile = [
            dict(platform='a/b'), dict(platform='c\\d'),
            dict(platform='/Users/someone/py'), dict(platform={}),
            dict(implementation='Evil/Impl'), dict(implementation=['CPython']),
            dict(platform='LINUX-WeirdLongStringXX'),
        ]
        for over in hostile:
            kw = dict(version_info=(3, 13, 1), implementation='CPython',
                      machine='AMD64', platform='win32', pointer_bits=64,
                      gil_disabled=False, debug_build=False)
            kw.update(over)
            r = native_gateway.check_interpreter(**kw)
            self.assertNotIn('/', r['running'])
            self.assertNotIn('\\', r['running'])
            # Never echo container repr characters into the running text.
            for ch in '{}[]':
                self.assertNotIn(ch, r['running'])

    def test_running_exact_supported_string_preserved(self):
        # Stage 2 must not change the exact supported rendering nor the ABI suffixes.
        ok = self._supported_bundle()
        self.assertEqual(ok['running'], 'CPython 3.13.1 win_amd64')
        self.assertTrue(self._supported_bundle(gil_disabled=True)['running']
                        .endswith(' (free-threaded)'))
        self.assertTrue(self._supported_bundle(debug_build=True)['running']
                        .endswith(' (debug)'))
        self.assertTrue(self._supported_bundle(releaselevel='beta')['running']
                        .endswith(' (pre-release)'))


class CygwinMsysBootstrapTests(unittest.TestCase):
    """Native bootstrap on Cygwin/MSYS Python is refused BEFORE anything is made."""
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name) / 'AQ-MCP-Gateway'
        self.gw = native_gateway.NativeGateway(self.root)

    def test_cygwin_refused_nothing_created(self):
        for plat in ('cygwin', 'msys'):
            with mock.patch.object(native_gateway.sys, 'platform', plat), \
                 mock.patch.object(native_gateway.subprocess, 'run') as run_spy:
                with self.assertRaisesRegex(DeploymentError, 'Cygwin/MSYS'):
                    self.gw.bootstrap(approved=True)
            self.assertFalse(self.root.exists())
            self.assertFalse(run_spy.called)

    def test_genuine_linux_platform_not_refused_by_cygwin_guard(self):
        # A 'linux' platform string must NOT trip the Cygwin/MSYS refusal. We mock
        # check_interpreter -> ok (so the gate is a pass-through if ever reached on
        # a host where os.name=='nt' is forced elsewhere) and subprocess.run, then
        # confirm the flow proceeds to READY -- i.e. the Cygwin guard did not fire.
        supported = {'ok': True, 'running': 'CPython 3.13.1 win_amd64',
                     'reason': 'ok',
                     'supported': native_gateway.SUPPORTED_WINDOWS_INTERPRETERS}

        def execute(argv, *a, **kw):
            if argv[1:3] == ['-m', 'venv']:
                py = native_gateway.local_python(self.root)
                py.parent.mkdir(parents=True)
                py.write_text('stub')
            return mock.Mock(returncode=0)

        with mock.patch.object(native_gateway.sys, 'platform', 'linux'), \
             mock.patch.object(native_gateway, 'check_interpreter',
                               return_value=supported), \
             mock.patch.object(native_gateway.subprocess, 'run',
                               side_effect=execute):
            state = self.gw.bootstrap(approved=True)
        self.assertEqual(state['state'], 'READY')


class BootstrapGateTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name) / 'AQ-MCP-Gateway'
        self.gw = native_gateway.NativeGateway(self.root)

    def test_unsupported_interpreter_creates_nothing_and_no_subprocess(self):
        # Force Windows so the gate is active, and force an unsupported interpreter.
        unsupported = {'ok': False, 'running': 'CPython 3.14.0 win_amd64',
                       'reason': 'Unsupported interpreter for the native-Windows '
                                 'gateway. Run the wizard under a supported '
                                 'interpreter; the wizard will not switch '
                                 'interpreters for you.',
                       'supported': native_gateway.SUPPORTED_WINDOWS_INTERPRETERS}
        with mock.patch.object(native_gateway.os, 'name', 'nt'), \
             mock.patch.object(native_gateway, 'check_interpreter',
                               return_value=unsupported), \
             mock.patch.object(native_gateway.subprocess, 'run') as run_spy:
            with self.assertRaisesRegex(DeploymentError, 'Unsupported interpreter'):
                self.gw.bootstrap(approved=True)
        # Nothing on disk, and subprocess.run never called.
        self.assertFalse(self.root.exists())
        self.assertFalse(run_spy.called)

    def test_supported_interpreter_reaches_existing_flow_unchanged(self):
        supported = {'ok': True, 'running': 'CPython 3.13.7 win_amd64',
                     'reason': 'ok',
                     'supported': native_gateway.SUPPORTED_WINDOWS_INTERPRETERS}

        def execute(argv, *a, **kw):
            if argv[1:3] == ['-m', 'venv']:
                py = native_gateway.local_python(self.root)
                py.parent.mkdir(parents=True)
                py.write_text('stub')
            return mock.Mock(returncode=0)

        # os.name left as the real platform EXCEPT we also prove the gate passes
        # when Windows: patch check_interpreter to 'supported' so the flow proceeds
        # whether or not the test host is Windows, then assert the existing flow ran.
        with mock.patch.object(native_gateway, 'check_interpreter',
                               return_value=supported), \
             mock.patch.object(native_gateway.subprocess, 'run',
                               side_effect=execute) as run:
            state = self.gw.bootstrap(approved=True)
        self.assertEqual(state['state'], 'READY')
        self.assertTrue((self.root / 'aq_registry.py').exists())
        self.assertEqual(json.loads((self.root / 'targets.json').read_text()),
                         {'targets': {}})
        self.assertTrue(run.called)


class InspectInterpreterFieldTests(unittest.TestCase):
    """The informational fields must not change READY/not-READY state."""
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name) / 'AQ-MCP-Gateway'
        self.gw = native_gateway.NativeGateway(self.root)

    def _ready(self, venv_version=None):
        self.root.mkdir()
        for f in ('aq_registry.py', 'aq_mcp_stdio.py', 'aq_check.py',
                  'requirements-gateway.txt'):
            (self.root / f).write_text('test')
        python = native_gateway.local_python(self.root)
        python.parent.mkdir(parents=True)
        python.write_text('test')
        (self.root / 'targets.json').write_text('{"targets": {}}\n')
        if venv_version is not None:
            (self.root / 'venv' / 'pyvenv.cfg').write_text(
                'home = /somewhere/python\nversion = %s\n' % venv_version)

    def test_ready_state_identical_with_and_without_field(self):
        self._ready()
        # With the field as the code computes it (now named 'wizard_interpreter'):
        with_field = self.gw.inspect()
        self.assertEqual(with_field['state'], 'READY')
        self.assertIn('wizard_interpreter', with_field)
        self.assertIn('running', with_field['wizard_interpreter'])
        self.assertIn('supported', with_field['wizard_interpreter'])
        # Strip the new fields: the remaining status is the legacy result.
        without_field = {k: v for k, v in with_field.items()
                         if k not in ('wizard_interpreter', 'gateway_interpreter')}
        self.assertEqual(without_field['state'], with_field['state'])
        self.assertEqual(without_field['installed'], True)
        # 'supported' flag never promotes/demotes state.
        for forced in (True, False):
            fake = {'ok': forced, 'running': 'CPython 3.13.7 win_amd64',
                    'reason': 'x',
                    'supported': native_gateway.SUPPORTED_WINDOWS_INTERPRETERS}
            with mock.patch.object(native_gateway, 'check_interpreter',
                                   return_value=fake):
                r = self.gw.inspect()
            self.assertEqual(r['state'], 'READY')
            self.assertEqual(r['wizard_interpreter']['supported'], forced)

    def test_not_ready_state_unaffected(self):
        # MISSING gateway: state unaffected, and no interpreter field is added
        # (the early return happens before the READY receipt is built).
        r = self.gw.inspect()
        self.assertEqual(r['state'], 'MISSING')
        self.assertNotIn('wizard_interpreter', r)
        self.assertNotIn('gateway_interpreter', r)

    def test_ready_with_mismatched_venv_cfg_stays_ready(self):
        # A 3.14 venv cfg must NOT change state: READY stays READY, and the
        # informational gateway_interpreter note is present and warns only.
        self._ready(venv_version='3.14.0')
        r = self.gw.inspect()
        self.assertEqual(r['state'], 'READY')
        self.assertEqual(r['gateway_interpreter']['venv_version'], '3.14.0')
        self.assertFalse(r['gateway_interpreter']['matches_supported'])
        self.assertIn('note', r['gateway_interpreter'])
        self.assertIn('NOT been changed', r['gateway_interpreter']['note'])
        # The cfg's 'home' path must NEVER appear anywhere in the receipt.
        self.assertNotIn('/somewhere/python', repr(r))


class ReadGatewayVenvVersionTests(unittest.TestCase):
    """read_gateway_venv_version: read-only, never-raising, version-only, no paths."""
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name) / 'AQ-MCP-Gateway'
        (self.root / 'venv').mkdir(parents=True)
        self.cfg = self.root / 'venv' / 'pyvenv.cfg'

    def _read(self):
        return native_gateway.read_gateway_venv_version(self.root)

    def test_supported_version_matches(self):
        self.cfg.write_text('home = /x/y\nversion = 3.13.1\n')
        r = self._read()
        self.assertEqual(r['version'], '3.13.1')
        self.assertTrue(r['matches_supported'])
        # Never echo the cfg 'home' path.
        self.assertNotIn('/x/y', repr(r))

    def test_unsupported_version_no_match(self):
        self.cfg.write_text('version = 3.14.0\n')
        r = self._read()
        self.assertEqual(r['version'], '3.14.0')
        self.assertFalse(r['matches_supported'])

    def test_missing_version_key_falls_back_to_version_info_or_unknown(self):
        # No 'version'; a numeric 'version_info' is used as fallback.
        self.cfg.write_text('home = /x\nversion_info = 3.13.2\n')
        r = self._read()
        self.assertEqual(r['version'], '3.13.2')
        self.assertTrue(r['matches_supported'])
        # No 'version' and no 'version_info' -> unknown.
        self.cfg.write_text('home = /x\nexecutable = /x/python\n')
        r = self._read()
        self.assertEqual(r['version'], 'unknown')
        self.assertIsNone(r['matches_supported'])

    def test_empty_file_unknown(self):
        self.cfg.write_text('')
        r = self._read()
        self.assertEqual(r['version'], 'unknown')

    def test_huge_file_unknown_without_reading_all(self):
        # > 16 KiB: must be reported unknown via the size cap, NOT by scanning it.
        self.cfg.write_text('a' * (200 * 1024))
        with mock.patch('builtins.open',
                        side_effect=AssertionError('must not open an oversize cfg')):
            r = native_gateway.read_gateway_venv_version(self.root)
        self.assertEqual(r['version'], 'unknown')
        self.assertIsNone(r['matches_supported'])

    def test_non_utf8_bytes_no_raise(self):
        self.cfg.write_bytes(b'version = 3.13.1\n\xff\xfe\x00bad')
        r = self._read()  # must not raise; decodes with replace
        self.assertIn(r['version'], ('3.13.1', 'unknown'))

    def test_symlinked_cfg_unknown(self):
        self.cfg.write_text('version = 3.13.1\n')
        target = self.root / 'venv' / 'real_cfg.txt'
        target.write_text('version = 3.13.1\n')
        link = self.root / 'venv' / 'linked.cfg'
        try:
            os.symlink(str(target), str(link))
        except (OSError, NotImplementedError, AttributeError) as exc:
            self.skipTest('OS cannot create symlink: %r' % exc)
        # Point a fresh gateway root at a venv whose pyvenv.cfg IS a symlink.
        root2 = Path(self.tmp.name) / 'G2'
        (root2 / 'venv').mkdir(parents=True)
        os.symlink(str(target), str(root2 / 'venv' / 'pyvenv.cfg'))
        r = native_gateway.read_gateway_venv_version(root2)
        self.assertEqual(r['version'], 'unknown')
        self.assertIsNone(r['matches_supported'])

    def test_shell_junk_value_unknown(self):
        self.cfg.write_text('version = 3.13.1; rm -rf /\n')
        r = self._read()
        self.assertEqual(r['version'], 'unknown')
        self.assertIsNone(r['matches_supported'])

    def test_home_path_never_in_returned_dict(self):
        self.cfg.write_text('home = /Users/someone/pythons/3.13\nversion = 3.13.1\n')
        r = self._read()
        self.assertNotIn('/Users/someone/pythons/3.13', repr(r))
        self.assertNotIn('home', r)
        self.assertNotIn('executable', r)

    def test_version_info_dotted_form_ok(self):
        # Tester MINOR-C / Stage 4: 'version_info' written in the extended dotted
        # form (major.minor.micro.releaselevel.serial) is accepted and ONLY the
        # leading three numeric components are returned.
        #   MUTATION reasoned: if the fallback still used the strict numeric-only
        #   _VENV_VERSION_RE, '3.13.2.final.0' would be rejected -> version 'unknown'
        #   and this assertEqual('3.13.2') would FAIL. Non-vacuous.
        self.cfg.write_text('home = /x\nversion_info = 3.13.2.final.0\n')
        r = self._read()
        self.assertEqual(r['version'], '3.13.2')
        self.assertTrue(r['matches_supported'])
        # The trailing '.final.0' must never appear in the result.
        self.assertNotIn('final', repr(r))

    def test_version_info_garbage_unknown(self):
        # A 'version_info' that is neither the strict numeric shape nor the extended
        # dotted shape stays 'unknown'.
        self.cfg.write_text('home = /x\nversion_info = 3.13.2.final.0.extra\n')
        r = self._read()
        self.assertEqual(r['version'], 'unknown')
        self.assertIsNone(r['matches_supported'])
        self.cfg.write_text('version_info = not.a.version\n')
        r = self._read()
        self.assertEqual(r['version'], 'unknown')
        self.assertIsNone(r['matches_supported'])

    def test_both_keys_present_version_wins(self):
        # When BOTH 'version' and 'version_info' are present, 'version' is preferred
        # and parsed with the strict pattern; 'version_info' is ignored.
        #   MUTATION reasoned: if preference flipped to 'version_info', this would
        #   return 3.14.0 and the assertEqual('3.13.1') would FAIL.
        self.cfg.write_text('version = 3.13.1\nversion_info = 3.14.0.final.0\n')
        r = self._read()
        self.assertEqual(r['version'], '3.13.1')
        self.assertTrue(r['matches_supported'])

    def test_missing_file_unknown(self):
        # setUp creates only the venv folder, never pyvenv.cfg, so the file is
        # already absent. (The previous self.cfg.unlink() raised FileNotFoundError.)
        self.assertFalse(self.cfg.exists())
        r = self._read()
        self.assertEqual(r['version'], 'unknown')
        self.assertIsNone(r['matches_supported'])


class LiveInterpreterInfoTest(unittest.TestCase):
    """Informational, NON-failing: print what the live interpreter resolves to.

    It NEVER asserts ok. A human reading the -v output sees exactly what the
    wizard is running under (which is the interpreter that would be gated on a
    real native-Windows bootstrap). Failing here would break non-3.13 dev
    machines, so it only prints.
    """
    def test_print_live_interpreter(self):
        r = native_gateway.check_interpreter()
        # Write to stderr so it shows with -v without being parsed as a failure.
        sys.stderr.write(
            '\n[informational] live check_interpreter() -> '
            'ok=%r running=%r\n' % (r.get('ok'), r.get('running')))
        # No assertion on ok by design.
        self.assertIn('running', r)


if __name__ == '__main__':
    unittest.main()
