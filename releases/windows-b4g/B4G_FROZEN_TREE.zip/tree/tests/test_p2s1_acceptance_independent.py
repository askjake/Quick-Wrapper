"""P2 Slice 1 (remote-only macOS wizard) - INDEPENDENT acceptance tests (Tester T1b).

T1b = T1 (A1 two operation-bound G1b scopes + decision-B export guard) re-pinned to the
FROZEN tree and extended with the A1.1/B3b-B3e items: any-Exception SSH-library import,
pre-connect validation/size, remote-error redaction, receipt-path guard, central FULL
gating, exact-type tokens, Step 4/5 redaction helpers, stale-callback ownership, CLI help
constants and BASE (Windows v0.4) parity goldens for every changed function. Stdlib unittest only. No network, SSH, subprocess or
clipboard; writes only in tempfile folders; export tests point HOME/USERPROFILE at a temp
folder. SSH authentication is UNCHANGED (user decision 2026-10-29): no test asserts
agent-only. paramiko is never needed: a STUB object is put in sys.modules inside a test
only; other darwin tests FAIL on any paramiko import attempt.
RUN (staging copy, never BASE): cd <tree> && python -m unittest tests.test_p2s1_acceptance_independent -v
  Wizard handler tests need only `import tkinter` (no display); Tk-window tests skip without a display.
  AQ_P2_TREE=<path> tree to test; AQ_P2_REQUIRE_CONTRACT=1 missing contract FAILS instead of skipping.
"""
import ast
import contextlib
import hashlib
import io
import json
import os
import pathlib
import shutil
import socket
import sqlite3
import subprocess
import sys
import tempfile
import threading
import unittest
from unittest import mock

HERE = pathlib.Path(__file__).resolve().parent
TREE = pathlib.Path(os.environ.get('AQ_P2_TREE') or HERE.parent).resolve()
if str(TREE) not in sys.path:
  sys.path.insert(0, str(TREE))
REQUIRE = os.environ.get('AQ_P2_REQUIRE_CONTRACT') == '1'

WIN_PARAMIKO_MSG = 'Install Paramiko first: py -m pip install paramiko'
HOST, USER, HOST_B, USER_B, TARGET = 'gateway.example.com', 'fakeuser', '192.0.2.10', 'otheruser', 'demo-epg'
SCOPE_I, SCOPE_V = 'inspect-gateway', 'verify-backend'
INSPECT_LABEL = USER + '@' + HOST
INSPECT_ACK = 'INSPECT GATEWAY ' + INSPECT_LABEL
VERIFY_ACK = 'VERIFY BACKEND ' + TARGET
INSPECT_OPS = ('inspect',)
VERIFY_OPS = ('inspect', 'inspect_lambda_target', 'discover', 'probe_existing')
G1B_OPS = VERIFY_OPS
G2_OPS = ('bootstrap', 'repair_permissions', 'apply', 'rollback')
NEVER_OPS = ('check', 'git_check') + G2_OPS
SPEC = {'host': HOST, 'user': USER, 'transport': 'linux-ssh', 'kind': 'lambda', 'target': TARGET,
    'url': 'https://abc123.lambda-url.us-west-2.on.aws/mcp', 'allow': ['list_genres']}
NATIVE_SPEC = dict(SPEC, transport='native-local', host='127.0.0.1', user='local')
# A1.1 P2-SEC-059: a discover request must carry a VALID entry (checked before connect).
ENTRY = {'url': SPEC['url'], 'allow': ['list_genres']}


def _table(text):
  return dict(line.split() for line in text.strip().splitlines())


# ---------------------------------------------------------------- golden constants (BASE)
SHARED_SHA256 = {'platform_p2.py': '919248a136708bfd762392893f09543aab21e98edabf3afbf76baeeafd29d387'}
UNTOUCHED_FILE_SHA256 = _table('''
remote_agent.py 7f4e32a9f2f61e2352fd8e99d463854883fff3ca3dcabce0a724dae9f2748807
bootstrap_lib.py d8aff711f712f7a0ca471a8a9fb278e4ec6664c0777bc694386963f9e846bccb
bootstrap_payload/aq_check.py 5a0f4eca917fbd564e9a719d7d64caf92f722fc760e8ed10e6bca7f3928556de
bootstrap_payload/aq_mcp_stdio.py d5527bacd3d18deb8906c38f79f9621539ad5ce9be6837e42c36d4ddc66bbf8f
bootstrap_payload/aq-run.sh ff9bb104db92501c9d1034cd11ee2e634314316fd6c96a9cc5d7a893766c9368
bootstrap_payload/requirements-gateway.txt ce9aa1d563081d46697133908c48c8f6eceb760087cfbdef61879ee3d465240c
bootstrap_payload/requirements-gateway.lock 8cda25c6c470e838c83707a916f208c08c60c3330082986e5be4778e7f87c8ce
bootstrap_payload/aq_registry.py a062a586cc12ca4baf6a5f7817a08ae9443ebf17d9ab29be4806e47499956393
''')
# sha256 of ast.get_source_segment of BASE functions Slice 1 must NOT change at all.
UNCHANGED_DEF_SHA256 = _table('''
model.py::normalize_tools afffa22131841b60d8decf0307762cfaab7e5b2cab657b7bfeaf68cff7b93dad
model.py::validate_lambda_url 820ac294881d935faca535b8ac1af6b222f9e9f81d889791d4e2bf867adaa3d1
model.py::make_registry_entry 81e032c4200c1aa72697fb3db76c0ccd5aee68d64057925595e7e53309db8fc7
model.py::plan bc9bef641bc28efe707d795d23146c0ef153e704251e4c0602e24045d34da517
model.py::redact_identity d8508855a51d6aac12ec0b1dcbc24e4d087c93ec12c1f037becb3ab643f44948
model.py::backend_identity 51adfa404fe9d7958a56ab5f8a0e8bd3ee0b913c6a4cf4bbe5a15542680ef4c2
model.py::risk_tool_names f7b07018fdd771ac2d9c383fa0cef4b93c913233e9c74a65c3bfb66d91c836ce
model.py::validate_gateway 72065951fcd2a735e9a03445a74bbdbf7abbc677fd5f47eb18964a540a227434
model.py::quick_connector e2f00270ea3c5c3efa45a570c538175ac6c90df6c5528cdced5816f532835d6a
model.py::config_export 808489b01daa0213495a60c9ae318a68428ff45349b219fd5cb82a377d5b9c11
native_gateway.py::native_root 6173e4076c5c3fb36fc5668ccbfe47ed9c8a70c5fc956c03350a6c60766eaba5
native_gateway.py::local_python b2f1f3e529595bdca410c7a8d428bfc04ec44ae102b822e5e1a805b6d892bfee
native_gateway.py::check_interpreter 667987c9316c846093962bad0f70dd3024b21bbb8029e047dfe14a644c94dcc5
native_gateway.py::_running_platform_tag b3467da96901c9b68107feb64864ae35f18e4dfef2c2c80c5bec857958dd1498
native_gateway.py::digest b46c442db8153d4caa4e3d7ebb3560f6dc261f2c614ac20722d41b32fb1785fd
quick_reg.py::quick_copy_fields acb29dd5cf905e0b935624975989ef832d03770f356e6fab6beb1bfb2bb6089b
quick_reg.py::quick_instructions de927f285aef66561ace44c33013d979a246c5b4edfad9fe21026f3f85ab09e2
quick_reg.py::quick_instructions_variants 039586f91d4ab39e2ab367f5ebb3e3c64f1c26728142b04a3a04cc4d388fd78a
quick_reg.py::config_export_text 00351aeb8ee437bb6ba084aa01fd35a767e9b3a58c701c708571743f82295d92
quick_reg.py::_validate_import_name 98575486c205eac32852e602cd6abfad006473fb8932eaa65b4eca745d916561
quick_reg.py::_build_import_payload ace4effeb5dd3b76c7d7f2a3c53ef41640452283de8075a7660101c42889d714
quick_reg.py::verify_quick_import ecd79c5a910cc808028bf53e2b1d3c713363cf3a04ed8ad83ad2525411046429
quick_reg.py::check_name_collision b6f424728b6778f607ffde16907ae1a53d8d6c3a7d32020dd3b0e8c0dff901c2
cli.py::confirm_apply 6472911c059061a6c0dc550065a71c012d15e4fd8675cd12fe2aecb9a5559c55
cli.py::read_json 100926b286e3b92c5ba63dbf18ac66ab5d0a57d88233033f90f059e40e59a419
cli.py::write_new_json 967a57b0ee871d377b5eb1f5011718469765b29bcf86af84da4d4eebe5bfda0c
cli.py::load_bootstrap_receipt cd274c7378d5839eae37d75ccd5d14aafc630b61a0d982c2d53431157ac90746
''')
# T1b: BASE (Windows v0.4) functions that Slice 1 changed ONLY by adding statements that are
# inert off macOS (gate calls, `if <darwin-only>:` without else at any depth, new private
# wizard attributes, the --ack option) plus the documented all-platform B1b delta (deploy
# refuses an offline plan). Removing exactly <count> such statements (and the comment lines
# directly above them) from the frozen segment must give the BASE segment; sha256 values
# were computed from the BASE v0.4 files, not typed by hand.
# key  base_sha256  count
LEADING_GATE_DEF = dict((k, (s, int(c))) for k, s, c in (ln.split() for ln in '''
deploy_lib.py::ConnectorDeployer.inspect 5f614331d0781ff3d9302eb4fe5e02278f281e2566b1f5aac01cd66724dddd30 1
deploy_lib.py::ConnectorDeployer.bootstrap d1cff3a759811559556946542d4b0aba0a377868b1da4193f30f055574883f15 1
deploy_lib.py::ConnectorDeployer.repair_permissions 1b778f471d63a860a2ded05c88caddf4dac563afec8cf840c11a7fa97b4de3fb 1
deploy_lib.py::ConnectorDeployer.verify_backend d524c8e4cf9b3e2b2e6bc2640eb92ae5aa2101f89d33fb8adc8453d24a45b563 1
deploy_lib.py::ConnectorDeployer.prepare 816bf74310e7025269608869d87410354bfc0ad3fb6c322273af88bf44048fb3 1
deploy_lib.py::ConnectorDeployer.discover 2bd779d0caeac267c9ddb02f059c4b74adaf1741991e8ee3ae2591e611fc6e91 1
deploy_lib.py::ConnectorDeployer.deploy 9aa9b0ffc85685c8e06238b5fff167c1ea9d4884d8cb34680842bd4e04d19a9d 2
deploy_lib.py::ConnectorDeployer.rollback ad67d3d4a38a3980fa0da1042c87a9adae9472c02c3310bb3b4ff6ea24d9fa83 1
native_gateway.py::ensure_safe_root 910a4931b119637d151cda8fc4268507dbcecdc6c6f9940b5f923c06bd50791f 1
native_gateway.py::exclusive_lock 77e5c03cdb092420d80a7764a85382fad6ba3fe88bdd924a5a4361f9818606c6 1
native_gateway.py::atomic_write e3d6b797769f5c61cfb8f721eeaaae8fea396cdad8425819840659e31b028f90 1
native_gateway.py::NativeGateway.inspect 5ad3630904f50f8ab0a5374599bb6b0cbced8b8fa56644e4cacdb929741b98ac 1
native_gateway.py::NativeGateway._load 27cf5e8ae55778253cd49dcf5002b732af9003025f8bdedae0988158be36077c 1
native_gateway.py::NativeGateway.bootstrap fb87c6d09605ca7ed3c33c4f3646b0d272435be117a94b5d6188379a15fdee6a 1
native_gateway.py::NativeGateway._probe_entry d6551f3f6f1a88aaef92ebc225ae80a7dec00881503aa73b153d8fb8efc8e2b5 1
native_gateway.py::NativeGateway.run 8c1dccdf11e772564bd14676941981156a8c481a89930ee8520e72f087bc17a3 1
native_gateway.py::NativeGateway._apply 07bb557b490bdb92bec134f6ceb3d34abf008f8a77e6e5227ed625a4209e4742 1
native_gateway.py::NativeGateway._rollback a55a3412128f9838fb27d285c074964484de4b299a88ef57dafd3bb93fa741d8 1
model.py::validate_spec 27c8593c6a956749801b058681c36de0dd5c3b4989be79384e0489a9483bcf3a 1
quick_reg.py::inspect_dips_read_only e32d9b8a2d81cab4d829e96d37708decf70328ba4a4f80841c01316206f7c234 1
quick_reg.py::emit_quick_import_file 2f978e5d962b0226672b62496d12c1ec9fa79c12976e403d69019e92bb0d8b56 1
quick_reg.py::find_quick_profile_configs d6d0d7a49fb2608c8aa23569a96afb4b21d2a54dc49fe23a0e89bb7145084e4b 1
wizard.py::Wizard.text_area 667a97814e80ff8b61ee293ea3e64fe031407c7f0271e72ef7884c7c0566e8d6 1
wizard.py::Wizard.render_gateway 1e225a8a271b314f18b8dd69cba1364f7d5d9cbca340a0eab92291e5e94e4241 1
wizard.py::Wizard.verify_backend_action 32258412d855e729948e5403a499009704492d49c51db27355d34359d3723f97 1
wizard.py::Wizard.render_tools e07efd3a48d45576059b409e8edb14f608c202ed5031835462dece89936b4fe9 1
wizard.py::Wizard.action 821cfe4538e32bea7ef64c63986cdc0359c483065e06dbc7c4ff7c3113553f26 1
wizard.py::Wizard.inspect_action 6af57c2bacb1ce4f7891a0e6c77339488364619afbf1755743a2ca950e611e0e 1
wizard.py::Wizard.bootstrap_action f3f833ef6c0238d55fef5e7a83f16e819662c308132bbb7d13bc9b89366a485c 1
wizard.py::Wizard.repair_action d487d64aeba4379676838dfc42d6cf8aeb7a0e1f741849fd287c2f0e6f38b8e2 1
wizard.py::Wizard.discover_action 9c94a8d04c9fbbc67c6806c065b9b2b53f5bcf2e79f95910d1dfecc35f2b0330 1
wizard.py::Wizard.deploy_action 166845004c2077e8fa858e92a8921d40e257d0f8460e0e904e0f870102aa1ddd 1
wizard.py::Wizard.save_receipt_action c54ff74a53dc4cd03736351978679ace5e908e13e4c27a912137504135bab215 1
wizard.py::Wizard.save_bootstrap_receipt_action 939b200b1b2533d468d19b91cdf7230d38f733b2adf1999f3c730456a52d7a50 1
wizard.py::Wizard.rollback_action c270adf68b2b46e223958155fd65f7a971b62e5ddae4ccca771c8afba85700e9 1
wizard.py::Wizard.copy_quick_full 8b42834b48db0de2163715fd78aa8b8a87644fbe883b6c855cd2ba3f190f494f 1
wizard.py::Wizard.export_full_action 1161bc69b217eee03843421c30900516478d25386ac1c5f1e8cc7bc2a374b50e 1
wizard.py::Wizard._export cc6599020039617f02b10024b1ec53f66f09412e5d6e828565b5601a2135efaa 1
wizard.py::Wizard.dips_action 5c226de18ae7bcff362c47dedfb014898219ecf8f05f0910164b792e22db27da 1
wizard.py::Wizard.__init__ 05747ed0387a507e6a705d09ec681c189445c99ed495902ff0e6e1ce21be9e03 7
wizard.py::Wizard.summary_text d2cc08a27eb5e5b6c25512c28bec777b08b569f3ff9dec02d98a665525b6747d 2
cli.py::main 4888b694860f8abfd84993e414137cbe97dbe5f06455f3fdbe54ce068f2c310c 4
'''.strip().splitlines()))
GOLD_QUICK_CONNECTOR = {
  'id': 'aq-demo-epg', 'name': 'AQ demo-epg', 'connection_type': 'Local', 'command': 'ssh',
  'arguments': ['-T', '-q', 'fakeuser@gateway.example.com', '/home/fakeuser/aq-mcp/aq-run.sh', 'demo-epg'],
  'timeout_seconds': 30, 'environment_variables': {}}
GOLD_COPY_FIELDS = {'command': 'ssh',
          'arguments': '-T -q fakeuser@gateway.example.com /home/fakeuser/aq-mcp/aq-run.sh demo-epg',
          'id': 'aq-demo-epg', 'name': 'AQ demo-epg', 'timeout_seconds': 30}
GOLD_CONFIG_EXPORT_SHA = '089999b64caf674f27a89da597083577a9fad768cd04aa5e2010e6676ee173d7'
GOLD_CONFIG_EXPORT_REDACTED_SHA = '21b6801132f5ed96323873e6446045e94328b694545933ad1896747904959943'
GOLD_VARIANTS_SHA = {
  'redacted': '4509d583b4b09b5045594b07d2a309009289959772efe60836dd6813f276f094',
  'full': 'f5c4d32a6c989ccf4883dbd0636895113be1ad59bbbdcf925e660a9026a2349a',
  'full_labeled': '6083cb47222922ff5ba4bd4c0363039cab2387ac214f8a296c306df6017f14d1'}
GOLD_FULL_WARNING = ('FULL variant - contains your real login and host. Do NOT paste into tickets, '
          'decks or chat. Use the redacted variant to share.')
GOLD_PREPARE_SHA = '98aef543872c2f287b06cc6d627c15cc5c5881d3e2ee3ff033624d540c543d43'
GOLD_PREPARE_KEYS = ['backend_identity_sha256', 'execution_plan', 'existing_target_count',
          'expected_registry_sha256', 'gateway', 'kind', 'mode', 'no_secrets_in_manifest',
          'potentially_mutating_tools_name_only', 'quick_connector', 'registration',
          'registry_entry', 'target', 'tool_count_to_expose', 'version', 'warnings']
GOLD_VERIFY_SHA = '4aca816558d025533b6382a3d13f77832e40232109e15258e23a24bbebabce1b'
GOLD_DEPLOY_OPS = ['discover', 'apply', 'check']  # T1b: T0/T1 value was wrong (re-derived on BASE)
GOLD_BASE_REMOTE_OPS = {'apply', 'git_check', 'bootstrap', 'inspect', 'check', 'repair_permissions',
            'discover', 'inspect_lambda_target', 'probe_existing', 'rollback'}
GOLD_BASE_CLI_VERBS = ['inspect', 'discover', 'plan', 'apply', 'export', 'rollback', 'bootstrap',
           'repair-permissions', 'save-bootstrap-receipt', 'import-file', 'import-check',
           'import-verify']
FORBIDDEN_WORDS = ('sudo', 'brew', 'launchctl', 'osascript', 'security', 'tccutil', 'xattr',
         'spctl', 'codesign', 'keychain')
DARWIN_FILES = ('wizard.py', 'cli.py', 'deploy_lib.py', 'native_gateway.py', 'model.py',
        'quick_reg.py', 'platform_p2.py', 'capability_gate.py')

BASE_BLOB_SHA256 = {
  'deploy_lib.py::SSHGateway.run': '9d572d9514e036f1b6906f628460e4c320f8fb872f1d06bca96b0fd0c0fe7c16',
  'quick_reg.py::write_quick_config': '248d34de984d373892208f515c08b1b55524630be28bd3054f05659f8c124072',
  'wizard.py::Wizard.plan_action': 'cc7a7decf953de494ae723134d17ec380f55f422ce19ea8a5c7294edff619ece',
  'wizard.py::Wizard.render_quick': '567246ce226b35a03eeb5d23a7358eaafc86dbadbdcb17a8b2557b440e6959e8',
  'wizard.py::Wizard.render_review': 'd8c13d9dbb7a26ffdaf1453e2f25458094d5055f89a43c7b088e2da665f45e53',
}
# zlib+base64 JSON {key: BASE v0.4 source segment} of the functions whose off-darwin view
# needs AST comparison (darwin if/else branches). Integrity: each segment must hash to
# BASE_BLOB_SHA256 (computed from the BASE files).
BASE_BLOB = (
  'eNq1WXtz2zYS/yqo8wfJO5pxfI6vJ49uxrGV1lc3ce2k7UyS4UDkUkLFVwHQtprJd79dAKQoSnKdns+Z2BQB7Pvx'
  'W+jzXgp1Xi3jXEyjejka3dx8/x3XcMeXkWzKvRHDDRnDR19BnoVMwu8NKB0yLQqoGj0+fhmMPpbM/Wi57H2iH1HU'
  'ldSs5pIXYlGtFuE+gVqzC7M+kbKSg5OSCwXs3MhXQGn3+N5FqTTPc3blKLJMSKVHrF6y/YLVombC7Wh5esGKsMhY'
  'WWlWqajmeh4JlYkcjG7RoqzuynheKa2Cx4nyA53YNycY0WFCsUIoJcpZxM6qsoREs1vB0SyN0pCytzWUaGEr8gm7'
  'BSmyJSMC+KqcgaylKHXUF1jJZOx/P7mePPckFJWGmM9QAnSWF0QSeBpPlxqU3zuSFOnYq5d6XpX/YPsJ+7jnnDDl'
  'Co6PTuAeEt8+R9PjoxSSKgX/40fv8xf8FQQf97woq2TBdW8XlGYXihNE7oTHVSIEHVixzgUKN24tH6GyZ+aVv7Ep'
  'yisUXi3RMIWxeryApdq1b7Vhw1cbBxTo2LmhOxfXVS6Spd9Jdg2/oXeu7Nu+Cpsh7Mgm1qFWAKIbNgpkyQsYm1f0'
  'KWzTwrxxH0Le6Hm8dWWd0eBnypGh3H4Q47u6s6EwficbCPOqWsToNWMk8yoYJGJZh3QSpBw7jSgQ4qQqCl6mPkZN'
  'J737O6BQ8yX5YvybqsoobYpa+W05UBheuzlnLIfSd8eDfx8eH744Ohpt6r4jza4tE1MxIFVM8Qz0kinxB7BcFEJ7'
  'm6pGd1JoaHlGLnq9Rmf7365FbLs/yxs197csJHNyQx6peaNTijpLORhWiLsxWsxkpP/i4PDob/RrsEnplKyP/+2+'
  'b1/86zBgz1gJWAkYJPPKbRmxgi8ZBpzmokQpNMVZzt5fX6ohRa4bZTi3ckpIbmO4Fzq2i/6mN+zCN+ODx/vANQV2'
  'V8kFyYr0sZ7dCT131NjnL13VsG+GVk655jZ2yCUYO/yuqyQ7/GKLNR2MZqB9r1p4waNlXh0D+uyFGEhUQFlVg+Ra'
  'VCXLOFbtdIOvBN3I0vD9gFVXNbn2Pm10rgG/bS1j48zE/CHWXNG7waFnq65mZEbbYkOYKZZwFEeoJK9Q0bbsKIZ5'
  'ux4dJ7SrztFRelmjpmW+jB7VyrBQP9eSl8o0CmsX5n/+EmAjm0Oy6FqYaVaY6SGjRmYKkBHDVUdxK/Qy6iKBpPBR'
  'zyCKYxI5jvu2xp6HdWxXuSVd/WAvZHu/NyJZxBJmBqKY/IvtO+SaiVkLUzZXfFVDEprmHFPDJwCT8gQVsYXKsf64'
  'R//OMCk17JPRQoaZDtI8M//g+OAgsNRZlTE9B/YTMWGWCfvPzds36E1e1DmguS3Nc8g4Bo49psyh68n56dm7yTnz'
  '1Zwjs2kOAbvlUnDUF12v1Eq81zxX1oEMbcm4JZoCAjWKXmCv319eIlPjLz3nGmNESuE4IfGc5dVMlM/JYRF7M/l5'
  'cs0qrDNOHu7ExExWGmPM2Cg0rrR7ddUkc0fOasvrGrulzZxaVnQg6tvPPrukxcj1O7MHmPJ3IP0AC3GqqGr4XkSl'
  'YC2dbWj+zPMGXFSeGfs2LludsgUGIpsCcwQ6ri2mMxqpHvMNFq9xaWJ2dR0mawguoNIrG6EtVtaxvDtk9owpSBoJ'
  'thnEGu41gb9kFUHMfxtPfj27DGyRpBBiWHcKxfyrtzcXvzIo0a8JpCctxV9Eif1FoWpK70OWka7UJiw5rrEUTBvt'
  'YmIfBQBWYPHEzmRFwbJWBs4hG9L5vRSwURtbleyqTZMu+NqHNlldQexoUFLeiT+4TE1G/uIec17GeA591WZk75XB'
  'TX1fEE8LaujJ3wTpZm3KkwUGTWywcht9VBl3LdqS366IFGsJlqQYM+7w5bEXfDMeLhnlh23FkK8lIF5Ee7ypSlhf'
  'x+qrsPhNq3sEBhTbJo5eWdJGeisTdhfqO8Z8GFw3Gmp2aLJME6Sh5EJWQMZmTjAMAPQ9MCytpk9h9HFjSIy+E+uJ'
  'lSxk5BSl86tFaDvVUJN24llsaZybWp7YV+S2WwHUoHNAtOO9iA5QEZQOZRhswXELpG63XOF71z9GzPs7lQEnV7DJ'
  'f7sVeyS8sE9gQ3unn13/C45fBV/wOOs8IDDNnIAGeIcubT2J/s8RsBI0m2Gmo6DOqWA8v8upNuVIpw9eP7Rj1SBW'
  'l0vv0/izZ0GWN/JenZ79MHlzHmPRvnh9MTn3tkwVHkqQoiUW4I12Zs6H3q5P24hUWQZoilhXVY4Ntin1g9R62x4k'
  'Z4CBc9Moju2wGsc+iqPm2O9w0LWrPpo3+q0SWEtwB6T+/QePDnufTI+8RyzE/kQe5X0KgnYcwKc53KdihqnoB18e'
  'qgDWHUO09uH24OgTuirD5blx6Zmdpp6fyllD8Erh1ISonGWyKswGsxULeBsIqY2CLbwpwDowUy9jG0w2aHuvCUiE'
  '/Qzo8A/hMcS9w8T7HzN8bfojriH2LRpDD7cycsZpQ9cQ7Nd6s8l1iJwX05SPzlrRLUpF3GA2zewIQl5zbrGVO6T6'
  'F2xvSRL1wRHamKS7zOq922hKWi+iSz6F3PKcVukypA459g5eMnYNM8QDOP9goJ0W/A9sRQYaUZla5jD2vsd+Tbc/'
  '7wwNDNwaI9HnJY52cuzdeUPF55DXrX6GVzdopR1CN93CIrBzUAtd1VRHUA4Hi9AQSIwuNrCsoHS1QriHS7ewn1cJ'
  '4kCcFxTOBZJuo67MtRDzy4rwe3DCLkXZ3Bssb7YpNY/YuzliGcwdReQtGmxRbGWC+Pzi6saMR3Q/dMIEhrlCsFhw'
  'I6tq6trk57qcucggWSY5GImbsm2Qa9ddm7cvDh+rsY1rutyTjYkXFbdra5V8mKRvy32FwAxKdof2waQyKhj4bHDb'
  'FBKOupu3NFrRbSfBXsJzNpsRctGqkEPSOCTgpJ7MBbYGl/71kiFK0ygdEkbUi8W/oqGthVTMT+1ggMhfsazJ80Hu'
  'F2o2bvX64NGGLbPn+hy5y2K2ZSE9BNI0m2B81FKYsRKjpG3PMAxKV3Q6Mu3Daltb+Vy1Y8/ZRr1DLmSQHMOQdbWI'
  '+RRo+LfsxWcQDfgPituYcvI1jsWwyhNXogY7bbYhSs3H3r0X1jxdjv2X4YuD4f3eV9fXQU1di7dgt3e+nhG5bOgP'
  'NHHDc3f/hxFrdvZqxovD7SfW6zbGQf+qtCq1xHa43bjt6jaDrnGj069MuPvtGVcuTSbYqqVAa3OL4XdzhRe61LJa'
  'Gf3bKd9tsbwVgrWxl0OmDfv7sX8w9OfDIpg89wfz8AP8KeGegPfEzqr9m4Hd6rtJzHbBp2NuVCcJtrMjTZ+O50VJ'
  '6aBta3DNwO/G16HGqajVTt5/3iRPM2rCit/ScCRcEw7pYg8LInasX9r7mTnXYfs1i4F/z3NsSFSBOJtzWeRg7lx4'
  'am8+JBA8oTl9n3abgZ2+SKjKLogjBwJcU7MofMR+PH3z/vQyvp789P7ienKOPe1BQGIZDRCJffk1kOSIMZo9QocW'
  'jA5W2ydEJDTQtL26m2xMn28HV2NZuhJKmwTcsMp4o6sCjZTQFR9hCtcMHCZYmvsSulqEbuLlNdK45fkJO63r3OzA'
  'DkEbcIYQuaFb2ruqUqg5qDXo8NdL2vGjIvzawfweMiOBBpHdu/F4gqw6d341hnGzwjCV7Be4T8byuspz8jLLOWbK'
  'StkBW+m2PR3jG26iIwFRD5lhpkPslh5TNh6PT1ZjWNfcQ3tj14dy/1+Ecjww0VeDBuavDatU3ujm/k+nwWfs5uWI'
  'YkqU+xhYs4bPECHbQQ3TuKzKfewVCCHM9w9UJtmryeu31xMXkPZqyoZI9JiCdbWVVVerfmzQETsrlbPWUbjFWL3h'
  'cjdO+vahY+tgaW3Z3JA+yDNK3EU1mO++UJVUKLreTzfqazdVPxLP0dd1feeOHjmbrx3aOqJDruBBat53/RvIQdlb'
  'r+/2fuMRXSKKog2TcOrm/j9fWqsT3Zg4BHtf/gslLIfw')
INERT_GATE_CALLS = ('_g1b_entry', 'refuse_g2', 'refuse_g3_write', 'refuse_g4', '_p2_darwin_export_guard',
          '_p2_refuse_native')


# ---------------------------------------------------------------- helpers
def _src(name):
  p = TREE / name
  return p.read_text(encoding='utf-8') if p.is_file() else None


def _landed(module_file):
  s = _src(module_file)
  return bool(s) and ('capability_gate' in s or 'platform_p2' in s)


def need(cond, why):
  """Skip while a contract item is absent; FAIL instead under AQ_P2_REQUIRE_CONTRACT=1."""
  if cond:
    return
  if REQUIRE:
    raise AssertionError('CONTRACT ITEM MISSING: ' + why)
  raise unittest.SkipTest('contract not landed yet: ' + why)


def _imp(name):
  __import__(name)
  return sys.modules[name]


def _module_names(mod):
  return sorted(vars(mod))


def _state(mod):
  out = {}
  for k in _module_names(mod):
    v = getattr(mod, k)
    if not k.startswith('_' + '_') and isinstance(v, (bool, int, str, list, dict, set, frozenset, tuple, type(None))):
      out[k] = repr(v)
  return out


def _gate():
  need((TREE / 'capability_gate.py').is_file(), 'capability_gate.py at tree root')
  g = _imp('capability_gate')
  need(hasattr(g, 'SCOPE_INSPECT_GATEWAY') and hasattr(g, 'gateway_label'), 'A1 two-scope gate API')
  return g


def _tw(label):
  def boom(*a, **k):
    raise AssertionError('TRIPWIRE: ' + label)
  return boom


class _ParamikoCtl(object):
  def __init__(self, mode, stub, exc=None):
    self.mode, self.stub, self.attempts, self.exc = mode, stub, 0, exc


class _ParamikoTrap(object):
  def __init__(self, ctl):
    self.ctl = ctl

  def find_spec(self, fullname, path=None, target=None):
    if fullname == 'paramiko' or fullname.startswith('paramiko.'):
      self.ctl.attempts += 1
      if self.ctl.mode == 'assert':
        raise AssertionError('TRIPWIRE: paramiko import')
      if self.ctl.mode == 'raise':
        raise self.ctl.exc
      raise ImportError('paramiko blocked by test')
    return None

  find_module = None


@contextlib.contextmanager
def paramiko_state(mode='assert', stub=None, exc=None):
  """'assert': any import attempt fails the test; 'missing': ImportError (counted);
  'raise': the import raises `exc` (any exception type); 'stub': `stub` sits in
  sys.modules for this block only."""
  ctl = _ParamikoCtl(mode, stub, exc)
  saved = {k: v for k, v in sys.modules.items() if k == 'paramiko' or k.startswith('paramiko.')}
  for k in saved:
    del sys.modules[k]
  trap = _ParamikoTrap(ctl)
  sys.meta_path.insert(0, trap)
  if mode == 'stub':
    sys.modules['paramiko'] = stub
  try:
    yield ctl
  finally:
    sys.meta_path.remove(trap)
    for k in [k for k in sys.modules if k == 'paramiko' or k.startswith('paramiko.')]:
      del sys.modules[k]
    sys.modules.update(saved)


def _has(obj, name):
  # hasattr that never raises (some restricted interpreters raise on blocked names).
  try:
    return hasattr(obj, name)
  except Exception:
    return False


def _arm_tripwires(st, fs=True, env_copy=True):
  for attr in ('run', 'Popen', 'call', 'check_call', 'check_output', 'getoutput', 'getstatusoutput'):
    st.enter_context(mock.patch.object(subprocess, attr, _tw('subprocess.' + attr)))
  for attr in ('system', 'popen', 'execv', 'execve', 'execvp', 'execvpe', 'execl', 'execlp',
        'spawnv', 'spawnve', 'posix_spawn', 'fork', 'startfile'):
    if _has(os, attr):
      st.enter_context(mock.patch.object(os, attr, _tw('os.' + attr)))
  st.enter_context(mock.patch.object(socket, 'socket', _tw('socket.socket')))
  st.enter_context(mock.patch.object(socket, 'create_connection', _tw('socket.create_connection')))
  st.enter_context(mock.patch.object(sqlite3, 'connect', _tw('sqlite3.connect')))
  if env_copy:
    st.enter_context(mock.patch.object(type(os.environ), 'copy', _tw('os.environ.copy')))
  if fs:
    st.enter_context(mock.patch.object(os, 'mkdir', _tw('os.mkdir')))
    st.enter_context(mock.patch.object(os, 'makedirs', _tw('os.makedirs')))
    st.enter_context(mock.patch.object(pathlib.Path, 'mkdir', _tw('Path.mkdir')))
    for attr in ('copy', 'copy2', 'copyfile', 'copytree', 'move'):
      st.enter_context(mock.patch.object(shutil, attr, _tw('shutil.' + attr)))


@contextlib.contextmanager
def darwin(fs=True, paramiko='assert', env_copy=True, stub=None, exc=None):
  """sys.platform='darwin' + tripwires + paramiko control (see paramiko_state)."""
  with contextlib.ExitStack() as st:
    st.enter_context(mock.patch.object(sys, 'platform', 'darwin'))
    _arm_tripwires(st, fs=fs, env_copy=env_copy)
    yield st.enter_context(paramiko_state(paramiko, stub, exc))


class RecGateway(object):
  """Fake gateway: records every request; answers like a READY Linux gateway."""
  def __init__(self):
    self.calls = []
    self.sha = 'a' * 64

  def run(self, q, timeout=65):
    self.calls.append(q.get('op'))
    op = q.get('op')
    if op == 'inspect':
      return {'state': 'READY', 'installed': True, 'sha256': self.sha, 'target_names': [],
          'kinds': {}, 'git_targets': ['github-ghes']}
    if op == 'discover':
      return {'tools': [{'name': 'list_genres', 'description': 'Read'}], 'truncated': False, 'count': 1}
    if op == 'apply':
      return {'status': 'DEPLOYED_PENDING_CHECK', 'target': q['target'], 'before': self.sha,
          'after': 'b' * 64, 'backup_name': 'x'}
    if op == 'check':
      return {'ok': True}
    if op == 'rollback':
      return {'status': 'ROLLED_BACK'}
    raise AssertionError(q)


class ScopedGateway(RecGateway):
  def __init__(self, scope, ack, label=None, host=HOST, user=USER):
    RecGateway.__init__(self)
    self.scope, self.ack, self.label, self.host, self.user = scope, ack, label, host, user


class NoCallGateway(object):
  def __init__(self):
    self.calls = []

  def run(self, q, timeout=65):
    self.calls.append(q.get('op'))
    raise AssertionError('TRIPWIRE: gateway.run called with ' + str(q.get('op')))


class Bomb(object):
  """Any inspection (attribute, ==, hash, str, bool, len) fails the test."""
  def __getattribute__(self, name):
    raise AssertionError('TRIPWIRE: argument inspected')

  def __eq__(self, other):
    raise AssertionError('TRIPWIRE: argument compared')

  __ne__ = __eq__

  def __hash__(self):
    raise AssertionError('TRIPWIRE: argument hashed')

  def __str__(self):
    raise AssertionError('TRIPWIRE: argument str()')

  def __repr__(self):
    return 'Bomb'

  def __bool__(self):
    raise AssertionError('TRIPWIRE: argument bool()')

  def __len__(self):
    raise AssertionError('TRIPWIRE: argument len()')


class StrSub(str):
  pass


def _eq_all(text):
  """A str subclass whose == is always True (reflected-__eq__ bypass probe)."""
  return type('EqAll', (str,), {'__eq__': lambda a, b: True, '__ne__': lambda a, b: False,
                 '__hash__': str.__hash__})(text)


def _sha(s):
  return hashlib.sha256(s.encode('utf-8')).hexdigest()


def _defs_from_text(s):
  out = {}
  for n in ast.parse(s).body:
    if isinstance(n, (ast.FunctionDef, ast.ClassDef)):
      out[n.name] = n
      if isinstance(n, ast.ClassDef):
        for m in n.body:
          if isinstance(m, ast.FunctionDef):
            out[n.name + '.' + m.name] = m
  return out


def _defs(path):
  s = path.read_text(encoding='utf-8')
  return s, _defs_from_text(s)


def _is_darwin_test(expr):
  txt = ast.dump(expr)
  return ('is_darwin' in txt) or ("'darwin'" in txt) or ('refuse_g2' in txt) or ("attr='_darwin'" in txt)


def _darwin_only_test(e):
  """True when an `if` test can only be true on macOS (no negation of the darwin check)."""
  if isinstance(e, ast.BoolOp) and isinstance(e.op, ast.And):
    return any(_darwin_only_test(v) for v in e.values)
  if isinstance(e, ast.UnaryOp) and isinstance(e.op, ast.Not):
    return False
  return _is_darwin_test(e) and 'refuse_g2' not in ast.dump(e)


def _drop_docstring(body):
  if body and isinstance(body[0], ast.Expr) and isinstance(body[0].value, ast.Constant) \
      and isinstance(body[0].value.value, str):
    return body[1:]
  return body


def _first_stmt_is_darwin_refusal(fn):
  body = _drop_docstring(list(fn.body))
  if not body:
    return False
  s0 = body[0]
  if isinstance(s0, ast.If) and _is_darwin_test(s0.test):
    return any(isinstance(x, (ast.Raise, ast.Call)) for x in ast.walk(ast.Module(body=s0.body, type_ignores=[])))
  if isinstance(s0, ast.Expr) and isinstance(s0.value, ast.Call):
    d = ast.dump(s0.value.func)
    return any(k in d for k in ('refuse', 'darwin', 'native_disabled', 'require_g1b'))
  return False


class _StripDarwin(ast.NodeTransformer):
  """Off-darwin view: `if <darwin>:` blocks become their else branch (body when negated);
  statement-level inert gate calls are dropped."""
  def flat(self, stmts):
    out = []
    for s in stmts:
      r = self.visit(s)
      if r is not None:
        out.extend(r if isinstance(r, list) else [r])
    return out

  def visit_If(self, node):
    if _is_darwin_test(node.test) and 'refuse_g2' not in ast.dump(node.test):
      neg = isinstance(node.test, ast.UnaryOp) and isinstance(node.test.op, ast.Not)
      return self.flat(node.body if neg else node.orelse)
    return self.generic_visit(node)

  def visit_Expr(self, node):
    if isinstance(node.value, ast.Call):
      f = node.value.func
      if (getattr(f, 'attr', None) or getattr(f, 'id', None)) in INERT_GATE_CALLS:
        return None
    return node


class _StripDarwinBase(_StripDarwin):
  """_StripDarwin + drops the Slice 1 additions that are inert off macOS: assignments of
  the new private wizard attributes and the single `--ack` add_argument (B1b; ignored
  off macOS). `self.acks` counts the dropped --ack statements."""
  NEW_ATTRS = ('_darwin', '_tearing_down', '_ui_queue', '_poll_id', '_clip_after', '_clip_value')

  def __init__(self):
    self.acks = 0

  def visit_Assign(self, node):
    t = node.targets[0] if len(node.targets) == 1 else None
    if isinstance(t, ast.Attribute) and isinstance(t.value, ast.Name) and t.value.id == 'self' \
        and t.attr in self.NEW_ATTRS:
      return None
    return self.generic_visit(node)

  def visit_Expr(self, node):
    c = node.value
    if isinstance(c, ast.Call) and getattr(c.func, 'attr', None) == 'add_argument' and c.args \
        and isinstance(c.args[0], ast.Constant) and c.args[0].value == '--ack':
      self.acks += 1
      return None
    return _StripDarwin.visit_Expr(self, node)


def _strip_off_darwin_lines(src, fn):
  """Frozen source segment of fn minus the lines of every statement (any depth) that is
  inert off macOS: inert gate calls, `if <darwin-only>:` without else, assignments of the
  new private wizard attributes, the `--ack` add_argument, and the B1b all-platform
  offline-plan refusal; comment lines directly above a removed statement go too.
  Returns (text, number_of_statements_removed)."""
  seg = ast.get_source_segment(src, fn)
  lines, off, drop, count = seg.split('\n'), fn.lineno, set(), [0]

  def hit(st):
    if isinstance(st, ast.Expr) and isinstance(st.value, ast.Call):
      c = st.value
      name = getattr(c.func, 'attr', None) or getattr(c.func, 'id', None)
      return name in INERT_GATE_CALLS or (name == 'add_argument' and bool(c.args) and
                        isinstance(c.args[0], ast.Constant) and c.args[0].value == '--ack')
    if isinstance(st, ast.If) and not st.orelse:
      body = ast.dump(ast.Module(body=st.body, type_ignores=[]))
      return _darwin_only_test(st.test) or ("'offline'" in ast.dump(st.test) and 'OFFLINE_PLAN_REFUSED' in body)
    if isinstance(st, ast.Assign) and len(st.targets) == 1:
      t = st.targets[0]
      return isinstance(t, ast.Attribute) and isinstance(t.value, ast.Name) and t.value.id == 'self' \
        and t.attr in _StripDarwinBase.NEW_ATTRS
    return False

  def walk(stmts):
    for st in stmts:
      if hit(st):
        count[0] += 1
        a = st.lineno - off
        drop.update(range(a, st.end_lineno - off + 1))
        j = a - 1
        while j > 0 and lines[j].strip().startswith('#'):
          drop.add(j)
          j -= 1
        continue
      for fld in ('body', 'orelse', 'finalbody'):
        v = getattr(st, fld, None)
        if isinstance(v, list):
          walk(v)
      for h in getattr(st, 'handlers', None) or []:
        walk(h.body)
  walk(fn.body)
  return '\n'.join(x for i, x in enumerate(lines) if i not in drop), count[0]


def _base_blob():
  import base64
  import zlib
  return json.loads(zlib.decompress(base64.b64decode(''.join(BASE_BLOB))).decode('utf-8'))


def _bad_acks(good, other_scope_token):
  head, _, label = good.rpartition(' ')
  return [('lower', good.lower()), ('title', good.title()), ('upper_label', head + ' ' + label.upper()),
      ('lead_sp', ' ' + good), ('trail_sp', good + ' '), ('trail_nl', good + '\n'),
      ('trail_crlf', good + '\r\n'), ('tab', good.replace(' ', '\t', 1)),
      ('dbl_sp', good.replace(' ', '  ', 1)), ('nbsp', good.replace(' ', '\u00a0', 1)),
      ('zw_inner', head + ' \u200b' + label), ('zw_trail', good + '\u200b'), ('bom', '\ufeff' + good),
      ('zwj', good[:3] + '\u200d' + good[3:]), ('bidi_rlo', head + ' \u202e' + label),
      ('fullwidth', '\uff36' + good[1:]), ('other_label', head + ' other-target'),
      ('prefix_only', head + ' '), ('label_only', label), ('other_scope', other_scope_token),
      ('empty', ''), ('none', None), ('bytes', good.encode('ascii')), ('list', [good]),
      ('str_subclass', StrSub(good)), ('eq_all', _eq_all('x'))]


BAD_LABELS = ['', ' ', 'a b', TARGET + ' ', ' ' + TARGET, 'demo\tepg', 'demo\nepg', 'demo\x00', 'demo\x7f',
       'demo\x1b', 'demo\u200bepg', 'demo\u200d', '\ufeffdemo', 'demo\u202eepg', '\u2066demo',
       'demo\u00a0epg', 'demo\u2028', None, 5, b'demo', ['demo'], StrSub(TARGET)]
BAD_GATEWAY_PAIRS = [('', HOST), (USER, ''), ('a@b', HOST), (USER, 'h@x'), ('fake user', HOST),
          (StrSub(USER), HOST), (USER, StrSub(HOST)), (None, HOST), (USER, 5),
          (USER, HOST + '\u200b'), ('\u202e' + USER, HOST), (USER + '\n', HOST)]
BAD_INSPECT_LABELS = [USER + '@@' + HOST, 'a@b@c', '@' + HOST, USER + '@', USER + HOST,
           'fake user@' + HOST, INSPECT_LABEL + '\u200b', INSPECT_LABEL + ' ']
BAD_OPS = ['tools_call', 'call_tool', 'exec', '', 'INSPECT', 'Inspect', ' inspect', 'inspect ',
     'inspect\x00', 'inspect\u200b', None, 5, b'inspect', ['inspect'], StrSub('inspect'),
     _eq_all('inspect')]


class _GwMixin(object):
  """Drives the REAL SSHGateway.run on darwin with the paramiko trap armed."""
  def setUp(self):
    need(_landed('deploy_lib.py'), 'deploy_lib SSHGateway gate')
    self.dl = _imp('deploy_lib')
    self.g = _gate()

  def _gw(self, ack=None, scope=None, label=None, host=HOST, user=USER):
    return self.dl.SSHGateway(host, user, known_hosts=os.devnull, ack=ack, scope=scope, label=label)

  def _gwi(self, ack=INSPECT_ACK, **k):
    return self._gw(ack=ack, scope=SCOPE_I, **k)

  def _gwv(self, ack=VERIFY_ACK, label=TARGET, **k):
    return self._gw(ack=ack, scope=SCOPE_V, label=label, **k)

  def _refused(self, gw, req):
    with darwin() as trap:
      with self.assertRaises(self.g.GateRefused):
        gw.run(req)
    self.assertEqual(trap.attempts, 0, 'paramiko import attempted before the gate refused')

  def _reaches_import(self, gw, req):
    with darwin(paramiko='missing') as trap:
      with self.assertRaises(self.dl.DeploymentError) as cm:
        gw.run(req)
    self.assertGreaterEqual(trap.attempts, 1, 'gate passed but paramiko import was not attempted')
    return cm.exception


# ================================================================ A. shared modules / A1 API
class A01_SharedModulesFrozen(unittest.TestCase):
  def test_platform_p2_byte_identical(self):
    for name, want in SHARED_SHA256.items():
      p = TREE / name
      need(p.is_file(), name + ' at tree root')
      self.assertEqual(hashlib.sha256(p.read_bytes()).hexdigest(), want, name + ' was edited')

  def test_capability_gate_a1_api_shape(self):
    g = _gate()
    self.assertEqual((g.SCOPE_INSPECT_GATEWAY, g.SCOPE_VERIFY_BACKEND), (SCOPE_I, SCOPE_V))
    self.assertEqual({k: set(v) for k, v in g.G1B_SCOPE_OPS.items()},
            {SCOPE_I: set(INSPECT_OPS), SCOPE_V: set(VERIFY_OPS)})
    self.assertTrue(all(isinstance(v, frozenset) for v in g.G1B_SCOPE_OPS.values()))
    self.assertEqual((g.FULL_COPY_TOKEN, g.FULL_EXPORT_TOKEN), ('COPY FULL', 'EXPORT FULL'))
    for removed in ('G1B_PREFIX', '_bad_target'):
      self.assertNotIn(removed, _module_names(g), 'old one-argument API still present: ' + removed)
    for fn in ('g1b_token', 'gateway_label', 'require_g1b', 'token_matches', 'refuse_g2',
         'refuse_g3_write', 'refuse_g4', 'require_full_variant'):
      self.assertTrue(callable(getattr(g, fn, None)), fn)

  def test_deploy_g1b_ops_is_union_of_scope_ops(self):
    need(_landed('deploy_lib.py'), 'deploy_lib gate')
    dl = _imp('deploy_lib')
    self.assertEqual((set(dl.G1B_OPS), set(dl.G2_OPS)), (set(G1B_OPS), set(G2_OPS)))


# ================================================================ B. gate token matrix
class B01_GateTokenMatrix(unittest.TestCase):
  def test_exact_tokens_accepted_both_scopes(self):
    g = _gate()
    self.assertEqual(g.g1b_token(SCOPE_I, INSPECT_LABEL), INSPECT_ACK)
    self.assertEqual(g.g1b_token(SCOPE_V, TARGET), VERIFY_ACK)
    self.assertEqual(g.gateway_label(USER, HOST), INSPECT_LABEL)
    self.assertEqual(g.gateway_label(USER, HOST_B), USER + '@' + HOST_B)
    with darwin():
      for op in INSPECT_OPS:
        self.assertIsNone(g.require_g1b(SCOPE_I, INSPECT_LABEL, INSPECT_ACK, op))
      for op in VERIFY_OPS:
        self.assertIsNone(g.require_g1b(SCOPE_V, TARGET, VERIFY_ACK, op))
      self.assertTrue(g.token_matches(VERIFY_ACK, VERIFY_ACK))

  def test_every_ack_variant_refused_both_scopes(self):
    g = _gate()
    cases = [(SCOPE_I, INSPECT_LABEL, 'inspect', _bad_acks(INSPECT_ACK, 'VERIFY BACKEND ' + INSPECT_LABEL)),
        (SCOPE_V, TARGET, 'discover', _bad_acks(VERIFY_ACK, 'INSPECT GATEWAY ' + TARGET))]
    with darwin():
      for scope, label, op, bad in cases:
        for name, ack in bad:
          with self.subTest(scope=scope, variant=name):
            with self.assertRaises(g.GateRefused):
              g.require_g1b(scope, label, ack, op)

  def test_refusal_message_never_echoes_input(self):
    g = _gate()
    with darwin():
      for scope, label, bad in ((SCOPE_V, TARGET, 'VERIFY BACKEND SECRET-SENTINEL-123'),
                   (SCOPE_I, INSPECT_LABEL, 'INSPECT GATEWAY SECRET-SENTINEL-123'),
                   (SCOPE_V, 'SECRET-SENTINEL-123 x', VERIFY_ACK)):
        with self.subTest(scope=scope, label=label):
          with self.assertRaises(g.GateRefused) as cm:
            g.require_g1b(scope, label, bad, 'inspect')
          for leak in ('SENTINEL', TARGET, USER, HOST):
            self.assertNotIn(leak, str(cm.exception))

  def test_bad_labels_refused(self):
    g = _gate()
    for scope in (SCOPE_I, SCOPE_V):
      for t in BAD_LABELS:
        with self.subTest(scope=scope, label=repr(t)):
          with self.assertRaises(g.GateRefused):
            g.g1b_token(scope, t)
    for t in BAD_INSPECT_LABELS:
      with self.subTest(inspect_label=repr(t)):
        with self.assertRaises(g.GateRefused):
          g.g1b_token(SCOPE_I, t)
    for u, h in BAD_GATEWAY_PAIRS:
      with self.subTest(user=repr(u), host=repr(h)):
        with self.assertRaises(g.GateRefused):
          g.gateway_label(u, h)

  def test_g2_g3_g4_refused_with_valid_looking_ack(self):
    g = _gate()
    with darwin():
      for i, f in enumerate((g.refuse_g2, g.refuse_g3_write, g.refuse_g4)):
        for op in ('bootstrap', INSPECT_ACK, VERIFY_ACK, 'CREATE_FRESH_GATEWAY', 'EXPORT FULL', None):
          with self.subTest(f=i, op=op):
            with self.assertRaises(g.GateRefused):
              f(op)

  def test_full_variant_tokens(self):
    g = _gate()
    with darwin():
      self.assertIsNone(g.require_full_variant('copy', 'COPY FULL'))
      self.assertIsNone(g.require_full_variant('export', 'EXPORT FULL'))
      for kind, bad in (('copy', 'copy full'), ('copy', 'COPY FULL '), ('copy', 'EXPORT FULL'),
               ('export', 'COPY FULL'), ('export', None), ('export', ''),
               ('export', 'EXPORT\u00a0FULL'), ('export', 'EXPORT FULL\n'),
               ('export', b'EXPORT FULL'), ('export', VERIFY_ACK), ('other', 'COPY FULL')):
        with self.subTest(kind=kind, bad=bad):
          with self.assertRaises(g.GateRefused):
            g.require_full_variant(kind, bad)

  def test_non_darwin_is_inert(self):
    g = _gate()
    for plat in ('win32', 'linux'):
      with mock.patch.object(sys, 'platform', plat):
        self.assertIsNone(g.require_g1b(None, None, None, None))
        self.assertIsNone(g.require_g1b(SCOPE_I, INSPECT_LABEL, 'wrong', 'bootstrap'))
        self.assertIsNone(g.refuse_g2('bootstrap'))
        self.assertIsNone(g.refuse_g3_write('x'))
        self.assertIsNone(g.refuse_g4('x'))
        self.assertIsNone(g.require_full_variant('nonsense', None))

  def test_no_module_unlock_flag(self):
    g = _gate()
    for name in _module_names(g):
      if isinstance(getattr(g, name), bool):
        self.fail('module-level boolean in capability_gate: ' + name)
    before = _state(g)
    with darwin():
      g.require_g1b(SCOPE_I, INSPECT_LABEL, INSPECT_ACK, 'inspect')
      g.require_g1b(SCOPE_V, TARGET, VERIFY_ACK, 'discover')
      for bad in (None, 'x'):
        with self.assertRaises(g.GateRefused):
          g.require_g1b(SCOPE_V, TARGET, bad, 'discover')
    self.assertEqual(before, _state(g), 'capability_gate module state changed by a call')


class B02_ScopeBindingA1(unittest.TestCase):
  def test_scope_separation_both_directions(self):
    g = _gate()
    with darwin():
      for op in VERIFY_OPS:
        for label in (TARGET, INSPECT_LABEL):
          with self.subTest(direction='inspect->verify', op=op, label=label):
            with self.assertRaises(g.GateRefused):
              g.require_g1b(SCOPE_V, label, INSPECT_ACK, op)
      for ack in (VERIFY_ACK, 'VERIFY BACKEND ' + INSPECT_LABEL):
        with self.subTest(direction='verify->inspect', ack=ack):
          with self.assertRaises(g.GateRefused):
            g.require_g1b(SCOPE_I, INSPECT_LABEL, ack, 'inspect')

  def test_ops_outside_scope_refused_with_valid_token(self):
    g = _gate()
    with darwin():
      for scope, label, ack, extra in ((SCOPE_I, INSPECT_LABEL, INSPECT_ACK, ['discover', 'inspect_lambda_target', 'probe_existing']),
                      (SCOPE_V, TARGET, VERIFY_ACK, [])):
        for op in extra + list(NEVER_OPS) + BAD_OPS:
          with self.subTest(scope=scope, op=repr(op)):
            with self.assertRaises(g.GateRefused):
              g.require_g1b(scope, label, ack, op)

  def test_unknown_scopes_refused(self):
    g = _gate()
    with darwin():
      for scope in ('INSPECT-GATEWAY', 'inspect_gateway', 'verify', '', None, 5,
             StrSub(SCOPE_I), _eq_all(SCOPE_V), SCOPE_I + ' '):
        with self.subTest(scope=repr(scope)):
          with self.assertRaises(g.GateRefused):
            g.require_g1b(scope, TARGET, VERIFY_ACK, 'inspect')
          with self.assertRaises(g.GateRefused):
            g.g1b_token(scope, TARGET)

  def test_token_bound_to_destination_and_target(self):
    g = _gate()
    with darwin():
      for label in (USER + '@' + HOST_B, USER_B + '@' + HOST):
        with self.subTest(inspect_label=label):
          with self.assertRaises(g.GateRefused):
            g.require_g1b(SCOPE_I, label, INSPECT_ACK, 'inspect')
      for label in ('other-target', 'Demo-epg'):
        with self.subTest(verify_label=label):
          with self.assertRaises(g.GateRefused):
            g.require_g1b(SCOPE_V, label, VERIFY_ACK, 'discover')

  def test_full_token_rejects_str_subclass(self):
    # F-T1-01 (fixed by B3c): exact str type only, for every typed token.
    g = _gate()
    with darwin():
      for kind, tok in (('copy', 'COPY FULL'), ('export', 'EXPORT FULL')):
        for bad in (_eq_all('x'), _eq_all(tok), StrSub(tok)):
          with self.subTest(kind=kind, bad=type(bad).__name__ + ':' + str.__str__(bad)):
            with self.assertRaises(g.GateRefused):
              g.require_full_variant(kind, bad)

  def test_exact_type_token_everywhere(self):
    g = _gate()
    for exp, sup in ((VERIFY_ACK, _eq_all('x')), (VERIFY_ACK, StrSub(VERIFY_ACK)), (_eq_all(VERIFY_ACK), VERIFY_ACK),
            (StrSub(VERIFY_ACK), VERIFY_ACK), ('', ''), (None, None), (b'x', b'x')):
      with self.subTest(exp=type(exp).__name__, sup=type(sup).__name__):
        self.assertIs(g.token_matches(exp, sup), False)
    self.assertIs(g.token_matches(VERIFY_ACK, VERIFY_ACK), True)
    with darwin():
      for scope, label, op, tok in ((SCOPE_I, INSPECT_LABEL, 'inspect', INSPECT_ACK), (SCOPE_V, TARGET, 'discover', VERIFY_ACK)):
        for bad in (_eq_all('x'), _eq_all(tok), StrSub(tok)):
          with self.subTest(scope=scope, bad=type(bad).__name__):
            with self.assertRaises(g.GateRefused):
              g.require_g1b(scope, label, bad, op)


# ================================================================ C. native gateway disabled (3.1)
class C01_NativeGatewayDisabled(unittest.TestCase):
  def setUp(self):
    need(_landed('native_gateway.py'), 'native_gateway darwin refusal')
    self.ng = _imp('native_gateway')
    self.dl = _imp('deploy_lib')
    self.tmp = tempfile.mkdtemp(prefix='p2t1-')
    self.addCleanup(shutil.rmtree, self.tmp, True)
    self.root = pathlib.Path(self.tmp) / 'AQ-MCP-Gateway'

  def _assert_refused(self, fn):
    with self.assertRaises(self.dl.DeploymentError) as cm:
      fn()
    self.assertEqual(str(cm.exception), self.ng.NATIVE_DISABLED_ON_DARWIN)
    self.assertFalse(self.root.exists(), 'gateway root was created')

  def test_every_entry_point_refused_before_side_effects(self):
    with darwin():
      gw = self.ng.NativeGateway(self.root)
      self.assertFalse(self.root.exists())
      self._assert_refused(lambda: gw.bootstrap(approved=True, install_dependencies=True))
      self._assert_refused(lambda: gw.inspect())
      self._assert_refused(lambda: gw._apply({'target': TARGET, 'entry': dict(ENTRY), 'expected_sha256': 'a' * 64}))
      self._assert_refused(lambda: gw._rollback({'target': TARGET}))
      self._assert_refused(lambda: gw._probe_entry({'url': SPEC['url'], 'allow': []}))
      for op in ('inspect', 'bootstrap', 'discover', 'inspect_lambda_target', 'apply', 'rollback',
           'check', 'probe_existing', 'git_check', 'repair_permissions', 'nonsense', None):
        with self.subTest(op=op):
          self._assert_refused(lambda: gw.run({'op': op, 'confirm': 'CREATE_FRESH_GATEWAY',
                            'install_dependencies': True}))

  def test_exclusive_lock_refused(self):
    with darwin():
      with self.assertRaises(self.dl.DeploymentError):
        with self.ng.exclusive_lock(self.root):
          pass
      self.assertFalse(self.root.exists())

  def test_refusal_is_first_statement_of_bootstrap_and_run(self):
    _, d = _defs(TREE / 'native_gateway.py')
    for name in ('NativeGateway.bootstrap', 'NativeGateway.run'):
      with self.subTest(fn=name):
        self.assertTrue(_first_stmt_is_darwin_refusal(d[name]), name)

  def test_unhashed_pip_unreachable_on_darwin(self):
    _, d = _defs(TREE / 'native_gateway.py')
    for fname, fn in d.items():
      if not isinstance(fn, ast.FunctionDef):
        continue  # T1b fix: classes are covered through their methods
      for n in ast.walk(fn):
        if isinstance(n, ast.List) and any(isinstance(e, ast.Constant) and e.value == 'pip' for e in n.elts):
          with self.subTest(fn=fname):
            self.assertTrue(_first_stmt_is_darwin_refusal(fn), fname + ' builds a pip argv reachable on darwin')

  def test_no_slice2_material_added(self):
    s = _src('native_gateway.py')
    for bad in ('macosx_', 'darwin_lock', 'MACOS_INTERPRETER', 'macos.lock'):
      self.assertNotIn(bad, s)

  def test_pure_helpers_unchanged(self):
    s, d = _defs(TREE / 'native_gateway.py')
    for n in ('native_root', 'local_python'):
      self.assertEqual(_sha(ast.get_source_segment(s, d[n])), UNCHANGED_DEF_SHA256['native_gateway.py::' + n])


class C02_ModelAndCliRejectNative(unittest.TestCase):
  def test_validate_spec_rejects_native_local_on_darwin(self):
    need(_landed('model.py'), 'model.validate_spec darwin native-local refusal')
    m = _imp('model')
    with darwin():
      with self.assertRaises(m.ValidationError):
        m.validate_spec(dict(NATIVE_SPEC))
      self.assertEqual(m.validate_spec(dict(SPEC))['transport'], 'linux-ssh')

  def test_cli_native_local_is_parser_error_on_darwin(self):
    need("'--ack'" in (_src('cli.py') or ''), 'cli --ack option')
    cli = _imp('cli')
    with tempfile.TemporaryDirectory() as d:
      mf = os.path.join(d, 'm.json')
      with open(mf, 'w') as f:
        json.dump(NATIVE_SPEC, f)
      with darwin(fs=False), mock.patch.object(cli, 'NativeGateway', _tw('NativeGateway constructed')), \
          contextlib.redirect_stderr(io.StringIO()):
        for argv in (['inspect', mf, '--native-local'], ['bootstrap', '--native-local', '--approve-bootstrap'],
              ['plan', mf, '--native-local']):
          with self.subTest(argv=argv):
            with self.assertRaises(SystemExit) as cm:
              cli.main(argv)
            self.assertNotEqual(cm.exception.code, 0)


# ================================================================ D. SSHGateway G1b (A1)
class D01_SSHGatewayGate(_GwMixin, unittest.TestCase):
  def test_constructor_signature(self):
    gw = self.dl.SSHGateway(HOST, USER)
    self.assertEqual((gw.ack, gw.scope, gw.label), (None, None, None))
    self.assertFalse(hasattr(gw, 'target'), 'pre-A1 target attribute still present')
    self.assertEqual(self.dl.SSHGateway(HOST, USER, None, 15).timeout, 15)
    gw3 = self.dl.SSHGateway(HOST, USER, os.devnull, 15, INSPECT_ACK, SCOPE_I, None)
    self.assertEqual((gw3.ack, gw3.scope, gw3.label), (INSPECT_ACK, SCOPE_I, None))

  def test_no_ack_never_imports_paramiko_or_opens_socket(self):
    for scope, label in ((SCOPE_I, None), (SCOPE_V, TARGET), (None, None)):
      for op in G1B_OPS:
        with self.subTest(scope=scope, op=op):
          self._refused(self._gw(None, scope, label), {'op': op, 'target': TARGET})

  def test_every_bad_ack_refused_before_paramiko(self):
    for mk, bad in ((self._gwi, _bad_acks(INSPECT_ACK, 'VERIFY BACKEND ' + INSPECT_LABEL)),
            (self._gwv, _bad_acks(VERIFY_ACK, 'INSPECT GATEWAY ' + TARGET))):
      for name, ack in bad:
        with self.subTest(scope=mk().scope, variant=name):
          self._refused(mk(ack=ack), {'op': 'inspect'})

  def test_verify_ack_bound_to_gateway_label(self):
    for label in ('other-target', None, '', StrSub(TARGET)):
      for req in ({'op': 'inspect'}, {'op': 'discover', 'entry': dict(ENTRY)},
            {'op': 'inspect_lambda_target', 'target': label},
            {'op': 'probe_existing', 'kind': 'git', 'target': label}):
        with self.subTest(label=repr(label), op=req['op']):
          self._refused(self._gwv(label=label), req)

  def test_g2_ops_refused_even_with_valid_ack(self):
    for op in G2_OPS:
      for mk in (self._gwi, self._gwv):
        with self.subTest(op=op, scope=mk().scope):
          self._refused(mk(), {'op': op, 'confirm': 'CREATE_FRESH_GATEWAY', 'target': TARGET})

  def test_unknown_ops_refused_even_with_valid_ack(self):
    for op in ['check', 'git_check'] + BAD_OPS:
      for mk in (self._gwi, self._gwv):
        with self.subTest(op=repr(op), scope=mk().scope):
          self._refused(mk(), {'op': op, 'target': TARGET})

  def test_valid_ack_missing_paramiko_refuses_cleanly_never_pip(self):
    cases = [(self._gwi(), {'op': 'inspect'})] + \
        [(self._gwv(), r) for r in ({'op': 'inspect'}, {'op': 'discover', 'entry': dict(ENTRY)},
                      {'op': 'inspect_lambda_target', 'target': TARGET},
                      {'op': 'probe_existing', 'kind': 'git', 'target': TARGET})]
    for gw, req in cases:
      with self.subTest(scope=gw.scope, op=req['op']):
        exc = self._reaches_import(gw, req)
        self.assertEqual(str(exc), self.dl.DARWIN_NO_SSH_LIB)
        self.assertNotIn('pip', str(exc).lower())

  def test_no_agent_forwarding_in_ssh_layer(self):
    s = _src('deploy_lib.py')
    for bad in ('AgentRequestHandler', 'forward_agent', 'ForwardAgent'):
      self.assertNotIn(bad, s)

  def test_windows_branch_still_has_original_paramiko_message(self):
    self.assertIn("'Install Paramiko first: py -m pip install paramiko'", _src('deploy_lib.py'))


class D03_SSHGatewayBindingA1(_GwMixin, unittest.TestCase):
  """A1.2 rules b, c, d and F6 at the gateway (REAL SSHGateway.run)."""
  def test_destination_bound_inside_gateway(self):
    cases = {'other_host': self._gwi(host=HOST_B), 'other_user': self._gwi(user=USER_B),
        'caller_label_ignored': self._gwi(host=HOST_B, label=INSPECT_LABEL),
        'caller_label_ignored_user': self._gwi(user=USER_B, label=INSPECT_LABEL)}
    for attr, val in (('host', HOST_B), ('user', USER_B)):
      gw = self._gwi()
      setattr(gw, attr, val)
      cases[attr + '_changed_after_build'] = gw
    for name, gw in cases.items():
      with self.subTest(case=name):
        self._refused(gw, {'op': 'inspect'})
    self._reaches_import(self._gwi(), {'op': 'inspect'})
    self._reaches_import(self._gwi(ack='INSPECT GATEWAY ' + USER + '@' + HOST_B, host=HOST_B), {'op': 'inspect'})

  def test_request_target_must_equal_label(self):
    gw = self._gwv()
    for req in ({'op': 'inspect_lambda_target', 'target': 'other-target'}, {'op': 'inspect_lambda_target'},
          {'op': 'probe_existing', 'kind': 'git', 'target': 'other-target'},
          {'op': 'probe_existing', 'kind': 'git'},
          {'op': 'probe_existing', 'kind': 'local', 'target': StrSub('x')},
          {'op': 'discover', 'entry': dict(ENTRY), 'target': 'other-target'},
          {'op': 'inspect', 'target': 'other-target'}, {'op': 'inspect', 'target': None},
          # T1b (A1.1 P2-SEC-055/059): inspect never carries a target on macOS.
          {'op': 'inspect', 'target': TARGET}):
      with self.subTest(req=req):
        self._refused(gw, req)
    for req in ({'op': 'inspect_lambda_target', 'target': TARGET},
          {'op': 'probe_existing', 'kind': 'git', 'target': TARGET},
          {'op': 'discover', 'entry': dict(ENTRY)}):
      with self.subTest(ok=req):
        self._reaches_import(gw, req)

  def test_inspect_scope_refuses_any_request_target(self):
    for t in (TARGET, INSPECT_LABEL, None, ''):
      with self.subTest(target=t):
        self._refused(self._gwi(), {'op': 'inspect', 'target': t})

  def test_ops_outside_scope_refused_before_import(self):
    for op in ('discover', 'inspect_lambda_target', 'probe_existing'):
      with self.subTest(scope=SCOPE_I, op=op):
        self._refused(self._gwi(), {'op': op, 'entry': dict(ENTRY)})
    for gw in (self._gwi(), self._gwv()):
      for req in ({}, {'target': TARGET}, None, 'inspect', ['inspect'], {'op': {'op': 'inspect'}}):
        with self.subTest(scope=gw.scope, request=repr(req)):
          self._refused(gw, req)

  def test_invalid_labels_and_scopes_refused_before_import(self):
    for h in (HOST + '\u200b', 'gate way', HOST + '\n', '\u202e' + HOST, ''):
      with self.subTest(host=repr(h)):
        self._refused(self._gwi(ack='INSPECT GATEWAY ' + USER + '@' + h, host=h), {'op': 'inspect'})
    for u in ('a@b', 'fake user', USER + '\x00', ''):
      with self.subTest(user=repr(u)):
        self._refused(self._gwi(ack='INSPECT GATEWAY ' + u + '@' + HOST, user=u), {'op': 'inspect'})
    for lab in BAD_LABELS:
      with self.subTest(label=repr(lab)):
        self._refused(self._gwv(ack='VERIFY BACKEND ' + (lab if isinstance(lab, str) else 'x'), label=lab),
               {'op': 'inspect'})
    for scope in (None, 'INSPECT-GATEWAY', StrSub(SCOPE_I)):
      with self.subTest(scope=repr(scope)):
        self._refused(self._gw(INSPECT_ACK, scope), {'op': 'inspect'})

  def test_no_reusable_unlock(self):
    gw = self._gwi()
    self._reaches_import(gw, {'op': 'inspect'})
    gw.ack = None
    self._refused(gw, {'op': 'inspect'})
    gw.ack, gw.scope = INSPECT_ACK, SCOPE_V
    self._refused(gw, {'op': 'inspect'})
    self._refused(self.dl.SSHGateway(HOST, USER, known_hosts=os.devnull), {'op': 'inspect'})
    before = _state(self.dl)
    self._reaches_import(self._gwv(), {'op': 'discover', 'entry': dict(ENTRY)})
    self.assertEqual(before, _state(self.dl), 'deploy_lib module state changed by an authorized run')


# ---------------------------------------------------------------- paramiko STUB (never the real library)
class _Chan(object):
  def __init__(self, status):
    self.status = status

  def shutdown_write(self):
    return None

  def recv_exit_status(self):
    return self.status


class _Stream(object):
  def __init__(self, raw, chan):
    self.raw, self.channel, self.data = raw, chan, []

  def write(self, b):
    self.data.append(b)

  def flush(self):
    return None

  def read(self, n=-1):
    return self.raw


class StubParamiko(object):
  """Stand-in module object for `import paramiko`; records every client call."""
  def __init__(self, exc_name=None, status=0, response=None):
    stub = self
    self.clients, self.exc_name, self.status = [], exc_name, status
    self.raw = json.dumps(response if response is not None
               else {'ok': True, 'result': {'state': 'READY'}}).encode('utf-8')
    self.SSHException = type('SSHException', (Exception,), {})
    self.AuthenticationException = type('AuthenticationException', (self.SSHException,), {})
    self.NoValidAuthMethodsException = type('NoValidAuthMethodsException', (self.AuthenticationException,), {})
    self.BadHostKeyException = type('BadHostKeyException', (self.SSHException,), {})
    self.RejectPolicy = type('RejectPolicy', (object,), {})
    self.AutoAddPolicy = type('AutoAddPolicy', (object,), {})
    self.WarningPolicy = type('WarningPolicy', (object,), {})

    class SSHClient(object):
      def __init__(c):
        stub.clients.append(c)
        c.policies, c.connects, c.execs, c.loaded, c.saved, c.closed, c.stdin = [], [], [], [], 0, False, None

      def load_system_host_keys(c, *a):
        c.loaded.append(('system',) + a)

      def load_host_keys(c, path):
        c.loaded.append(('file', path))

      def set_missing_host_key_policy(c, p):
        c.policies.append(p)

      def save_host_keys(c, *a):
        c.saved += 1

      def connect(c, hostname, *a, **kw):
        c.connects.append((hostname, a, kw))
        if stub.exc_name:
          raise getattr(stub, stub.exc_name)(USER + '@' + HOST + ' SECRET-SENTINEL-7781')

      def exec_command(c, cmd, *a, **kw):
        c.execs.append(cmd)
        chan = _Chan(stub.status)
        c.stdin = _Stream(b'', chan)
        return c.stdin, _Stream(stub.raw, chan), _Stream(b'', chan)

      def close(c):
        c.closed = True
    self.SSHClient = SSHClient


class D04_FailClosedStubParamiko(unittest.TestCase):
  """A1.4 F1-F5 with a STUB paramiko (REAL SSHGateway.run)."""
  BAD_KW = ('password', 'key_filename', 'pkey', 'passphrase', 'gss_auth', 'gss_kex', 'gss_deleg_creds',
       'gss_host', 'sock')

  def setUp(self):
    need(_landed('deploy_lib.py'), 'deploy_lib SSHGateway gate')
    self.dl = _imp('deploy_lib')
    self.g = _gate()
    self.tmp = tempfile.mkdtemp(prefix='p2t1s-')
    self.addCleanup(shutil.rmtree, self.tmp, True)
    self.kh = os.path.join(self.tmp, 'known_hosts')
    with open(self.kh, 'w') as f:
      f.write('')

  def _gwi(self, kh=None, ack=INSPECT_ACK):
    return self.dl.SSHGateway(HOST, USER, known_hosts=kh or self.kh, ack=ack, scope=SCOPE_I)

  def _gwv(self):
    return self.dl.SSHGateway(HOST, USER, known_hosts=self.kh, ack=VERIFY_ACK, scope=SCOPE_V, label=TARGET)

  def _run(self, stub, gw, req):
    with darwin(paramiko='stub', stub=stub):
      return gw.run(req)

  def test_f1_absent_no_pip_no_subprocess(self):
    for gw, req in ((self._gwi(), {'op': 'inspect'}), (self._gwv(), {'op': 'discover', 'entry': dict(ENTRY)})):
      with self.subTest(scope=gw.scope):
        with darwin(paramiko='missing') as trap:  # subprocess/os.exec*/socket tripwires armed
          with self.assertRaises(self.dl.DeploymentError) as cm:
            gw.run(req)
        self.assertEqual(str(cm.exception), self.dl.DARWIN_NO_SSH_LIB)
        self.assertEqual(trap.attempts, 1, 'paramiko import retried or repaired')
        for bad in ('pip', 'ensurepip'):
          self.assertNotIn(bad, str(cm.exception).lower())

  def test_success_path_reject_policy_only(self):
    stub = StubParamiko()
    self.assertEqual(self._run(stub, self._gwi(), {'op': 'inspect'}), {'state': 'READY'})
    self.assertEqual(len(stub.clients), 1)
    c = stub.clients[0]
    self.assertGreaterEqual(len(c.policies), 1)
    self.assertTrue(all(type(p) is stub.RejectPolicy for p in c.policies), 'non-Reject host-key policy')
    self.assertEqual(c.saved, 0, 'host keys saved')
    self.assertIn(('file', self.kh), c.loaded)
    self.assertEqual(len(c.connects), 1)
    host, _, kw = c.connects[0]
    self.assertEqual((host, kw.get('username')), (HOST, USER))
    for k in self.BAD_KW:
      self.assertNotIn(k, kw)
    self.assertEqual(len(c.execs), 1)
    self.assertNotIn('sudo', c.execs[0])
    self.assertEqual(json.loads(b''.join(c.stdin.data).decode('utf-8')), {'op': 'inspect'})
    self.assertTrue(c.closed)

  def test_auth_kwargs_unchanged_per_user_decision(self):
    stub = StubParamiko()
    self._run(stub, self._gwi(), {'op': 'inspect'})
    kw = stub.clients[0].connects[0][2]
    self.assertEqual((kw.get('allow_agent'), kw.get('look_for_keys')), (True, True))

  def test_known_hosts_missing_refused_before_connect(self):
    stub = StubParamiko()
    with self.assertRaises(self.dl.DeploymentError):
      self._run(stub, self._gwi(kh=os.path.join(self.tmp, 'no-such-known_hosts')), {'op': 'inspect'})
    self.assertEqual(stub.clients, [], 'SSH client built although known_hosts is missing')

  def test_f2_f3_connect_errors_type_only_no_retry(self):
    for name in ('AuthenticationException', 'NoValidAuthMethodsException', 'BadHostKeyException', 'SSHException'):
      with self.subTest(exc=name):
        stub = StubParamiko(exc_name=name)
        with self.assertRaises(self.dl.DeploymentError) as cm:
          self._run(stub, self._gwi(), {'op': 'inspect'})
        self.assertIn(name, str(cm.exception))
        for leak in ('SENTINEL', USER, HOST):
          self.assertNotIn(leak, str(cm.exception))
        c = stub.clients[0]
        self.assertEqual((len(stub.clients), len(c.connects), c.execs, c.saved), (1, 1, [], 0))
        self.assertTrue(all(type(p) is stub.RejectPolicy for p in c.policies))
        for k in self.BAD_KW:
          self.assertNotIn(k, c.connects[0][2])
        self.assertTrue(c.closed)

  def test_f4_nonzero_exit_and_ok_false_refused_no_escalation(self):
    for name, stub in (('nonzero_exit', StubParamiko(status=3)),
             ('ok_false', StubParamiko(response={'ok': False, 'error': 'denied', 'result': {'state': 'READY'}}))):
      with self.subTest(case=name):
        with self.assertRaises(self.dl.DeploymentError):
          self._run(stub, self._gwv(), {'op': 'inspect'})
        c = stub.clients[0]
        self.assertEqual((len(stub.clients), len(c.connects), len(c.execs)), (1, 1, 1), 'retry/escalation')
        self.assertNotIn('sudo', c.execs[0])

  def test_gate_refusal_precedes_stub(self):
    stub = StubParamiko()
    for gw, req in ((self._gwi(ack=VERIFY_ACK), {'op': 'inspect'}), (self._gwi(), {'op': 'discover', 'entry': dict(ENTRY)}),
            (self._gwv(), {'op': 'check', 'target': TARGET}), (self._gwv(), {'op': 'apply', 'target': TARGET})):
      with self.subTest(scope=gw.scope, op=req['op']):
        with self.assertRaises(self.g.GateRefused):
          self._run(stub, gw, req)
    self.assertEqual(stub.clients, [])

  def test_f3_f5_static_host_key_and_verification(self):
    n_set = 0
    for n in ast.walk(ast.parse(_src('deploy_lib.py'))):
      if isinstance(n, ast.Call) and getattr(n.func, 'attr', None) == 'set_missing_host_key_policy':
        n_set += 1
        a = n.args[0] if len(n.args) == 1 else None
        self.assertTrue(isinstance(a, ast.Call) and getattr(a.func, 'attr', None) == 'RejectPolicy')
    self.assertGreaterEqual(n_set, 1)
    for f in DARWIN_FILES:
      src = _src(f) or ''
      for bad in ('AutoAddPolicy', 'WarningPolicy', 'save_host_keys', '_create_unverified_context',
            'CERT_NONE', 'StrictHostKeyChecking', 'UserKnownHostsFile', 'verify=False',
            'check_hostname=False', 'disabled_algorithms'):
        with self.subTest(f=f, token=bad):
          self.assertNotIn(bad, src)


class D02_DeployerG2(unittest.TestCase):
  def setUp(self):
    need(_landed('deploy_lib.py'), 'ConnectorDeployer G2 refusal')
    self.dl = _imp('deploy_lib')
    self.g = _gate()

  def test_g2_methods_refused_before_gateway(self):
    for gw in (RecGateway(), ScopedGateway(SCOPE_V, VERIFY_ACK, TARGET), ScopedGateway(SCOPE_I, INSPECT_ACK)):
      d = self.dl.ConnectorDeployer(gw)
      prepared = {'target': TARGET, 'kind': 'lambda', 'gateway': {'host': HOST, 'user': USER}}
      calls = [('bootstrap', lambda: d.bootstrap(approved=True)),
          ('repair_permissions', lambda: d.repair_permissions({'state': 'PERMISSIONS_NEED_REPAIR', 'mode_issues': []}, approved=True)),
          ('deploy', lambda: d.deploy(dict(SPEC), prepared, True)),
          ('rollback', lambda: d.rollback({'target': TARGET}))]
      with darwin():
        for name, fn in calls:
          with self.subTest(m=name, scope=getattr(gw, 'scope', None)):
            with self.assertRaises(self.g.GateRefused):
              fn()
      self.assertEqual(gw.calls, [])

  def test_g2_methods_first_statement_is_refuse_g2(self):
    _, d = _defs(TREE / 'deploy_lib.py')
    for n in ('bootstrap', 'repair_permissions', 'deploy', 'rollback'):
      with self.subTest(m=n):
        self.assertTrue(_first_stmt_is_darwin_refusal(d['ConnectorDeployer.' + n]))

  def test_prepare_offline_contract(self):
    need(hasattr(self.dl.ConnectorDeployer, 'prepare_offline'), 'ConnectorDeployer.prepare_offline')
    gw = NoCallGateway()
    with darwin():
      p = self.dl.ConnectorDeployer(gw).prepare_offline(dict(SPEC))
      p2 = self.dl.ConnectorDeployer(None).prepare_offline(dict(SPEC))
    self.assertEqual((gw.calls, p), ([], p2))
    self.assertIs(p.get('offline'), True)
    self.assertEqual(sorted(k for k in p if k != 'offline'), GOLD_PREPARE_KEYS)
    self.assertEqual(p['target'], TARGET)
    self.assertNotEqual(p['expected_registry_sha256'], 'a' * 64)

  def test_offline_plan_never_deployable_any_platform(self):
    need(hasattr(self.dl.ConnectorDeployer, 'prepare_offline'), 'ConnectorDeployer.prepare_offline')
    with darwin():
      p = self.dl.ConnectorDeployer(NoCallGateway()).prepare_offline(dict(SPEC))
    for plat in ('win32', 'linux'):
      with self.subTest(plat=plat), mock.patch.object(sys, 'platform', plat):
        gw = RecGateway()
        with self.assertRaises(Exception):
          self.dl.ConnectorDeployer(gw).deploy(dict(SPEC), dict(p), True)
        self.assertNotIn('apply', gw.calls)


class D05_DeployerScopeA1(unittest.TestCase):
  """ConnectorDeployer._g1b_entry (A1.3) with fake scoped gateways (no SSH at all)."""
  def setUp(self):
    need(_landed('deploy_lib.py'), 'deploy_lib deployer gate')
    self.dl = _imp('deploy_lib')
    self.g = _gate()

  def _refused(self, gw, fn):
    with darwin():
      with self.assertRaises(self.g.GateRefused):
        fn(self.dl.ConnectorDeployer(gw))
    if gw is not None:
      self.assertEqual(gw.calls, [])

  def test_inspect_allowed_under_either_scope(self):
    for gw in (ScopedGateway(SCOPE_I, INSPECT_ACK), ScopedGateway(SCOPE_V, VERIFY_ACK, TARGET)):
      with self.subTest(scope=gw.scope), darwin():
        self.assertEqual(self.dl.ConnectorDeployer(gw).inspect()['state'], 'READY')
      self.assertEqual(gw.calls, ['inspect'])

  def test_inspect_refused_without_valid_scoped_token(self):
    for gw in (RecGateway(), ScopedGateway(SCOPE_I, VERIFY_ACK), ScopedGateway(SCOPE_I, None),
         ScopedGateway(SCOPE_V, INSPECT_ACK, TARGET), ScopedGateway(None, INSPECT_ACK),
         ScopedGateway('bogus', VERIFY_ACK, TARGET)):
      with self.subTest(scope=getattr(gw, 'scope', None), ack=getattr(gw, 'ack', None)):
        self._refused(gw, lambda d: d.inspect())

  def test_inspect_destination_bound_at_entry(self):
    for gw in (ScopedGateway(SCOPE_I, INSPECT_ACK, host=HOST_B), ScopedGateway(SCOPE_I, INSPECT_ACK, user=USER_B),
         ScopedGateway(SCOPE_I, INSPECT_ACK, label=INSPECT_LABEL, host=HOST_B)):
      with self.subTest(host=gw.host, user=gw.user, label=gw.label):
        self._refused(gw, lambda d: d.inspect())

  def test_verify_and_discover_need_verify_scope(self):
    for name, fn in (('verify_backend', lambda d: d.verify_backend(dict(SPEC))),
            ('discover', lambda d: d.discover(dict(SPEC)))):
      with self.subTest(m=name):
        self._refused(ScopedGateway(SCOPE_I, INSPECT_ACK), fn)

  def test_spec_target_must_equal_label(self):
    for label, spec in (('other-target', dict(SPEC)), (TARGET, dict(SPEC, target='other-target'))):
      for name, fn in (('verify_backend', lambda d: d.verify_backend(dict(spec))),
              ('discover', lambda d: d.discover(dict(spec)))):
        with self.subTest(label=label, spec_target=spec['target'], m=name):
          self._refused(ScopedGateway(SCOPE_V, 'VERIFY BACKEND ' + label, label), fn)
    gw = ScopedGateway(SCOPE_V, VERIFY_ACK, TARGET)
    with darwin():
      for bad in (None, 'x', ['target'], {}):
        with self.subTest(spec=repr(bad)):
          with self.assertRaises(Exception):
            self.dl.ConnectorDeployer(gw).discover(bad)
    self.assertEqual(gw.calls, [])

  def test_prepare_refused_on_darwin(self):
    for gw in (ScopedGateway(SCOPE_V, VERIFY_ACK, TARGET), ScopedGateway(SCOPE_I, INSPECT_ACK), NoCallGateway(), None):
      with self.subTest(gw=type(gw).__name__):
        self._refused(gw, lambda d: d.prepare(dict(SPEC)))

  def test_verify_backend_sends_only_metadata_ops_darwin(self):
    gw = ScopedGateway(SCOPE_V, VERIFY_ACK, TARGET)
    with darwin():
      r = self.dl.ConnectorDeployer(gw).verify_backend(dict(SPEC))
    self.assertEqual((gw.calls, r['status']), (['inspect', 'discover'], 'BACKEND_VERIFIED'))


# ================================================================ D06/D07. A1.1 pre-connect, import, remote errors (T1b)
class D06_PreconnectAndImportA11(unittest.TestCase):
  """A1.1 P2-SEC-058/059 with a STUB paramiko: everything checkable locally happens
  BEFORE the SSH library is imported and before any client/connect/exec."""
  def setUp(self):
    need(_landed('deploy_lib.py'), 'deploy_lib SSHGateway gate')
    self.dl = _imp('deploy_lib')
    self.g = _gate()
    need(hasattr(self.dl, 'DARWIN_REQUEST_LIMIT'), 'A1.1 pre-connect checks')
    self.tmp = tempfile.mkdtemp(prefix='p2t1b-')
    self.addCleanup(shutil.rmtree, self.tmp, True)
    self.kh = os.path.join(self.tmp, 'known_hosts')
    with open(self.kh, 'w') as f:
      f.write('')

  def _gwv(self, label=TARGET, host=HOST, user=USER):
    return self.dl.SSHGateway(host, user, known_hosts=self.kh, ack='VERIFY BACKEND ' + label,
                 scope=SCOPE_V, label=label)

  def _gwi(self, host=HOST, user=USER):
    return self.dl.SSHGateway(host, user, known_hosts=self.kh, ack='INSPECT GATEWAY ' + user + '@' + host,
                 scope=SCOPE_I)

  def _never_connects(self, gw, req, exc_types):
    stub = StubParamiko()
    with darwin(paramiko='stub', stub=stub) as trap:
      with self.assertRaises(exc_types) as cm:
        gw.run(req)
    self.assertEqual((stub.clients, trap.attempts), ([], 0), 'SSH library imported / client built before refusal')
    return cm.exception

  def test_any_exception_on_import_gives_fixed_message(self):
    path_text = os.path.join(os.sep + 'opt', 'site-packages', 'paramiko', '__init__.py')
    for exc in (RuntimeError('boom ' + path_text), OSError(5, 'denied', path_text), SyntaxError('bad ' + path_text),
          AttributeError('x'), ValueError(USER + '@' + HOST), ImportError('No module named paramiko')):
      for gw, req in ((self._gwi(), {'op': 'inspect'}), (self._gwv(), {'op': 'discover', 'entry': dict(ENTRY)})):
        with self.subTest(exc=type(exc).__name__, scope=gw.scope):
          with darwin(paramiko='raise', exc=exc) as trap:
            with self.assertRaises(self.dl.DeploymentError) as cm:
              gw.run(req)
          self.assertEqual(str(cm.exception), self.dl.DARWIN_NO_SSH_LIB)
          self.assertEqual(trap.attempts, 1)
          for leak in ('site-packages', path_text, USER, HOST, 'pip'):
            self.assertNotIn(leak, str(cm.exception))

  def test_oversize_request_refused_before_connect_ascii_and_utf8(self):
    lim = self.dl.DARWIN_REQUEST_LIMIT
    for name, extra in (('ascii', 'a' * (lim + 10)), ('non_ascii_utf8', '\u00e9' * (lim // 2 + 10)),
              ('astral', '\U0001f600' * (lim // 4 + 10))):
      with self.subTest(payload=name):
        req = {'op': 'discover', 'entry': dict(ENTRY, note=extra)}
        self._never_connects(self._gwv(), req, self.dl.DeploymentError)

  def test_request_just_under_limit_reaches_client(self):
    lim = self.dl.DARWIN_REQUEST_LIMIT
    base = json.dumps({'op': 'discover', 'entry': dict(ENTRY, note='')}, sort_keys=True)
    req = {'op': 'discover', 'entry': dict(ENTRY, note='a' * (lim - len(base) - 1))}
    stub = StubParamiko()
    with darwin(paramiko='stub', stub=stub):
      self.dl.SSHGateway.run(self._gwv(), req)
    self.assertEqual(len(stub.clients), 1)

  def test_validation_before_connect(self):
    cases = [('bad_host', self._gwi(host='-oProxyCommand'), {'op': 'inspect'}),
        ('bad_host_dots', self._gwi(host='a..b'), {'op': 'inspect'}),
        ('bad_user', self._gwi(user='-l'), {'op': 'inspect'}),
        ('bad_url', self._gwv(), {'op': 'discover', 'entry': {'url': 'http://x.example/mcp', 'allow': ['a']}}),
        ('url_with_query', self._gwv(), {'op': 'discover', 'entry': dict(ENTRY, url=SPEC['url'] + '?q=1')}),
        ('entry_not_dict', self._gwv(), {'op': 'discover', 'entry': [ENTRY]}),
        ('extra_key', self._gwv(), {'op': 'inspect', 'x': 1}),
        ('extra_key_discover', self._gwv(), {'op': 'discover', 'entry': dict(ENTRY), 'timeout': 1}),
        ('bad_kind', self._gwv(), {'op': 'probe_existing', 'kind': 'shell', 'target': TARGET}),
        ('target_pattern', self._gwv(label='Demo_EPG'), {'op': 'inspect_lambda_target', 'target': 'Demo_EPG'}),
        ('unencodable', self._gwv(), {'op': 'discover', 'entry': dict(ENTRY, note=object())})]
    for name, gw, req in cases:
      with self.subTest(case=name):
        self._never_connects(gw, req, Exception)


class D07_RemoteErrorRedaction(unittest.TestCase):
  """A1.1 P2-SEC-060: the worker's ok:false `error` text is redacted on macOS; the
  Windows branch keeps the raw BASE behaviour."""
  LEAKY = ('denied for ' + USER + '@' + HOST + ' via https://abc123.lambda-url.us-west-2.on.aws/mcp '
      'token=SECRETVALUE123 from 192.0.2.10 at /home/' + USER + '/aq-mcp/registry.json on ' + HOST)

  def setUp(self):
    need(_landed('deploy_lib.py'), 'deploy_lib SSHGateway gate')
    self.dl = _imp('deploy_lib')
    need(hasattr(self.dl, 'DARWIN_REMOTE_ERROR_FALLBACK'), 'A1.1 remote-error redaction')
    self.tmp = tempfile.mkdtemp(prefix='p2t1b-')
    self.addCleanup(shutil.rmtree, self.tmp, True)
    self.kh = os.path.join(self.tmp, 'known_hosts')
    with open(self.kh, 'w') as f:
      f.write('')

  def _err(self, error, plat='darwin'):
    stub = StubParamiko(response={'ok': False, 'error': error})
    gw = self.dl.SSHGateway(HOST, USER, known_hosts=self.kh, ack=VERIFY_ACK, scope=SCOPE_V, label=TARGET)
    if plat == 'darwin':
      ctx = darwin(paramiko='stub', stub=stub)
    else:
      ctx = contextlib.ExitStack()
      ctx.enter_context(mock.patch.object(sys, 'platform', plat))
      ctx.enter_context(paramiko_state('stub', stub))
    with ctx:
      with self.assertRaises(self.dl.DeploymentError) as cm:
        gw.run({'op': 'inspect'})
    self.assertEqual((len(stub.clients), len(stub.clients[0].execs)), (1, 1))
    return str(cm.exception)

  def test_darwin_error_text_has_no_identity(self):
    msg = self._err(self.LEAKY)
    for leak in (USER, HOST, 'https://', 'lambda-url', 'SECRETVALUE123', '192.0.2.10', '/home/', 'registry.json'):
      self.assertNotIn(leak.lower(), msg.lower())
    self.assertTrue(msg.isascii() and msg.isprintable())

  def test_darwin_error_capped_and_fail_closed(self):
    long_msg = self._err('x ' * 5000)
    self.assertLessEqual(len(long_msg), self.dl.DARWIN_REMOTE_ERROR_MAX + 3)
    for bad in (None, 5, '', '   ', ['x'], {'e': USER}):
      with self.subTest(error=repr(bad)):
        self.assertEqual(self._err(bad), self.dl.DARWIN_REMOTE_ERROR_FALLBACK)
    ctl = self._err('bad \u202e\u0000 char ' + USER)
    self.assertTrue(ctl.isascii() and ctl.isprintable())
    self.assertNotIn(USER, ctl)

  def test_redactor_direct(self):
    f = self.dl._darwin_redact_remote_error
    out = f(self.LEAKY, USER, HOST)
    for leak in (USER, HOST, 'SECRETVALUE123', '192.0.2.10'):
      self.assertNotIn(leak, out)
    self.assertEqual(f(self.LEAKY, '', HOST), self.dl.DARWIN_REMOTE_ERROR_FALLBACK)

  def test_windows_branch_returns_raw_text(self):
    for plat in ('win32', 'linux'):
      with self.subTest(plat=plat):
        self.assertEqual(self._err(self.LEAKY, plat), self.LEAKY)


# ================================================================ E. quick_reg G3 (3.6) + export guard (decision B)
class E01_QuickRegG3(unittest.TestCase):
  def setUp(self):
    need(_landed('quick_reg.py'), 'quick_reg darwin G3 gates')
    self.q = _imp('quick_reg')
    self.g = _gate()
    self.tmp = tempfile.mkdtemp(prefix='p2t1q-')
    self.addCleanup(shutil.rmtree, self.tmp, True)
    qh = os.path.join(self.tmp, '.quickwork')
    os.makedirs(os.path.join(qh, 'profiles', 'p1'))
    for p in (os.path.join(qh, 'mcp_config.json'), os.path.join(qh, 'profiles', 'p1', 'mcp_config.json')):
      with open(p, 'w') as f:
        f.write('{"mcpServers": {}}')
    self.qh = qh

  def test_default_scan_scans_nothing_on_darwin(self):
    with mock.patch.dict(os.environ, {'HOME': self.tmp, 'USERPROFILE': self.tmp}), darwin(), \
        mock.patch.object(os, 'listdir', _tw('os.listdir')), mock.patch.object(os, 'scandir', _tw('os.scandir')), \
        mock.patch.object(os.path, 'isdir', _tw('os.path.isdir')), \
        mock.patch.object(os.path, 'isfile', _tw('os.path.isfile')):
      self.assertEqual(self.q.find_quick_profile_configs(), [])
      self.assertEqual(self.q.find_quick_profile_configs(None), [])

  def test_explicit_home_reads_as_today(self):
    with darwin():
      found = self.q.find_quick_profile_configs(self.qh)
    self.assertEqual([os.path.relpath(p, self.qh) for p in found],
            ['mcp_config.json', os.path.join('profiles', 'p1', 'mcp_config.json')])

  def test_import_file_writer_refused(self):
    dest = os.path.join(self.tmp, 'out')
    os.mkdir(dest)
    settings = {'id': 'aq-demo-epg', 'name': TARGET, 'command': 'ssh', 'arguments': ['-T', 'x']}
    with darwin(), mock.patch.object(os, 'open', _tw('os.open')):
      with self.assertRaises(self.g.GateRefused):
        self.q.emit_quick_import_file(settings, dest, allow_inside_repo=True)
    self.assertEqual(os.listdir(dest), [])

  def test_dips_reader_refused_without_sqlite(self):
    db = os.path.join(self.tmp, 'x.sqlite')
    with open(db, 'wb') as f:
      f.write(b'')
    with darwin():
      with self.assertRaises(self.g.GateRefused):
        self.q.inspect_dips_read_only(db)

  def test_layout_mismatch_fails_soft(self):
    weird = os.path.join(self.tmp, 'weird')
    os.makedirs(os.path.join(weird, 'profiles'))
    with open(os.path.join(weird, 'profiles', 'not-a-dir'), 'w') as f:
      f.write('x')
    with darwin():
      self.assertEqual(self.q.find_quick_profile_configs(weird), [])


class E02_ExportGuard(unittest.TestCase):
  """Decision B: write_quick_config refuses Quick-owned destinations and needs the exact
  EXPORT FULL token IN THE CODE PATH. HOME/USERPROFILE point at a temp folder."""
  def setUp(self):
    need(_landed('quick_reg.py'), 'quick_reg darwin export guard')
    self.q = _imp('quick_reg')
    need(hasattr(self.q, 'p2_export_destination_refused'), 'decision-B export guard')
    self.g = _gate()
    self.tmp = tempfile.mkdtemp(prefix='p2t1e-')
    self.addCleanup(shutil.rmtree, self.tmp, True)
    self.home = os.path.join(self.tmp, 'home')
    self.qh = os.path.join(self.home, '.quickwork')
    self.out = os.path.join(self.tmp, 'out')
    os.makedirs(os.path.join(self.qh, 'profiles', 'p1'))
    os.makedirs(self.out)
    with open(os.path.join(self.qh, 'mcp_config.json'), 'w') as f:
      f.write('{"mcpServers": {}}')
    p = mock.patch.dict(os.environ, {'HOME': self.home, 'USERPROFILE': self.home})
    p.start()
    self.addCleanup(p.stop)
    self.writes = []

  def _refused(self, dest, redacted=True, full_ack=None):
    with darwin(), mock.patch.object(self.q, 'secure_write_text', _tw('secure_write_text')), \
        mock.patch.object(os, 'open', _tw('os.open')):
      with self.assertRaises(self.g.GateRefused):
        self.q.write_quick_config(dict(SPEC), dest, redacted=redacted, full_ack=full_ack)

  def _allowed(self, dest, redacted=True, full_ack=None):
    with darwin(), mock.patch.object(self.q, 'secure_write_text', lambda p, t: self.writes.append((p, t))):
      return self.q.write_quick_config(dict(SPEC), dest, redacted=redacted, full_ack=full_ack)

  def _files(self):
    return sorted(os.path.relpath(os.path.join(r, f), self.tmp) for r, _, fs in os.walk(self.tmp) for f in fs)

  def test_inside_quickwork_refused_before_write(self):
    before = self._files()
    for dest in (os.path.join(self.qh, 'x.json'), os.path.join(self.qh, 'profiles', 'p1', 'x.json'),
          os.path.join(self.qh, 'new', 'deeper', 'x.json'), self.qh, self.qh + os.sep,
          pathlib.Path(self.qh) / 'p.json'):
      for redacted, ack in ((True, None), (False, 'EXPORT FULL')):
        with self.subTest(dest=str(dest), redacted=redacted):
          self._refused(dest, redacted, ack)
    self.assertEqual(self._files(), before)

  def test_tilde_dotdot_case_and_name_refused(self):
    cases = ['~/.quickwork/x.json', '~' + os.sep + '.quickwork' + os.sep + 'y.json', '~/.quickwork/../.quickwork/z.json',
        os.path.join(self.out, '..', 'home', '.quickwork', 'x.json'),
        os.path.join(self.qh, 'profiles', '..', 'x.json'), os.path.join(self.home, 'a', '..', '.quickwork', 'x.json'),
        os.path.join(self.home, '.QUICKWORK', 'x.json'), os.path.join(self.home, '.QuickWork', 'x.json')]
    cases += [os.path.join(folder, name) for folder in (self.out, self.tmp)
         for name in ('mcp_config.json', 'MCP_CONFIG.JSON', 'Mcp_Config.json')]
    for dest in cases:
      with self.subTest(dest=dest):
        self._refused(dest)

  def test_symlink_dir_and_file_refused(self):
    dlink, flink = os.path.join(self.tmp, 'innocent-folder'), os.path.join(self.out, 'innocent.json')
    try:
      os.symlink(self.qh, dlink)
      os.symlink(os.path.join(self.qh, 'profiles', 'p1', 'target.json'), flink)
    except (OSError, NotImplementedError, AttributeError):
      self.skipTest('NOT RUN: symlink creation not permitted on this machine')
    for dest in (os.path.join(dlink, 'x.json'), os.path.join(dlink, 'profiles', 'p1', 'x.json'), flink):
      with self.subTest(dest=dest):
        self._refused(dest)

  def test_malformed_paths_fail_closed(self):
    for bad in ('', 'a\x00b.json', None, 5, b'x.json', ['x.json'], os.path.join(self.out, 'a\x00.json')):
      with self.subTest(bad=repr(bad)):
        self._refused(bad)
        self.assertTrue(self.q.p2_export_destination_refused(bad))

  def test_outside_and_sibling_allowed(self):
    for dest in (os.path.join(self.out, 'a.json'), os.path.join(self.home, '.quickworkX', 'a.json'),
          os.path.join(self.home, 'quickwork', 'a.json'), os.path.join(self.home, 'a.json'),
          pathlib.Path(self.out) / 'b.json'):
      with self.subTest(dest=str(dest)):
        self.assertFalse(self.q.p2_export_destination_refused(dest))
        self.writes = []
        self._allowed(dest)
        self.assertEqual(len(self.writes), 1)

  def test_full_token_required_in_code_path(self):
    for bad in (None, '', 'export full', 'EXPORT FULL ', ' EXPORT FULL', 'EXPORT  FULL', 'COPY FULL',
          'EXPORT FULL\n', 'EXPORT\u00a0FULL', 'EXPORT FULL\u200b', b'EXPORT FULL', VERIFY_ACK, 5):
      with self.subTest(bad=repr(bad)):
        self._refused(os.path.join(self.out, 'full.json'), redacted=False, full_ack=bad)
    self.assertEqual(os.listdir(self.out), [])

  def test_full_with_token_and_redacted_without_token_reach_writer(self):
    full, red = os.path.join(self.out, 'full.json'), os.path.join(self.out, 'red.json')
    self._allowed(full, redacted=False, full_ack='EXPORT FULL')
    self._allowed(red, redacted=True, full_ack=None)
    self.assertEqual([p for p, _ in self.writes], [full, red])
    self.assertEqual(self.writes[0][1], self.q.config_export_text(dict(SPEC), redacted=False))
    self.assertIn(USER + '@' + HOST, self.writes[0][1])
    self.assertNotIn(USER, self.writes[1][1])
    self.assertNotIn(HOST, self.writes[1][1])

  def test_real_write_full_with_token_outside(self):
    dest = os.path.join(self.out, 'real-full.json')
    with darwin(fs=False):
      self.q.write_quick_config(dict(SPEC), dest, redacted=False, full_ack='EXPORT FULL')
    with open(dest, encoding='utf-8') as f:
      self.assertEqual(f.read(), self.q.config_export_text(dict(SPEC), redacted=False))
    self.assertEqual(sorted(os.listdir(self.qh)), ['mcp_config.json', 'profiles'])

  def test_no_direct_quick_config_write_sinks(self):
    expected = {'quick_reg.py': {('write_quick_config', 'secure_write_text'), ('emit_quick_import_file', 'secure_open'),
                  ('inspect_dips_read_only', 'sqlite3.connect')},
          'cli.py': {('write_new_json', 'secure_write_json')},
          'wizard.py': {('Wizard.save_receipt_action', 'secure_write_json'),
                 ('Wizard.save_bootstrap_receipt_action', 'secure_write_json')}}
    sinks = ('secure_write_text', 'secure_write_json', 'secure_open', 'write_text', 'write_bytes')
    for f, want in expected.items():
      got = set()

      def walk(node, qual):
        for c in ast.iter_child_nodes(node):
          q = (qual + '.' if qual else '') + c.name if isinstance(c, (ast.FunctionDef, ast.ClassDef)) else qual
          if isinstance(c, ast.Call):
            fn = c.func
            name = getattr(fn, 'attr', None) or getattr(fn, 'id', None)
            if name in sinks:
              got.add((qual, name))
            elif name == 'open' and isinstance(fn, ast.Attribute):
              got.add((qual, 'os.open'))
            elif name == 'open':
              mode = c.args[1] if len(c.args) > 1 else None
              for kw in c.keywords:
                mode = kw.value if kw.arg == 'mode' else mode
              if any(ch in str(getattr(mode, 'value', 'r')) for ch in 'wax+'):
                got.add((qual, 'open-write'))
            elif name == 'connect' and getattr(getattr(fn, 'value', None), 'id', None) == 'sqlite3':
              got.add((qual, 'sqlite3.connect'))
          walk(c, q)
      walk(ast.parse(_src(f)), '')
      with self.subTest(f=f):
        self.assertEqual(got, want)


class E03_CentralFullGating(unittest.TestCase):
  """B3b/B3c: FULL text only through token-gated builders; screen builder never FULL."""
  def setUp(self):
    self.q, self.g = _imp('quick_reg'), _gate()
    need(hasattr(self.q, 'quick_instructions_full'), 'quick_instructions_full / screen builder')

  def test_full_builder_needs_copy_full(self):
    with darwin():
      for bad in (None, '', 'copy full', 'COPY FULL ', 'EXPORT FULL', _eq_all('x'), StrSub('COPY FULL'), b'COPY FULL'):
        with self.subTest(bad=repr(bad)):
          with self.assertRaises(self.g.GateRefused):
            self.q.quick_instructions_full(dict(SPEC), bad)
      full = self.q.quick_instructions_full(dict(SPEC), 'COPY FULL')
    self.assertIn(USER + '@' + HOST, full)
    with mock.patch.object(sys, 'platform', 'win32'):
      self.assertEqual(self.q.quick_instructions_full(dict(SPEC), Bomb()), full)

  def test_screen_builder_never_has_identity(self):
    for plat in ('darwin', 'win32'):
      with mock.patch.object(sys, 'platform', plat), self.subTest(plat=plat):
        v = self.q.quick_instructions_screen(dict(SPEC))
        self.assertEqual(sorted(v), ['redacted'])
        for leak in (USER, HOST):
          self.assertNotIn(leak, v['redacted'])


# ================================================================ F. CLI (3.1, 3.4, 3.6, 7, A1, B)
class F01_CliDarwin(unittest.TestCase):
  def setUp(self):
    need("'--ack'" in (_src('cli.py') or ''), 'cli --ack option')
    self.cli = _imp('cli')
    self.tmp = tempfile.mkdtemp(prefix='p2t1c-')
    self.addCleanup(shutil.rmtree, self.tmp, True)
    self.home = os.path.join(self.tmp, 'home')
    self.qh = os.path.join(self.home, '.quickwork')
    os.makedirs(self.qh)
    self.mf = os.path.join(self.tmp, 'm.json')
    with open(self.mf, 'w') as f:
      json.dump(SPEC, f)
    p = mock.patch.dict(os.environ, {'HOME': self.home, 'USERPROFILE': self.home})
    p.start()
    self.addCleanup(p.stop)
    self.built, self.exports = [], []
    test = self

    class FakeSSH(object):
      def __init__(self, host, user, known_hosts=None, timeout=15, ack=None, scope=None, label=None):
        test.built.append({'host': host, 'user': user, 'ack': ack, 'scope': scope, 'label': label})
        self.host, self.user, self.ack, self.scope, self.label = host, user, ack, scope, label

      def run(self, q, timeout=65):
        return RecGateway().run(q, timeout)
    self.FakeSSH = FakeSSH

  def _rec_export(self, spec, file_path, redacted=True, full_ack=None):
    self.exports.append({'path': file_path, 'redacted': redacted, 'full_ack': full_ack})
    return file_path

  def _main(self, argv, writer=None):
    out, err = io.StringIO(), io.StringIO()
    with mock.patch.object(self.cli, 'SSHGateway', self.FakeSSH), \
        mock.patch.object(self.cli, 'NativeGateway', _tw('NativeGateway')), \
        mock.patch.object(self.cli, 'write_quick_config', writer or _tw('write_quick_config')), \
        contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
      try:
        rc = self.cli.main(argv)
      except SystemExit as e:
        rc = e.code
      except Exception as e:
        rc = 'EXC:' + type(e).__name__
    return rc, out.getvalue(), err.getvalue()

  def _refused_all(self, argvs, writer=None):
    with darwin(fs=False):
      for argv in argvs:
        with self.subTest(argv=argv):
          self.built.clear()
          rc, _, _ = self._main(argv, writer)
          self.assertNotIn(rc, (0, None))
          self.assertEqual(self.built, [], 'gateway constructed for a refused command')

  def test_g2_and_import_file_refused_before_gateway(self):
    h = ['--host', HOST, '--user', USER]
    rcpt = os.path.join(self.tmp, 'r.json')
    with open(rcpt, 'w') as f:
      json.dump({'target': TARGET}, f)
    argvs = [['import-file', self.mf, '--out-dir', self.tmp]]
    for ack in (INSPECT_ACK, VERIFY_ACK):
      argvs += [['bootstrap', '--approve-bootstrap', '--ack', ack] + h,
           ['repair-permissions', '--approve-repair', '--ack', ack] + h,
           ['rollback', '--receipt-file', rcpt, '--approve-target', TARGET, '--ack', ack] + h,
           ['apply', self.mf, '--plan-file', rcpt, '--receipt-file', os.path.join(self.tmp, 'o.json'),
           '--approve-target', TARGET, '--approve-apply', '--ack', ack]]
    self._refused_all(argvs)
    self.assertEqual(sorted(os.listdir(self.tmp)), ['home', 'm.json', 'r.json'])

  def test_remote_reads_require_exact_scoped_ack(self):
    bad = {'inspect': [None, '', 'inspect gateway ' + INSPECT_LABEL, VERIFY_ACK, INSPECT_ACK + ' ',
             'INSPECT GATEWAY ' + USER + '@' + HOST_B, 'INSPECT GATEWAY ' + USER_B + '@' + HOST],
       'discover': [None, '', 'verify backend demo-epg', INSPECT_ACK, VERIFY_ACK + '\u200b',
              'VERIFY BACKEND other-target']}
    self._refused_all([[op, self.mf] + ([] if a is None else ['--ack', a]) for op, acks in bad.items() for a in acks])

  def test_inspect_and_discover_with_exact_ack_build_scoped_gateway(self):
    with darwin(fs=False):
      rc, out, _ = self._main(['inspect', self.mf, '--ack', INSPECT_ACK])
      rc2, out2, _ = self._main(['discover', self.mf, '--ack', VERIFY_ACK])
    self.assertEqual((rc in (0, None), rc2 in (0, None)), (True, True))
    self.assertEqual(self.built, [{'host': HOST, 'user': USER, 'ack': INSPECT_ACK, 'scope': SCOPE_I, 'label': None},
                   {'host': HOST, 'user': USER, 'ack': VERIFY_ACK, 'scope': SCOPE_V, 'label': TARGET}])
    self.assertEqual((json.loads(out)['state'], json.loads(out2)['count']), ('READY', 1))

  def test_plan_without_ack_is_offline(self):
    with darwin(fs=False):
      rc, out, _ = self._main(['plan', self.mf])
    self.assertIn(rc, (0, None))
    self.assertEqual(self.built, [], 'a gateway object was built for an offline plan')
    self.assertIs(json.loads(out).get('offline'), True)

  def test_plan_refuses_any_ack(self):
    self._refused_all([['plan', self.mf, '--ack', a] for a in (VERIFY_ACK, INSPECT_ACK, '', 'x', 'EXPORT FULL')])

  def test_plan_file_inside_quick_dir_refused(self):
    dests = [os.path.join(self.qh, 'plan.json'), os.path.join(self.tmp, 'mcp_config.json')]
    self._refused_all([['plan', self.mf, '--plan-file', d] for d in dests])
    self.assertFalse(any(os.path.exists(d) for d in dests))

  def test_export_inside_quick_dir_refused(self):
    cq = os.path.join(self.tmp, 'customquick')
    os.makedirs(cq)
    dests = [os.path.join(self.qh, 'x.json'), '~/.quickwork/x.json',
        os.path.join(self.tmp, 'a', '..', 'home', '.quickwork', 'x.json'),
        os.path.join(self.home, '.QUICKWORK', 'x.json'), os.path.join(self.tmp, 'MCP_config.json')]
    argvs = [['export', self.mf, '--output-file', d] + extra for d in dests
        for extra in ([], ['--full-export', '--ack', 'EXPORT FULL'])]
    argvs.append(['export', self.mf, '--output-file', os.path.join(cq, 'x.json'), '--profile-dir', cq])
    self._refused_all(argvs, writer=self._rec_export)
    self.assertEqual(self.exports, [])

  def test_full_export_needs_token_and_reaches_writer(self):
    dest = os.path.join(self.tmp, 'out-full.json')
    base = ['export', self.mf, '--output-file', dest, '--full-export']
    self._refused_all([base + ([] if a is None else ['--ack', a]) for a in (None, '', 'export full', 'COPY FULL', VERIFY_ACK)],
             writer=self._rec_export)
    self.assertEqual(self.exports, [])
    with darwin(fs=False):
      rc, _, _ = self._main(base + ['--ack', 'EXPORT FULL'], writer=self._rec_export)
      rc2, _, _ = self._main(['export', self.mf, '--output-file', os.path.join(self.tmp, 'red.json')],
                 writer=self._rec_export)
    self.assertEqual((rc in (0, None), rc2 in (0, None)), (True, True))
    self.assertEqual(self.exports[0], {'path': dest, 'redacted': False, 'full_ack': 'EXPORT FULL'})
    self.assertIs(self.exports[1]['redacted'], True)

  def test_import_check_needs_explicit_home_on_darwin(self):
    self._refused_all([['import-check', '--name', TARGET], ['import-verify', self.mf, '--name', TARGET]])

  def test_no_new_cli_verbs(self):
    for n in ast.walk(ast.parse(_src('cli.py'))):
      if isinstance(n, ast.keyword) and n.arg == 'choices':
        self.assertEqual(ast.literal_eval(n.value), GOLD_BASE_CLI_VERBS)

  def test_windows_cli_ignores_ack(self):
    with mock.patch.object(sys, 'platform', 'win32'):
      rc, out, _ = self._main(['plan', self.mf, '--ack', 'anything'])
    self.assertIn(rc, (0, None))
    self.assertEqual([(b['ack'], b['scope'], b['label']) for b in self.built], [(None, None, None)])
    self.assertNotIn('offline', json.loads(out))


class F02_CliHelpAndReceiptGuard(unittest.TestCase):
  """CLI help constants (no prose pinned) and the receipt-path guard (T1b-1, T1b-5)."""
  setUp, _main, _refused_all = F01_CliDarwin.setUp, F01_CliDarwin._main, F01_CliDarwin._refused_all
  def _help(self, plat):
    out = io.StringIO()
    with mock.patch.object(sys, 'platform', plat), contextlib.redirect_stdout(out), \
        contextlib.redirect_stderr(io.StringIO()):
      with self.assertRaises(SystemExit) as cm:
        self.cli.main(['--help'])
    self.assertEqual(cm.exception.code, 0)
    return ' '.join(out.getvalue().split())

  def test_help_constants(self):
    c, g = self.cli, _gate()
    norm = ' '.join(c.DARWIN_ACK_HELP.split())
    self.assertIn(norm, self._help('darwin'))
    self.assertNotIn(norm, self._help('win32'))
    self.assertEqual((set(c.DARWIN_G2_CLI_OPS), tuple(c.DARWIN_G1B_CLI_OPS)),
            ({'bootstrap', 'repair-permissions', 'apply', 'rollback'}, ('inspect', 'discover')))
    for op, scope, label in (('inspect', SCOPE_I, INSPECT_LABEL), ('discover', SCOPE_V, TARGET)):
      hint = c.DARWIN_CLI_ACK_HINT[op]
      self.assertIn(hint, c.DARWIN_ACK_HELP)
      self.assertTrue(g.g1b_token(scope, label).startswith(hint.split('<')[0]))
    self.assertIn(g.FULL_EXPORT_TOKEN, c.DARWIN_ACK_HELP)
    with darwin(fs=False):
      rc, _, err = self._main(['inspect', self.mf])
    self.assertNotIn(rc, (0, None))
    self.assertIn(c.DARWIN_CLI_ACK_HINT['inspect'], err)

  def test_save_bootstrap_receipt_destination_guard(self):
    rc_in = os.path.join(self.tmp, 'receipt.json')
    with open(rc_in, 'w') as f:
      json.dump({'target': TARGET}, f)
    writes = []
    inside = [os.path.join(self.qh, 'r.json'), '~/.quickwork/r.json', os.path.join(self.tmp, 'mcp_config.json')]
    outside = os.path.join(self.tmp, 'saved.json')
    with mock.patch.object(self.cli, 'host_is_wizard_lambda_only', lambda r: True), \
        mock.patch.object(self.cli, 'write_new_json', lambda p, d: writes.append(p)):
      self._refused_all([['save-bootstrap-receipt', rc_in, '--output-file', d] for d in inside])
      self.assertEqual(writes, [])
      with darwin(fs=False):
        rc, _, _ = self._main(['save-bootstrap-receipt', rc_in, '--output-file', outside])
    self.assertIn(rc, (0, None))
    self.assertEqual(writes, [outside])


# ================================================================ G. G4 absence + forbidden strings (3.11, 3.12)
def _exec_string_constants(tree):
  doc_ids = set()
  for n in ast.walk(tree):
    if isinstance(n, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)) and n.body:
      b0 = n.body[0]
      if isinstance(b0, ast.Expr) and isinstance(b0.value, ast.Constant) and isinstance(b0.value.value, str):
        doc_ids.add(id(b0.value))
  for n in ast.walk(tree):
    if isinstance(n, ast.Constant) and isinstance(n.value, str) and id(n) not in doc_ids:
      yield n


def _parents(tree):
  par = {}
  for n in ast.walk(tree):
    for c in ast.iter_child_nodes(n):
      par[id(c)] = n
  return par


def _unreachable_on_darwin(node, par, tree):
  cur = node
  while id(cur) in par:
    p = par[id(cur)]
    if isinstance(p, ast.If) and _is_darwin_test(p.test):
      neg = isinstance(p.test, ast.UnaryOp) and isinstance(p.test.op, ast.Not)
      if (any(cur is x for x in p.orelse) and not neg) or (any(cur is x for x in p.body) and neg):
        return True
    if isinstance(p, (ast.FunctionDef, ast.AsyncFunctionDef)):
      return _first_stmt_is_darwin_refusal(p)
    cur = p
  return False


class G01_G4AbsenceAndForbidden(unittest.TestCase):
  def test_g4_no_tool_call_surface(self):
    for f in DARWIN_FILES:
      s = _src(f)
      if s is None:
        continue
      t = ast.parse(s)
      with self.subTest(f=f):
        for n in _exec_string_constants(t):
          self.assertNotIn('tools/call', n.value)
        for n in ast.walk(t):
          if isinstance(n, ast.Attribute):
            self.assertNotIn(n.attr, ('call_tool', 'tools_call'))
          if isinstance(n, ast.FunctionDef):
            self.assertNotIn(n.name, ('call_tool', 'tools_call', 'execute_tool', 'run_tool'))

  def test_g4_remote_op_vocabulary_frozen(self):
    ops = set()
    for f in ('deploy_lib.py', 'wizard.py', 'cli.py', 'native_gateway.py'):
      for n in ast.walk(ast.parse(_src(f))):
        if isinstance(n, ast.Dict):
          for k, v in zip(n.keys, n.values):
            if isinstance(k, ast.Constant) and k.value == 'op' and isinstance(v, ast.Constant):
              ops.add(v.value)
        if isinstance(n, ast.Call) and getattr(n.func, 'id', None) == 'dict':
          for kw in n.keywords:
            if kw.arg == 'op' and isinstance(kw.value, ast.Constant):
              ops.add(kw.value.value)
    self.assertTrue(ops <= GOLD_BASE_REMOTE_OPS, 'new remote ops: ' + str(ops - GOLD_BASE_REMOTE_OPS))

  def test_g4_runtime_verify_backend_only_metadata_ops(self):
    dl = _imp('deploy_lib')
    gw = RecGateway()
    with mock.patch.object(sys, 'platform', 'win32'):
      dl.ConnectorDeployer(gw).verify_backend(dict(SPEC))
    self.assertEqual(gw.calls, ['inspect', 'discover'])

  def test_forbidden_strings_unreachable_on_darwin(self):
    need(all(_landed(f) for f in ('deploy_lib.py', 'native_gateway.py', 'wizard.py', 'cli.py', 'quick_reg.py', 'model.py')),
      'all six modules landed (darwin guards present)')
    import re
    word = re.compile(r'\b(' + '|'.join(FORBIDDEN_WORDS) + r')\b', re.I)
    pip = re.compile(r'pip\s+install', re.I)
    for f in DARWIN_FILES:
      s = _src(f)
      if s is None:
        continue
      t = ast.parse(s)
      par = _parents(t)
      for n in _exec_string_constants(t):
        if word.search(n.value):
          self.fail('%s:%d forbidden word in executable string: %r' % (f, n.lineno, n.value[:80]))
        if pip.search(n.value) and not _unreachable_on_darwin(n, par, t):
          self.fail('%s:%d pip install string reachable on darwin: %r' % (f, n.lineno, n.value[:80]))
      for n in ast.walk(t):
        if isinstance(n, ast.List) and any(isinstance(e, ast.Constant) and e.value == 'pip' for e in n.elts):
          self.assertTrue(_unreachable_on_darwin(n, par, t), '%s:%d pip argv reachable on darwin' % (f, n.lineno))
        if isinstance(n, (ast.Import, ast.ImportFrom)):
          names = [a.name for a in n.names] + [getattr(n, 'module', None) or '']
          self.assertFalse(any('simpledialog' in x or 'keyring' in x for x in names), '%s:%d %s' % (f, n.lineno, names))


# ================================================================ H. wizard (3.4-3.10, A1.3/A1.4); real Tk, withdrawn
def _tk_ok():
  try:
    import tkinter
    r = tkinter.Tk()
    r.withdraw()
    r.destroy()
    return True
  except Exception:
    return False


class H00_WizardStatic(unittest.TestCase):
  def setUp(self):
    need(_landed('wizard.py'), 'wizard darwin changes')
    self.s = _src('wizard.py')

  def test_windows_font_tuples_literal_and_darwin_table(self):
    for lit in ("('Segoe UI',10)", "('Segoe UI',9)", "('Segoe UI Semibold',16)", "('Consolas',10)",
          'Helvetica Neue', 'Menlo'):
      self.assertIn(lit, self.s)

  def test_no_simpledialog(self):
    self.assertNotIn('simpledialog', self.s)

  def test_windows_after0_kept_in_else_branch(self):
    self.assertIn('self.after(0,done)', self.s)
    self.assertIn('queue', self.s)

  def test_no_unlock_state_on_self(self):
    # T1 fix: whole name segments only (T0's bare 'ack' also matched backend_verification).
    import re
    bad = re.compile(r'(^|_)(unlock|unlocked|ack|acks|token|tokens|typed|approval|authori[sz]ed)(_|$)')
    for n in ast.walk(ast.parse(self.s)):
      if isinstance(n, ast.Attribute) and isinstance(n.value, ast.Name) and n.value.id == 'self' \
          and isinstance(n.ctx, ast.Store):
        self.assertIsNone(bad.search(n.attr.lower()), 'state stored: self.' + n.attr)

  def test_every_darwin_gateway_is_scoped(self):
    found = 0
    for fn in ast.walk(ast.parse(self.s)):
      if isinstance(fn, ast.FunctionDef) and 'darwin' in fn.name:
        for n in ast.walk(fn):
          if isinstance(n, ast.Call) and getattr(n.func, 'id', None) == 'SSHGateway':
            found += 1
            self.assertTrue({'ack', 'scope', 'label'} <= {k.arg for k in n.keywords}, fn.name)
    self.assertGreaterEqual(found, 1)


@unittest.skipUnless(_tk_ok(), 'Tk display not available')
class H01_WizardRuntimeDarwinBranch(unittest.TestCase):
  """Executes the DARWIN branch of wizard.py on whatever Tk is present. NOT Aqua evidence."""
  def setUp(self):
    need(_landed('wizard.py'), 'wizard darwin changes')
    self.w = _imp('wizard')
    self.tmp = tempfile.mkdtemp(prefix='p2t1w-')
    self.addCleanup(shutil.rmtree, self.tmp, True)
    home = os.path.join(self.tmp, 'home')
    st = contextlib.ExitStack()
    self.addCleanup(st.close)
    P = mock.patch.object
    st.enter_context(mock.patch.dict(os.environ, {'HOME': home, 'USERPROFILE': home}))
    st.enter_context(P(sys, 'platform', 'darwin'))
    self.errors = []
    st.enter_context(P(self.w.messagebox, 'showerror', lambda *a, **k: self.errors.append(a)))
    for name in ('showinfo', 'showwarning'):
      st.enter_context(P(self.w.messagebox, name, lambda *a, **k: None))
    st.enter_context(P(self.w.messagebox, 'askyesno', return_value=True))
    import tkinter
    st.enter_context(P(tkinter.Misc, 'wait_window', lambda self, w=None: None))
    st.enter_context(P(tkinter.Misc, 'grab_set', lambda self: None))
    st.enter_context(P(tkinter.Misc, 'clipboard_append', _tw('real clipboard')))
    st.enter_context(P(tkinter.Misc, 'clipboard_clear', lambda self: None))
    for obj, name in ((self.w, 'SSHGateway'), (self.w, 'NativeGateway'), (sqlite3, 'connect'),
             (subprocess, 'Popen'), (subprocess, 'run')):
      st.enter_context(P(obj, name, _tw(name)))
    self.app = self.w.Wizard()
    self.app.withdraw()
    self.addCleanup(self._safe_destroy)
    for k, v in (('host', HOST), ('user', USER), ('target', TARGET), ('url', SPEC['url'])):
      self.app.vars[k].set(v)

  def _safe_destroy(self):
    try:
      self.app.destroy()
    except Exception:
      pass

  def _radio_values(self):
    vals = []

    def walk(w):
      for c in w.winfo_children():
        if c.winfo_class() in ('TRadiobutton', 'Radiobutton'):
          vals.append(str(c.cget('value')))
        walk(c)
    walk(self.app.body)
    return vals

  def test_transport_selector_linux_only(self):
    self.app.step = 0
    self.app.render()
    self.assertNotIn('native-local', self._radio_values())

  def test_g2_buttons_refused_without_gateway(self):
    self.app.gateway_inspection = {'state': 'MISSING'}
    self.app.bootstrap_action()
    self.app.gateway_inspection = {'state': 'PERMISSIONS_NEED_REPAIR', 'mode_issues': [{'file': 'x'}]}
    self.app.repair_action()
    self.app.last_receipt = {'backup_name': 'x', 'target': TARGET}
    self.app.last_gateway = RecGateway()
    self.app.rollback_action()
    self.app.prepared = {'target': TARGET}
    self.app.deploy_action()
    for _ in range(20):
      self.app.update()
    self.assertEqual(self.app.last_gateway.calls, [])
    self.assertFalse(self.app.busy)

  def test_copy_full_needs_typed_token(self):
    self.app._quick_variants = {'redacted': 'R', 'full': 'FULL-SENTINEL', 'full_labeled': 'L'}
    got = []
    with mock.patch.object(self.app, 'clipboard_append', lambda v: got.append(v)):
      self.app.copy_quick_full()
      self.app.copy_quick_redacted()
    self.assertNotIn('FULL-SENTINEL', got)
    self.assertIn('R', got)

  def test_export_full_needs_typed_token(self):
    with mock.patch.object(self.w.filedialog, 'asksaveasfilename', _tw('save dialog opened')), \
        mock.patch.object(self.w, 'write_quick_config', _tw('write_quick_config')):
      self.app.export_full_action()

  def test_dips_disabled(self):
    with mock.patch.object(self.w.filedialog, 'askopenfilename', _tw('DIPS dialog opened')):
      self.app.dips_action()

  def test_g1b_action_without_token_never_builds_gateway(self):
    with mock.patch.object(self.w, 'darwin_ssh_library_present', lambda: True):
      self.app.step = 0
      self.app.render()
      self.app.inspect_action()      # typed prompt left empty
      self.app.verify_backend_action()
      for _ in range(20):
        self.app.update()
    self.assertFalse(self.app.busy)

  def test_ssh_library_absent_refuses_before_prompt(self):
    with mock.patch.object(self.w, 'darwin_ssh_library_present', lambda: False), \
        mock.patch.object(self.app, '_typed_prompt', _tw('typed prompt shown')):
      self.app.step = 0
      self.app.render()
      self.app.inspect_action()
      self.app.verify_backend_action()
    self.assertGreaterEqual(len(self.errors), 2)
    self.assertFalse(self.app.busy)

  def test_step4_step5_panels_redacted_on_darwin(self):
    # Mac counterpart of tests/test_gui_quick_copy.py (which expects FULL values; Windows only).
    from tkinter import ttk
    self.app.tool_selection = ['list_genres']
    self.app.prepared = self.w.ConnectorDeployer(None).prepare_offline(self.app.spec())

    def entries(wd):
      out = []
      for c in wd.winfo_children():
        if isinstance(c, ttk.Entry):
          out.append(c.get())
        out.extend(entries(c))
      return out
    for step in (3, 4):
      with self.subTest(step=step):
        self.app.step = step
        self.app.render()
        vals = entries(self.app.quick_copy_area)
        self.assertTrue(vals, 'no Command/Arguments fields shown')
        self.assertFalse([v for v in vals if USER in v or HOST in v], 'real login/host shown on macOS')

  def test_worker_never_touches_tk_and_poller_cancelled(self):
    main = threading.current_thread()
    offenders = []
    real_after = self.app.after

    def spy_after(*a, **k):
      if threading.current_thread() is not main:
        offenders.append('after')
      return real_after(*a, **k)
    ev = threading.Event()
    with mock.patch.object(self.app, 'after', spy_after):
      self.app.action(lambda: (ev.wait(2), 'ok')[1], lambda ok, r: None)
      ev.set()
      for _ in range(60):
        self.app.update()
        if not self.app.busy:
          break
        threading.Event().wait(0.02)
    self.assertEqual(offenders, [])
    self.assertFalse(self.app.busy)
    ev2 = threading.Event()
    self.app.action(lambda: (ev2.wait(2), 'late')[1], lambda ok, r: offenders.append('late-callback'))
    self.app.destroy()
    ev2.set()
    threading.Event().wait(0.3)
    self.assertNotIn('late-callback', offenders)


def _wizard_or_skip():
  try:
    return _imp('wizard')
  except Exception as exc:  # no tkinter: the module cannot be imported at all
    raise unittest.SkipTest('NOT RUN: wizard/tkinter not importable here: ' + type(exc).__name__)


class _Rec(object):
  """Fake widget / dialog module: records calls; asksaveasfilename returns .path."""
  def __init__(self, path='', yes=True, alive=True):
    self.calls, self.path, self.yes, self.alive, self.text = [], path, yes, alive, ''

  def __getattr__(self, name):
    def f(*a, **k):
      self.calls.append((name,) + a)
      return {'asksaveasfilename': self.path, 'askyesno': self.yes, 'winfo_exists': self.alive}.get(name)
    return f

  def insert(self, i, t):
    self.text += t

  def delete(self, *a):
    self.text = ''


class H02_WizardHandlersNoTk(unittest.TestCase):
  """REAL wizard functions/handlers driven with a fake `self` (no Tk window, no display)."""
  def setUp(self):
    self.w = w = _wizard_or_skip()
    need(hasattr(w, 'darwin_step4_view'), 'B3c-B3e wizard helpers')
    self.tmp = tempfile.mkdtemp(prefix='p2t1b-w-')
    self.addCleanup(shutil.rmtree, self.tmp, True)
    self.home = os.path.join(self.tmp, 'home')
    self.qh = os.path.join(self.home, '.quickwork')
    os.makedirs(self.qh)
    self.mb, self.writes = _Rec(), []
    st = contextlib.ExitStack()
    self.addCleanup(st.close)
    st.enter_context(mock.patch.dict(os.environ, {'HOME': self.home, 'USERPROFILE': self.home}))
    st.enter_context(mock.patch.object(w, 'messagebox', self.mb))
    st.enter_context(mock.patch.object(w, 'write_quick_config', lambda *a, **k: self.writes.append((a, k))))
    st.enter_context(mock.patch.object(w, 'secure_write_json', lambda p, d: self.writes.append(p)))

  def _fake(self, names, **attrs):
    cls = type('FakeWizard', (object,), dict((n, getattr(self.w.Wizard, n)) for n in names))
    o = cls()
    o.spec, o._darwin, o.status = (lambda: dict(SPEC)), True, _Rec()
    for k, v in attrs.items():
      setattr(o, k, v)
    return o

  def _plan(self):
    with darwin():
      return self.w.ConnectorDeployer(None).prepare_offline(dict(SPEC))

  def test_step4_view_redacted_and_fail_closed(self):
    w, p = self.w, self._plan()
    ok, text = w.darwin_step4_view(dict(SPEC), p)
    self.assertTrue(ok)
    for leak in (USER, HOST):
      self.assertNotIn(leak, text)
    self.assertEqual(w.darwin_step4_view(dict(SPEC), None), (False, w.DARWIN_STEP4_PLAN_WAITING))
    bad = [dict(p, gateway={'host': HOST_B, 'user': USER}), dict(p, quick_connector={}), 'x']
    for b in bad:
      self.assertEqual(w.darwin_step4_view(dict(SPEC), b), (False, w.DARWIN_STEP4_UNAVAILABLE))
    for spec in (dict(SPEC, user=''), dict(SPEC, host=HOST + '\u00e9'), None):
      self.assertEqual(w.darwin_step4_view(spec, p)[0], False)
    m = _imp('model')
    for weak in (lambda t, u, h, home_root=None: t, lambda t, u, h, home_root=None: t.replace(u + '@' + h, 'X')):
      with mock.patch.object(m, 'redact_identity', weak):
        self.assertEqual(w.darwin_step4_view(dict(SPEC), p), (False, w.DARWIN_STEP4_UNAVAILABLE))

  def test_step4_view_refuses_if_bare_login_remains(self):
    # FINDING probe F-T1b-01: the post-redaction check must catch a remaining login too,
    # not only the host and user@host (brief: refuse when host/user remain).
    w, m, p = self.w, _imp('model'), self._plan()
    with mock.patch.object(m, 'redact_identity', lambda t, u, h, home_root=None: t.replace(h, 'X')):
      self.assertEqual(w.darwin_step4_view(dict(SPEC), p), (False, w.DARWIN_STEP4_UNAVAILABLE))

  def test_plan_failure_text_fixed_and_plan_action_never_shows_error(self):
    w = self.w
    for r in (USER + '@' + HOST + ' token=abc', Bomb(), None):
      self.assertEqual(w.darwin_plan_failure_text(r), w.DARWIN_STEP4_PLAN_FAILED)
    for leak in (USER, HOST):
      self.assertNotIn(leak, w.DARWIN_STEP4_PLAN_FAILED)
    got = []
    o = self._fake(['plan_action', '_darwin_wrap_plan_done'], plan_view=_Rec(), prepared='old',
           backend_verification={'backend_identity_sha256': w.backend_identity(dict(SPEC)),
                      'handshake': 'h', 'tool_count': 1, 'tools': [{'name': 'list_genres'}]},
           action=lambda task, cb: got.append((task, cb)), _darwin_step4_owned=lambda: ('a', 'v'),
           _darwin_refresh_provenance=lambda: None, refresh_summary_view=lambda: None,
           _darwin_render_step4=lambda: got.append('render'))
    o.plan_action()
    task, cb = got[0]
    cb(False, 'failed for ' + USER + '@' + HOST)
    self.assertEqual((o.prepared, o.plan_view.text), (None, w.DARWIN_STEP4_PLAN_FAILED))
    self.assertNotIn(USER, repr(self.mb.calls))
    with darwin():
      cb(True, task())
    self.assertIs(o.prepared.get('offline'), True)
    self.assertIn('render', got)

  def test_stale_plan_callback_dropped(self):
    w = self.w
    area, view = _Rec(), _Rec()
    base = dict(step=3, _tearing_down=False, _darwin_step4_widgets=(area, view), quick_copy_area=area, plan_view=view)
    for name, change in (('current', {}), ('other_step', {'step': 4}), ('teardown', {'_tearing_down': True}),
              ('rebuilt', {'quick_copy_area': _Rec()}), ('no_widgets', {'_darwin_step4_widgets': None}),
              ('destroyed', {'plan_view': _Rec(alive=False), '_darwin_step4_widgets': (area, _Rec(alive=False))})):
      with self.subTest(case=name):
        done = []
        o = self._fake(['_darwin_wrap_plan_done', '_darwin_step4_owned'], _darwin_refresh_provenance=lambda: done.append('p'),
               **dict(base, **change))
        o._darwin_wrap_plan_done(lambda ok, r: done.append(ok))(True, {})
        self.assertEqual(done, [True, 'p'] if name == 'current' else [])

  def test_worker_and_poller_teardown(self):
    import queue
    w = self.w
    for tearing in (True, False):
      q = queue.Queue()
      o = self._fake(['_darwin_start_worker'], _ui_queue=q, _tearing_down=tearing)
      o._darwin_start_worker(lambda: 'r', lambda ok, r: None).join(5)
      self.assertEqual(q.qsize(), 0 if tearing else 1)
    ran, after = [], []

    def boom():
      raise RuntimeError(USER + '@' + HOST)
    for tearing in (True, False):
      q = queue.Queue()
      for item in (boom, lambda: ran.append(1)):
        q.put(item)
      o = self._fake(['_poll_ui_queue', '_darwin_report_callback_failure'], _ui_queue=q, _tearing_down=tearing,
             after=lambda ms, f: after.append(ms))
      o._poll_ui_queue()
    self.assertEqual((ran, after), ([1], [w.DARWIN_POLL_MS]))
    self.assertEqual([c for c in self.mb.calls if c[0] == 'showerror'], [('showerror', 'Operation failed', w.DARWIN_CALLBACK_FAILED)])

  def test_receipt_and_export_destination_guard(self):
    w, q = self.w, _imp('quick_reg')
    inside, outside = os.path.join(self.qh, 'r.json'), os.path.join(self.tmp, 'r.json')
    with mock.patch.object(w, 'host_is_wizard_lambda_only', lambda r: True):
      for darwin_flag, path, n in ((True, inside, 0), (True, outside, 1), (False, inside, 1)):
        self.writes = []
        with mock.patch.object(w, 'filedialog', _Rec(path)):
          self._fake(['save_bootstrap_receipt_action'], bootstrap_receipt={}, _darwin=darwin_flag).save_bootstrap_receipt_action()
        self.assertEqual(len(self.writes), n, (darwin_flag, path))
    for path, n in ((inside, 0), (os.path.join(self.tmp, 'MCP_CONFIG.json'), 0), (outside, 1)):
      self.writes = []
      with mock.patch.object(w, 'filedialog', _Rec(path)), darwin(fs=False):
        self._fake(['_export_darwin'])._export_darwin(False, 'EXPORT FULL')
      self.assertEqual(len(self.writes), n, path)
    self.assertEqual(self.writes[0][1], {'redacted': False, 'full_ack': 'EXPORT FULL'})
    self.assertIn(('showerror', 'Export refused', q.P2_QUICK_DIR_REFUSED), self.mb.calls)

  def test_full_copy_and_export_handlers_need_exact_token(self):
    w, q = self.w, _imp('quick_reg')
    for typed in ('', 'COPY FULL', 'EXPORT FULL', _eq_all('x'), StrSub('COPY FULL'), StrSub('EXPORT FULL')):
      copied, exported = [], []
      o = self._fake(['_copy_quick_full_darwin', '_copy_quick_field_full_darwin', '_export_full_darwin'],
             _quick_variants={'redacted': 'R'}, _typed_prompt=lambda *a: typed,
             copy_text=copied.append, _arm_clipboard_clear=lambda v: None,
             _export_darwin=lambda r, a: exported.append((r, a)))
      built, real_full = [], q.quick_instructions_full
      with darwin(fs=False), mock.patch.object(q, 'quick_instructions_full',
                                               lambda s, a=None: (built.append(a), real_full(s, a))[1]):
        o._copy_quick_full_darwin()
        o._copy_quick_field_full_darwin('arguments')
        o._export_full_darwin()
      with self.subTest(typed=repr(typed)):
        if type(typed) is str and typed == 'COPY FULL':
          self.assertEqual((len(copied), built), (2, ['COPY FULL']), 'FULL text not from the gated builder')
          self.assertIn(USER + '@' + HOST, copied[0])
          self.assertIn(USER + '@' + HOST, copied[1])
        else:
          self.assertEqual(copied, [])
        self.assertEqual(exported, [(False, 'EXPORT FULL')] if (type(typed) is str and typed == 'EXPORT FULL') else [])

  def test_panel_helpers_redacted_and_full_field_gated(self):
    # Mac counterpart of tests/test_gui_quick_copy.py: on macOS Step 4/5 show REDACTED
    # Command/Arguments; the real value needs COPY FULL (plat forced to darwin).
    w = self.w
    full = w.quick_copy_fields(w.quick_connector(dict(SPEC)))
    red = w.darwin_redacted_copy_fields(dict(SPEC))
    self.assertEqual(sorted(red), sorted(full))
    for k in ('command', 'arguments', 'id', 'name'):
      for leak in (USER, HOST):
        self.assertNotIn(leak, red[k])
    self.assertNotEqual(red['arguments'], full['arguments'])
    with self.assertRaises(Exception):
      w.darwin_redacted_copy_fields(dict(SPEC, user=''))
    for plat in ('win32', 'darwin'):
      with mock.patch.object(sys, 'platform', plat):
        self.assertEqual(w.darwin_full_copy_field(dict(SPEC), 'arguments', 'COPY FULL'), full['arguments'])
        for bad in (None, 'EXPORT FULL', _eq_all('x')):
          with self.assertRaises(_gate().GateRefused):
            w.darwin_full_copy_field(dict(SPEC), 'nonsense', bad)
        with self.assertRaises(ValueError):
          w.darwin_full_copy_field(dict(SPEC), 'id', 'COPY FULL')


# ================================================================ P. Windows parity (any tree)
class P01_WindowsParity(unittest.TestCase):
  def setUp(self):
    p = mock.patch.object(sys, 'platform', 'win32')
    p.start()
    self.addCleanup(p.stop)
    self.m, self.q, self.dl = _imp('model'), _imp('quick_reg'), _imp('deploy_lib')

  def test_quick_connector_and_fields(self):
    c = self.m.quick_connector(dict(SPEC))
    self.assertEqual(c, GOLD_QUICK_CONNECTOR)
    self.assertEqual(self.q.quick_copy_fields(c), GOLD_COPY_FIELDS)

  def test_exports_and_variants(self):
    self.assertEqual(_sha(self.m.config_export(dict(SPEC))), GOLD_CONFIG_EXPORT_SHA)
    self.assertEqual(_sha(self.q.config_export_text(dict(SPEC), redacted=True)), GOLD_CONFIG_EXPORT_REDACTED_SHA)
    v = self.q.quick_instructions_variants(dict(SPEC))
    self.assertEqual({k: _sha(x) for k, x in v.items()}, GOLD_VARIANTS_SHA)
    self.assertEqual(self.m.FULL_VARIANT_WARNING, GOLD_FULL_WARNING)
    for bad in ('AKIA', 'aws_secret', 'token', 'password', 'ghp_'):
      self.assertNotIn(bad, v['full'])

  def test_prepare_verify_deploy(self):
    gw = RecGateway()
    p = self.dl.ConnectorDeployer(gw).prepare(dict(SPEC))
    self.assertEqual(sorted(p), GOLD_PREPARE_KEYS)
    self.assertEqual(_sha(json.dumps(p, sort_keys=True)), GOLD_PREPARE_SHA)
    self.assertEqual(gw.calls, ['inspect'])
    v = self.dl.ConnectorDeployer(RecGateway()).verify_backend(dict(SPEC))
    self.assertEqual(_sha(json.dumps(v, sort_keys=True)), GOLD_VERIFY_SHA)
    gw2 = RecGateway()
    self.dl.ConnectorDeployer(gw2).deploy(dict(SPEC), p, True)
    self.assertEqual(gw2.calls, GOLD_DEPLOY_OPS)

  def test_native_local_still_valid_off_darwin(self):
    self.assertEqual(self.m.validate_spec(dict(NATIVE_SPEC))['transport'], 'native-local')

  def test_ssh_gateway_positional_signature(self):
    gw = self.dl.SSHGateway(HOST, USER, os.devnull, 15)
    self.assertEqual((gw.host, gw.user, gw.known_hosts, gw.timeout), (HOST, USER, os.devnull, 15))

  def test_find_configs_missing_home(self):
    self.assertEqual(self.q.find_quick_profile_configs(os.path.join(tempfile.gettempdir(), 'p2t1-no-such-home')), [])

  def test_unchanged_function_sources(self):
    cache = {}
    for key, want in UNCHANGED_DEF_SHA256.items():
      f, name = key.split('::')
      if f not in cache:
        cache[f] = _defs(TREE / f)
      s, d = cache[f]
      with self.subTest(fn=key):
        self.assertIn(name, d)
        self.assertEqual(_sha(ast.get_source_segment(s, d[name])), want)

  def test_changed_functions_equal_base_minus_darwin_only_statements(self):
    # T1b-7: literal BASE goldens for every BASE function Slice 1 changed by adding
    # top-level darwin-only statements (deploy_lib, native_gateway, model, quick_reg, wizard).
    cache = {}
    for key, (want, count) in sorted(LEADING_GATE_DEF.items()):
      f, name = key.split('::')
      if f not in cache:
        cache[f] = _defs(TREE / f)
      s, d = cache[f]
      with self.subTest(fn=key):
        self.assertIn(name, d)
        text, n = _strip_off_darwin_lines(s, d[name])
        self.assertEqual(n, count, key + ': unexpected number of darwin-only statements')
        self.assertEqual(_sha(text), want, key + ': off-darwin source differs from BASE v0.4')

  def test_untouched_files(self):
    for f, want in UNTOUCHED_FILE_SHA256.items():
      with self.subTest(f=f):
        self.assertEqual(hashlib.sha256((TREE / f).read_bytes()).hexdigest(), want)


class P02_WindowsParityA1(unittest.TestCase):
  def setUp(self):
    p = mock.patch.object(sys, 'platform', 'win32')
    p.start()
    self.addCleanup(p.stop)

  def test_gate_functions_inert_never_inspect_args(self):
    g = _gate()
    for plat in ('win32', 'linux'):
      with mock.patch.object(sys, 'platform', plat), self.subTest(plat=plat):
        self.assertIsNone(g.require_g1b(Bomb(), Bomb(), Bomb(), Bomb()))
        self.assertIsNone(g.require_g1b(Bomb(), Bomb(), Bomb(), Bomb(), plat=plat))
        self.assertIsNone(g.refuse_g2(Bomb()))
        self.assertIsNone(g.refuse_g3_write(Bomb()))
        self.assertIsNone(g.refuse_g4(Bomb()))
        self.assertIsNone(g.require_full_variant(Bomb(), Bomb()))
    with mock.patch.object(sys, 'platform', 'darwin'):
      self.assertIsNone(g.require_g1b(Bomb(), Bomb(), Bomb(), Bomb(), plat='win32'))

  def test_ssh_run_off_darwin_skips_gate(self):
    dl = _imp('deploy_lib')
    for req in ({'op': 'bootstrap'}, {'op': 'check', 'target': 'x'}, {'op': 'inspect'}):
      for gw in (dl.SSHGateway(HOST, USER, os.devnull, 15),
           dl.SSHGateway(HOST, USER, os.devnull, 15, ack='wrong', scope='bogus', label='x y')):
        with self.subTest(op=req['op'], scoped=gw.scope):
          with paramiko_state('missing') as ctl:
            with self.assertRaises(dl.DeploymentError) as cm:
              gw.run(req)
          self.assertEqual((str(cm.exception), ctl.attempts), (WIN_PARAMIKO_MSG, 1))

  def test_write_quick_config_off_darwin_has_no_guard(self):
    q = _imp('quick_reg')
    tmp = tempfile.mkdtemp(prefix='p2t1p-')
    self.addCleanup(shutil.rmtree, tmp, True)
    home = os.path.join(tmp, 'home')
    writes = []
    with mock.patch.dict(os.environ, {'HOME': home, 'USERPROFILE': home}), \
        mock.patch.object(q, 'secure_write_text', lambda p, t: writes.append((p, t))), \
        mock.patch.object(q, '_p2_darwin_export_guard', _tw('darwin export guard called off darwin')):
      dest = os.path.join(home, '.quickwork', 'x.json')
      self.assertEqual(q.write_quick_config(dict(SPEC), dest, redacted=False), dest)
      q.write_quick_config(dict(SPEC), os.path.join(tmp, 'mcp_config.json'), redacted=True, full_ack='junk')
    self.assertEqual(len(writes), 2)
    self.assertEqual(writes[0][1], q.config_export_text(dict(SPEC), redacted=False))

  def test_non_darwin_bodies_match_base(self):
    # Functions with darwin if/else branches: off-darwin AST must equal BASE v0.4 (docstrings dropped).
    blob = _base_blob()
    self.assertEqual(sorted(blob), sorted(BASE_BLOB_SHA256))
    for key, seg in sorted(blob.items()):
      f, name = key.split('::')
      _, d = _defs(TREE / f)
      with self.subTest(fn=key):
        self.assertEqual(_sha(seg), BASE_BLOB_SHA256[key], 'embedded BASE segment corrupted')
        base = ast.parse(seg).body[0]
        self.assertIn(name, d)
        stripper = _StripDarwinBase()
        got = stripper.flat(_drop_docstring(list(d[name].body)))
        want = _drop_docstring(list(base.body))
        self.assertEqual([ast.dump(s) for s in got], [ast.dump(s) for s in want],
                key + ': non-darwin statements differ from BASE')
        self.assertEqual(stripper.acks, 0)
        bargs = [a.arg for a in base.args.args]
        self.assertEqual([a.arg for a in d[name].args.args],
                bargs + (['full_ack'] if name == 'write_quick_config' else []))

  def test_deployer_and_native_gate_helpers_inert_off_darwin(self):
    dl, ng = _imp('deploy_lib'), _imp('native_gateway')
    for plat in ('win32', 'linux'):
      with mock.patch.object(sys, 'platform', plat), self.subTest(plat=plat):
        self.assertIsNone(dl.ConnectorDeployer(Bomb())._g1b_entry(Bomb(), Bomb()))
        self.assertIsNone(ng._p2_refuse_native())
        self.assertIsNone(_imp('quick_reg').find_quick_profile_configs(
          os.path.join(tempfile.gettempdir(), 'p2t1b-no-such-home')) or None)


if __name__ == '__main__':
  unittest.main()
