"""P2 Slice 1 / B4: macOS Step 5 identity-redaction correction.

Scope: the Step 5 output paths (on-screen panel, shareable text, redacted clipboard
copy and redacted JSON export) must REFUSE rather than emit text in which the real
SSH login is still readable because it is embedded in an approved name - a target
such as "<login>-epg" renders as the Quick connector id "aq-<login>-epg".

ARCHITECTURE NOTE (why the checks are where they are): model.redact_identity,
quick_reg.quick_instructions, quick_instructions_variants and config_export_text are
BYTE-FROZEN for Windows parity - tests/test_p2s1_acceptance_independent.py pins their
exact source SHA-256 (UNCHANGED_DEF_SHA256) and compares off-darwin ASTs against the
BASE v0.4 bodies. The refusal is therefore applied in the darwin-only boundaries the
wizard and CLI actually use on macOS: quick_reg.quick_instructions_screen,
quick_reg._p2_darwin_export_guard and wizard.darwin_redacted_copy_fields. The Windows
path keeps its exact previous bytes and behaviour.

Every darwin test drives the REAL function with sys.platform patched to 'darwin'; no
Mac, no SSH, no network, no clipboard and no Tk window is used. All identities are
synthetic placeholders (fakeuser / gateway.example.com).
"""
import sys
import unittest
from unittest import mock

import model
import quick_reg
from model import (IdentityRedactionError, RedactionError, assert_identity_safe,
                   login_token_present, redact_identity, redact_identity_strict)

HOST = 'gateway.example.com'
URL = 'https://abc123.lambda-url.us-west-2.on.aws/mcp'


def darwin():
    return mock.patch.object(sys, 'platform', 'darwin')


def windows():
    return mock.patch.object(sys, 'platform', 'win32')


def spec(user='fakeuser', target='demo-epg', host=HOST):
    return {'transport': 'linux-ssh', 'host': host, 'user': user, 'kind': 'lambda',
            'target': target, 'display_name': 'AQ ' + target, 'url': URL,
            'allow': ['list_things']}


LEAK = spec(user='fakeuser', target='fakeuser-epg')
CLEAN = spec(user='fakeuser', target='demo-epg')


class LoginTokenBoundaryRule(unittest.TestCase):
    """The boundary rule: '-', '_', '.', '@', '/' and space are boundaries; ASCII
    letters and digits are not."""

    def test_true_positives(self):
        for login, text in [('fakeuser', 'aq-fakeuser-epg'), ('fakeuser', 'AQ FAKEUSER-epg'),
                            ('fakeuser', 'fakeuser-epg'), ('fakeuser', 'x/fakeuser.1'),
                            ('fakeuser', 'AQ fakeuser-demo'), ('fakeuser', 'a_fakeuser_b'),
                            ('ops', 'ops-epg'), ('ops', 'aq-ops'), ('ops', 'run ops now')]:
            with self.subTest(login=login, text=text):
                self.assertTrue(login_token_present(text, login))

    def test_no_false_positive_inside_a_longer_word(self):
        for login, text in [('ops', 'devopstools'), ('ops', 'devopstools-epg'),
                            ('ops', 'operations'), ('ops', 'aq-devopstools-epg'),
                            ('fakeuser', 'myfakeuserx'), ('fakeuser', 'fakeusers'),
                            ('fakeuser', '1fakeuser2')]:
            with self.subTest(login=login, text=text):
                self.assertFalse(login_token_present(text, login))

    def test_our_own_placeholder_is_not_a_survival(self):
        self.assertFalse(login_token_present('ssh <user>@<3090-host> ok', 'user'))
        self.assertFalse(login_token_present('/home/<user>/aq-mcp', 'user'))
        self.assertTrue(login_token_present('<user>@<3090-host> user-epg', 'user'))

    def test_empty_or_non_str_login_fails_closed(self):
        for bad in ('', '   ', None, 7, b'fakeuser'):
            with self.subTest(login=bad):
                with self.assertRaises(IdentityRedactionError):
                    login_token_present('anything', bad)

    def test_none_text_is_absent_not_an_error(self):
        self.assertFalse(login_token_present(None, 'fakeuser'))


class AssertIdentitySafeRule(unittest.TestCase):

    def test_safe_text_is_returned_unchanged(self):
        text = 'ssh -T -q <user>@<3090-host> /home/<user>/aq-mcp/aq-run.sh demo-epg'
        self.assertEqual(assert_identity_safe(text, 'fakeuser', HOST), text)

    def test_refuses_surviving_login_host_and_composite(self):
        for text in ['aq-fakeuser-epg', 'host is gateway.example.com',
                     'fakeuser@gateway.example.com', 'AQ-FAKEUSER-EPG']:
            with self.subTest(text=text):
                with self.assertRaises(IdentityRedactionError):
                    assert_identity_safe(text, 'fakeuser', HOST)

    def test_fails_closed_on_empty_non_str_or_non_ascii_identity(self):
        for user, host in [('', HOST), ('   ', HOST), ('fakeuser', ''), ('fakeuser', '  '),
                           (None, HOST), ('fakeuser', None), (7, HOST),
                           ('f\u00e5keuser', HOST), ('fakeuser', 'g\u00e5teway.example.com')]:
            with self.subTest(user=user, host=host):
                with self.assertRaises(IdentityRedactionError):
                    assert_identity_safe('clean text', user, host)

    def test_refusal_message_never_echoes_identity(self):
        try:
            assert_identity_safe('aq-fakeuser-epg', 'fakeuser', HOST)
        except IdentityRedactionError as exc:
            self.assertNotIn('fakeuser', str(exc))
            self.assertNotIn(HOST, str(exc))
        else:
            self.fail('expected a refusal')

    def test_is_a_redaction_error_subclass(self):
        # Existing callers (cli.py export, wizard copy/export) already treat
        # RedactionError as a hard refusal, so the new error fails closed through those
        # exact paths with no new catch sites and no new wording.
        self.assertTrue(issubclass(IdentityRedactionError, RedactionError))
        self.assertTrue(issubclass(IdentityRedactionError, ValueError))

    def test_strict_equals_redact_then_assert_for_safe_text(self):
        text = 'ssh fakeuser@gateway.example.com /home/fakeuser/aq-mcp/aq-run.sh demo-epg'
        self.assertEqual(redact_identity_strict(text, 'fakeuser', HOST),
                         redact_identity(text, 'fakeuser', HOST))

    def test_never_edits_an_approved_target_name(self):
        # Requirement: do not silently truncate, mask or alter unrelated approved
        # target names. The artifact is withheld instead.
        self.assertEqual(redact_identity('aq-fakeuser-epg', 'fakeuser', HOST),
                         'aq-fakeuser-epg')


class Step5ShareableTextDarwin(unittest.TestCase):
    """quick_instructions_screen is the macOS boundary behind the Step 5 on-screen
    text and the redacted clipboard copy (the wizard holds only what it returns)."""

    def test_refuses_when_login_survives(self):
        with darwin():
            with self.assertRaises(IdentityRedactionError):
                quick_reg.quick_instructions_screen(LEAK)

    def test_frozen_shared_formatter_is_deliberately_unchanged(self):
        # quick_instructions is byte-frozen for Windows parity. Its staying permissive
        # is the parity contract, not a gap: on macOS the wizard and CLI only ever
        # render what quick_instructions_screen returns.
        with darwin():
            self.assertIn('aq-fakeuser-epg', quick_reg.quick_instructions(LEAK, redacted=True))

    def test_clean_target_still_renders_and_hides_identity(self):
        with darwin():
            text = quick_reg.quick_instructions_screen(CLEAN)['redacted']
        self.assertNotIn('fakeuser', text)
        self.assertNotIn(HOST, text)
        self.assertIn('<user>@<3090-host>', text)
        self.assertIn('aq-demo-epg', text)

    def test_login_equal_to_the_placeholder_word_is_not_refused(self):
        # Without masking our own placeholders, '<user>' would itself look like a
        # surviving login and refuse EVERY artifact for a login named 'user'.
        with darwin():
            text = quick_reg.quick_instructions_screen(spec(user='user'))['redacted']
        self.assertIn('<user>', text)
        self.assertIn('<3090-host>', text)
        self.assertNotIn(HOST, text)
        self.assertFalse(login_token_present(text, 'user'))

    def test_preexisting_placeholder_double_wrap_is_observed_not_a_leak(self):
        # OBSERVED (pre-existing, NOT introduced by B4 and deliberately NOT changed):
        # redact_identity's standalone-token pass also rewrites the 'user' inside the
        # '<user>' placeholder it just emitted, so a login literally equal to 'user'
        # renders as '<<user>>'. Cosmetic only: no real login or host is exposed, and
        # redact_identity is byte-frozen and shared with Windows.
        out = redact_identity('ssh user@' + HOST, 'user', HOST)
        self.assertIn('<<user>>', out)
        self.assertNotIn('user@' + HOST, out)
        self.assertFalse(login_token_present(out, 'user'))

    def test_short_login_inside_a_longer_target_is_not_refused(self):
        with darwin():
            text = quick_reg.quick_instructions_screen(
                spec(user='ops', target='devopstools-epg'))['redacted']
        self.assertIn('aq-devopstools-epg', text)

    def test_display_name_only_leak_is_refused(self):
        # config_export has no 'name' field, so a login carried ONLY in display_name is
        # invisible to the JSON-export check but IS visible in the instructions text.
        # The login must be '-'/'_' adjacent to survive redact_identity (a
        # space-delimited login is already replaced), so this is the real leak shape.
        leak = spec(user='fakeuser', target='demo-epg')
        leak['display_name'] = 'AQ fakeuser-demo'
        with darwin():
            self.assertNotIn('fakeuser', quick_reg.config_export_text(leak, redacted=True))
            with self.assertRaises(IdentityRedactionError):
                quick_reg.quick_instructions_screen(leak)

    def test_space_delimited_login_in_display_name_is_already_redacted(self):
        ok = spec(user='fakeuser', target='demo-epg')
        ok['display_name'] = 'AQ fakeuser demo'
        with darwin():
            text = quick_reg.quick_instructions_screen(ok)['redacted']
        self.assertIn('AQ <user> demo', text)

    def test_full_variant_is_unaffected(self):
        # The FULL path is a deliberate, token-gated reveal; B4 must not block it.
        with darwin():
            full = quick_reg.quick_instructions(LEAK, redacted=False)
        self.assertIn('fakeuser@' + HOST, full)


class Step5RedactedExportDarwin(unittest.TestCase):

    def test_darwin_export_guard_refuses_when_login_survives(self):
        # The macOS export boundary, called by write_quick_config BEFORE anything is
        # opened or created. config_export_text itself is byte-frozen for parity.
        with darwin():
            with self.assertRaises(IdentityRedactionError):
                quick_reg._p2_darwin_export_guard(
                    '/tmp/p2s1-b4-does-not-exist.json', True, None, LEAK)
            quick_reg._p2_darwin_export_guard(
                '/tmp/p2s1-b4-does-not-exist.json', True, None, CLEAN)

    def test_export_guard_without_a_spec_keeps_the_old_3_arg_behaviour(self):
        with darwin():
            self.assertIsNone(quick_reg._p2_darwin_export_guard(
                '/tmp/p2s1-b4-does-not-exist.json', True, None))

    def test_write_quick_config_writes_nothing_when_refused(self):
        import os
        import tempfile
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, 'example.json')
            with darwin():
                with self.assertRaises(IdentityRedactionError):
                    quick_reg.write_quick_config(LEAK, path, redacted=True)
            self.assertFalse(os.path.exists(path), 'a refused export must leave no file')

    def test_write_quick_config_clean_spec_still_writes(self):
        import json
        import os
        import tempfile
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, 'example.json')
            with darwin():
                quick_reg.write_quick_config(CLEAN, path, redacted=True)
            with open(path) as fh:
                body = fh.read()
        self.assertNotIn('fakeuser', body)
        self.assertIn('aq-demo-epg', json.dumps(json.loads(body)))

    def test_full_export_text_is_unaffected(self):
        with darwin():
            out = quick_reg.config_export_text(LEAK, redacted=False)
        self.assertIn('fakeuser@' + HOST, out)


class WindowsParityPreserved(unittest.TestCase):
    """The strict check is macOS-only, so every Windows output stays byte-identical to
    the pre-B4 staged behaviour (redact_identity alone, no refusal)."""

    def test_windows_shareable_text_is_byte_identical_to_redact_identity(self):
        with windows():
            got = quick_reg.quick_instructions(LEAK, redacted=True)
            expected = redact_identity(quick_reg.quick_instructions(LEAK, redacted=False),
                                       'fakeuser', HOST)
        self.assertEqual(got, expected)

    def test_windows_does_not_refuse_the_leaking_spec(self):
        with windows():
            text = quick_reg.quick_instructions(LEAK, redacted=True)
            export = quick_reg.config_export_text(LEAK, redacted=True)
            variants = quick_reg.quick_instructions_variants(LEAK)
        # Documented pre-existing Windows behaviour, deliberately NOT changed here.
        self.assertIn('aq-fakeuser-epg', text)
        self.assertIn('aq-fakeuser-epg', export)
        self.assertIn('aq-fakeuser-epg', variants['redacted'])

    def test_windows_clean_spec_unchanged(self):
        with windows():
            text = quick_reg.quick_instructions(CLEAN, redacted=True)
        self.assertNotIn('fakeuser', text)
        self.assertIn('<user>@<3090-host>', text)

    def test_windows_export_guard_is_never_called(self):
        # write_quick_config calls the guard only under the darwin branch.
        def boom(*a, **k):
            raise AssertionError('darwin export guard called off darwin')
        import os
        import tempfile
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, 'win.json')
            with windows(), mock.patch.object(quick_reg, '_p2_darwin_export_guard', boom):
                quick_reg.write_quick_config(LEAK, path, redacted=True)
            self.assertTrue(os.path.exists(path))


class CliDarwinExportOrdering(unittest.TestCase):
    """[B4b] macOS CLI export: the complete redacted-output validation must run BEFORE
    any file is created, so an identity refusal leaves no output file. The written JSON
    never contained the login (config_export emits no 'name' field), so this is an
    ordering/atomicity requirement, not a content leak."""

    @classmethod
    def setUpClass(cls):
        import cli
        cls.cli = cli

    class _Parser(object):
        def error(self, msg):
            raise SystemExit('PARSER_ERROR: ' + msg)

    def _args(self, out, full=False, ack=None):
        import types
        return types.SimpleNamespace(output_file=out, full_export=full, ack=ack)

    @staticmethod
    def _quiet():
        # _darwin_export prints the instructions; keep test output clean.
        import contextlib
        import io as _io
        return contextlib.redirect_stdout(_io.StringIO())

    def _leak_spec(self):
        leak = spec(user='fakeuser', target='demo-epg')
        leak['display_name'] = 'AQ fakeuser-demo'
        return leak

    def test_display_name_only_refusal_leaves_no_output_file(self):
        import os
        import tempfile
        with tempfile.TemporaryDirectory() as tmp:
            out = os.path.join(tmp, 'example.json')
            with darwin():
                with self.assertRaises(SystemExit):
                    self.cli._darwin_export(self._Parser(), self._args(out), self._leak_spec())
            self.assertFalse(os.path.exists(out),
                             'an identity refusal must leave NO output file')
            self.assertEqual(os.listdir(tmp), [], 'no partial artifact may remain')

    def test_successful_redacted_export_still_writes_and_prints(self):
        import json
        import os
        import tempfile
        with tempfile.TemporaryDirectory() as tmp:
            out = os.path.join(tmp, 'example.json')
            with darwin(), self._quiet():
                rc = self.cli._darwin_export(self._Parser(), self._args(out), CLEAN)
            self.assertEqual(rc, 0)
            self.assertTrue(os.path.exists(out))
            with open(out) as fh:
                body = fh.read()
        self.assertNotIn('fakeuser', body)
        self.assertNotIn(HOST, body)
        self.assertIn('aq-demo-epg', json.dumps(json.loads(body)))

    def test_leaking_target_refusal_also_leaves_no_output_file(self):
        import os
        import tempfile
        with tempfile.TemporaryDirectory() as tmp:
            out = os.path.join(tmp, 'example.json')
            with darwin():
                with self.assertRaises(SystemExit):
                    self.cli._darwin_export(self._Parser(), self._args(out), LEAK)
            self.assertFalse(os.path.exists(out))

    def test_full_export_authorization_order_is_preserved(self):
        # The FULL variant must still be refused by the EXPORT FULL token check inside
        # write_quick_config, and must not be written without the exact token.
        import os
        import tempfile
        with tempfile.TemporaryDirectory() as tmp:
            out = os.path.join(tmp, 'full.json')
            with darwin():
                with self.assertRaises(SystemExit) as cm:
                    self.cli._darwin_export(self._Parser(),
                                            self._args(out, full=True, ack='junk'), LEAK)
            self.assertIn('FULL variant', str(cm.exception))
            self.assertFalse(os.path.exists(out), 'FULL export must not be written without the token')

    def test_full_export_with_token_still_reveals_deliberately(self):
        import capability_gate
        import os
        import tempfile
        with tempfile.TemporaryDirectory() as tmp:
            out = os.path.join(tmp, 'full.json')
            with darwin(), self._quiet():
                rc = self.cli._darwin_export(
                    self._Parser(),
                    self._args(out, full=True, ack=capability_gate.FULL_EXPORT_TOKEN), LEAK)
            self.assertEqual(rc, 0)
            with open(out) as fh:
                body = fh.read()
        self.assertIn('fakeuser@' + HOST, body)


class Step5PanelDarwin(unittest.TestCase):
    """wizard.darwin_redacted_copy_fields: the Step 5 Command / Arguments panel."""

    @classmethod
    def setUpClass(cls):
        try:
            import wizard
        except Exception as exc:
            raise unittest.SkipTest('wizard import unavailable: %s' % type(exc).__name__)
        cls.wizard = wizard

    def test_panel_withheld_when_login_survives(self):
        with darwin():
            with self.assertRaises(IdentityRedactionError):
                self.wizard.darwin_redacted_copy_fields(LEAK)

    def test_panel_renders_for_a_clean_target(self):
        with darwin():
            values = self.wizard.darwin_redacted_copy_fields(CLEAN)
        self.assertEqual(values['command'], 'ssh')
        self.assertIn('<user>@<3090-host>', values['arguments'])
        self.assertEqual(values['id'], 'aq-demo-epg')
        for key in ('command', 'arguments', 'id', 'name'):
            self.assertNotIn('fakeuser', str(values[key]))

    def test_joined_record_is_checked_not_only_each_field(self):
        # id/name/timeout are rendered together in one helper line.
        with darwin():
            with self.assertRaises(IdentityRedactionError):
                self.wizard.darwin_redacted_copy_fields(spec(target='aq-fakeuser'))

    def test_full_field_path_is_unaffected(self):
        import capability_gate
        with darwin():
            value = self.wizard.darwin_full_copy_field(
                LEAK, 'arguments', capability_gate.FULL_COPY_TOKEN)
        self.assertIn('fakeuser@' + HOST, value)

    def test_refusal_texts_never_echo_identity(self):
        for text in (self.wizard.DARWIN_STEP5_IDENTITY_REFUSED,
                     self.wizard.DARWIN_PANEL_IDENTITY_REFUSED,
                     model.IDENTITY_UNSAFE_REFUSAL):
            self.assertNotIn('fakeuser', text)
            self.assertNotIn(HOST, text)
            self.assertNotIn('epg', text)


if __name__ == '__main__':
    unittest.main(verbosity=2)
