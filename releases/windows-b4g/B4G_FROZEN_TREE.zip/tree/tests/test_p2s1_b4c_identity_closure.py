"""P2 Slice 1 / B4c: closure of the two demonstrated identity-output defects.

F-B4b-01  deploy_lib._darwin_redact_remote_error (macOS remote-error text) kept the
          dash-boundary weakness: a login embedded in an approved target name survived
          into the text that is raised and displayed.
F-B4b-02  model.plain_language_summary / wizard.Wizard.summary_text printed the target
          name on macOS with no identity check, while the Step 4 plan JSON beside it was
          checked (B3f).

Both are fixed macOS-only. model.plain_language_summary and model.redact_identity are
BYTE-FROZEN and are NOT modified. Every darwin test drives the REAL function with
sys.platform patched to 'darwin'; no Mac, no SSH, no network, no Tk window. All
identities are synthetic placeholders.
"""
import sys
import unittest
from unittest import mock

import deploy_lib
import model

HOST = 'gateway.example.com'
URL = 'https://abc123.lambda-url.us-west-2.on.aws/mcp'
FALLBACK = deploy_lib.DARWIN_REMOTE_ERROR_FALLBACK


def darwin():
    return mock.patch.object(sys, 'platform', 'darwin')


def windows():
    return mock.patch.object(sys, 'platform', 'win32')


def spec(user='fakeuser', target='demo-epg', host=HOST):
    return {'transport': 'linux-ssh', 'host': host, 'user': user, 'kind': 'lambda',
            'target': target, 'display_name': 'AQ ' + target, 'url': URL,
            'allow': ['list_things']}


def plan(sp):
    return {'offline': True, 'gateway': {'host': sp['host'], 'user': sp['user']},
            'target': sp['target'], 'kind': 'lambda',
            'registry_entry': {'region': 'us-west-2', 'allow': ['list_things']}}


# ===================================================================== F-B4b-01
class RemoteErrorIdentityClosure(unittest.TestCase):
    """deploy_lib._darwin_redact_remote_error"""

    def f(self, text, user='fakeuser', host=HOST):
        return deploy_lib._darwin_redact_remote_error(text, user, host)

    def test_login_inside_target_name_yields_the_fixed_fallback(self):
        for text in ['worker failed for target fakeuser-epg',
                     'launcher aq-fakeuser-epg missing',
                     'FAKEUSER-EPG not found',
                     'registry entry fakeuser_epg absent',
                     'no such file: fakeuser-epg.json']:
            with self.subTest(text=text):
                self.assertEqual(self.f(text), FALLBACK)

    def test_fallback_never_echoes_the_unsafe_text(self):
        out = self.f('worker failed for target fakeuser-epg')
        self.assertNotIn('fakeuser', out)
        self.assertNotIn('epg', out)
        self.assertEqual(out, FALLBACK)

    def test_existing_user_at_host_masking_is_preserved(self):
        out = self.f('denied: fakeuser@gateway.example.com')
        self.assertNotIn('fakeuser', out)
        self.assertNotIn(HOST, out)
        self.assertNotEqual(out, FALLBACK, 'masked text must still be shown, not withheld')

    def test_existing_home_path_masking_is_preserved(self):
        out = self.f('cannot read /home/fakeuser/aq-mcp/registry.json')
        self.assertNotIn('fakeuser', out)
        self.assertIn('<path>', out)
        self.assertNotEqual(out, FALLBACK)

    def test_ordinary_clean_message_is_unchanged(self):
        for text in ['registry file is locked', 'permission denied',
                     'tools/list returned no tools']:
            with self.subTest(text=text):
                self.assertEqual(self.f(text), text)

    def test_unrelated_word_containing_a_short_login_is_not_withheld(self):
        out = deploy_lib._darwin_redact_remote_error(
            'devopstools-epg launcher failed during operations', 'ops', HOST)
        self.assertEqual(out, 'devopstools-epg launcher failed during operations')

    def test_short_login_as_a_standalone_token_is_withheld(self):
        self.assertEqual(
            deploy_lib._darwin_redact_remote_error('launcher ops-epg failed', 'ops', HOST),
            FALLBACK)

    def test_malformed_identity_fails_closed(self):
        for user, host in [('', HOST), ('   ', HOST), (None, HOST), (7, HOST),
                           ('fakeuser', ''), ('fakeuser', None),
                           ('f\u00e5keuser', HOST)]:
            with self.subTest(user=user, host=host):
                self.assertEqual(
                    deploy_lib._darwin_redact_remote_error('some clean error', user, host),
                    FALLBACK)

    def test_empty_or_non_str_text_still_fails_closed(self):
        for text in ['', '   ', None, 7, b'x']:
            with self.subTest(text=text):
                self.assertEqual(self.f(text), FALLBACK)

    def test_length_cap_is_preserved(self):
        long_clean = 'registry locked ' * 60
        out = self.f(long_clean)
        self.assertLessEqual(len(out), deploy_lib.DARWIN_REMOTE_ERROR_MAX + 3)
        self.assertTrue(out.endswith('...'))

    def test_non_printable_sanitising_is_preserved(self):
        out = self.f('locked\x07\x00 registry')
        self.assertNotIn('\x07', out)
        self.assertIn('?', out)

    def test_check_runs_on_the_text_after_truncation(self):
        # The login must be caught even when it only appears beyond the length cap,
        # because the check runs on the ACTUAL returned text.
        text = ('x' * (deploy_lib.DARWIN_REMOTE_ERROR_MAX + 50)) + ' fakeuser-epg'
        out = self.f(text)
        self.assertNotIn('fakeuser', out)

    def test_windows_run_path_does_not_use_the_darwin_redactor(self):
        # Off darwin, SSHGateway.run raises the worker error directly: unchanged contract.
        import ast
        with open('deploy_lib.py', encoding='utf-8') as fh:
            src = fh.read()
        run = [n for n in ast.walk(ast.parse(src))
               if isinstance(n, ast.FunctionDef) and n.name == 'run'][0]
        seg = ast.get_source_segment(src, run)
        self.assertIn("_darwin_redact_remote_error", seg)
        self.assertIn("raise DeploymentError(data.get('error','Remote operation failed'))", seg)


# ===================================================================== F-B4b-02
class _Stub(object):
    """Drives the REAL Wizard.summary_text / _darwin_summary_text without Tk."""

    def __init__(self, wizard_mod, sp, is_darwin, prepared=None):
        self._w = wizard_mod
        self._darwin = is_darwin
        self._spec = sp
        self.prepared = plan(sp) if prepared is None else prepared
        self.backend_verification = None

    def spec(self):
        return self._spec

    def summary_text(self):
        return self._w.Wizard.summary_text(self)

    def _darwin_summary_text(self, discovered):
        return self._w.Wizard._darwin_summary_text(self, discovered)


class SummaryIdentityClosure(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        try:
            import wizard
        except Exception as exc:
            raise unittest.SkipTest('wizard import unavailable: %s' % type(exc).__name__)
        cls.w = wizard

    def test_login_inside_target_is_refused_on_macos(self):
        sp = spec(user='fakeuser', target='fakeuser-epg')
        with darwin():
            out = _Stub(self.w, sp, True).summary_text()
        self.assertEqual(out, self.w.DARWIN_SUMMARY_UNAVAILABLE)
        self.assertNotIn('fakeuser', out)

    def test_unrelated_word_is_not_refused(self):
        # login 'ops' must not be refused because of 'operations' / 'devopstools'
        for target in ('operations-epg', 'devopstools-epg'):
            with self.subTest(target=target):
                sp = spec(user='ops', target=target)
                with darwin():
                    out = _Stub(self.w, sp, True).summary_text()
                self.assertNotEqual(out, self.w.DARWIN_SUMMARY_UNAVAILABLE)
                self.assertIn(target, out)

    def test_safe_summary_still_displays_normally(self):
        sp = spec(user='fakeuser', target='demo-epg')
        with darwin():
            out = _Stub(self.w, sp, True).summary_text()
        self.assertIn('PLAIN-LANGUAGE SUMMARY', out)
        self.assertIn('demo-epg', out)
        self.assertNotIn('fakeuser', out)

    def test_waiting_note_still_returned_when_no_plan(self):
        sp = spec()
        st = _Stub(self.w, sp, True)
        st.prepared = None
        with darwin():
            out = st.summary_text()
        self.assertIn('plain-language summary will appear here', out)

    def test_empty_or_malformed_identity_fails_closed(self):
        for user, host in [('', HOST), ('   ', HOST), ('fakeuser', ''),
                           ('f\u00e5keuser', HOST)]:
            with self.subTest(user=user, host=host):
                sp = spec(user=user or 'x', target='demo-epg', host=host or HOST)
                sp['user'] = user
                sp['host'] = host
                with darwin():
                    out = _Stub(self.w, sp, True).summary_text()
                self.assertEqual(out, self.w.DARWIN_SUMMARY_UNAVAILABLE)

    def test_fallback_does_not_disclose_the_unsafe_text(self):
        sp = spec(user='fakeuser', target='fakeuser-epg')
        with darwin():
            out = _Stub(self.w, sp, True).summary_text()
        self.assertNotIn('fakeuser', out)
        self.assertNotIn('fakeuser-epg', out)
        self.assertEqual(out, self.w.DARWIN_SUMMARY_UNAVAILABLE)

    def test_byte_frozen_summary_builder_is_unchanged(self):
        # model.plain_language_summary must NOT be edited: it still renders the target.
        sp = spec(user='fakeuser', target='fakeuser-epg')
        self.assertIn('fakeuser-epg', model.plain_language_summary(sp, plan(sp)))

    def test_windows_summary_behaviour_is_unchanged(self):
        sp = spec(user='fakeuser', target='fakeuser-epg')
        with windows():
            out = _Stub(self.w, sp, False).summary_text()
        self.assertEqual(out, model.plain_language_summary(sp, plan(sp)))
        self.assertIn('fakeuser-epg', out)

    def test_windows_exception_path_unchanged(self):
        sp = spec()
        st = _Stub(self.w, sp, False)
        st.prepared = {'bogus': object()}
        with windows(), mock.patch.object(self.w, 'plain_language_summary',
                                          side_effect=ValueError('boom')):
            out = st.summary_text()
        self.assertTrue(out.startswith('Summary unavailable: '))

    def test_confirmation_dialog_is_unreachable_on_macos(self):
        # deploy_action refuses on darwin BEFORE building its confirmation dialog, so the
        # summary + target can never reach a confirm prompt on macOS.
        class Tripwire(object):
            def __getattr__(self, name):
                def boom(*a, **k):
                    raise AssertionError('messagebox.%s called on darwin deploy_action' % name)
                return boom

        calls = []

        class DeployStub(_Stub):
            def _refuse_g2_ui(self, label):
                calls.append(label)
                return None

        sp = spec(user='fakeuser', target='fakeuser-epg')
        st = DeployStub(self.w, sp, True)
        with darwin(), mock.patch.object(self.w, 'messagebox', Tripwire()):
            self.w.Wizard.deploy_action(st)
        self.assertEqual(calls, ['Deploy approved plan'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
