"""P2 Slice 1 / B4d: closure of F-B4c-03 (cli.py macOS offline 'plan' identity boundary).

F-B4c-03  cli.py::_darwin_remote(), args.operation=='plan': model.plain_language_summary()
          was printed to stderr, optionally written to --plan-file, and the plan dict was
          printed to stdout, all with NO assert_identity_safe() boundary. A standalone
          login embedded in an approved target name (e.g. 'fakeuser-epg') survived into
          the printed summary, exactly as in the already-closed F-B4b-01/F-B4b-02.

FIX: the 'plan' branch now builds the summary with the BYTE-FROZEN model.plain_language_summary
(not modified) and validates the COMPLETE text with model.assert_identity_safe() BEFORE any
output (stderr summary, stdout plan JSON, or --plan-file) is produced. Any failure (unsafe
text, malformed identity, or any other error) refuses with the fixed DARWIN_PLAN_SUMMARY_UNSAFE
message via the SAME p.error() mechanism already used for every other macOS CLI refusal in
this module (argparse .error() -> stderr + SystemExit(2)). No plan file, no plan JSON, no
unredacted summary is ever produced on refusal.

Every darwin test drives the REAL cli.main() with sys.platform patched to 'darwin'; no Mac,
no SSH, no network, no subprocess, no Tk window. All identities are synthetic placeholders.

BEHAVIORAL vs STATIC test count is tracked explicitly in the final suite summary class below.
"""
import contextlib
import io
import json
import os
import socket
import subprocess
import sys
import tempfile
import unittest
from unittest import mock

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import cli
import model
import platform_p2

HOST = 'gateway.example.com'
URL = 'https://abc123.lambda-url.us-west-2.on.aws/mcp'


def darwin():
    return mock.patch.object(sys, 'platform', 'darwin')


def windows():
    return mock.patch.object(sys, 'platform', 'win32')


def spec(user='fakeuser', target='demo-epg', host=HOST, display_name=None):
    sp = {'transport': 'linux-ssh', 'host': host, 'user': user, 'kind': 'lambda',
          'target': target, 'url': URL, 'allow': ['list_things']}
    if display_name is not None:
        sp['display_name'] = display_name
    return sp


def write_manifest(path, sp):
    with open(path, 'w', encoding='utf-8', newline='\n') as f:
        f.write(json.dumps(sp))
    return path


def run_cli(argv):
    """Run cli.main(argv) in-process; mirrors test_cli_import.py's run_cli so results are
    directly comparable. argparse p.error raises SystemExit(2); any other exception is
    surfaced as exit 1 so a test never hangs on an uncaught error."""
    out, err = io.StringIO(), io.StringIO()
    code = None
    with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
        try:
            code = cli.main(argv)
        except SystemExit as e:
            code = e.code if isinstance(e.code, int) else 2
        except Exception as e:
            print('ERROR: ' + str(e), file=sys.stderr)
            code = 1
    return code, out.getvalue(), err.getvalue()


class _NetworkTripwire(object):
    """Fails the test if ANYTHING opens a socket, starts a subprocess, or imports
    paramiko while this context is active. G1a: offline plan must stay fully offline."""

    def __enter__(self):
        self._orig_socket = socket.socket
        self._orig_popen = subprocess.Popen
        self._orig_import = __builtins__['__import__'] if isinstance(__builtins__, dict) \
            else __builtins__.__import__

        def boom_socket(*a, **k):
            raise AssertionError('TRIPWIRE: socket opened during offline plan')

        def boom_popen(*a, **k):
            raise AssertionError('TRIPWIRE: subprocess started during offline plan')

        def guarded_import(name, *a, **k):
            if name == 'paramiko' or name.startswith('paramiko.'):
                raise AssertionError('TRIPWIRE: paramiko imported during offline plan')
            return self._orig_import(name, *a, **k)

        socket.socket = boom_socket
        subprocess.Popen = boom_popen
        if isinstance(__builtins__, dict):
            __builtins__['__import__'] = guarded_import
        else:
            __builtins__.__import__ = guarded_import
        return self

    def __exit__(self, *exc):
        socket.socket = self._orig_socket
        subprocess.Popen = self._orig_popen
        if isinstance(__builtins__, dict):
            __builtins__['__import__'] = self._orig_import
        else:
            __builtins__.__import__ = self._orig_import
        return False


# ===================================================================== behavioral tests
class PlanIdentityClosure(unittest.TestCase):
    """Drives the real cli.main(['plan', ...]) macOS handler. BEHAVIORAL."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.manifest = os.path.join(self.tmp.name, 'manifest.json')

    def tearDown(self):
        self.tmp.cleanup()

    # ---- case 1: login inside target name -> refused, no disclosure -------------
    def test_1_login_in_target_name_refused_without_disclosure(self):
        sp = spec(user='fakeuser', target='fakeuser-epg')
        write_manifest(self.manifest, sp)
        with darwin():
            code, out, err = run_cli(['plan', self.manifest])
        self.assertNotEqual(code, 0)
        self.assertNotIn('fakeuser', out)
        self.assertNotIn('fakeuser', err)
        self.assertIn(cli.DARWIN_PLAN_SUMMARY_UNSAFE, err)

    # ---- case 2: safe content containing a non-identity substring is NOT refused
    def test_2_safe_target_text_not_falsely_refused(self):
        sp = spec(user='ops', target='operations-epg')
        write_manifest(self.manifest, sp)
        with darwin():
            code, out, err = run_cli(['plan', self.manifest])
        self.assertEqual(code, 0, err)
        self.assertNotIn(cli.DARWIN_PLAN_SUMMARY_UNSAFE, err)
        parsed = json.loads(out)
        self.assertEqual(parsed['target'], 'operations-epg')

    # ---- case 3: standalone login via a DIFFERENT summary field (region, not the
    # target-name prefix/suffix form already covered by case 1) ------------------
    def test_3_standalone_login_in_summary_refused(self):
        # target itself is safe; the login instead surfaces as a standalone token via
        # registry_entry.region, which plain_language_summary also interpolates
        # verbatim ('... a new connector target named "{target}" in region {region}.').
        # This proves the boundary catches the login regardless of which field of the
        # prepared result carries it, not only the target-name case already covered.
        sp = spec(user='fakeuser', target='demo-epg')
        write_manifest(self.manifest, sp)
        prepared = {'offline': True, 'gateway': {'host': HOST, 'user': 'fakeuser'},
                    'target': 'demo-epg', 'kind': 'lambda',
                    'registry_entry': {'region': 'fakeuser', 'allow': ['list_things']}}
        with darwin(), mock.patch('cli.ConnectorDeployer') as MockDeployer:
            MockDeployer.return_value.prepare_offline.return_value = prepared
            code, out, err = run_cli(['plan', self.manifest])
        self.assertNotEqual(code, 0)
        self.assertNotIn('fakeuser', out)
        self.assertNotIn('fakeuser', err)

    # ---- case 4: unsafe summary with --plan-file -> NO file created -------------
    def test_4_unsafe_summary_with_plan_file_creates_no_file(self):
        sp = spec(user='fakeuser', target='fakeuser-epg')
        write_manifest(self.manifest, sp)
        plan_file = os.path.join(self.tmp.name, 'plan_out.json')
        with darwin():
            code, out, err = run_cli(['plan', self.manifest, '--plan-file', plan_file])
        self.assertNotEqual(code, 0)
        self.assertFalse(os.path.exists(plan_file))

    # ---- case 5: clean summary with --plan-file -> file IS created --------------
    def test_5_clean_summary_with_plan_file_creates_expected_file(self):
        sp = spec(user='ops', target='operations-epg')
        write_manifest(self.manifest, sp)
        plan_file = os.path.join(self.tmp.name, 'plan_out.json')
        with darwin():
            code, out, err = run_cli(['plan', self.manifest, '--plan-file', plan_file])
        self.assertEqual(code, 0, err)
        self.assertTrue(os.path.exists(plan_file))
        with open(plan_file, encoding='utf-8') as f:
            written = json.load(f)
        self.assertEqual(written['target'], 'operations-epg')

    # ---- case 6: refusal never prints the unsafe summary anywhere ---------------
    def test_6_refusal_prints_summary_to_neither_stream(self):
        sp = spec(user='fakeuser', target='fakeuser-epg')
        write_manifest(self.manifest, sp)
        with darwin():
            code, out, err = run_cli(['plan', self.manifest])
        # the ONLY stderr content must be the fixed refusal (+ argparse usage banner),
        # never the plain-language summary text itself.
        self.assertNotIn('Deploy', out)  # plain_language_summary conventionally starts narrative text
        self.assertNotIn('demo-epg', out)
        self.assertEqual(out, '')  # stdout must be completely empty on refusal

    # ---- case 7: no remote gateway / socket / subprocess / paramiko during plan -
    def test_7_offline_plan_opens_no_network_or_subprocess(self):
        sp = spec(user='fakeuser', target='fakeuser-epg')
        write_manifest(self.manifest, sp)
        with darwin(), _NetworkTripwire():
            code, out, err = run_cli(['plan', self.manifest])
        self.assertNotEqual(code, 0)  # still refused (unsafe), but no tripwire fired

        sp2 = spec(user='ops', target='operations-epg')
        write_manifest(self.manifest, sp2)
        with darwin(), _NetworkTripwire():
            code, out, err = run_cli(['plan', self.manifest])
        self.assertEqual(code, 0, err)  # clean path, still no tripwire fired

    # ---- case 8a: Windows/Linux plan behavior is byte-for-byte unchanged --------
    def test_8_windows_plan_output_unchanged(self):
        sp = spec(user='fakeuser', target='fakeuser-epg')
        write_manifest(self.manifest, sp)
        prepared = {'target': 'fakeuser-epg', 'kind': 'lambda',
                    'gateway': {'host': HOST, 'user': 'fakeuser'},
                    'warnings': [], 'existing_target_count': 0,
                    'potentially_mutating_tools_name_only': [],
                    'execution_plan': [], 'registry_entry': {},
                    'quick_connector': {}, 'backend_identity_sha256': 'x',
                    'expected_registry_sha256': 'y', 'mode': 'new-target',
                    'no_secrets_in_manifest': True, 'tool_count_to_expose': 1,
                    'version': 1}
        with windows(), mock.patch('cli.SSHG') as MockSSHG:
            MockSSHG.return_value = mock.Mock()
            with mock.patch('cli.ConnectorDeployer') as MockDeployer:
                MockDeployer.return_value.prepare.return_value = prepared
                code, out, err = run_cli(['plan', self.manifest])
        self.assertEqual(code, 0, err)
        # Windows/Linux path is UNCHANGED: plain_language_summary(spec, result) is still
        # printed unconditionally with no identity-safety boundary (off-Darwin behavior
        # is untouched by this fix; identity scoping on Windows/Linux is out of P2 scope).
        self.assertIn('fakeuser', err)  # unchanged legacy behavior, proves no regression


# ===================================================================== static tests
class PlanIdentityClosureStatic(unittest.TestCase):
    """Source-level checks that do not execute cli.main(). STATIC."""

    @classmethod
    def setUpClass(cls):
        cls.src = open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                                     'cli.py'), encoding='utf-8').read()

    def test_s1_plain_language_summary_is_not_modified_in_source(self):
        # model.plain_language_summary must stay byte-frozen; cli.py must not redefine it.
        self.assertNotIn('def plain_language_summary', self.src)

    def test_s2_fixed_refusal_never_formats_in_identity_fields(self):
        import inspect, ast
        tree = ast.parse(self.src)
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign) and len(node.targets) == 1 \
                    and isinstance(node.targets[0], ast.Name) \
                    and node.targets[0].id == 'DARWIN_PLAN_SUMMARY_UNSAFE':
                # must be built entirely from string literals, no .format()/%/f-string
                self.assertNotIsInstance(node.value, ast.JoinedStr)
                for n in ast.walk(node.value):
                    self.assertNotIsInstance(n, ast.FormattedValue)

    def test_s3_identity_boundary_precedes_both_outputs_in_source(self):
        # Textual ordering guard: assert_identity_safe must appear BEFORE both the
        # write_new_json(args.plan_file,...) call and the final stdout print, inside
        # the plan branch of _darwin_remote.
        start = self.src.index('def _darwin_remote')
        end = self.src.index('def _darwin_export')
        body = self.src[start:end]
        i_assert = body.index('assert_identity_safe(')
        i_planfile = body.index('write_new_json(args.plan_file,result)')
        i_stdout = body.rindex('print(json.dumps(result,indent=2))')
        self.assertLess(i_assert, i_planfile)
        self.assertLess(i_assert, i_stdout)

    def test_s4_main_function_untouched_by_this_change(self):
        # cli.py::main is the one byte-frozen LEADING_GATE_DEF pin in this file; this
        # B4d change must be confined to _darwin_remote and must not touch main's body.
        import ast
        tree = ast.parse(self.src)
        main_fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'main')
        seg = ast.get_source_segment(self.src, main_fn)
        self.assertNotIn('DARWIN_PLAN_SUMMARY_UNSAFE', seg)
        self.assertNotIn('F-B4c-03', seg)


# ===================================================================== bookkeeping
class SuiteCounts(unittest.TestCase):
    """Not a functional test: records the behavioral/static split for the evidence
    packet so the counts in FINDINGS/MANIFEST are independently re-derivable from the
    test file itself rather than hand-typed."""

    def test_behavioral_vs_static_count(self):
        behavioral = len([n for n in dir(PlanIdentityClosure) if n.startswith('test_')])
        static = len([n for n in dir(PlanIdentityClosureStatic) if n.startswith('test_')])
        self.assertEqual(behavioral, 8)
        self.assertEqual(static, 4)


if __name__ == '__main__':
    unittest.main()
