"""P2 Slice 1 / B4e: macOS FULL-JSON export destination safety (finding C, SEC-B-01).

On macOS quick_reg.write_quick_config(redacted=False) refused Quick-owned folders and
mcp_config.json but WROTE the FULL file (real login/host) inside a git work tree or a
cloud-synced folder. B4e refuses those too (reusing _dest_inside_repo and the single
_SYNCED_PATH_MARKERS list via _path_is_synced), fails closed when the location cannot be
classified, and does all of it BEFORE any file is created. Token (EXPORT FULL), 0600,
create-only, no-overwrite and no-symlink behaviour are unchanged; the redacted export
and Windows/Linux are unchanged.

Drives the REAL write_quick_config and the REAL cli.main(['export', ...]) with
sys.platform patched to 'darwin' (every is_darwin copy is asserted). Synthetic
identities only. No network, SSH, subprocess or Tk.

Class prefixes: C_* = finding C (refusals / fail-closed), K_* = kept behaviour (must also
pass on B4d), P_* = non-darwin parity.
"""
import contextlib
import io
import json
import os
import stat
import sys
import tempfile
import unittest
from unittest import mock

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import capability_gate
import cli
import deploy_lib
import model
import native_gateway
import platform_p2
import quick_reg

USER = 'fakeuser'
HOST = 'fakehost'
TOKEN = 'EXPORT FULL'
SPEC = {'transport': 'linux-ssh', 'host': HOST, 'user': USER, 'kind': 'lambda',
        'target': 'demo-epg', 'url': 'https://abc123.lambda-url.us-west-2.on.aws/mcp',
        'allow': ['list_things']}


def _darwin_copies():
    return {'platform_p2.is_darwin': platform_p2.is_darwin,
            'cli.platform_p2.is_darwin': cli.platform_p2.is_darwin,
            'deploy_lib.platform_p2.is_darwin': deploy_lib.platform_p2.is_darwin,
            'capability_gate.is_darwin': capability_gate.is_darwin,
            'quick_reg._p2_is_darwin': quick_reg._p2_is_darwin,
            'model._p2_is_darwin': model._p2_is_darwin,
            'native_gateway._p2_is_darwin': native_gateway._p2_is_darwin}


@contextlib.contextmanager
def platform_as(name):
    with mock.patch.object(sys, 'platform', name):
        want = (name == 'darwin')
        bad = sorted(k for k, f in _darwin_copies().items() if bool(f()) != want)
        if bad:
            raise AssertionError('platform emulation incomplete for: ' + ', '.join(bad))
        yield


def _snapshot(root):
    """Every entry (files AND dirs) under root, so a refusal that leaves an empty
    file, a temp file or a new directory is detected."""
    out = []
    for base, dirs, files in os.walk(root):
        for n in dirs + files:
            out.append(os.path.relpath(os.path.join(base, n), root))
    return sorted(out)


def _inside_git(path):
    cur = os.path.realpath(path)
    while True:
        if os.path.lexists(os.path.join(cur, '.git')):
            return True
        nxt = os.path.dirname(cur)
        if nxt == cur:
            return False
        cur = nxt


class _Base(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.root = os.path.realpath(self._tmp.name)

    def tearDown(self):
        self._tmp.cleanup()

    def symlink(self, target, link):
        try:
            os.symlink(target, link)
        except (OSError, NotImplementedError, AttributeError):
            self.skipTest('NOT RUN: symlink creation not permitted on this machine')

    def mk(self, *parts):
        p = os.path.join(self.root, *parts)
        os.makedirs(p, exist_ok=True)
        return p

    def full_darwin(self, dest, ack=TOKEN):
        guard = mock.patch.object(quick_reg, '_p2_darwin_export_guard',
                                  wraps=quick_reg._p2_darwin_export_guard)
        with platform_as('darwin'), guard as g:
            try:
                quick_reg.write_quick_config(dict(SPEC), dest, redacted=False, full_ack=ack)
                result = None
            except Exception as exc:  # noqa: BLE001 - classified by the caller
                result = exc
        self.assertTrue(g.called, 'macOS export guard was not reached')
        return result

    def assert_refused(self, dest, exc_type=capability_gate.GateRefused):
        before = _snapshot(self.root)
        exc = self.full_darwin(dest)
        self.assertIsNotNone(exc, 'FULL export was WRITTEN to ' + os.path.relpath(dest, self.root))
        self.assertIsInstance(exc, exc_type)
        self.assertFalse(os.path.lexists(dest))
        self.assertEqual(_snapshot(self.root), before, 'refusal created something')
        msg = str(exc)
        for ident in (USER, HOST):
            self.assertNotIn(ident, msg)
        return exc


# ===================================================================== C: refusals
class C_FullExportDestinationRefused(_Base):

    def test_c1_git_work_tree_directory(self):
        repo = self.mk('repo')
        self.mk('repo', '.git')
        sub = self.mk('repo', 'sub', 'deeper')
        exc = self.assert_refused(os.path.join(sub, 'full.json'))
        self.assertEqual(str(exc), quick_reg.P2_FULL_EXPORT_DEST_REFUSED)
        self.assert_refused(os.path.join(repo, 'full.json'))

    def test_c2_git_worktree_gitlink_file(self):
        wt = self.mk('worktree')
        with open(os.path.join(wt, '.git'), 'w', encoding='utf-8') as f:
            f.write('gitdir: /nonexistent/.git/worktrees/x\n')
        self.assert_refused(os.path.join(wt, 'full.json'))

    def test_c3_known_cloud_synced_folders(self):
        for name in ('Dropbox', 'OneDrive', 'Google Drive', 'GoogleDrive', 'iCloud Drive', 'iCloud'):
            with self.subTest(folder=name):
                d = self.mk(name, 'notes')
                self.assert_refused(os.path.join(d, 'full.json'))

    def test_c4_symlink_alias_into_synced_or_git_resolved(self):
        real_sync = self.mk('Dropbox')
        repo = self.mk('repo2')
        self.mk('repo2', '.git')
        for target, alias in ((real_sync, 'innocent'), (repo, 'innocent2')):
            link = os.path.join(self.root, alias)
            self.symlink(target, link)
            self.assert_refused(os.path.join(link, 'full.json'))

    def test_c5_this_program_folder(self):
        prog = self.mk('program')
        fake_module = os.path.join(prog, 'quick_reg.py')
        with mock.patch.object(quick_reg, '__file__', fake_module):
            self.assert_refused(os.path.join(prog, 'full.json'))


class C_FullExportFailClosed(_Base):

    def test_c6_relative_path_refused(self):
        # Run from inside the temp folder so a (defective) write can only land there.
        here = os.getcwd()
        os.chdir(self.mk('cwd'))
        try:
            exc = self.full_darwin('full_relative.json')
            written = os.path.lexists('full_relative.json')
        finally:
            os.chdir(here)
        self.assertFalse(written, 'relative FULL export destination was written')
        self.assertIsInstance(exc, capability_gate.GateRefused)

    def test_c7_missing_parent_refused_without_mkdir(self):
        self.assert_refused(os.path.join(self.root, 'missing', 'deeper', 'full.json'))
        self.assertFalse(os.path.lexists(os.path.join(self.root, 'missing')))

    def test_c8_parent_is_a_file_refused(self):
        with open(os.path.join(self.root, 'afile'), 'w', encoding='utf-8') as f:
            f.write('x')
        self.assert_refused(os.path.join(self.root, 'afile', 'full.json'))

    def test_c9_symlink_loop_refused(self):
        a, b = os.path.join(self.root, 'loop_a'), os.path.join(self.root, 'loop_b')
        self.symlink(b, a)
        self.symlink(a, b)
        self.assert_refused(os.path.join(a, 'full.json'))

    def test_c10_unreadable_ancestor_refused(self):
        d = self.mk('private', 'out')
        real_lstat = quick_reg.os.lstat

        def lstat(path, *a, **k):
            if os.path.basename(str(path)) == '.git':
                raise PermissionError(13, 'Permission denied (test)', path)
            return real_lstat(path, *a, **k)
        with mock.patch.object(quick_reg.os, 'lstat', side_effect=lstat):
            self.assert_refused(os.path.join(d, 'full.json'))

    def test_c11_realpath_oserror_refused(self):
        d = self.mk('private2')
        with mock.patch.object(quick_reg.os.path, 'realpath', side_effect=OSError('test')):
            self.assert_refused(os.path.join(d, 'full.json'))

    def test_c11b_classifier_fails_closed_on_resolution_error(self):
        # Unit-level (needs the B4e helper; on B4d this is a missing-symbol ERROR, not a
        # detection): any OSError/ValueError while classifying means 'refuse'.
        d = self.mk('private3')
        for exc in (OSError('test'), ValueError('test'), RuntimeError('test')):
            with self.subTest(exc=type(exc).__name__), \
                    mock.patch.object(quick_reg.os, 'stat', side_effect=exc):
                self.assertTrue(quick_reg._p2_full_export_destination_unsafe(os.path.join(d, 'f.json')))
        if not _inside_git(d):
            self.assertFalse(quick_reg._p2_full_export_destination_unsafe(os.path.join(d, 'f.json')))

    def test_c12_odd_values_refused(self):
        for bad in ('', 'a\x00b.json'):
            with self.subTest(bad=repr(bad)):
                exc = self.full_darwin(bad)
                self.assertIsInstance(exc, capability_gate.GateRefused)

    def test_c13_cli_full_export_into_git_tree_refused(self):
        repo = self.mk('clirepo')
        self.mk('clirepo', '.git')
        dest = os.path.join(repo, 'full.json')
        manifest = os.path.join(self.root, 'manifest.json')
        with open(manifest, 'w', encoding='utf-8', newline='\n') as f:
            f.write(json.dumps(SPEC))
        before = _snapshot(self.root)
        out, err = io.StringIO(), io.StringIO()
        code = None
        with platform_as('darwin'), contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
            try:
                code = cli.main(['export', manifest, '--output-file', dest, '--full-export',
                                 '--ack', TOKEN])
            except SystemExit as e:
                code = e.code
        self.assertFalse(os.path.lexists(dest), 'CLI FULL export written into a git tree')
        self.assertEqual(code, 2)
        self.assertEqual(out.getvalue(), '')
        self.assertIn(quick_reg.P2_FULL_EXPORT_DEST_REFUSED, err.getvalue())
        for ident in (USER, HOST):
            self.assertNotIn(ident, err.getvalue())
        self.assertEqual(_snapshot(self.root), before)


# ===================================================================== kept behaviour
class K_KeptBehaviour(_Base):

    def test_k1_safe_private_destination_still_written_0600(self):
        if _inside_git(self.root):
            self.skipTest('ENVIRONMENT: the temp folder itself is inside a git work tree')
        d = self.mk('private_ok')
        dest = os.path.join(d, 'full.json')
        exc = self.full_darwin(dest)
        self.assertIsNone(exc, repr(exc))
        with open(dest, encoding='utf-8') as f:
            body = f.read()
        self.assertEqual(body, quick_reg.config_export_text(dict(SPEC), redacted=False) + '\n')
        self.assertIn(USER + '@' + HOST, body)
        if os.name != 'nt':
            self.assertEqual(stat.S_IMODE(os.stat(dest).st_mode), 0o600)

    def test_k2_token_still_required_before_destination(self):
        d = self.mk('private_tok')
        for bad in (None, '', 'export full', 'EXPORT FULL ', 'COPY FULL'):
            with self.subTest(bad=bad):
                exc = self.full_darwin(os.path.join(d, 'full.json'), ack=bad)
                self.assertIsInstance(exc, capability_gate.GateRefused)
                self.assertFalse(os.path.lexists(os.path.join(d, 'full.json')))

    def test_k3_quick_owned_name_still_refused(self):
        d = self.mk('private_q')
        exc = self.full_darwin(os.path.join(d, 'mcp_config.json'))
        self.assertIsInstance(exc, capability_gate.GateRefused)
        self.assertEqual(str(exc), quick_reg.P2_QUICK_DIR_REFUSED)

    def test_k4_existing_file_never_overwritten(self):
        d = self.mk('private_exist')
        dest = os.path.join(d, 'full.json')
        with open(dest, 'w', encoding='utf-8') as f:
            f.write('ORIGINAL')
        exc = self.full_darwin(dest)
        self.assertIsInstance(exc, FileExistsError)
        with open(dest, encoding='utf-8') as f:
            self.assertEqual(f.read(), 'ORIGINAL')

    def test_k5_dangling_symlink_destination_refused(self):
        if _inside_git(self.root):
            self.skipTest('ENVIRONMENT: the temp folder itself is inside a git work tree')
        d = self.mk('private_link')
        victim = os.path.join(self.root, 'victim.json')
        dest = os.path.join(d, 'full.json')
        self.symlink(victim, dest)
        exc = self.full_darwin(dest)
        self.assertIsNotNone(exc)
        self.assertFalse(os.path.lexists(victim))

    def test_k6_redacted_export_destination_rules_unchanged(self):
        # Scope check: the REDACTED (shareable) variant is NOT newly refused in a git tree.
        repo = self.mk('repo_redacted')
        self.mk('repo_redacted', '.git')
        dest = os.path.join(repo, 'redacted.json')
        with platform_as('darwin'):
            quick_reg.write_quick_config(dict(SPEC), dest, redacted=True)
        with open(dest, encoding='utf-8') as f:
            body = f.read()
        self.assertNotIn(USER, body)
        self.assertNotIn(HOST, body)


# ===================================================================== parity
class P_NonDarwinExportUnchanged(_Base):

    def test_p1_windows_linux_full_export_in_git_tree_unchanged(self):
        repo = self.mk('repo_win')
        self.mk('repo_win', '.git')
        for plat in ('win32', 'linux'):
            with self.subTest(plat=plat):
                dest = os.path.join(repo, plat + '.json')
                with platform_as(plat), \
                        mock.patch.object(quick_reg, '_p2_darwin_export_guard',
                                          side_effect=AssertionError('darwin guard off macOS')):
                    self.assertEqual(quick_reg.write_quick_config(dict(SPEC), dest, redacted=False), dest)
                with open(dest, encoding='utf-8') as f:
                    self.assertEqual(f.read(), quick_reg.config_export_text(dict(SPEC), redacted=False) + '\n')


if __name__ == '__main__':
    unittest.main()
