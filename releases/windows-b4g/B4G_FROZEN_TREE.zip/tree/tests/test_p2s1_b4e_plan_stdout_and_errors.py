"""P2 Slice 1 / B4e: macOS CLI offline plan - stdout redaction (A) and error handling (B).

A  (F-SA-01) On macOS `cli.py plan` printed the identity-bearing plan JSON to stdout
   (user@host, gateway.user/host, /home/<login>/...). B4e prints it REDACTED with the
   existing macOS boundary (model.redact_identity_strict) and re-validates the whole
   text; --plan-file stays the private, unredacted, 0600, create-only artifact.
B  (Q-B / R-01 / R-02 / F-SA-03) The single `except Exception` relabelled every internal
   failure as an identity refusal ('Rename the target ...') and raised from inside the
   except block. B4e: identity failures -> DARWIN_PLAN_SUMMARY_UNSAFE (exit 2, p.error);
   any other failure -> DARWIN_PLAN_INTERNAL_ERROR (exit 1); neither carries exception
   text and neither is chained; SystemExit / KeyboardInterrupt pass through.

Every darwin test drives the REAL cli.main() with sys.platform patched to 'darwin' (all
is_darwin copies read sys.platform at call time; each test asserts every copy really
reports darwin and that the darwin handler ran). Synthetic identities only
(fakeuser / fakehost / /home/fakeuser). No network, SSH, subprocess or Tk.

Class prefixes map to findings: A_* = finding A, B_* = finding B, P_* = Windows/Linux
parity (must pass on B4d too), T_* = tripwire positive control, S_* = static checks.
"""
import ast
import contextlib
import hashlib
import io
import json
import os
import socket
import ssl
import stat
import subprocess
import sys
import tempfile
import unittest
from unittest import mock

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import capability_gate
import cli
import deploy_lib
import model
import native_gateway
import platform_p2
import quick_reg

USER = 'fakeuser'
HOST = 'fakehost'
URL = 'https://abc123.lambda-url.us-west-2.on.aws/mcp'
IDENTITIES = (USER, HOST, USER + '@' + HOST, '/home/' + USER)
CLI_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'cli.py')
MAIN_SEGMENT_SHA256 = 'f779013323db90db8b22e9c3886dfde142508bdda53dd0c5dc51331737f6f648'


# [P2-S1 / B4f] TB4E-01: urllib.request and http.client are on the guarded runner v2.1
# DENY_IMPORTS list, so a module-level import made this whole file fail at discovery under
# the runner. They are now obtained lazily: an already-loaded module is used as is; if the
# runner's import guard (its _DenyFinder on sys.meta_path) is active, the import is NOT
# attempted (an attempt is itself a recorded guard hit) and that tripwire family is reported
# as not applicable (the runner blocks those entry points itself); otherwise (plain
# unittest, e.g. the Linux 3080) the module is imported and the family is exercised.
def _runner_import_guard_active():
    return any(type(f).__name__ == '_DenyFinder' for f in sys.meta_path)


def _optional_net_module(name):
    mod = sys.modules.get(name)
    if mod is not None:
        return mod
    if _runner_import_guard_active():
        return None
    mod = __import__(name)
    for part in name.split('.')[1:]:
        mod = getattr(mod, part)
    return mod


def spec(user=USER, host=HOST, target='demo-epg', allow=('list_things',), display_name=None):
    sp = {'transport': 'linux-ssh', 'host': host, 'user': user, 'kind': 'lambda',
          'target': target, 'url': URL, 'allow': list(allow)}
    if display_name is not None:
        sp['display_name'] = display_name
    return sp


def _darwin_copies():
    """Every is_darwin binding reachable from the CLI plan/export paths (wizard is not
    imported here: it needs Tk and is not on these paths)."""
    return {'platform_p2.is_darwin': platform_p2.is_darwin,
            'cli.platform_p2.is_darwin': cli.platform_p2.is_darwin,
            'deploy_lib.platform_p2.is_darwin': deploy_lib.platform_p2.is_darwin,
            'capability_gate.is_darwin': capability_gate.is_darwin,
            'quick_reg._p2_is_darwin': quick_reg._p2_is_darwin,
            'model._p2_is_darwin': model._p2_is_darwin,
            'native_gateway._p2_is_darwin': native_gateway._p2_is_darwin}


@contextlib.contextmanager
def platform_as(name):
    with mock.patch.object(sys, 'platform', name):
        want = (name == 'darwin')
        got = dict((k, bool(f())) for k, f in _darwin_copies().items())
        bad = [k for k, v in got.items() if v != want]
        if bad:
            raise AssertionError('platform emulation incomplete for: ' + ', '.join(sorted(bad)))
        yield


class Tripwire(object):
    """Records and refuses network / DNS / TLS / HTTP / process / paramiko activity."""

    def __init__(self):
        self.hits = []

    def _trip(self, what):
        def f(*a, **k):
            self.hits.append(what)
            raise AssertionError('TRIPWIRE: ' + what)
        return f

    def __enter__(self):
        trip = self._trip
        hits = self.hits

        class _ParamikoBomb(object):
            def __getattr__(self, name):
                hits.append('paramiko.' + name)
                raise AssertionError('TRIPWIRE: paramiko used')

        targets = [(socket, 'socket'), (socket, 'create_connection'), (socket, 'getaddrinfo'),
                   (socket, 'gethostbyname'), (socket, 'gethostbyname_ex'),
                   (ssl, 'create_default_context'), (ssl.SSLContext, 'wrap_socket')]
        self.not_applicable = []
        urlreq = _optional_net_module('urllib.request')
        if urlreq is not None:
            targets.append((urlreq, 'urlopen'))
        else:
            self.not_applicable.append('urllib.request')
        httpc = _optional_net_module('http.client')
        if httpc is not None:
            targets += [(httpc.HTTPConnection, 'connect'), (httpc.HTTPSConnection, 'connect')]
        else:
            self.not_applicable.append('http.client')
        for name in ('Popen', 'run', 'call', 'check_call', 'check_output', 'getoutput',
                     'getstatusoutput'):
            targets.append((subprocess, name))
        for name in ('system', 'popen', 'execv', 'execve', 'execvp', 'execvpe', 'execl',
                     'execlp', 'spawnv', 'spawnvp', 'spawnl', 'posix_spawn', 'posix_spawnp',
                     'fork', 'forkpty', 'startfile'):
            if hasattr(os, name):
                targets.append((os, name))
        self._patches = [mock.patch.object(obj, name, trip('%s.%s' % (getattr(obj, '__name__', obj), name)))
                         for obj, name in targets]
        self._patches.append(mock.patch.dict(sys.modules, {'paramiko': _ParamikoBomb()}))
        for p in self._patches:
            p.start()
        return self

    def __exit__(self, *exc):
        for p in reversed(self._patches):
            p.stop()
        return False


def run_cli(argv):
    """cli.main(argv) in-process -> (code, stdout, stderr, raised SystemExit or None)."""
    out, err = io.StringIO(), io.StringIO()
    code, sysexit = None, None
    with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
        try:
            code = cli.main(argv)
        except SystemExit as e:
            sysexit = e
            code = e.code if isinstance(e.code, int) else (0 if e.code is None else 2)
        except Exception as e:  # mirrors __main__: 'ERROR: ' + str(e), exit 1
            print('ERROR: ' + str(e), file=sys.stderr)
            code = 1
    return code, out.getvalue(), err.getvalue(), sysexit


def _shape(obj):
    """Test-local JSON structure: dict keys, list lengths, value types."""
    if isinstance(obj, dict):
        return ('dict', tuple(sorted((k, _shape(v)) for k, v in obj.items())))
    if isinstance(obj, list):
        return ('list', tuple(_shape(v) for v in obj))
    return type(obj).__name__


def _identity_free(testcase, text, where):
    low = text.lower()
    for ident in IDENTITIES:
        testcase.assertNotIn(ident.lower(), low, '%s leaks %r' % (where, ident))


class _PlanBase(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.tmp = self._tmp.name
        self.manifest = os.path.join(self.tmp, 'manifest.json')
        self.plan_file = os.path.join(self.tmp, 'plan_out.json')

    def tearDown(self):
        self._tmp.cleanup()

    def write_manifest(self, sp):
        with open(self.manifest, 'w', encoding='utf-8', newline='\n') as f:
            f.write(json.dumps(sp))

    def listing(self):
        return sorted(n for n in os.listdir(self.tmp) if n != 'manifest.json')

    def run_darwin_plan(self, sp, plan_file=True, extra=None):
        self.write_manifest(sp)
        argv = ['plan', self.manifest] + (['--plan-file', self.plan_file] if plan_file else [])
        argv += extra or []
        spy = mock.patch.object(cli, '_darwin_remote', wraps=cli._darwin_remote)
        with platform_as('darwin'), Tripwire() as tw, spy as remote:
            res = run_cli(argv)
        self.assertEqual(tw.hits, [], 'tripwire fired')
        self.assertTrue(remote.called, 'macOS _darwin_remote branch was not taken')
        return res

    def expected_plan(self, sp):
        with platform_as('darwin'):
            return deploy_lib.ConnectorDeployer(None).prepare_offline(sp)


# ===================================================================== A: stdout
class A_PlanStdoutRedaction(_PlanBase):

    def test_a1_clean_plan_stdout_and_stderr_carry_no_identity(self):
        sp = spec()
        code, out, err, _ = self.run_darwin_plan(sp)
        self.assertEqual(code, 0, err)
        # non-vacuity: both streams really carry the plan output
        self.assertIn(model.plain_language_summary(sp, self.expected_plan(sp)), err)
        self.assertIn('"backend_identity_sha256"', out)
        _identity_free(self, out, 'stdout')
        _identity_free(self, err, 'stderr')

    def test_a2_stdout_keeps_plan_schema_with_existing_placeholders(self):
        sp = spec()
        code, out, err, _ = self.run_darwin_plan(sp)
        self.assertEqual(code, 0, err)
        shown = json.loads(out)
        full = self.expected_plan(sp)
        self.assertEqual(_shape(shown), _shape(json.loads(json.dumps(full))))
        self.assertEqual(sorted(shown), sorted(full))
        self.assertEqual(shown['mode'], 'offline-plan-only')
        self.assertIs(shown['offline'], True)
        self.assertEqual(shown['gateway'], {'host': model.REDACTED_HOST, 'user': model.REDACTED_USER})
        args = shown['quick_connector']['arguments']
        self.assertEqual(args[2], model.REDACTED_USER + '@' + model.REDACTED_HOST)
        self.assertEqual(args[3], '/home/' + model.REDACTED_USER + '/aq-mcp/aq-run.sh')
        # Only identity values differ: redact_identity applied to the full text gives stdout.
        self.assertEqual(out, model.redact_identity(json.dumps(full, indent=2), USER, HOST) + '\n')

    def test_a3_private_plan_file_keeps_full_unredacted_plan_0600(self):
        sp = spec()
        code, out, err, _ = self.run_darwin_plan(sp)
        self.assertEqual(code, 0, err)
        self.assertTrue(os.path.isfile(self.plan_file))
        with open(self.plan_file, 'rb') as f:
            data = f.read()
        # Byte-identical to what B4d wrote: secure_write_json(result) = sorted, indent 2, LF.
        want = (json.dumps(self.expected_plan(sp), indent=2, sort_keys=True) + '\n').encode('utf-8')
        self.assertEqual(data, want)
        text = data.decode('utf-8')
        self.assertIn(USER + '@' + HOST, text)
        self.assertIn('/home/' + USER + '/aq-mcp', text)
        if os.name != 'nt':
            self.assertEqual(stat.S_IMODE(os.stat(self.plan_file).st_mode), 0o600)

    def test_a4_identity_only_in_plan_json_is_refused_and_nothing_produced(self):
        # display_name is not in the summary but IS in plan JSON (quick_connector.name);
        # '<login>-conn' survives redact_identity, so the stdout check must refuse.
        for sp in (spec(display_name=USER + '-conn'), spec(allow=('list_things', USER + '_tool'))):
            with self.subTest(sp=sp):
                if os.path.exists(self.plan_file):
                    os.remove(self.plan_file)
                before = self.listing()
                code, out, err, _ = self.run_darwin_plan(sp)
                self.assertNotEqual(code, 0)
                self.assertEqual(out, '')
                _identity_free(self, err, 'stderr')
                self.assertFalse(os.path.exists(self.plan_file))
                self.assertEqual(self.listing(), before)
                self.assertEqual(code, 2)
                self.assertIn(cli.DARWIN_PLAN_SUMMARY_UNSAFE, err)

    def test_a5_summary_refusal_produces_nothing_anywhere(self):
        for target in (USER + '-epg', HOST + '-epg'):
            with self.subTest(target=target):
                before = self.listing()
                code, out, err, _ = self.run_darwin_plan(spec(target=target))
                self.assertEqual(code, 2)
                self.assertEqual(out, '')
                _identity_free(self, err, 'stderr')
                sp = spec(target=target)
                first = model.plain_language_summary(sp, self.expected_plan(sp)).splitlines()[0]
                self.assertNotIn(first, err)
                self.assertIn(cli.DARWIN_PLAN_SUMMARY_UNSAFE, err)
                self.assertFalse(os.path.exists(self.plan_file))
                self.assertEqual(self.listing(), before)

    def test_a6_login_that_would_rewrite_plan_keys_fails_closed(self):
        # login 'user' equals a plan JSON key; redaction would change the schema ->
        # refuse rather than print a plan with altered keys.
        code, out, err, _ = self.run_darwin_plan(spec(user='user'))
        self.assertEqual(code, 2, err)
        self.assertEqual(out, '')
        self.assertFalse(os.path.exists(self.plan_file))
        self.assertIn(cli.DARWIN_PLAN_SUMMARY_UNSAFE, err)

    def test_a7_existing_plan_file_not_overwritten_and_streams_empty(self):
        with open(self.plan_file, 'wb') as f:
            f.write(b'{"pre-existing": true}\n')
        with open(self.plan_file, 'rb') as f:
            original = f.read()
        code, out, err, _ = self.run_darwin_plan(spec())
        self.assertNotEqual(code, 0)
        self.assertEqual(out, '')
        _identity_free(self, err, 'stderr')
        with open(self.plan_file, 'rb') as f:
            self.assertEqual(f.read(), original)

    def test_a8_clean_plan_without_plan_file_writes_nothing(self):
        before = self.listing()
        code, out, err, _ = self.run_darwin_plan(spec(), plan_file=False)
        self.assertEqual(code, 0, err)
        _identity_free(self, out, 'stdout')
        _identity_free(self, err, 'stderr')
        self.assertEqual(self.listing(), before)

    def test_a9_ops_operations_not_falsely_refused(self):
        code, out, err, _ = self.run_darwin_plan(spec(user='ops', target='operations-epg'))
        self.assertEqual(code, 0, err)
        self.assertEqual(json.loads(out)['target'], 'operations-epg')


# ===================================================================== B: errors
class B_PlanErrorHandling(_PlanBase):

    LEAKY = 'boom ' + USER + '@' + HOST + ' /home/' + USER

    def _assert_internal_refusal(self, code, out, err, sysexit):
        # Genuine checks first (meaningful on B4d too): not reported as an identity
        # problem, no exception text, nothing produced.
        self.assertNotIn(cli.DARWIN_PLAN_SUMMARY_UNSAFE, err)
        self.assertNotIn('Rename the target', err)
        for leak in ('boom', 'RuntimeError', 'ImportError', 'cannot import', 'Traceback'):
            self.assertNotIn(leak, err)
        _identity_free(self, err, 'stderr')
        self.assertEqual(out, '')
        self.assertFalse(os.path.exists(self.plan_file))
        self.assertEqual(err, 'ERROR: ' + cli.DARWIN_PLAN_INTERNAL_ERROR + '\n')
        self.assertEqual(code, cli.DARWIN_PLAN_INTERNAL_EXIT)
        self.assertEqual(code, 1)
        self.assertIsNotNone(sysexit)
        self.assertIsNone(sysexit.__context__)
        self.assertIsNone(sysexit.__cause__)

    def test_b1_unrelated_internal_error_gets_separate_sanitized_message(self):
        with mock.patch.object(cli, 'plain_language_summary', side_effect=RuntimeError(self.LEAKY)):
            res = self.run_darwin_plan(spec())
        self._assert_internal_refusal(*res)

    def test_b2_internal_error_in_stdout_redaction_step(self):
        with mock.patch.object(cli, 'json', wraps=json) as j:
            j.dumps.side_effect = TypeError(self.LEAKY)
            res = self.run_darwin_plan(spec())
        self._assert_internal_refusal(*res)

    def test_b3_missing_spec_identity_import_is_internal_error(self):
        saved = quick_reg._spec_identity
        del quick_reg._spec_identity
        try:
            res = self.run_darwin_plan(spec())
        finally:
            quick_reg._spec_identity = saved
        self._assert_internal_refusal(*res)

    def test_b4_identity_refusal_exit_2_unchained(self):
        code, out, err, sysexit = self.run_darwin_plan(spec(target=USER + '-epg'))
        self.assertEqual(code, 2)
        self.assertEqual(out, '')
        self.assertIn(cli.DARWIN_PLAN_SUMMARY_UNSAFE, err)
        self.assertIsNotNone(sysexit)
        self.assertIsNone(sysexit.__context__)
        self.assertIsNone(sysexit.__cause__)

    def test_b5_systemexit_passes_through_untouched(self):
        with mock.patch.object(cli, 'plain_language_summary', side_effect=SystemExit(7)):
            code, out, err, _ = self.run_darwin_plan(spec())
        self.assertEqual(code, 7)
        self.assertEqual(out, '')
        self.assertEqual(err, '')
        self.assertFalse(os.path.exists(self.plan_file))

    def test_b6_keyboardinterrupt_passes_through_untouched(self):
        self.write_manifest(spec())
        out, err = io.StringIO(), io.StringIO()
        with platform_as('darwin'), \
                mock.patch.object(cli, 'plain_language_summary', side_effect=KeyboardInterrupt), \
                contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
            with self.assertRaises(KeyboardInterrupt):
                cli.main(['plan', self.manifest, '--plan-file', self.plan_file])
        self.assertEqual(out.getvalue(), '')
        self.assertEqual(err.getvalue(), '')
        self.assertFalse(os.path.exists(self.plan_file))

    def test_b7_identity_message_does_not_blame_only_the_target(self):
        # STATIC (text): the refusal can be caused by host/tool/URL/empty identity.
        self.assertNotIn('Rename the target', cli.DARWIN_PLAN_SUMMARY_UNSAFE)
        self.assertNotEqual(cli.DARWIN_PLAN_SUMMARY_UNSAFE, cli.DARWIN_PLAN_INTERNAL_ERROR)
        self.assertNotIn('target name', cli.DARWIN_PLAN_INTERNAL_ERROR)


# ===================================================================== parity
class P_NonDarwinPlanUnchanged(_PlanBase):
    """Windows/Linux plan output must equal the B4d main() behaviour byte for byte:
    stderr = summary, stdout = unredacted JSON, plan file = secure_write_json."""

    def test_p1_windows_and_linux_plan_bytes(self):
        sp = spec()
        prepared = model.plan(sp, '0' * 64)
        prepared['gateway'] = {'host': HOST, 'user': USER}
        prepared['existing_target_count'] = 0
        for plat in ('win32', 'linux'):
            with self.subTest(plat=plat):
                if os.path.exists(self.plan_file):
                    os.remove(self.plan_file)
                self.write_manifest(sp)
                with platform_as(plat), mock.patch.object(cli, 'SSHG'), \
                        mock.patch.object(cli, 'ConnectorDeployer') as D, \
                        mock.patch.object(cli, '_darwin_remote', side_effect=AssertionError('darwin')):
                    D.return_value.prepare.return_value = json.loads(json.dumps(prepared))
                    code, out, err, _ = run_cli(['plan', self.manifest, '--plan-file', self.plan_file])
                self.assertEqual(code, 0, err)
                self.assertEqual(out, json.dumps(prepared, indent=2) + '\n')
                self.assertEqual(err, model.plain_language_summary(sp, prepared) + '\n')
                with open(self.plan_file, 'rb') as f:
                    self.assertEqual(f.read(), (json.dumps(prepared, indent=2, sort_keys=True) + '\n').encode('utf-8'))
                self.assertIn(USER + '@' + HOST, out)  # legacy behaviour retained off macOS


# ===================================================================== tripwire control
class T_TripwirePositiveControl(unittest.TestCase):

    def test_t1_every_tripwire_family_fires(self):
        calls = [lambda: socket.socket(), lambda: socket.create_connection(('127.0.0.1', 9)),
                 lambda: socket.getaddrinfo('localhost', 22), lambda: socket.gethostbyname('localhost'),
                 lambda: ssl.create_default_context(),
                 lambda: subprocess.Popen(['true']), lambda: subprocess.run(['true']),
                 lambda: os.system('true'), lambda: sys.modules['paramiko'].SSHClient]
        with Tripwire() as tw:
            for call in calls:
                with self.assertRaises(AssertionError):
                    call()
        self.assertEqual(len(tw.hits), len(calls), tw.hits)

    def test_t1b_http_and_urllib_tripwire_families_fire(self):
        # [P2-S1 / B4f] TB4E-01: separate from t1 so a not-applicable family can never hide
        # the others.
        urlreq = _optional_net_module('urllib.request')
        httpc = _optional_net_module('http.client')
        if urlreq is None or httpc is None:
            self.skipTest('NOT APPLICABLE under the guarded runner: urllib.request/http.client '
                          'imports are refused by its import guard, which blocks them itself')
        with Tripwire() as tw:
            self.assertEqual(tw.not_applicable, [])
            with self.assertRaises(AssertionError):
                urlreq.urlopen('http://127.0.0.1:9/')
            with self.assertRaises(AssertionError):
                httpc.HTTPConnection('127.0.0.1', 9).connect()
        self.assertEqual(len(tw.hits), 2, tw.hits)


# ===================================================================== static
class S_StaticPins(unittest.TestCase):
    """Source-level checks for properties behaviour cannot show (STATIC)."""

    @classmethod
    def setUpClass(cls):
        with open(CLI_PATH, encoding='utf-8') as f:
            cls.src = f.read()
        cls.tree = ast.parse(cls.src)

    def _const(self, name):
        nodes = [n for n in self.tree.body if isinstance(n, ast.Assign) and len(n.targets) == 1
                 and isinstance(n.targets[0], ast.Name) and n.targets[0].id == name]
        self.assertEqual(len(nodes), 1, name + ' must be assigned exactly once')
        return nodes[0].value

    def test_s1_both_refusal_texts_are_plain_literals(self):
        for name in ('DARWIN_PLAN_SUMMARY_UNSAFE', 'DARWIN_PLAN_INTERNAL_ERROR'):
            node = self._const(name)
            self.assertIsInstance(node, ast.Constant, name)
            self.assertIsInstance(node.value, str, name)

    def test_s2_main_segment_byte_identical_to_b4d(self):
        fn = next(n for n in self.tree.body if isinstance(n, ast.FunctionDef) and n.name == 'main')
        seg = ast.get_source_segment(self.src, fn)
        self.assertEqual(hashlib.sha256(seg.encode('utf-8')).hexdigest(), MAIN_SEGMENT_SHA256)

    def test_s3_no_raise_inside_plan_except_handlers(self):
        fn = next(n for n in self.tree.body if isinstance(n, ast.FunctionDef) and n.name == '_darwin_remote')
        handlers = [h for n in ast.walk(fn) if isinstance(n, ast.Try) for h in n.handlers]
        self.assertTrue(handlers)
        for h in handlers:
            if h.type is None or ast.unparse(h.type) not in ('RedactionError', 'Exception'):
                continue
            for n in ast.walk(h):
                self.assertNotIsInstance(n, ast.Raise)
                if isinstance(n, ast.Call):
                    self.assertNotIn(ast.unparse(n.func), ('p.error', 'p.exit'))
            self.assertIsNone(h.name, 'exception object must not be bound/used')


if __name__ == '__main__':
    unittest.main()
