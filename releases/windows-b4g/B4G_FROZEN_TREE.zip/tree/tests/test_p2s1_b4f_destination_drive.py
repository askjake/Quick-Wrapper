"""P2 Slice 1 / B4f: macOS FULL-JSON export destination - Google Drive, kernel-order
resolution, the designated private export folder (M2) and the '~' check/write mismatch.

F1 (SD-01/SD-02) Google Drive for desktop locations are refused:
   .../Library/CloudStorage/GoogleDrive[-<account>]/... and /Volumes/GoogleDrive[-<id>]/...
F2 (SD-03/S-01) every rule also runs on dirname(realpath(path)) (symlink-then-'..').
F3 (user decision M2) when Google Drive for desktop is detected by local evidence, a FULL
   file is written only directly inside ~/.aq_mcp_wizard/private_exports.
F4 (S-02) a path that is not absolute AS GIVEN ('~/...') is refused.

Real temp filesystems and real symlinks; the REAL write_quick_config / cli.main with
sys.platform patched to 'darwin' (every is_darwin copy asserted, guard spy asserted).
The Drive-detection inputs (home, app path, /Volumes) are pointed at fixtures in every
test, so the result does not depend on the machine running the tests. Synthetic
identities only. No network, SSH, subprocess or Tk; a tripwire refuses all of them.

Class prefixes: F1_/F2_/F3_/F4_ = the B4f finding, K_ = kept behaviour (must also pass on
B4e), P_ = non-darwin parity, T_ = tripwire positive controls, D_ = detection.
"""
import contextlib
import io
import json
import os
import socket
import sqlite3
import stat
import sys
import tempfile
import unittest
from unittest import mock

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import capability_gate
import cli
import deploy_lib
import model
import native_gateway
import platform_p2
import quick_reg

USER = 'fakeuser'
HOST = 'fakehost'
ACCOUNT = 'fakeuser@example.com'
TOKEN = 'EXPORT FULL'
SPEC = {'transport': 'linux-ssh', 'host': HOST, 'user': USER, 'kind': 'lambda',
        'target': 'demo-epg', 'url': 'https://abc123.lambda-url.us-west-2.on.aws/mcp',
        'allow': ['list_things']}
PRIVATE_PARTS = ('.aq_mcp_wizard', 'private_exports')
# Network / process modules whose NEW import during a guarded call is reported.
WATCHED_IMPORTS = ('ssl', '_ssl', 'http.client', 'urllib.request', 'ftplib', 'smtplib', 'imaplib',
                   'poplib', 'xmlrpc.client', 'socketserver', 'asyncio', 'multiprocessing',
                   'ctypes', 'webbrowser', 'paramiko', 'subprocess', 'requests', 'urllib3')
POSIX_OWNER = hasattr(os, 'getuid') and os.name != 'nt'


def _darwin_copies():
    return {'platform_p2.is_darwin': platform_p2.is_darwin,
            'cli.platform_p2.is_darwin': cli.platform_p2.is_darwin,
            'deploy_lib.platform_p2.is_darwin': deploy_lib.platform_p2.is_darwin,
            'capability_gate.is_darwin': capability_gate.is_darwin,
            'quick_reg._p2_is_darwin': quick_reg._p2_is_darwin,
            'model._p2_is_darwin': model._p2_is_darwin,
            'native_gateway._p2_is_darwin': native_gateway._p2_is_darwin}


@contextlib.contextmanager
def platform_as(name):
    with mock.patch.object(sys, 'platform', name):
        want = (name == 'darwin')
        bad = sorted(k for k, f in _darwin_copies().items() if bool(f()) != want)
        if bad:
            raise AssertionError('platform emulation incomplete for: ' + ', '.join(bad))
        yield


class Tripwire(object):
    """Refuses and records network / DNS (incl. reverse lookups) / TLS / HTTP / process /
    paramiko activity. Modules that are not loaded are NOT imported here (ImportWatch
    reports a new import instead), so nothing on the runner's deny list is touched."""

    def __init__(self):
        self.hits = []
        self.targets = []

    def _trip(self, what):
        def f(*a, **k):
            self.hits.append(what)
            raise AssertionError('TRIPWIRE: ' + what)
        return f

    def __enter__(self):
        hits = self.hits

        class _ParamikoBomb(object):
            def __getattr__(self, name):
                hits.append('paramiko.' + name)
                raise AssertionError('TRIPWIRE: paramiko used')

        t = []
        for n in ('socket', 'create_connection', 'create_server', 'socketpair', 'getaddrinfo',
                  'gethostbyname', 'gethostbyname_ex', 'gethostbyaddr', 'getnameinfo', 'getfqdn'):
            if hasattr(socket, n):
                t.append((socket, n, 'socket.' + n))
        low = sys.modules.get('_socket')
        if low is not None:
            for n in ('getaddrinfo', 'gethostbyname', 'gethostbyname_ex', 'gethostbyaddr',
                      'getnameinfo'):
                if hasattr(low, n):
                    t.append((low, n, '_socket.' + n))
        ssl_m = sys.modules.get('ssl')
        if ssl_m is not None:
            t += [(ssl_m, 'create_default_context', 'ssl.create_default_context'),
                  (ssl_m.SSLContext, 'wrap_socket', 'ssl.SSLContext.wrap_socket')]
        ur = sys.modules.get('urllib.request')
        if ur is not None:
            t.append((ur, 'urlopen', 'urllib.request.urlopen'))
        hc = sys.modules.get('http.client')
        if hc is not None:
            t += [(hc.HTTPConnection, 'connect', 'http.client.HTTPConnection.connect'),
                  (hc.HTTPSConnection, 'connect', 'http.client.HTTPSConnection.connect')]
        sp = sys.modules.get('subprocess')
        if sp is not None:
            for n in ('Popen', 'run', 'call', 'check_call', 'check_output', 'getoutput',
                      'getstatusoutput'):
                t.append((sp, n, 'subprocess.' + n))
        for n in ('system', 'popen', 'execv', 'execve', 'execvp', 'execvpe', 'execl', 'execlp',
                  'spawnv', 'spawnvp', 'spawnl', 'posix_spawn', 'posix_spawnp', 'fork', 'forkpty',
                  'startfile'):
            if hasattr(os, n):
                t.append((os, n, 'os.' + n))
        self.targets = t
        self._patches = [mock.patch.object(o, n, self._trip(lab)) for o, n, lab in t]
        self._patches.append(mock.patch.dict(sys.modules, {'paramiko': _ParamikoBomb()}))
        for p in self._patches:
            p.start()
        return self

    def __exit__(self, *exc):
        for p in reversed(self._patches):
            p.stop()
        return False


class ImportWatch(object):
    """Records watched modules that appear in sys.modules during the block (an import-only
    side effect that no call tripwire can see)."""

    def __init__(self, watched=WATCHED_IMPORTS):
        self.watched = tuple(watched)
        self.new = []

    def __enter__(self):
        self._before = set(sys.modules)
        return self

    def __exit__(self, *exc):
        after = set(sys.modules)
        self.new = sorted(m for m in after - self._before
                          if any(m == w or m.startswith(w + '.') for w in self.watched))
        return False


def _snapshot(root):
    out = []
    for base, dirs, files in os.walk(root):
        for n in dirs + files:
            out.append(os.path.relpath(os.path.join(base, n), root))
    return sorted(out)


class _Base(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.root = os.path.realpath(self._tmp.name)
        # Drive-detection fixtures: an empty fake Mac (nothing detected) by default.
        self.mac = self.mk('mac')
        self.home = self.mk('mac', 'Users', USER)
        self.drive_app = os.path.join(self.mac, 'Applications', 'Google Drive.app')
        self.volumes = os.path.join(self.mac, 'Volumes')

    def tearDown(self):
        for base, dirs, files in os.walk(self.root):
            for n in dirs:
                p = os.path.join(base, n)
                if not os.path.islink(p):
                    try:
                        os.chmod(p, 0o700)
                    except OSError:
                        pass
        self._tmp.cleanup()

    def mk(self, *parts):
        p = os.path.join(self.root, *parts)
        os.makedirs(p, exist_ok=True)
        return p

    def symlink(self, target, link):
        try:
            os.symlink(target, link)
        except (OSError, NotImplementedError, AttributeError):
            self.skipTest('NOT RUN: symlink creation not permitted on this machine')

    @contextlib.contextmanager
    def drive_env(self):
        """Point detection at the fixture Mac. create=True so the B4e tree (which has no
        detection) can run the F1/F2/F4 tests unchanged for the defect proof."""
        with mock.patch.object(quick_reg, '_p2_home', lambda: self.home, create=True), \
                mock.patch.object(quick_reg, '_P2_DRIVE_APP_PATHS', (self.drive_app,), create=True), \
                mock.patch.object(quick_reg, '_P2_VOLUMES_DIR', self.volumes, create=True):
            yield

    def detect_drive(self):
        """Make Drive for desktop 'installed' on the fixture Mac (DriveFS support folder)."""
        self.mk('mac', 'Users', USER, 'Library', 'Application Support', 'Google', 'DriveFS')

    def environment_classifies_root_unsafe(self):
        with self.drive_env():
            return quick_reg._p2_full_export_destination_unsafe(os.path.join(self.root, 'probe.json'))

    def need_safe_root(self):
        if self.environment_classifies_root_unsafe():
            self.skipTest('ENVIRONMENT: the temp folder itself is classified unsafe (inside a git '
                          'work tree, a synced-named folder or the program folder); move TMPDIR')

    def full_darwin(self, dest, ack=TOKEN):
        guard = mock.patch.object(quick_reg, '_p2_darwin_export_guard',
                                  wraps=quick_reg._p2_darwin_export_guard)
        with platform_as('darwin'), self.drive_env(), ImportWatch() as iw, Tripwire() as tw, \
                guard as g:
            try:
                quick_reg.write_quick_config(dict(SPEC), dest, redacted=False, full_ack=ack)
                result = None
            except Exception as exc:  # noqa: BLE001 - classified by the caller
                result = exc
        self.assertTrue(g.called, 'macOS export guard was not reached')
        self.assertEqual(tw.hits, [], 'tripwire fired')
        self.assertEqual(iw.new, [], 'network/process module imported')
        return result

    def assert_refused(self, dest, message=None, exc_type=capability_gate.GateRefused):
        before = _snapshot(self.root)
        exc = self.full_darwin(dest)
        self.assertIsNotNone(exc, 'FULL export was WRITTEN to ' + os.path.relpath(dest, self.root))
        self.assertIsInstance(exc, exc_type)
        self.assertFalse(os.path.lexists(dest))
        self.assertEqual(_snapshot(self.root), before, 'refusal created something')
        msg = str(exc)
        for ident in (USER, HOST, self.root):
            self.assertNotIn(ident, msg)
        if message is not None:
            self.assertEqual(msg, message)
        return exc

    def assert_written(self, dest):
        exc = self.full_darwin(dest)
        self.assertIsNone(exc, repr(exc))
        with open(dest, encoding='utf-8') as f:
            self.assertEqual(f.read(), quick_reg.config_export_text(dict(SPEC), redacted=False) + '\n')
        if os.name != 'nt':
            self.assertEqual(stat.S_IMODE(os.stat(dest).st_mode), 0o600)

    def drive_root(self, *more):
        return self.mk('Users', USER, 'Library', 'CloudStorage', 'GoogleDrive-' + ACCOUNT, *more)

    def dest_refused_message(self):
        return quick_reg.P2_FULL_EXPORT_DEST_REFUSED


# ===================================================================== F1: Google Drive
class F1_GoogleDriveLocationsRefused(_Base):

    def test_f1a_file_provider_roots_refused(self):
        for sub in ((), ('My Drive',), ('My Drive', 'sub'), ('Shared drives', 'TeamX'),
                    ('Other computers',)):
            with self.subTest(sub=sub):
                d = self.drive_root(*sub)
                self.assert_refused(os.path.join(d, 'x.json'), self.dest_refused_message())

    def test_f1b_case_and_suffix_variants_refused(self):
        for name in ('GOOGLEDRIVE-FAKEUSER@EXAMPLE.COM', 'googledrive', 'GoogleDrive-1234'):
            with self.subTest(name=name):
                d = self.mk('V' + str(len(name)), 'library', 'CLOUDSTORAGE', name, 'My Drive')
                self.assert_refused(os.path.join(d, 'x.json'), self.dest_refused_message())

    def test_f1c_account_alias_and_innocent_symlink_refused(self):
        target = self.drive_root('My Drive', 'sub')
        for alias in (ACCOUNT + ' - Google Drive', 'innocent'):
            with self.subTest(alias=alias):
                link = os.path.join(self.root, 'Users', USER, alias)
                self.symlink(target, link)
                self.assert_refused(os.path.join(link, 'x.json'), self.dest_refused_message())

    def test_f1d_dotdot_into_drive_refused(self):
        self.drive_root('My Drive')
        self.mk('Users', USER, 'private')
        dest = os.path.join(self.root, 'Users', USER, 'private', '..', 'Library', 'CloudStorage',
                            'GoogleDrive-' + ACCOUNT, 'My Drive', 'x.json')
        self.assert_refused(dest, self.dest_refused_message())

    def test_f1e_legacy_volume_classifier_pure(self):
        cls = quick_reg._p2_is_google_drive_location
        for p in ('/Volumes/GoogleDrive-1234567890/a', '/Volumes/GoogleDrive/a', '/VOLUMES/googledrive-9/a',
                  '/Users/x/Library/CloudStorage/GoogleDrive-a@b.c/My Drive/f.json',
                  '/Users/x/Library/CloudStorage/GoogleDrive'):
            with self.subTest(p=p):
                self.assertTrue(cls(p))
        for p in ('/Volumes/GoogleDriveX/a', '/Volumes/Data/GoogleDrive-1/a',
                  '/Users/x/Library/CloudStorage/OneDrive-Contoso/a', '/Users/x/Library/CloudStorage/Box-Box/a',
                  '/Users/x/Library/CloudStorage/Dropbox/a', '/Users/x/Library/CloudStorage/GoogleDriveBackupX/a',
                  '/Users/x/MyGoogleDrive/a', '/Users/x/Library/CloudStorage', '/Users/x/private/a.json'):
            with self.subTest(p=p):
                self.assertFalse(cls(p))

    def test_f1f_non_drive_siblings_unchanged(self):
        # Same results as frozen B4e: only the pre-existing marker refuses Dropbox.
        self.need_safe_root()
        cs = ('Users', USER, 'Library', 'CloudStorage')
        for name, refused in (('OneDrive-Contoso', False), ('Box-Box', False),
                              ('GoogleDriveBackupX', False), ('Dropbox', True)):
            with self.subTest(name=name):
                d = self.mk(*(cs + (name, 'sub')))
                dest = os.path.join(d, 'x.json')
                if refused:
                    self.assert_refused(dest, self.dest_refused_message())
                else:
                    self.assert_written(dest)
        for name in ('MyGoogleDrive', 'Google Drive Backup'):
            with self.subTest(name=name):
                d = self.mk('Users', USER, name)
                self.assert_written(os.path.join(d, 'x.json'))
        self.assertEqual(quick_reg._SYNCED_PATH_MARKERS,
                         ('onedrive', 'dropbox', 'google drive', 'googledrive', 'icloud', 'icloud drive',
                          'icloudrive'))


# ===================================================================== F2: kernel order
class F2_SymlinkThenDotDot(_Base):

    def test_f2a_symlink_dotdot_into_git_repo_refused(self):
        self.mk('repo', '.git')
        self.mk('repo', 'a', 'b')
        self.mk('Users', USER)
        link = os.path.join(self.root, 'Users', USER, 'repolink')
        self.symlink(os.path.join(self.root, 'repo', 'a', 'b'), link)
        dest = os.path.join(link, '..', 'x.json')
        self.assertEqual(os.path.dirname(os.path.realpath(dest)), os.path.join(self.root, 'repo', 'a'))
        self.assert_refused(dest, self.dest_refused_message())
        self.assertFalse(os.path.lexists(os.path.join(self.root, 'repo', 'a', 'x.json')))

    def test_f2b_symlink_dotdot_into_program_folder_refused(self):
        prog = self.mk('program')
        self.mk('program', 'sub')
        self.mk('Users', USER)
        link = os.path.join(self.root, 'Users', USER, 'proglink')
        self.symlink(os.path.join(prog, 'sub'), link)
        with mock.patch.object(quick_reg, '__file__', os.path.join(prog, 'quick_reg.py')):
            self.assert_refused(os.path.join(link, '..', 'x.json'), self.dest_refused_message())
        self.assertFalse(os.path.lexists(os.path.join(prog, 'x.json')))

    def test_f2c_innocent_symlink_dotdot_still_allowed(self):
        self.need_safe_root()
        self.mk('Users', USER, 'safe', 'deep')
        link = os.path.join(self.root, 'Users', USER, 'safelink')
        self.symlink(os.path.join(self.root, 'Users', USER, 'safe', 'deep'), link)
        self.assert_written(os.path.join(link, '..', 'x.json'))
        self.assertTrue(os.path.isfile(os.path.join(self.root, 'Users', USER, 'safe', 'x.json')))

    def test_f2d_dangling_git_symlink_refused(self):
        repo = self.mk('repo_dangling')
        self.symlink(os.path.join(self.root, 'does-not-exist'), os.path.join(repo, '.git'))
        d = self.mk('repo_dangling', 'sub')
        self.assert_refused(os.path.join(d, 'x.json'), self.dest_refused_message())


# ===================================================================== F4: S-02
class F4_TildeAndRelativePaths(_Base):

    def _expanduser(self, p):
        return self.home + p[1:] if p.startswith('~') else p

    def test_f4a_tilde_path_refused_by_classifier(self):
        # S-02 reproduction: '~/out/full.json' was classified at <home>/out but written to
        # the relative path ./~/out/full.json. The classifier now refuses it as given.
        self.need_safe_root()
        self.mk('mac', 'Users', USER, 'out')
        with self.drive_env(), mock.patch.object(quick_reg.os.path, 'expanduser', self._expanduser):
            self.assertTrue(quick_reg._p2_full_export_destination_unsafe('~/out/full.json'))
            self.assertFalse(quick_reg._p2_full_export_destination_unsafe(
                os.path.join(self.home, 'out', 'full.json')))
        self.assertFalse(os.path.isabs('~/out/full.json'))  # what the writer would open

    def test_f4b_tilde_full_export_refused_before_any_write(self):
        self.mk('mac', 'Users', USER, 'out')
        with mock.patch.object(quick_reg.os.path, 'expanduser', self._expanduser):
            exc = self.full_darwin('~/out/full.json')
        self.assertIsInstance(exc, capability_gate.GateRefused)
        self.assertFalse(os.path.lexists(os.path.join(self.home, 'out', 'full.json')))

    def test_f4c_relative_path_refused_without_chdir(self):
        # TB4E-08: classifier called directly with relative strings (no os.chdir).
        for rel in ('rel.json', os.path.join('sub', 'rel.json'), '.' + os.sep + 'x.json'):
            with self.subTest(rel=rel), self.drive_env():
                self.assertTrue(quick_reg._p2_full_export_destination_unsafe(rel))

    def test_f4d_odd_values_refused_by_classifier_itself(self):
        # c11/c12 strengthening: the classifier itself (not only the Quick-owned check).
        for bad in ('', 'a\x00b.json', 123, None, b'/tmp/x.json'):
            with self.subTest(bad=repr(bad)), self.drive_env():
                self.assertTrue(quick_reg._p2_full_export_destination_unsafe(bad))
        d = self.mk('private_rp')
        with self.drive_env(), mock.patch.object(quick_reg.os.path, 'realpath', side_effect=OSError('t')):
            self.assertTrue(quick_reg._p2_full_export_destination_unsafe(os.path.join(d, 'f.json')))


# ===================================================================== D: detection
class D_DriveDetection(_Base):

    def detected(self):
        with self.drive_env():
            return quick_reg.p2_google_drive_detected()

    def test_d1_nothing_installed_not_detected(self):
        self.mk('mac', 'Users', USER, 'Library', 'CloudStorage', 'OneDrive-Contoso')
        self.mk('mac', 'Users', USER, 'Library', 'CloudStorage', 'Dropbox')
        self.mk('mac', 'Volumes', 'Macintosh HD')
        self.assertFalse(self.detected())

    def test_d2_each_evidence_source_detects(self):
        cases = (('app', lambda: self.mk('mac', 'Applications', 'Google Drive.app')),
                 ('drivefs', self.detect_drive),
                 ('cloudstorage', lambda: self.mk('mac', 'Users', USER, 'Library', 'CloudStorage',
                                                  'GoogleDrive-' + ACCOUNT)),
                 ('cloudstorage-case', lambda: self.mk('mac', 'Users', USER, 'Library', 'CloudStorage',
                                                       'googledrive')),
                 ('volumes', lambda: self.mk('mac', 'Volumes', 'GoogleDrive')),
                 ('volumes-id', lambda: self.mk('mac', 'Volumes', 'GoogleDrive-123')))
        for label, make in cases:
            with self.subTest(source=label):
                self.tearDown()
                self.setUp()
                self.assertFalse(self.detected())
                make()
                self.assertTrue(self.detected())

    def test_d3_fail_closed_on_errors_other_than_missing(self):
        real_lstat, real_listdir = os.lstat, os.listdir
        cs = os.path.join(self.home, 'Library', 'CloudStorage')
        os.makedirs(cs)

        def lstat_denied(path, *a, **k):
            if str(path) == self.drive_app:
                raise PermissionError(13, 'denied (test)')
            return real_lstat(path, *a, **k)

        def listdir_denied(path='.'):
            if str(path) == cs:
                raise PermissionError(13, 'denied (test)')
            return real_listdir(path)
        with mock.patch.object(quick_reg.os, 'lstat', side_effect=lstat_denied):
            self.assertTrue(self.detected())
        with mock.patch.object(quick_reg.os, 'listdir', side_effect=listdir_denied):
            self.assertTrue(self.detected())
        with mock.patch.object(quick_reg, '_p2_home', lambda: 'relative-home', create=True):
            self.assertTrue(quick_reg.p2_google_drive_detected())
        self.assertFalse(self.detected())

    def test_d4_no_google_data_opened_or_listed(self):
        fs = self.mk('mac', 'Users', USER, 'Library', 'Application Support', 'Google', 'DriveFS', '1234')
        with open(os.path.join(fs, 'metadata_sqlite_db'), 'w', encoding='utf-8') as f:
            f.write('synthetic')
        acct = self.mk('mac', 'Users', USER, 'Library', 'CloudStorage', 'GoogleDrive-' + ACCOUNT, 'My Drive')
        other = self.mk('mac', 'Users', USER, 'Library', 'CloudStorage', 'OneDrive-Contoso')
        seen = []

        def rec(name, real):
            def f(*a, **k):
                seen.append((name, str(a[0]) if a else str(k)))
                return real(*a, **k)
            return f
        patches = [mock.patch.object(quick_reg.os, 'listdir', rec('listdir', os.listdir)),
                   mock.patch.object(quick_reg.os, 'scandir', rec('scandir', os.scandir)),
                   mock.patch.object(quick_reg.os, 'open', rec('os.open', os.open)),
                   mock.patch.object(sqlite3, 'connect', rec('sqlite3.connect', sqlite3.connect)),
                   mock.patch('builtins.open', rec('open', open))]
        dest = os.path.join(self.mk('elsewhere'), 'x.json')
        with contextlib.ExitStack() as st:
            for p in patches:
                st.enter_context(p)
            self.assertTrue(self.detected())
            # the darwin-only F3 step and the destination classifier, as the guard calls them
            with self.drive_env():
                self.assertEqual(quick_reg._p2_drive_private_dir_refusal(dest),
                                 quick_reg.P2_FULL_EXPORT_PRIVATE_DIR_ONLY)
                quick_reg._p2_full_export_destination_unsafe(dest)
        drivefs = os.path.join('Application Support', 'Google', 'DriveFS')
        for name, path in seen:
            self.assertNotIn(drivefs, path, (name, 'DriveFS must never be opened or listed'))
            self.assertFalse(path.startswith(os.path.dirname(acct)), (name, 'Drive folder listed'))
            self.assertFalse(path.startswith(other), (name, 'other provider listed'))
        self.assertTrue(all(n == 'listdir' for n, _ in seen), seen)  # names only, never content


# ===================================================================== F3: private folder
@unittest.skipUnless(POSIX_OWNER, 'NOT RUN: owner/mode checks need POSIX (macOS/Linux)')
class F3_DesignatedPrivateFolder(_Base):

    def setUp(self):
        super().setUp()
        self.detect_drive()
        self.private = os.path.join(self.home, *PRIVATE_PARTS)

    def make_private(self, mode=0o700, parent_mode=0o700):
        os.mkdir(os.path.join(self.home, PRIVATE_PARTS[0]), parent_mode)
        os.chmod(os.path.join(self.home, PRIVATE_PARTS[0]), parent_mode)
        os.mkdir(self.private, mode)
        os.chmod(self.private, mode)

    def test_f3a_outside_private_folder_refused_nothing_created(self):
        self.need_safe_root()
        for d in (self.mk('elsewhere'), self.home, self.mk('mac', 'Users', USER, 'Documents')):
            with self.subTest(d=os.path.relpath(d, self.root)):
                self.assert_refused(os.path.join(d, 'full.json'), quick_reg.P2_FULL_EXPORT_PRIVATE_DIR_ONLY)
        self.assertFalse(os.path.lexists(os.path.join(self.home, PRIVATE_PARTS[0])))

    def test_f3b_inside_private_folder_created_0700_and_written_0600(self):
        self.need_safe_root()
        dest = os.path.join(self.private, 'full.json')
        self.assert_written(dest)
        for p in (os.path.join(self.home, PRIVATE_PARTS[0]), self.private):
            st = os.lstat(p)
            self.assertTrue(stat.S_ISDIR(st.st_mode) and not stat.S_ISLNK(st.st_mode))
            self.assertEqual(stat.S_IMODE(st.st_mode), 0o700)
            self.assertEqual(st.st_uid, os.getuid())
        # existing private folder: second file allowed; an existing file is never overwritten
        self.assert_written(os.path.join(self.private, 'second.json'))
        exc = self.full_darwin(dest)
        self.assertIsInstance(exc, FileExistsError)

    def test_f3c_wrong_mode_or_owner_refused(self):
        self.need_safe_root()
        self.make_private(mode=0o755)
        self.assert_refused(os.path.join(self.private, 'full.json'), quick_reg.P2_FULL_EXPORT_PRIVATE_DIR_UNSAFE)
        os.chmod(self.private, 0o700)
        os.chmod(os.path.join(self.home, PRIVATE_PARTS[0]), 0o750)
        self.assert_refused(os.path.join(self.private, 'full.json'), quick_reg.P2_FULL_EXPORT_PRIVATE_DIR_UNSAFE)
        os.chmod(os.path.join(self.home, PRIVATE_PARTS[0]), 0o700)
        with mock.patch.object(quick_reg.os, 'getuid', lambda: os.getuid() + 1):
            self.assert_refused(os.path.join(self.private, 'full.json'),
                                quick_reg.P2_FULL_EXPORT_PRIVATE_DIR_UNSAFE)
        self.assert_written(os.path.join(self.private, 'full.json'))  # control: now valid

    def test_f3d_symlink_components_refused(self):
        self.need_safe_root()
        elsewhere = self.mk('elsewhere_real')
        os.chmod(elsewhere, 0o700)
        os.mkdir(os.path.join(self.home, PRIVATE_PARTS[0]), 0o700)
        self.symlink(elsewhere, self.private)
        self.assert_refused(os.path.join(self.private, 'full.json'), quick_reg.P2_FULL_EXPORT_PRIVATE_DIR_UNSAFE)
        os.unlink(self.private)
        os.rmdir(os.path.join(self.home, PRIVATE_PARTS[0]))
        app_real = self.mk('app_real')
        os.chmod(app_real, 0o700)
        self.symlink(app_real, os.path.join(self.home, PRIVATE_PARTS[0]))
        self.assert_refused(os.path.join(self.private, 'full.json'), quick_reg.P2_FULL_EXPORT_PRIVATE_DIR_UNSAFE)
        self.assertEqual(os.listdir(app_real), [])

    def test_f3e_private_folder_under_git_or_drive_refused_before_mkdir(self):
        os.mkdir(os.path.join(self.home, '.git'))
        self.assert_refused(os.path.join(self.private, 'full.json'), quick_reg.P2_FULL_EXPORT_PRIVATE_DIR_UNSAFE)
        self.assertFalse(os.path.lexists(os.path.join(self.home, PRIVATE_PARTS[0])))
        os.rmdir(os.path.join(self.home, '.git'))
        drive_home = self.mk('mac', 'Users', USER, 'Library', 'CloudStorage', 'GoogleDrive-' + ACCOUNT, 'h')
        os.makedirs(os.path.join(drive_home, 'Library', 'Application Support', 'Google', 'DriveFS'))
        with mock.patch.object(self, 'home', drive_home):
            dest = os.path.join(drive_home, *(PRIVATE_PARTS + ('full.json',)))
            self.assert_refused(dest, quick_reg.P2_FULL_EXPORT_PRIVATE_DIR_UNSAFE)
            self.assertFalse(os.path.lexists(os.path.join(drive_home, PRIVATE_PARTS[0])))

    def test_f3f_private_folder_link_into_repo_refused(self):
        self.mk('repo3', '.git')
        target = self.mk('repo3', 'p')
        os.chmod(target, 0o700)
        os.mkdir(os.path.join(self.home, PRIVATE_PARTS[0]), 0o700)
        self.symlink(target, self.private)
        self.assert_refused(os.path.join(self.private, 'full.json'))
        self.assertEqual(os.listdir(target), [])

    def test_f3g_wrong_shape_inside_private_folder_refused(self):
        self.need_safe_root()
        self.make_private()
        sub = os.path.join(self.private, 'sub')
        os.mkdir(sub, 0o700)
        for dest in (os.path.join(sub, 'x.json'), os.path.join(self.private, 'x.txt'),
                     os.path.join(self.private, '..', PRIVATE_PARTS[1], 'x.json'),
                     '~/' + '/'.join(PRIVATE_PARTS) + '/x.json'):
            with self.subTest(dest=dest.replace(self.root, '<root>')):
                exc = self.full_darwin(dest)
                self.assertIsNotNone(exc)
                self.assertFalse(os.path.lexists(os.path.join(self.private, 'x.json')))
        # a dangling link inside the private folder pointing elsewhere is refused
        victim = os.path.join(self.mk('victim_dir'), 'v.json')
        self.symlink(victim, os.path.join(self.private, 'link.json'))
        exc = self.full_darwin(os.path.join(self.private, 'link.json'))
        self.assertIsNotNone(exc)
        self.assertFalse(os.path.lexists(victim))

    def test_f3h_wrong_shape_does_not_create_the_folder(self):
        for dest in (os.path.join(self.private, 'x.txt'), os.path.join(self.private, 'sub', 'x.json')):
            with self.subTest(dest=os.path.basename(dest)):
                self.full_darwin(dest)
                self.assertFalse(os.path.lexists(os.path.join(self.home, PRIVATE_PARTS[0])))

    def test_f3i_restrictive_umask_still_gives_0700(self):
        self.need_safe_root()
        try:
            old = os.umask(0o277)
        except Exception:  # noqa: BLE001 - restricted interpreters
            self.skipTest('NOT RUN: os.umask unavailable here')
        try:
            self.assert_written(os.path.join(self.private, 'full.json'))
        finally:
            os.umask(old)
        self.assertEqual(stat.S_IMODE(os.lstat(self.private).st_mode), 0o700)

    def test_f3j_cli_full_export_detected(self):
        self.need_safe_root()
        manifest = os.path.join(self.root, 'manifest.json')
        with open(manifest, 'w', encoding='utf-8', newline='\n') as f:
            f.write(json.dumps(SPEC))
        for dest, want_code in ((os.path.join(self.mk('cli_out'), 'full.json'), 2),
                                (os.path.join(self.private, 'full.json'), 0)):
            out, err = io.StringIO(), io.StringIO()
            with platform_as('darwin'), self.drive_env(), Tripwire() as tw, \
                    contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
                try:
                    code = cli.main(['export', manifest, '--output-file', dest, '--full-export',
                                     '--ack', TOKEN])
                except SystemExit as e:
                    code = e.code
            self.assertEqual(tw.hits, [])
            self.assertEqual(code, want_code, err.getvalue())
            if want_code:
                self.assertIn(quick_reg.P2_FULL_EXPORT_PRIVATE_DIR_ONLY, err.getvalue())
                self.assertFalse(os.path.lexists(dest))
                self.assertEqual(out.getvalue(), '')
                for ident in (USER, HOST, self.root):
                    self.assertNotIn(ident, err.getvalue())
            else:
                self.assertTrue(os.path.isfile(dest))


class F3_MessagesFixed(unittest.TestCase):

    def test_f3m_messages_fixed_no_paths_no_unsynced_claim(self):
        for name in ('P2_FULL_EXPORT_PRIVATE_DIR_ONLY', 'P2_FULL_EXPORT_PRIVATE_DIR_UNSAFE'):
            with self.subTest(name=name):
                msg = getattr(quick_reg, name)
                self.assertIsInstance(msg, str)
                self.assertIn('~/.aq_mcp_wizard/private_exports', msg)
                self.assertIn('cannot be inspected', msg)
                self.assertIn('manual FULL-copy', msg)
                low = msg.lower()
                for claim in ('unsynced', 'not synced', 'never synced', 'unsynchronized', 'guarantee',
                              '/users/', '/home/'):
                    self.assertNotIn(claim, low)
                self.assertEqual(msg.count('/'), 2)  # only the ~-relative folder name
        self.assertEqual(quick_reg.P2_PRIVATE_EXPORT_DIR_DISPLAY, '~/.aq_mcp_wizard/private_exports')


# ===================================================================== kept behaviour
class K_KeptWhenDriveNotDetected(_Base):
    """Drive NOT detected: same outcome as frozen B4e for non-Drive destinations. These
    must also pass on B4e (environment-independent replacements for B4e k1/k4)."""

    def test_k1_private_destination_written_0600(self):
        self.need_safe_root()
        self.assert_written(os.path.join(self.mk('private_ok'), 'full.json'))

    def test_k2_git_and_synced_still_refused(self):
        self.mk('repo', '.git')
        self.assert_refused(os.path.join(self.mk('repo', 'sub'), 'x.json'), self.dest_refused_message())
        self.assert_refused(os.path.join(self.mk('Dropbox', 'n'), 'x.json'), self.dest_refused_message())

    def test_k4_existing_file_never_overwritten(self):
        self.need_safe_root()
        d = self.mk('private_exist')
        dest = os.path.join(d, 'full.json')
        with open(dest, 'w', encoding='utf-8') as f:
            f.write('ORIGINAL')
        self.assertIsInstance(self.full_darwin(dest), FileExistsError)
        with open(dest, encoding='utf-8') as f:
            self.assertEqual(f.read(), 'ORIGINAL')


# ===================================================================== parity
class P_NonDarwinUnchanged(_Base):

    def test_p1_windows_linux_full_export_into_drive_shape_unchanged(self):
        d = self.drive_root('My Drive')
        self.detect_drive()
        for plat in ('win32', 'linux'):
            with self.subTest(plat=plat):
                dest = os.path.join(d, plat + '.json')
                with platform_as(plat), self.drive_env(), \
                        mock.patch.object(quick_reg, '_p2_darwin_export_guard',
                                          side_effect=AssertionError('darwin guard off macOS')), \
                        mock.patch.object(quick_reg, 'p2_google_drive_detected',
                                          side_effect=AssertionError('detection off macOS'), create=True):
                    self.assertEqual(quick_reg.write_quick_config(dict(SPEC), dest, redacted=False), dest)
                with open(dest, encoding='utf-8') as f:
                    self.assertEqual(f.read(), quick_reg.config_export_text(dict(SPEC), redacted=False) + '\n')

    def test_p2_shared_markers_and_public_helper_unchanged(self):
        self.assertIs(quick_reg.SYNCED_PATH_MARKERS, quick_reg._SYNCED_PATH_MARKERS)
        self.assertFalse(quick_reg.path_looks_synced(r'C:\Users\x\Library\CloudStorage\GoogleDrive-a\My Drive'))
        self.assertFalse(quick_reg.path_looks_synced('/Users/x/Library/CloudStorage/GoogleDrive-a/My Drive'))
        self.assertTrue(quick_reg.path_looks_synced(r'C:\Users\x\OneDrive\docs'))
        self.assertTrue(quick_reg.path_looks_synced('/Users/x/Google Drive/a'))


# ===================================================================== tripwire control
class T_TripwirePositiveControl(unittest.TestCase):

    def test_t1_every_patched_entry_point_fires(self):
        with Tripwire() as tw:
            labels = [lab for _, _, lab in tw.targets]
            for obj, name, lab in tw.targets:
                with self.assertRaises(AssertionError):
                    getattr(obj, name)()
            with self.assertRaises(AssertionError):
                sys.modules['paramiko'].SSHClient
        self.assertEqual(len(tw.hits), len(labels) + 1, tw.hits)
        for must in ('socket.socket', 'socket.getaddrinfo', 'socket.gethostbyaddr', 'socket.getnameinfo',
                     'socket.getfqdn', 'os.system'):
            self.assertIn(must, labels)

    def test_t2_import_watch_fires(self):
        probe = 'ssl.b4f_probe_watch'
        with ImportWatch() as iw, mock.patch.dict(sys.modules, {probe: type(unittest)(probe)}):
            pass
        self.assertEqual(iw.new, [])  # patch.dict removed it before the watch closed
        with ImportWatch() as iw:
            sys.modules[probe] = type(unittest)(probe)
        sys.modules.pop(probe, None)
        self.assertEqual(iw.new, [probe])


if __name__ == '__main__':
    unittest.main()
