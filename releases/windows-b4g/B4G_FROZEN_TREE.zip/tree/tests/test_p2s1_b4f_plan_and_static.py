"""P2 Slice 1 / B4f: macOS CLI offline plan - plan-file collision (S-04), identity case
variants (TB4E-04), extended tripwires and import detection (TB4E-05), and a STATIC check
that no p2s1 B4* test module imports a module the guarded runner v2.1 refuses (TB4E-01).

S-04 (= R-02 = TB4E-06): with an existing --plan-file, B4e let FileExistsError escape to
the __main__ handler, which printed 'ERROR: [Errno 17] File exists: <path>' (the path can
contain the account name). B4f prints a FIXED message, exits 2, leaves the file untouched
and prints nothing on stdout; any other file error -> a second fixed message, exit 1.

Every darwin test drives the REAL cli.main() with sys.platform patched to 'darwin' (every
is_darwin copy asserted; the _darwin_remote spy asserted). run_cli mirrors the real
__main__ handler ('ERROR: ' + str(e), exit 1). Synthetic identities only. No network, SSH,
subprocess or Tk. Class prefixes: S04_, C_ (case variants), N_ (network/import), P_
(non-darwin parity), T_ (positive controls), X_ (static).
"""
import ast
import contextlib
import io
import json
import os
import socket
import sys
import tempfile
import unittest
from unittest import mock

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import capability_gate
import cli
import deploy_lib
import model
import native_gateway
import platform_p2
import quick_reg

USER = 'fakeuser'
HOST = 'fakehost'
URL = 'https://abc123.lambda-url.us-west-2.on.aws/mcp'
IDENTITIES = (USER, HOST, USER + '@' + HOST, '/home/' + USER)
TESTS_DIR = os.path.dirname(os.path.abspath(__file__))
# Copy of runner/run_p2_tests_guarded_v2_1.py DENY_IMPORTS (cross-checked below when the
# runner file sits next to the tree, as in the candidate ZIP layout).
RUNNER_DENY_IMPORTS = frozenset(('ctypes', '_ctypes', 'multiprocessing', '_multiprocessing',
                                 'concurrent.futures.process', 'webbrowser', 'urllib.request',
                                 'http.client', 'ftplib', 'smtplib', 'imaplib', 'poplib',
                                 'xmlrpc.client'))
WATCHED_IMPORTS = ('ssl', '_ssl', 'http.client', 'urllib.request', 'ftplib', 'smtplib', 'imaplib',
                   'poplib', 'xmlrpc.client', 'socketserver', 'asyncio', 'multiprocessing',
                   'ctypes', 'webbrowser', 'paramiko', 'subprocess', 'requests', 'urllib3')


def spec(user=USER, host=HOST, target='demo-epg', allow=('list_things',), display_name=None):
    sp = {'transport': 'linux-ssh', 'host': host, 'user': user, 'kind': 'lambda',
          'target': target, 'url': URL, 'allow': list(allow)}
    if display_name is not None:
        sp['display_name'] = display_name
    return sp


def _darwin_copies():
    return {'platform_p2.is_darwin': platform_p2.is_darwin,
            'cli.platform_p2.is_darwin': cli.platform_p2.is_darwin,
            'deploy_lib.platform_p2.is_darwin': deploy_lib.platform_p2.is_darwin,
            'capability_gate.is_darwin': capability_gate.is_darwin,
            'quick_reg._p2_is_darwin': quick_reg._p2_is_darwin,
            'model._p2_is_darwin': model._p2_is_darwin,
            'native_gateway._p2_is_darwin': native_gateway._p2_is_darwin}


@contextlib.contextmanager
def platform_as(name):
    with mock.patch.object(sys, 'platform', name):
        want = (name == 'darwin')
        bad = sorted(k for k, f in _darwin_copies().items() if bool(f()) != want)
        if bad:
            raise AssertionError('platform emulation incomplete for: ' + ', '.join(bad))
        yield


class Tripwire(object):
    """Network / DNS (incl. gethostbyaddr, getnameinfo, getfqdn and _socket) / TLS / HTTP /
    process / paramiko tripwire. Never imports a module itself (see ImportWatch)."""

    def __init__(self):
        self.hits = []
        self.targets = []

    def _trip(self, what):
        def f(*a, **k):
            self.hits.append(what)
            raise AssertionError('TRIPWIRE: ' + what)
        return f

    def __enter__(self):
        hits = self.hits

        class _ParamikoBomb(object):
            def __getattr__(self, name):
                hits.append('paramiko.' + name)
                raise AssertionError('TRIPWIRE: paramiko used')

        t = []
        for n in ('socket', 'create_connection', 'create_server', 'socketpair', 'getaddrinfo',
                  'gethostbyname', 'gethostbyname_ex', 'gethostbyaddr', 'getnameinfo', 'getfqdn'):
            if hasattr(socket, n):
                t.append((socket, n, 'socket.' + n))
        low = sys.modules.get('_socket')
        if low is not None:
            for n in ('getaddrinfo', 'gethostbyname', 'gethostbyname_ex', 'gethostbyaddr',
                      'getnameinfo'):
                if hasattr(low, n):
                    t.append((low, n, '_socket.' + n))
        ssl_m = sys.modules.get('ssl')
        if ssl_m is not None:
            t += [(ssl_m, 'create_default_context', 'ssl.create_default_context'),
                  (ssl_m.SSLContext, 'wrap_socket', 'ssl.SSLContext.wrap_socket')]
        ur = sys.modules.get('urllib.request')
        if ur is not None:
            t.append((ur, 'urlopen', 'urllib.request.urlopen'))
        hc = sys.modules.get('http.client')
        if hc is not None:
            t += [(hc.HTTPConnection, 'connect', 'http.client.HTTPConnection.connect'),
                  (hc.HTTPSConnection, 'connect', 'http.client.HTTPSConnection.connect')]
        sp = sys.modules.get('subprocess')
        if sp is not None:
            for n in ('Popen', 'run', 'call', 'check_call', 'check_output', 'getoutput',
                      'getstatusoutput'):
                t.append((sp, n, 'subprocess.' + n))
        for n in ('system', 'popen', 'execv', 'execve', 'execvp', 'execvpe', 'execl', 'execlp',
                  'spawnv', 'spawnvp', 'spawnl', 'posix_spawn', 'posix_spawnp', 'fork', 'forkpty',
                  'startfile'):
            if hasattr(os, n):
                t.append((os, n, 'os.' + n))
        self.targets = t
        self._patches = [mock.patch.object(o, n, self._trip(lab)) for o, n, lab in t]
        self._patches.append(mock.patch.dict(sys.modules, {'paramiko': _ParamikoBomb()}))
        for p in self._patches:
            p.start()
        return self

    def __exit__(self, *exc):
        for p in reversed(self._patches):
            p.stop()
        return False


class ImportWatch(object):
    def __init__(self, watched=WATCHED_IMPORTS):
        self.watched = tuple(watched)
        self.new = []

    def __enter__(self):
        self._before = set(sys.modules)
        return self

    def __exit__(self, *exc):
        after = set(sys.modules)
        self.new = sorted(m for m in after - self._before
                          if any(m == w or m.startswith(w + '.') for w in self.watched))
        return False


def run_cli(argv):
    """cli.main(argv) in-process -> (code, stdout, stderr, SystemExit or None); an escaping
    Exception is printed exactly like cli.py's __main__ handler."""
    out, err = io.StringIO(), io.StringIO()
    code, sysexit = None, None
    with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
        try:
            code = cli.main(argv)
        except SystemExit as e:
            sysexit = e
            code = e.code if isinstance(e.code, int) else (0 if e.code is None else 2)
        except Exception as e:  # mirrors __main__
            print('ERROR: ' + str(e), file=sys.stderr)
            code = 1
    return code, out.getvalue(), err.getvalue(), sysexit


def _identity_free(testcase, text, where):
    low = text.lower()
    for ident in IDENTITIES:
        testcase.assertNotIn(ident.lower(), low, '%s leaks %r' % (where, ident))


class _PlanBase(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.tmp = os.path.realpath(self._tmp.name)
        self.manifest = os.path.join(self.tmp, 'manifest.json')
        # the plan file sits under a folder named like the login (as /Users/<login>/... would)
        self.user_dir = os.path.join(self.tmp, 'Users', USER)
        os.makedirs(self.user_dir)
        self.plan_file = os.path.join(self.user_dir, 'plan.json')

    def tearDown(self):
        self._tmp.cleanup()

    def write_manifest(self, sp):
        with open(self.manifest, 'w', encoding='utf-8', newline='\n') as f:
            f.write(json.dumps(sp))

    def listing(self):
        out = []
        for base, dirs, files in os.walk(self.tmp):
            for n in dirs + files:
                out.append(os.path.relpath(os.path.join(base, n), self.tmp))
        return sorted(x for x in out if x != 'manifest.json')

    def run_darwin_plan(self, sp, plan_file=None, use_plan_file=True):
        self.write_manifest(sp)
        pf = plan_file or self.plan_file
        argv = ['plan', self.manifest] + (['--plan-file', pf] if use_plan_file else [])
        spy = mock.patch.object(cli, '_darwin_remote', wraps=cli._darwin_remote)
        with platform_as('darwin'), ImportWatch() as iw, Tripwire() as tw, spy as remote:
            res = run_cli(argv)
        self.assertEqual(tw.hits, [], 'tripwire fired')
        self.assertEqual(iw.new, [], 'network/process module imported during the plan')
        self.assertTrue(remote.called, 'macOS _darwin_remote branch was not taken')
        return res


# ===================================================================== S-04
class S04_PlanFileCollision(_PlanBase):

    def test_s04a_existing_plan_file_fixed_message_exit_2_untouched(self):
        with open(self.plan_file, 'wb') as f:
            f.write(b'{"pre-existing": true}\n')
        before = self.listing()
        code, out, err, sysexit = self.run_darwin_plan(spec())
        # genuine checks first (they fail on B4e, whose stderr carried the errno text + path)
        self.assertNotIn(self.plan_file, err)
        self.assertNotIn(self.user_dir, err)
        self.assertNotIn('Errno', err)
        self.assertNotIn('Traceback', err)
        _identity_free(self, err, 'stderr')
        self.assertEqual(out, '')
        self.assertEqual(err, 'ERROR: ' + getattr(cli, 'DARWIN_PLAN_FILE_EXISTS', '<missing>') + '\n')
        self.assertEqual(code, 2)
        self.assertIsNotNone(sysexit)
        self.assertIsNone(sysexit.__context__)
        self.assertIsNone(sysexit.__cause__)
        with open(self.plan_file, 'rb') as f:
            self.assertEqual(f.read(), b'{"pre-existing": true}\n')
        self.assertEqual(self.listing(), before)

    def test_s04b_other_plan_file_error_fixed_message_exit_1(self):
        missing = os.path.join(self.user_dir, 'no-such-folder', 'plan.json')
        before = self.listing()
        code, out, err, sysexit = self.run_darwin_plan(spec(), plan_file=missing)
        self.assertNotIn(missing, err)
        self.assertNotIn('Errno', err)
        _identity_free(self, err, 'stderr')
        self.assertEqual(out, '')
        self.assertEqual(err, 'ERROR: ' + getattr(cli, 'DARWIN_PLAN_FILE_WRITE_ERROR', '<missing>') + '\n')
        self.assertEqual(code, 1)
        self.assertIsNotNone(sysexit)
        self.assertIsNone(sysexit.__context__)
        self.assertEqual(self.listing(), before)

    def test_s04c_a7_strengthened_no_summary_on_collision(self):
        # T-01: B4e test_a7 also passed on B4d (which printed the summary first). This one
        # asserts the summary is absent and stderr is exactly the fixed text.
        with open(self.plan_file, 'wb') as f:
            f.write(b'x')
        sp = spec()
        code, out, err, _ = self.run_darwin_plan(sp)
        with platform_as('darwin'):
            summary = model.plain_language_summary(sp, deploy_lib.ConnectorDeployer(None).prepare_offline(sp))
        self.assertNotIn(summary.splitlines()[0], err)
        self.assertEqual(out, '')
        self.assertNotEqual(code, 0)
        self.assertEqual(len(err.splitlines()), 1, err)

    def test_s04d_clean_plan_still_written_and_printed(self):
        code, out, err, _ = self.run_darwin_plan(spec())
        self.assertEqual(code, 0, err)
        self.assertTrue(os.path.isfile(self.plan_file))
        self.assertIn('"backend_identity_sha256"', out)
        _identity_free(self, out, 'stdout')
        _identity_free(self, err, 'stderr')

    def test_s04e_constants_are_plain_literals(self):
        with open(os.path.join(os.path.dirname(TESTS_DIR), 'cli.py'), encoding='utf-8') as f:
            tree = ast.parse(f.read())
        for name in ('DARWIN_PLAN_FILE_EXISTS', 'DARWIN_PLAN_FILE_WRITE_ERROR'):
            nodes = [n for n in tree.body if isinstance(n, ast.Assign) and len(n.targets) == 1
                     and isinstance(n.targets[0], ast.Name) and n.targets[0].id == name]
            self.assertEqual(len(nodes), 1, name)
            self.assertIsInstance(nodes[0].value, ast.Constant)
            self.assertIsInstance(nodes[0].value.value, str)


# ===================================================================== TB4E-04
class C_CaseVariantIdentities(_PlanBase):
    """TB4E-04: case variants of the login and host on the macOS plan path. Each case must
    either be REFUSED (exit 2, nothing printed or written) or print output that carries the
    login/host in NO letter case (redact_identity is case-insensitive). The expected outcome
    per case is fixed so a change in either direction is detected. (Uppercase targets are
    rejected by validate_spec before the macOS branch, so the target is not varied.)"""

    CASES = ((dict(display_name='FAKEUSER-conn'), 2), (dict(display_name='FakeUser conn'), 0),
             (dict(display_name='FAKEHOST-conn'), 0), (dict(display_name='FakeHost conn'), 0),
             (dict(allow=('list_things', 'FAKEUSER_tool')), 2), (dict(user='FakeUser'), 0),
             (dict(host='FAKEHOST'), 0), (dict(host='FakeHost', display_name='fakehost conn'), 0))

    def test_c1_case_variant_login_and_host_refused_or_fully_redacted(self):
        for kw, want in self.CASES:
            with self.subTest(case=kw):
                if os.path.exists(self.plan_file):
                    os.remove(self.plan_file)
                before = self.listing()
                code, out, err, _ = self.run_darwin_plan(spec(**kw))
                _identity_free(self, out, 'stdout')
                _identity_free(self, err, 'stderr')
                self.assertEqual(code, want, err)
                if want == 2:
                    self.assertEqual(out, '')
                    self.assertIn(cli.DARWIN_PLAN_SUMMARY_UNSAFE, err)
                    self.assertFalse(os.path.exists(self.plan_file))
                    self.assertEqual(self.listing(), before)
                else:
                    self.assertIn('"backend_identity_sha256"', out)
                    self.assertTrue(os.path.isfile(self.plan_file))


# ===================================================================== parity
class P_NonDarwinPlanFileCollisionUnchanged(_PlanBase):

    def test_p1_windows_linux_existing_plan_file_legacy_error(self):
        sp = spec()
        prepared = model.plan(sp, '0' * 64)
        prepared['gateway'] = {'host': HOST, 'user': USER}
        prepared['existing_target_count'] = 0
        for plat in ('win32', 'linux'):
            with self.subTest(plat=plat):
                with open(self.plan_file, 'wb') as f:
                    f.write(b'old')
                self.write_manifest(sp)
                with platform_as(plat), mock.patch.object(cli, 'SSHG'), \
                        mock.patch.object(cli, 'ConnectorDeployer') as D, \
                        mock.patch.object(cli, '_darwin_remote', side_effect=AssertionError('darwin')):
                    D.return_value.prepare.return_value = json.loads(json.dumps(prepared))
                    code, out, err, _ = run_cli(['plan', self.manifest, '--plan-file', self.plan_file])
                self.assertEqual(code, 1)
                self.assertEqual(out, '')
                self.assertTrue(err.startswith(model.plain_language_summary(sp, prepared)))
                self.assertIn('ERROR: ', err)
                self.assertNotIn(getattr(cli, 'DARWIN_PLAN_FILE_EXISTS', '<none>'), err)
                with open(self.plan_file, 'rb') as f:
                    self.assertEqual(f.read(), b'old')
                os.remove(self.plan_file)


# ===================================================================== network / imports
class N_OfflinePlanNoNetworkOrNewImports(_PlanBase):

    def test_n1_clean_plan_under_extended_tripwire_and_import_watch(self):
        code, out, err, _ = self.run_darwin_plan(spec(), use_plan_file=False)
        self.assertEqual(code, 0, err)

    def test_n2_dns_reverse_lookup_in_plan_path_is_caught(self):
        # mutant-style control: a reverse lookup injected into the plan path is caught
        self.write_manifest(spec())
        real = deploy_lib.ConnectorDeployer.prepare_offline

        def leaky(self_, sp):
            socket.gethostbyaddr('127.0.0.1')
            return real(self_, sp)
        with platform_as('darwin'), Tripwire() as tw, \
                mock.patch.object(deploy_lib.ConnectorDeployer, 'prepare_offline', leaky):
            run_cli(['plan', self.manifest])
        self.assertEqual(tw.hits, ['socket.gethostbyaddr'])


class T_PositiveControls(unittest.TestCase):

    def test_t1_every_patched_entry_point_fires(self):
        with Tripwire() as tw:
            labels = [lab for _, _, lab in tw.targets]
            for obj, name, _ in tw.targets:
                with self.assertRaises(AssertionError):
                    getattr(obj, name)()
            with self.assertRaises(AssertionError):
                sys.modules['paramiko'].SSHClient
        self.assertEqual(len(tw.hits), len(labels) + 1, tw.hits)
        for must in ('socket.gethostbyaddr', 'socket.getnameinfo', 'socket.getfqdn', 'socket.getaddrinfo'):
            self.assertIn(must, labels)

    def test_t2_import_watch_reports_new_watched_module(self):
        probe = 'ssl.b4f_plan_probe_watch'
        with ImportWatch() as iw:
            sys.modules[probe] = type(unittest)(probe)
        sys.modules.pop(probe, None)
        self.assertEqual(iw.new, [probe])


# ===================================================================== static (TB4E-01)
def _deny_hit(modname):
    parts = modname.split('.')
    return any('.'.join(parts[:i]) in RUNNER_DENY_IMPORTS for i in range(1, len(parts) + 1))


def _imports(nodes):
    """(lineno, module) for Import / ImportFrom nodes in `nodes` (a from-import of a
    submodule name, e.g. `from urllib import request`, counts as that submodule)."""
    out = []
    for n in nodes:
        if isinstance(n, ast.Import):
            out += [(n.lineno, a.name) for a in n.names]
        elif isinstance(n, ast.ImportFrom) and n.module and not n.level:
            out.append((n.lineno, n.module))
            out += [(n.lineno, n.module + '.' + a.name) for a in n.names]
    return out


def _module_level(tree):
    """Statements executed at import time: module body plus nested if/try/with blocks
    (NOT function or class bodies)."""
    todo, out = list(tree.body), []
    while todo:
        n = todo.pop()
        out.append(n)
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef, ast.Lambda)):
            continue
        for field in ('body', 'orelse', 'finalbody', 'handlers'):
            todo.extend(getattr(n, field, []) or [])
    return out


class X_RunnerDeniedImports(unittest.TestCase):

    def _files(self):
        names = sorted(n for n in os.listdir(TESTS_DIR)
                       if n.startswith('test_p2s1_b4') and n.endswith('.py') and '_' in n[len('test_p2s1_b4'):])
        self.assertTrue(any(n.startswith('test_p2s1_b4e_') for n in names), names)
        self.assertTrue(any(n.startswith('test_p2s1_b4f_') for n in names), names)
        return names

    def test_x1_no_module_level_import_of_runner_denied_modules(self):
        for name in self._files():
            with self.subTest(file=name):
                with open(os.path.join(TESTS_DIR, name), encoding='utf-8') as f:
                    tree = ast.parse(f.read())
                bad = [(ln, m) for ln, m in _imports(_module_level(tree)) if _deny_hit(m)]
                self.assertEqual(bad, [], 'runner-denied import at module level')

    def test_x2_b4f_files_import_no_denied_module_anywhere(self):
        for name in self._files():
            if not name.startswith('test_p2s1_b4f_'):
                continue
            with self.subTest(file=name):
                with open(os.path.join(TESTS_DIR, name), encoding='utf-8') as f:
                    tree = ast.parse(f.read())
                bad = [(ln, m) for ln, m in _imports(ast.walk(tree)) if _deny_hit(m)]
                self.assertEqual(bad, [])

    def test_x3_checker_positive_control(self):
        src = ('import os\nimport http.client\nfrom urllib import request\n'
               'try:\n    import ctypes\nexcept ImportError:\n    pass\n'
               'def f():\n    import ftplib\n')
        found = sorted(m for _, m in _imports(_module_level(ast.parse(src))) if _deny_hit(m))
        self.assertEqual(found, ['ctypes', 'http.client', 'urllib.request'])
        self.assertTrue(_deny_hit('concurrent.futures.process'))
        self.assertFalse(_deny_hit('urllib.parse'))

    def test_x4_deny_list_matches_runner_when_present(self):
        runner = os.path.join(os.path.dirname(os.path.dirname(TESTS_DIR)), 'runner',
                              'run_p2_tests_guarded_v2_1.py')
        if not os.path.isfile(runner):
            self.skipTest('NOT RUN: runner/ is not next to the tree here (it is in the candidate ZIP)')
        with open(runner, encoding='utf-8') as f:
            tree = ast.parse(f.read())
        node = next(n for n in tree.body if isinstance(n, ast.Assign)
                    and getattr(n.targets[0], 'id', None) == 'DENY_IMPORTS')
        self.assertEqual(frozenset(ast.literal_eval(node.value.args[0])), RUNNER_DENY_IMPORTS)


if __name__ == '__main__':
    unittest.main()
