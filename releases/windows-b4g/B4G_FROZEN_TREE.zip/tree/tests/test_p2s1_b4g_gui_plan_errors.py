"""P2 Slice 1 / B4g: macOS Wizard FULL file export first-use workflow (D1, G1-G7), the
macOS --plan-file destination policy (D2, P1), sanitized export/plan error texts (D3, P2),
offline tripwires (P3) and Windows/Linux parity (G7, S1).

Every darwin test patches sys.platform to 'darwin' and asserts EVERY is_darwin copy
(platform_p2, cli, deploy_lib, capability_gate, quick_reg, model, native_gateway). Google
Drive detection inputs (home, app path, /Volumes) are ALWAYS pointed at a fixture Mac in a
real temp folder, so nothing reads or modifies the real home, /Applications, /Volumes or
~/Library. Wizard handlers are driven WITHOUT a display: the REAL Wizard._export_darwin /
Wizard._export functions are called with a minimal fake `self`, and the wizard module's
`filedialog` / `messagebox` are replaced by recorders (asksaveasfilename return values are
the test inputs). If tkinter is not installed, wizard.py is loaded under a private module
name with a stub tkinter (the stub is removed from sys.modules again right after loading).
Synthetic identities only. No network, SSH, subprocess or Tk window.

Class prefixes: G_ = GUI requirement G1..G7, PL_ = plan file (P1), E_ = export/dialog
error texts (D3), S_ = generic sanitization (P2), N_ = offline tripwires (P3), W_ =
Windows/Linux parity (G7/S1), T_ = positive controls, X_ = static.
"""
import ast
import contextlib
import io
import json
import os
import socket
import sqlite3
import stat
import sys
import tempfile
import unittest
from unittest import mock

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import capability_gate
import cli
import deploy_lib
import model
import native_gateway
import platform_p2
import quick_reg

TESTS_DIR = os.path.dirname(os.path.abspath(__file__))
TREE_DIR = os.path.dirname(TESTS_DIR)
USER = 'fakeuser'
HOST = 'gateway.example.com'
ACCOUNT = 'fakeuser@example.com'
TOKEN = 'EXPORT FULL'
URL = 'https://abc123.lambda-url.us-west-2.on.aws/mcp'
PRIVATE_PARTS = ('.aq_mcp_wizard', 'private_exports')
POSIX_OWNER = hasattr(os, 'getuid') and os.name != 'nt'
WATCHED_IMPORTS = ('ssl', '_ssl', 'http.client', 'urllib.request', 'ftplib', 'smtplib', 'imaplib',
                   'poplib', 'xmlrpc.client', 'socketserver', 'asyncio', 'multiprocessing',
                   'ctypes', 'webbrowser', 'paramiko', 'subprocess', 'requests', 'urllib3')
MAIN_SEGMENT_SHA256 = 'f779013323db90db8b22e9c3886dfde142508bdda53dd0c5dc51331737f6f648'
MAIN_HANDLER_TEXT = ("if __name__=='__main__':\n    try:sys.exit(main())\n    except Exception as e:\n"
                     "        print('ERROR: '+str(e),file=sys.stderr);sys.exit(1)\n")


def spec(user=USER, host=HOST, target='demo-epg'):
    return {'transport': 'linux-ssh', 'host': host, 'user': user, 'kind': 'lambda',
            'target': target, 'url': URL, 'allow': ['list_things']}


def _absent(mod, name):
    """create=True only where the attribute does not exist (older tree in a defect-proof run);
    on the B4g tree every patched helper exists and is restored normally."""
    return not hasattr(mod, name)


def _new(mod, name):
    """A B4g constant, or a visible placeholder on an older tree (defect-proof runs)."""
    return getattr(mod, name, '<missing B4g constant ' + name + '>')


# ------------------------------------------------------------------ wizard without a display
def _stub_tk_modules():
    def mod(name):
        m = type(sys)(name)
        return m

    class _Widget(object):
        def __init__(self, *a, **k):
            pass

        def __getattr__(self, name):
            return lambda *a, **k: None
    tk = mod('tkinter')
    for n in ('Tk', 'Toplevel', 'Frame', 'Label', 'Button', 'Entry', 'Text', 'Canvas',
              'StringVar', 'IntVar', 'BooleanVar', 'Listbox', 'Scrollbar', 'Checkbutton'):
        setattr(tk, n, _Widget)
    for n in ('END', 'BOTH', 'LEFT', 'RIGHT', 'X', 'Y', 'W', 'E', 'N', 'S', 'NORMAL', 'DISABLED',
              'WORD', 'TOP', 'BOTTOM', 'NW', 'INSERT', 'HORIZONTAL', 'VERTICAL'):
        setattr(tk, n, n.lower())
    tk.TclError = type('TclError', (Exception,), {})
    subs = {}
    for n in ('ttk', 'messagebox', 'filedialog'):
        s = mod('tkinter.' + n)
        for w in ('Frame', 'Label', 'Button', 'Entry', 'Combobox', 'Style', 'Checkbutton',
                  'Scrollbar', 'Treeview', 'Notebook', 'Progressbar', 'Radiobutton'):
            setattr(s, w, _Widget)
        setattr(tk, n, s)
        subs['tkinter.' + n] = s
    subs['tkinter'] = tk
    return subs


def _load_wizard():
    try:
        import wizard
        return wizard, 'real tkinter'
    except ImportError:
        pass
    try:
        import importlib.util
        stubs = _stub_tk_modules()
        saved = dict((k, sys.modules[k]) for k in stubs if k in sys.modules)
        sys.modules.update(stubs)
        try:
            spec_ = importlib.util.spec_from_file_location('wizard_b4g_stub_tk',
                                                           os.path.join(TREE_DIR, 'wizard.py'))
            w = importlib.util.module_from_spec(spec_)
            spec_.loader.exec_module(w)
        finally:
            for k in stubs:
                sys.modules.pop(k, None)
            sys.modules.update(saved)
        return w, 'stub tkinter (no Tk installed)'
    except Exception as exc:  # noqa: BLE001 - reported as a visible skip
        return None, 'wizard.py not loadable here: ' + type(exc).__name__


WIZ, WIZ_MODE = _load_wizard()


def _need_wizard(tc):
    if WIZ is None:
        tc.skipTest('NOT RUN: ' + WIZ_MODE)


def _darwin_copies():
    out = {'platform_p2.is_darwin': platform_p2.is_darwin,
           'cli.platform_p2.is_darwin': cli.platform_p2.is_darwin,
           'deploy_lib.platform_p2.is_darwin': deploy_lib.platform_p2.is_darwin,
           'capability_gate.is_darwin': capability_gate.is_darwin,
           'quick_reg._p2_is_darwin': quick_reg._p2_is_darwin,
           'model._p2_is_darwin': model._p2_is_darwin,
           'native_gateway._p2_is_darwin': native_gateway._p2_is_darwin}
    if WIZ is not None:
        out['wizard.is_darwin'] = WIZ.is_darwin
    return out


@contextlib.contextmanager
def platform_as(name):
    with mock.patch.object(sys, 'platform', name):
        want = (name == 'darwin')
        bad = sorted(k for k, f in _darwin_copies().items() if bool(f()) != want)
        if bad:
            raise AssertionError('platform emulation incomplete for: ' + ', '.join(bad))
        yield


class Tripwire(object):
    """Refuses and records network / DNS (incl. reverse lookups) / TLS / HTTP / process /
    paramiko activity. Never imports a module itself (ImportWatch reports new imports)."""

    def __init__(self):
        self.hits = []
        self.targets = []

    def _trip(self, what):
        def f(*a, **k):
            self.hits.append(what)
            raise AssertionError('TRIPWIRE: ' + what)
        return f

    def __enter__(self):
        hits = self.hits

        class _ParamikoBomb(object):
            def __getattr__(self, name):
                hits.append('paramiko.' + name)
                raise AssertionError('TRIPWIRE: paramiko used')

        t = []
        for n in ('socket', 'create_connection', 'create_server', 'socketpair', 'getaddrinfo',
                  'gethostbyname', 'gethostbyname_ex', 'gethostbyaddr', 'getnameinfo', 'getfqdn'):
            if hasattr(socket, n):
                t.append((socket, n, 'socket.' + n))
        low = sys.modules.get('_socket')
        if low is not None:
            for n in ('getaddrinfo', 'gethostbyname', 'gethostbyname_ex', 'gethostbyaddr',
                      'getnameinfo'):
                if hasattr(low, n):
                    t.append((low, n, '_socket.' + n))
        ssl_m = sys.modules.get('ssl')
        if ssl_m is not None:
            t += [(ssl_m, 'create_default_context', 'ssl.create_default_context'),
                  (ssl_m.SSLContext, 'wrap_socket', 'ssl.SSLContext.wrap_socket')]
        ur = sys.modules.get('urllib.request')
        if ur is not None:
            t.append((ur, 'urlopen', 'urllib.request.urlopen'))
        hc = sys.modules.get('http.client')
        if hc is not None:
            t += [(hc.HTTPConnection, 'connect', 'http.client.HTTPConnection.connect'),
                  (hc.HTTPSConnection, 'connect', 'http.client.HTTPSConnection.connect')]
        sp = sys.modules.get('subprocess')
        if sp is not None:
            for n in ('Popen', 'run', 'call', 'check_call', 'check_output', 'getoutput',
                      'getstatusoutput'):
                t.append((sp, n, 'subprocess.' + n))
        for n in ('system', 'popen', 'execv', 'execve', 'execvp', 'execvpe', 'execl', 'execlp',
                  'spawnv', 'spawnvp', 'spawnl', 'posix_spawn', 'posix_spawnp', 'fork', 'forkpty',
                  'startfile'):
            if hasattr(os, n):
                t.append((os, n, 'os.' + n))
        self.targets = t
        self._patches = [mock.patch.object(o, n, self._trip(lab)) for o, n, lab in t]
        self._patches.append(mock.patch.dict(sys.modules, {'paramiko': _ParamikoBomb()}))
        for p in self._patches:
            p.start()
        return self

    def __exit__(self, *exc):
        for p in reversed(self._patches):
            p.stop()
        return False


class ImportWatch(object):
    def __init__(self, watched=WATCHED_IMPORTS):
        self.watched = tuple(watched)
        self.new = []

    def __enter__(self):
        self._before = set(sys.modules)
        return self

    def __exit__(self, *exc):
        after = set(sys.modules)
        self.new = sorted(m for m in after - self._before
                          if any(m == w or m.startswith(w + '.') for w in self.watched))
        return False


def _builtins_module():
    try:
        import builtins
        return builtins
    except Exception:  # noqa: BLE001 - restricted interpreters
        return None


class DriveReadWatch(object):
    """Records any listdir / scandir / open / os.open / sqlite3.connect of a path under a
    DriveFS folder or a Google Drive root (lstat existence checks are allowed by policy)."""

    def __init__(self):
        self.hits = []
        self.open_watched = False

    @staticmethod
    def _bad(path):
        try:
            low = os.fspath(path).lower() if not isinstance(path, int) else ''
        except TypeError:
            return False
        if isinstance(low, bytes):
            low = low.decode('utf-8', 'replace')
        return 'drivefs' in low or quick_reg._p2_is_google_drive_location(low)

    def _wrap(self, label, real):
        def f(*a, **k):
            if a and self._bad(a[0]):
                self.hits.append(label)
            return real(*a, **k)
        return f

    def __enter__(self):
        self._p = [mock.patch.object(os, 'listdir', self._wrap('os.listdir', os.listdir)),
                   mock.patch.object(os, 'scandir', self._wrap('os.scandir', os.scandir)),
                   mock.patch.object(os, 'open', self._wrap('os.open', os.open)),
                   mock.patch.object(sqlite3, 'connect', self._wrap('sqlite3.connect', sqlite3.connect))]
        b = _builtins_module()
        if b is not None:
            self._p.append(mock.patch.object(b, 'open', self._wrap('open', b.open)))
            self.open_watched = True
        for p in self._p:
            p.start()
        return self

    def __exit__(self, *exc):
        for p in reversed(self._p):
            p.stop()
        return False


def _snapshot(root):
    out = []
    for base, dirs, files in os.walk(root):
        for n in dirs + files:
            out.append(os.path.relpath(os.path.join(base, n), root))
    return sorted(out)


class Dialog(object):
    """Stands in for tkinter.filedialog: records every asksaveasfilename call (kwargs) and
    returns the configured value (the test input)."""

    def __init__(self, ret, on_call=None):
        self.calls, self.ret, self.on_call = [], ret, on_call

    def asksaveasfilename(self, **kw):
        self.calls.append(dict(kw))
        if self.on_call is not None:
            self.on_call(kw)
        return self.ret

    def __getattr__(self, name):
        raise AssertionError('unexpected filedialog.' + name)


class MessageBox(object):
    def __init__(self):
        self.calls = []

    def __getattr__(self, name):
        def f(*a, **k):
            self.calls.append((name,) + a)
            return True
        return f

    def texts(self):
        return ' '.join(str(x) for c in self.calls for x in c[1:])


class FakeWizard(object):
    """The minimal `self` the export handlers use."""

    def __init__(self, sp, darwin=True):
        self._sp, self._darwin = sp, darwin

    def spec(self):
        return dict(self._sp)


def run_cli(argv):
    """cli.main(argv) in-process -> (code, stdout, stderr, SystemExit or None); an escaping
    Exception is printed exactly like cli.py's __main__ handler (which is unchanged)."""
    out, err = io.StringIO(), io.StringIO()
    code, sysexit = None, None
    with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
        try:
            code = cli.main(argv)
        except SystemExit as e:
            sysexit = e
            code = e.code if isinstance(e.code, int) else (0 if e.code is None else 2)
        except Exception as e:  # mirrors __main__
            print('ERROR: ' + str(e), file=sys.stderr)
            code = 1
    return code, out.getvalue(), err.getvalue(), sysexit


class _Base(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.root = os.path.realpath(self._tmp.name)
        self.mac = self.mk('mac')
        self.home = self.mk('mac', 'Users', USER)
        self.drive_app = os.path.join(self.mac, 'Applications', 'Google Drive.app')
        self.volumes = os.path.join(self.mac, 'Volumes')
        self.private = os.path.join(self.home, *PRIVATE_PARTS)

    def tearDown(self):
        for base, dirs, files in os.walk(self.root):
            for n in dirs:
                p = os.path.join(base, n)
                if not os.path.islink(p):
                    try:
                        os.chmod(p, 0o700)
                    except OSError:
                        pass
        self._tmp.cleanup()

    def mk(self, *parts):
        p = os.path.join(self.root, *parts)
        os.makedirs(p, exist_ok=True)
        return p

    def symlink(self, target, link):
        try:
            os.symlink(target, link)
        except (OSError, NotImplementedError, AttributeError):
            self.skipTest('NOT RUN: symlink creation not permitted on this machine')

    @contextlib.contextmanager
    def drive_env(self, home=None):
        h = self.home if home is None else home
        with mock.patch.object(quick_reg, '_p2_home', lambda: h, create=_absent(quick_reg, '_p2_home')), \
                mock.patch.object(quick_reg, '_P2_DRIVE_APP_PATHS', (self.drive_app,), create=_absent(quick_reg, '_P2_DRIVE_APP_PATHS')), \
                mock.patch.object(quick_reg, '_P2_VOLUMES_DIR', self.volumes, create=_absent(quick_reg, '_P2_VOLUMES_DIR')):
            yield

    def detect_drive(self):
        self.mk('mac', 'Users', USER, 'Library', 'Application Support', 'Google', 'DriveFS')

    def drive_root(self, *more):
        return self.mk('mac', 'Users', USER, 'Library', 'CloudStorage', 'GoogleDrive-' + ACCOUNT, *more)

    def need_posix_owner(self):
        if not POSIX_OWNER:
            self.skipTest('NOT RUN: POSIX owner/mode semantics not available on this OS')

    def need_safe_root(self):
        with self.drive_env():
            if quick_reg._p2_full_export_destination_unsafe(os.path.join(self.root, 'probe.json')):
                self.skipTest('ENVIRONMENT: the temp folder itself is classified unsafe (inside a '
                              'git work tree, a synced-named folder or the program folder); move TMPDIR')

    # -------------------------------------------------------------- GUI driver
    def gui(self, ret, redacted=False, ack=TOKEN, sp=None, home=None, on_call=None, writer=None):
        _need_wizard(self)
        dlg, mb = Dialog(ret, on_call), MessageBox()
        guard = mock.patch.object(quick_reg, '_p2_darwin_export_guard',
                                  wraps=quick_reg._p2_darwin_export_guard)
        with contextlib.ExitStack() as st:
            st.enter_context(platform_as('darwin'))
            st.enter_context(self.drive_env(home))
            iw = st.enter_context(ImportWatch())
            tw = st.enter_context(Tripwire())
            fw = st.enter_context(DriveReadWatch())
            st.enter_context(mock.patch.object(WIZ, 'filedialog', dlg))
            st.enter_context(mock.patch.object(WIZ, 'messagebox', mb))
            if writer is not None:
                st.enter_context(mock.patch.object(WIZ, 'write_quick_config', writer))
            g = st.enter_context(guard)
            WIZ.Wizard._export_darwin(FakeWizard(sp or spec()), redacted, ack)
        self.assertEqual(tw.hits, [], 'tripwire fired')
        self.assertEqual(iw.new, [], 'network/process module imported')
        self.assertEqual(fw.hits, [], 'Google Drive data read')
        self.guard = g
        return dlg, mb

    def errors(self, mb):
        return [c for c in mb.calls if c[0] == 'showerror']


def _trip(label):
    def f(*a, **k):
        raise AssertionError('TRIPWIRE: ' + label)
    return f


# ===================================================================== G1 / G2
class G1_NoCreationOutsideTheExportWorkflow(_Base):

    def test_g1a_wizard_module_never_calls_folder_helpers_at_import_or_construction(self):
        with open(os.path.join(TREE_DIR, 'wizard.py'), encoding='utf-8') as f:
            tree = ast.parse(f.read())
        names = ('p2_ensure_private_export_dir', 'p2_full_export_dialog_folder',
                 '_p2_private_dir_prevalidate')
        users = set()
        for cls in [n for n in tree.body if isinstance(n, ast.ClassDef)]:
            for fn in [m for m in cls.body if isinstance(m, ast.FunctionDef)]:
                for n in ast.walk(fn):
                    if isinstance(n, ast.Name) and n.id in names:
                        users.add(cls.name + '.' + fn.name)
        self.assertEqual(users, {'Wizard._export_darwin'})
        for n in tree.body:  # module level: no call of a folder helper
            if not isinstance(n, (ast.FunctionDef, ast.ClassDef)):
                for c in ast.walk(n):
                    if isinstance(c, ast.Name):
                        self.assertNotIn(c.id, names)

    def test_g1b_quick_reg_never_creates_at_import(self):
        with open(os.path.join(TREE_DIR, 'quick_reg.py'), encoding='utf-8') as f:
            tree = ast.parse(f.read())
        for n in tree.body:
            if isinstance(n, (ast.FunctionDef, ast.ClassDef, ast.Import, ast.ImportFrom)):
                continue
            for c in ast.walk(n):
                if isinstance(c, ast.Call):
                    self.assertIn(ast.unparse(c.func), ('_re.compile', 'frozenset', 'range'), ast.unparse(c)[:80])

    def test_g1c_loading_wizard_with_drive_detected_creates_nothing(self):
        _need_wizard(self)
        self.detect_drive()
        before = _snapshot(self.root)
        with self.drive_env():
            w2, _mode = _load_wizard()
        self.assertIsNotNone(w2)
        self.assertEqual(_snapshot(self.root), before)
        self.assertFalse(os.path.lexists(os.path.join(self.home, PRIVATE_PARTS[0])))


class G2_TokenBeforeAnything(_Base):

    def test_g2a_wrong_or_missing_token_no_dialog_no_folder(self):
        self.detect_drive()
        for bad in (None, '', 'export full', 'COPY FULL', 'EXPORT FULL ', 'EXPORT FULL\n'):
            with self.subTest(token=repr(bad)):
                before = _snapshot(self.root)
                with mock.patch.object(quick_reg, 'p2_full_export_dialog_folder',
                                       _trip('folder helper before token'), create=_absent(quick_reg, 'p2_full_export_dialog_folder')), \
                        mock.patch.object(quick_reg, 'p2_ensure_private_export_dir',
                                          _trip('creator before token')):
                    dlg, mb = self.gui(os.path.join(self.private, 'x.json'), ack=bad,
                                       writer=_trip('writer'))
                self.assertEqual(dlg.calls, [], 'dialog opened before the token was accepted')
                errs = self.errors(mb)
                self.assertEqual(len(errs), 1)
                self.assertEqual(errs[0][1], 'Export failed')
                self.assertIn('typed confirmation', errs[0][2])
                self.assertEqual(_snapshot(self.root), before)

    def test_g2b_full_handler_still_requires_yes_and_token(self):
        _need_wizard(self)
        self.detect_drive()
        exported = []
        for typed in (None, 'export full', 'COPY FULL'):
            fake = FakeWizard(spec())
            fake._typed_prompt = lambda *a, **k: typed
            fake._export_darwin = lambda r, a: exported.append((r, a))
            mb = MessageBox()
            with platform_as('darwin'), self.drive_env(), mock.patch.object(WIZ, 'messagebox', mb):
                WIZ.Wizard._export_full_darwin(fake)
        self.assertEqual(exported, [])
        self.assertFalse(os.path.lexists(os.path.join(self.home, PRIVATE_PARTS[0])))


# ===================================================================== G3 / G4
class G3_FolderValidatedThenCreated(_Base):

    def test_g3a_first_use_creates_0700_and_dialog_opens_inside(self):
        self.need_posix_owner()
        self.need_safe_root()
        self.detect_drive()
        seen = []

        def at_dialog(kw):
            d = kw.get('initialdir')
            seen.append((d, os.path.isdir(d) if d else None,
                         stat.S_IMODE(os.lstat(d).st_mode) if d else None))
        dest = os.path.join(self.private, 'full.json')
        dlg, mb = self.gui(dest, on_call=at_dialog)
        self.assertEqual(len(dlg.calls), 1)
        self.assertEqual(dlg.calls[0].get('initialdir'), self.private)
        self.assertEqual(seen, [(self.private, True, 0o700)])
        self.assertEqual(stat.S_IMODE(os.lstat(os.path.join(self.home, PRIVATE_PARTS[0])).st_mode), 0o700)
        self.assertEqual(self.errors(mb), [], mb.calls)
        self.assertEqual(stat.S_IMODE(os.stat(dest).st_mode), 0o600)
        with open(dest, encoding='utf-8') as f:
            self.assertIn(USER + '@' + HOST, f.read())
        self.assertTrue(self.guard.called, 'write_quick_config guard did not run')
        self.assertTrue(any(c[0] == 'showinfo' for c in mb.calls))

    def test_g3b_validation_precedes_creation(self):
        self.need_posix_owner()
        self.need_safe_root()
        self.detect_drive()
        log = []
        real_pre, real_mkdir = getattr(quick_reg, '_p2_private_dir_prevalidate', lambda: True), os.mkdir

        def pre():
            log.append('validate')
            return real_pre()

        def mkdir(p, *a, **k):
            log.append('mkdir')
            return real_mkdir(p, *a, **k)
        with mock.patch.object(quick_reg, '_p2_private_dir_prevalidate', pre, create=_absent(quick_reg, '_p2_private_dir_prevalidate')), \
                mock.patch.object(os, 'mkdir', mkdir):
            self.gui('')
        self.assertIn('mkdir', log)
        self.assertEqual(log[0], 'validate')
        self.assertLess(log.index('validate'), log.index('mkdir'))

    def _assert_unsafe(self, home=None, expect_created=False):
        before = _snapshot(self.root)
        with mock.patch.object(quick_reg, 'p2_ensure_private_export_dir',
                               wraps=quick_reg.p2_ensure_private_export_dir) as ens:
            dlg, mb = self.gui(os.path.join(self.private, 'x.json'), home=home, writer=_trip('writer'))
        self.assertEqual(dlg.calls, [], 'a dialog was opened although the folder is unsafe')
        self.assertEqual(self.errors(mb), [('showerror', 'Export refused',
                                            _new(quick_reg, 'P2_FULL_EXPORT_GUI_FOLDER_UNSAFE'))])
        if not expect_created:
            self.assertEqual(_snapshot(self.root), before, 'refusal created something')
        return ens

    def test_g3c_unsafe_existing_components_refused_nothing_created(self):
        self.need_posix_owner()
        self.detect_drive()
        outer = os.path.join(self.home, PRIVATE_PARTS[0])
        cases = ('outer_0755', 'inner_0755', 'outer_file', 'outer_link', 'inner_link')
        for case in cases:
            with self.subTest(case=case):
                self.tearDown()
                self.setUp()
                self.detect_drive()
                outer = os.path.join(self.home, PRIVATE_PARTS[0])
                if case == 'outer_0755':
                    os.mkdir(outer, 0o700)
                    os.chmod(outer, 0o755)
                elif case == 'inner_0755':
                    os.mkdir(outer, 0o700)
                    os.chmod(outer, 0o700)
                    os.mkdir(self.private, 0o700)
                    os.chmod(self.private, 0o755)
                elif case == 'outer_file':
                    with open(outer, 'w') as f:
                        f.write('x')
                elif case == 'outer_link':
                    tgt = self.mk('elsewhere')
                    os.chmod(tgt, 0o700)
                    self.symlink(tgt, outer)
                else:
                    os.mkdir(outer, 0o700)
                    os.chmod(outer, 0o700)
                    self.symlink(self.drive_root('My Drive'), self.private)
                ens = self._assert_unsafe()
                self.assertFalse(ens.called, 'creator called although pre-validation refused')

    def test_g3d_wrong_owner_refused(self):
        self.need_posix_owner()
        self.detect_drive()
        outer = os.path.join(self.home, PRIVATE_PARTS[0])
        os.mkdir(outer, 0o700)
        os.chmod(outer, 0o700)
        real = os.getuid()
        with mock.patch.object(os, 'getuid', lambda: real + 1):
            self._assert_unsafe()

    def test_g3e_unsafe_home_locations_refused(self):
        self.need_posix_owner()
        self.detect_drive()
        self.mk('mac', 'Applications', 'Google Drive.app')  # detected for every home below
        # (a) home is a git work tree (dotfiles repo, .git dir) / (b) .git FILE
        for kind in ('dir', 'file'):
            with self.subTest(home_git=kind):
                g = os.path.join(self.home, '.git')
                if kind == 'dir':
                    os.mkdir(g)
                else:
                    with open(g, 'w') as f:
                        f.write('gitdir: /elsewhere\n')
                self._assert_unsafe()
                (os.rmdir if kind == 'dir' else os.remove)(g)
        # (c) home inside a Google Drive root
        dh = self.drive_root('My Drive', 'h')
        with self.subTest(home='drive'):
            self._assert_unsafe(home=dh)
        # (d) home reached through a symlink
        link = os.path.join(self.root, 'homelink')
        self.symlink(self.home, link)
        with self.subTest(home='symlink'):
            self._assert_unsafe(home=link)
        # (e) home under a synced-named folder
        sh = self.mk('Dropbox', 'h')
        with self.subTest(home='synced'):
            self._assert_unsafe(home=sh)

    def test_g3f_creator_failure_refused_without_dialog(self):
        self.need_posix_owner()
        self.detect_drive()
        with mock.patch.object(quick_reg, 'p2_ensure_private_export_dir', lambda create=True: None):
            dlg, mb = self.gui(os.path.join(self.private, 'x.json'), writer=_trip('writer'))
        self.assertEqual(dlg.calls, [])
        self.assertEqual(self.errors(mb)[0][2], _new(quick_reg, 'P2_FULL_EXPORT_GUI_FOLDER_UNSAFE'))

    def test_g4_refusal_text_fixed_points_to_copy_full_no_unsynced_claim(self):
        msgs = (_new(quick_reg, 'P2_FULL_EXPORT_GUI_FOLDER_UNSAFE'), _new(quick_reg, 'P2_FULL_EXPORT_RETURNED_PATH_REFUSED'),
                _new(quick_reg, 'P2_PLAN_FILE_DEST_REFUSED'), _new(quick_reg, 'P2_PLAN_FILE_PRIVATE_DIR_ONLY'))
        for msg in msgs:
            low = msg.lower()
            for claim in ('unsynced', 'not synced', 'never synced', 'unsynchronized', 'guarantee',
                          '/users/', '/home/', 'errno', 'traceback'):
                self.assertNotIn(claim, low)
        for msg in msgs[:2]:
            self.assertIn('Copy FULL', msg)
            self.assertIn('cannot be inspected', msg)
        self.assertIn('cannot be inspected', _new(quick_reg, 'P2_PLAN_FILE_PRIVATE_DIR_ONLY'))
        with open(os.path.join(TREE_DIR, 'quick_reg.py'), encoding='utf-8') as f:
            tree = ast.parse(f.read())
        for name in ('P2_FULL_EXPORT_GUI_FOLDER_UNSAFE', 'P2_FULL_EXPORT_RETURNED_PATH_REFUSED',
                     'P2_PLAN_FILE_DEST_REFUSED', 'P2_PLAN_FILE_PRIVATE_DIR_ONLY'):
            nodes = [n for n in tree.body if isinstance(n, ast.Assign) and len(n.targets) == 1
                     and isinstance(n.targets[0], ast.Name) and n.targets[0].id == name]
            self.assertEqual(len(nodes), 1, name)
            self.assertIsInstance(nodes[0].value, ast.Constant, name)


# ===================================================================== G5
class G5_ReturnedPathRevalidated(_Base):

    def _prime(self):
        self.need_posix_owner()
        self.need_safe_root()
        self.detect_drive()
        self.assertEqual(quick_reg_ensure(self), self.private)

    def _refused(self, ret):
        before = _snapshot(self.root)
        dlg, mb = self.gui(ret, writer=_trip('writer reached'))
        self.assertEqual(len(dlg.calls), 1)
        self.assertEqual(dlg.calls[0].get('initialdir'), self.private)
        self.assertEqual(self.errors(mb), [('showerror', 'Export refused',
                                            _new(quick_reg, 'P2_FULL_EXPORT_RETURNED_PATH_REFUSED'))])
        self.assertEqual(_snapshot(self.root), before, 'something was written')

    def test_g5a_navigation_out_of_the_private_folder_refused(self):
        self._prime()
        repo = self.mk('repo')
        os.mkdir(os.path.join(repo, '.git'))
        repo2 = self.mk('repo2')
        with open(os.path.join(repo2, '.git'), 'w') as f:
            f.write('gitdir: /elsewhere\n')
        link = os.path.join(self.home, 'drivelink')
        self.symlink(self.drive_root('My Drive'), link)
        cases = {
            'drive_root': os.path.join(self.drive_root('My Drive'), 'x.json'),
            'drive_root_case': os.path.join(self.mk('mac', 'Users', USER, 'LIBRARY', 'cloudstorage',
                                                    'GOOGLEDRIVE-X'), 'x.json'),
            'git_dir': os.path.join(repo, 'x.json'),
            'git_file': os.path.join(repo2, 'x.json'),
            'symlink_into_drive': os.path.join(link, 'x.json'),
            'other_folder': os.path.join(self.mk('mac', 'Users', USER, 'Documents'), 'x.json'),
            'home': os.path.join(self.home, 'x.json'),
            'subfolder': os.path.join(self.mk('mac', 'Users', USER, *(PRIVATE_PARTS + ('sub',))), 'x.json'),
        }
        for label, ret in sorted(cases.items()):
            with self.subTest(case=label):
                self._refused(ret)

    def test_g5b_shape_variants_refused(self):
        self._prime()
        cases = (os.path.join(self.private, '..', 'private_exports', 'x.json'),
                 os.path.join(self.private, 'sub', '..', 'x.json'),
                 self.private + '/./x.json',
                 'x.json', '~/.aq_mcp_wizard/private_exports/x.json',
                 os.path.join(self.private, 'x.txt'), os.path.join(self.private, 'x.json.txt'),
                 os.path.join(self.private, 'noext'), self.private + os.sep)
        for ret in cases:
            with self.subTest(ret=ret.replace(self.root, '<root>')):
                self._refused(ret)

    def test_g5c_symlink_named_file_inside_folder_refused(self):
        self._prime()
        victim = os.path.join(self.mk('victim'), 'v.json')
        self.symlink(victim, os.path.join(self.private, 'link.json'))
        dlg, mb = self.gui(os.path.join(self.private, 'link.json'), writer=_trip('writer'))
        self.assertEqual(self.errors(mb)[0][2], _new(quick_reg, 'P2_FULL_EXPORT_RETURNED_PATH_REFUSED'))
        self.assertFalse(os.path.lexists(victim))

    def test_g5d_revalidated_twice_and_last_check_is_right_before_writer(self):
        self._prime()
        dest = os.path.join(self.private, 'twice.json')
        order = []
        real_check = getattr(quick_reg, 'p2_full_export_returned_path_refusal', lambda p, f: None)
        real_quick = quick_reg.p2_export_destination_refused

        def check(p, folder):
            order.append(('check', p))
            return real_check(p, folder)

        def quick(p, *a):
            order.append(('quick', p))
            return real_quick(p, *a)

        def writer(sp, p, **kw):
            order.append(('write', p))
            return WIZ_REAL_WRITER(sp, p, **kw)
        with mock.patch.object(quick_reg, 'p2_full_export_returned_path_refusal', check, create=_absent(quick_reg, 'p2_full_export_returned_path_refusal')), \
                mock.patch.object(quick_reg, 'p2_export_destination_refused', quick):
            self.gui(dest, writer=writer)
        mine = [o[0] for o in order if o[1] == dest]  # the folder checks use other probe paths
        self.assertEqual(mine[:4], ['check', 'quick', 'check', 'write'])
        self.assertTrue(os.path.isfile(dest))

    def test_g5e_second_check_refusal_stops_the_writer(self):
        self._prime()
        answers = [None, _new(quick_reg, 'P2_FULL_EXPORT_RETURNED_PATH_REFUSED')]
        with mock.patch.object(quick_reg, 'p2_full_export_returned_path_refusal',
                               lambda p, f: answers.pop(0), create=_absent(quick_reg, 'p2_full_export_returned_path_refusal')):
            dlg, mb = self.gui(os.path.join(self.private, 'late.json'), writer=_trip('writer'))
        self.assertEqual(answers, [])
        self.assertEqual(self.errors(mb)[0][2], _new(quick_reg, 'P2_FULL_EXPORT_RETURNED_PATH_REFUSED'))
        self.assertFalse(os.path.lexists(os.path.join(self.private, 'late.json')))

    def test_g5f_writer_guard_still_runs_and_still_refuses(self):
        # the writer's own guard is kept: a token that the wizard check would pass is still
        # re-checked inside write_quick_config (here: guard sees a wrong token)
        self._prime()
        dest = os.path.join(self.private, 'g.json')

        def writer(sp, p, **kw):
            kw['full_ack'] = 'wrong'
            return WIZ_REAL_WRITER(sp, p, **kw)
        dlg, mb = self.gui(dest, writer=writer)
        self.assertTrue(self.guard.called)
        self.assertEqual(self.errors(mb)[0][1], 'Export failed')
        self.assertFalse(os.path.lexists(dest))


def quick_reg_ensure(tc):
    with tc.drive_env():
        return quick_reg.p2_ensure_private_export_dir(create=True)


WIZ_REAL_WRITER = quick_reg.write_quick_config


# ===================================================================== G6
class G6_CancelWritesNothing(_Base):

    def test_g6a_cancel_after_creation_leaves_only_empty_folder(self):
        self.need_posix_owner()
        self.need_safe_root()
        self.detect_drive()
        for ret in ('', (), None):
            with self.subTest(ret=repr(ret)):
                dlg, mb = self.gui(ret, writer=_trip('writer on cancel'))
                self.assertEqual(len(dlg.calls), 1)
                self.assertEqual(mb.calls, [], 'cancel produced a dialog message')
                self.assertTrue(os.path.isdir(self.private))
                self.assertEqual(os.listdir(self.private), [])

    def test_g6b_cancel_drive_not_detected_creates_nothing(self):
        before = _snapshot(self.root)
        dlg, mb = self.gui('', writer=_trip('writer on cancel'))
        self.assertEqual(mb.calls, [])
        self.assertEqual(_snapshot(self.root), before)


# ===================================================================== G7
class G7_DriveNotDetectedAndParity(_Base):

    def test_g7a_not_detected_b4f_dialog_no_initialdir_no_creation(self):
        self.need_safe_root()
        dest = os.path.join(self.mk('out'), 'full.json')
        dlg, mb = self.gui(dest)
        self.assertEqual(dlg.calls, [{'title': 'Save FULL example - contains real login/host',
                                      'defaultextension': '.json', 'filetypes': [('JSON', '*.json')]}])
        self.assertFalse(os.path.lexists(os.path.join(self.home, PRIVATE_PARTS[0])))
        self.assertTrue(os.path.isfile(dest))
        self.assertEqual(self.errors(mb), [])

    def test_g7b_not_detected_git_and_drive_still_refused_before_writer(self):
        repo = self.mk('repo')
        os.mkdir(os.path.join(repo, '.git'))
        drive_elsewhere = self.mk('elsewhere', 'Library', 'CloudStorage', 'GoogleDrive-' + ACCOUNT)
        for ret in (os.path.join(repo, 'x.json'), os.path.join(drive_elsewhere, 'x.json')):
            with self.subTest(ret=ret.replace(self.root, '<root>')):
                dlg, mb = self.gui(ret, writer=_trip('writer'))
                self.assertEqual(self.errors(mb)[0][2], _new(quick_reg, 'P2_FULL_EXPORT_RETURNED_PATH_REFUSED'))
                self.assertFalse(os.path.lexists(ret))

    def test_g7c_redacted_unaffected_with_drive_detected(self):
        self.need_safe_root()
        self.detect_drive()
        dest = os.path.join(self.mk('anywhere'), 'red.json')
        with mock.patch.object(quick_reg, 'p2_full_export_dialog_folder', _trip('folder helper on redacted'), create=_absent(quick_reg, 'p2_full_export_dialog_folder')), \
                mock.patch.object(quick_reg, 'p2_full_export_returned_path_refusal', _trip('revalidation on redacted'), create=_absent(quick_reg, 'p2_full_export_returned_path_refusal')):
            dlg, mb = self.gui(dest, redacted=True, ack=None)
        self.assertNotIn('initialdir', dlg.calls[0])
        self.assertTrue(os.path.isfile(dest))
        self.assertFalse(os.path.lexists(os.path.join(self.home, PRIVATE_PARTS[0])))

    def test_g7d_non_darwin_export_path_unchanged(self):
        _need_wizard(self)
        self.detect_drive()
        for plat in ('win32', 'linux'):
            with self.subTest(plat=plat):
                dest = os.path.join(self.mk('np_' + plat), 'full.json')
                dlg, mb, written = Dialog(dest), MessageBox(), []
                with platform_as(plat), self.drive_env(), \
                        mock.patch.object(WIZ, 'filedialog', dlg), mock.patch.object(WIZ, 'messagebox', mb), \
                        mock.patch.object(WIZ, 'write_quick_config',
                                          lambda sp, p, redacted=True: written.append((p, redacted))), \
                        mock.patch.object(quick_reg, 'p2_full_export_dialog_folder', _trip('helper off macOS'), create=_absent(quick_reg, 'p2_full_export_dialog_folder')), \
                        mock.patch.object(quick_reg, 'p2_full_export_returned_path_refusal', _trip('helper off macOS'), create=_absent(quick_reg, 'p2_full_export_returned_path_refusal')), \
                        mock.patch.object(quick_reg, 'p2_google_drive_detected', _trip('detection off macOS')):
                    WIZ.Wizard._export(FakeWizard(spec(), darwin=False), redacted=False)
                self.assertEqual(dlg.calls, [{'title': 'Save FULL example - contains real login/host',
                                              'defaultextension': '.json', 'filetypes': [('JSON', '*.json')]}])
                self.assertEqual(written, [(dest, False)])
                self.assertFalse(os.path.lexists(os.path.join(self.home, PRIVATE_PARTS[0])))

    def test_g7e_non_darwin_never_reaches_export_darwin(self):
        _need_wizard(self)
        fake = FakeWizard(spec(), darwin=False)
        fake._export_darwin = _trip('_export_darwin off macOS')
        dlg = Dialog('')
        with platform_as('win32'), mock.patch.object(WIZ, 'filedialog', dlg), \
                mock.patch.object(WIZ, 'messagebox', MessageBox()):
            WIZ.Wizard._export(fake, redacted=False)
        self.assertEqual(len(dlg.calls), 1)


# ===================================================================== E: D3 error texts
class E_ExportErrorTextsFixed(_Base):

    def _manifest(self, sp=None):
        m = os.path.join(self.root, 'manifest.json')
        with open(m, 'w', encoding='utf-8', newline='\n') as f:
            f.write(json.dumps(sp or spec()))
        return m

    def cli_export(self, dest, full=False, sp=None, extra_patch=None):
        argv = ['export', self._manifest(sp), '--output-file', dest]
        if full:
            argv += ['--full-export', '--ack', TOKEN]
        spy = mock.patch.object(cli, '_darwin_export', wraps=cli._darwin_export)
        with contextlib.ExitStack() as st:
            st.enter_context(platform_as('darwin'))
            st.enter_context(self.drive_env())
            tw = st.enter_context(Tripwire())
            s = st.enter_context(spy)
            if extra_patch is not None:
                st.enter_context(extra_patch)
            res = run_cli(argv)
        self.assertEqual(tw.hits, [])
        self.assertTrue(s.called, 'macOS export branch not taken')
        return res

    def assert_clean(self, text, *paths):
        for bad in ('Traceback', 'Errno', 'OSError', 'FileExistsError', 'PermissionError',
                    self.root) + tuple(paths):
            self.assertNotIn(bad, text)

    def test_e1_existing_export_file_fixed_exit_2_untouched(self):
        self.need_safe_root()
        d = self.mk('Users', USER, 'out')
        for full in (False, True):
            with self.subTest(full=full):
                dest = os.path.join(d, 'exists_%s.json' % full)
                with open(dest, 'wb') as f:
                    f.write(b'ORIGINAL')
                code, out, err, sysexit = self.cli_export(dest, full=full)
                self.assertEqual(code, 2)
                self.assertEqual(out, '')
                self.assertEqual(err, 'ERROR: ' + _new(cli, 'DARWIN_EXPORT_FILE_EXISTS') + '\n')
                self.assertIsNone(sysexit.__context__)
                self.assert_clean(err, dest)
                with open(dest, 'rb') as f:
                    self.assertEqual(f.read(), b'ORIGINAL')

    def test_e2_other_oserror_fixed_exit_1(self):
        self.need_safe_root()
        d = self.mk('Users', USER, 'out2')
        dest = os.path.join(d, 'x.json')

        def boom(path, text, newline='\n'):
            raise OSError(28, 'No space left on device', path)
        code, out, err, sysexit = self.cli_export(
            dest, full=True, extra_patch=mock.patch.object(quick_reg, 'secure_write_text', boom))
        self.assertEqual(code, 1)
        self.assertEqual(out, '')
        self.assertEqual(err, 'ERROR: ' + _new(cli, 'DARWIN_EXPORT_FILE_WRITE_ERROR') + '\n')
        self.assertIsNone(sysexit.__context__)
        self.assert_clean(err, dest)

    def test_e3_unwritable_folder_real_kernel_error(self):
        self.need_posix_owner()
        self.need_safe_root()
        if os.getuid() == 0:
            self.skipTest('NOT RUN: running as root (permission bits are not enforced)')
        d = self.mk('Users', USER, 'ro')
        os.chmod(d, 0o500)
        dest = os.path.join(d, 'x.json')
        code, out, err, _ = self.cli_export(dest)
        self.assertEqual(code, 1, err)
        self.assertEqual(err, 'ERROR: ' + _new(cli, 'DARWIN_EXPORT_FILE_WRITE_ERROR') + '\n')
        self.assert_clean(err, dest)
        self.assertFalse(os.path.lexists(dest))

    def test_e4_dangling_link_destination_fixed_text(self):
        self.need_safe_root()
        d = self.mk('Users', USER, 'dl')
        dest = os.path.join(d, 'x.json')
        self.symlink(os.path.join(d, 'missing', 'target.json'), dest)
        code, out, err, _ = self.cli_export(dest)
        self.assertIn(code, (1, 2))
        self.assertIn(err, ('ERROR: ' + _new(cli, 'DARWIN_EXPORT_FILE_EXISTS') + '\n',
                            'ERROR: ' + _new(cli, 'DARWIN_EXPORT_FILE_WRITE_ERROR') + '\n'))
        self.assert_clean(err, dest)
        self.assertFalse(os.path.lexists(os.path.join(d, 'missing')))

    def test_e5_wizard_dialog_texts_fixed(self):
        self.need_safe_root()
        d = self.mk('Users', USER, 'wz')
        dest = os.path.join(d, 'exists.json')
        with open(dest, 'w') as f:
            f.write('ORIGINAL')
        dlg, mb = self.gui(dest)
        self.assertEqual(self.errors(mb), [('showerror', 'Export failed', _new(WIZ, 'DARWIN_EXPORT_FILE_EXISTS_UI'))])

        def boom(path, text, newline='\n'):
            raise OSError(13, 'Permission denied', path)
        dest2 = os.path.join(d, 'new.json')
        with mock.patch.object(quick_reg, 'secure_write_text', boom):
            dlg, mb = self.gui(dest2)
        self.assertEqual(self.errors(mb), [('showerror', 'Export failed', _new(WIZ, 'DARWIN_EXPORT_FAILED_UI'))])
        self.assert_clean(mb.texts(), dest, dest2)

    def test_e6_main_and_main_handler_unchanged(self):
        with open(os.path.join(TREE_DIR, 'cli.py'), encoding='utf-8') as f:
            src = f.read()
        tree = ast.parse(src)
        fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'main')
        import hashlib
        self.assertEqual(hashlib.sha256(ast.get_source_segment(src, fn).encode('utf-8')).hexdigest(),
                         MAIN_SEGMENT_SHA256)
        self.assertTrue(src.endswith(MAIN_HANDLER_TEXT))
        for name in ('DARWIN_EXPORT_FILE_EXISTS', 'DARWIN_EXPORT_FILE_WRITE_ERROR'):
            nodes = [n for n in tree.body if isinstance(n, ast.Assign) and len(n.targets) == 1
                     and isinstance(n.targets[0], ast.Name) and n.targets[0].id == name]
            self.assertEqual(len(nodes), 1)
            self.assertIsInstance(nodes[0].value, ast.Constant)
        dx = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == '_darwin_export')
        for h in [h for n in ast.walk(dx) if isinstance(n, ast.Try) for h in n.handlers]:
            if h.type is not None and ast.unparse(h.type) in ('FileExistsError', 'OSError'):
                self.assertIsNone(h.name)
                for n in ast.walk(h):
                    self.assertNotIsInstance(n, ast.Raise)
                    if isinstance(n, ast.Call):
                        self.assertNotIn(ast.unparse(n.func), ('p.error', 'p.exit'))


# ===================================================================== PL: plan file (P1)
class _Plan(_Base):
    def setUp(self):
        _Base.setUp(self)
        self.manifest = os.path.join(self.root, 'manifest.json')
        self.write_manifest(spec())

    def write_manifest(self, sp):
        with open(self.manifest, 'w', encoding='utf-8', newline='\n') as f:
            f.write(json.dumps(sp))

    def run_plan(self, plan_file, forbid_prepare=False, expect_remote=True):
        argv = ['plan', self.manifest, '--plan-file', plan_file]
        spy = mock.patch.object(cli, '_darwin_remote', wraps=cli._darwin_remote)
        with contextlib.ExitStack() as st:
            st.enter_context(platform_as('darwin'))
            st.enter_context(self.drive_env())
            iw = st.enter_context(ImportWatch())
            tw = st.enter_context(Tripwire())
            fw = st.enter_context(DriveReadWatch())
            remote = st.enter_context(spy)
            if forbid_prepare:
                st.enter_context(mock.patch.object(deploy_lib.ConnectorDeployer, 'prepare_offline',
                                                   _trip('plan built before the destination check')))
            res = run_cli(argv)
        self.assertEqual(tw.hits, [], 'tripwire fired')
        self.assertEqual(iw.new, [], 'network/process module imported')
        self.assertEqual(fw.hits, [], 'Google Drive data read')
        if expect_remote:
            self.assertTrue(remote.called, 'macOS _darwin_remote branch not taken')
        return res

    def assert_plan_refused(self, plan_file, message):
        before = _snapshot(self.root)
        code, out, err, sysexit = self.run_plan(plan_file, forbid_prepare=True)
        self.assertEqual(code, 2, err)
        self.assertEqual(out, '')
        self.assertEqual(err, 'ERROR: ' + message + '\n')
        self.assertIsNotNone(sysexit)
        self.assertIsNone(sysexit.__context__)
        self.assertEqual(_snapshot(self.root), before, 'refusal created something')
        for bad in (USER, HOST, self.root, 'Traceback', 'Errno'):
            self.assertNotIn(bad, err)


class PL1_PlanFileDestinationPolicy(_Plan):

    def test_pl1a_git_drive_synced_program_relative_refused_before_plan(self):
        repo = self.mk('repo')
        os.mkdir(os.path.join(repo, '.git'))
        sub = self.mk('repo', 'a', 'b')
        repo2 = self.mk('repo2')
        with open(os.path.join(repo2, '.git'), 'w') as f:
            f.write('gitdir: /elsewhere\n')
        repo3 = self.mk('repo3')
        self.symlink(os.path.join(self.root, 'nowhere'), os.path.join(repo3, '.git'))
        safe = self.mk('safe')
        link = os.path.join(safe, 'lnk')
        self.symlink(sub, link)
        notdir = os.path.join(self.root, 'plainfile')
        with open(notdir, 'w') as f:
            f.write('x')
        cases = {
            'git_dir': os.path.join(repo, 'plan.json'),
            'git_subdir': os.path.join(sub, 'plan.json'),
            'git_file': os.path.join(repo2, 'plan.json'),
            'git_dangling_link': os.path.join(repo3, 'plan.json'),
            'drive_root': os.path.join(self.mk('elsewhere', 'Library', 'CloudStorage',
                                               'GoogleDrive-' + ACCOUNT, 'My Drive'), 'plan.json'),
            'drive_root_case': os.path.join(self.mk('elsewhere2', 'LIBRARY', 'cloudstorage',
                                                    'GOOGLEDRIVE'), 'plan.json'),
            'symlink_then_dotdot_into_repo': os.path.join(link, '..', 'plan.json'),
            'synced_dropbox': os.path.join(self.mk('Dropbox', 'n'), 'plan.json'),
            'synced_google_drive_name': os.path.join(self.mk('Google Drive'), 'plan.json'),
            'relative': 'plan_rel.json',
            'tilde': '~/plan_tilde.json',
            'parent_not_a_folder': os.path.join(notdir, 'plan.json'),
        }
        for label, dest in sorted(cases.items()):
            with self.subTest(case=label):
                self.assert_plan_refused(dest, _new(quick_reg, 'P2_PLAN_FILE_DEST_REFUSED'))
        self.assertFalse(os.path.lexists(os.path.join(repo, 'a', 'plan.json')))

    def test_pl1b_program_folder_refused(self):
        prog = self.mk('program')
        with mock.patch.object(quick_reg, '__file__', os.path.join(prog, 'quick_reg.py')):
            self.assert_plan_refused(os.path.join(prog, 'plan.json'), _new(quick_reg, 'P2_PLAN_FILE_DEST_REFUSED'))

    def test_pl1c_quick_owned_still_refused_by_preflight(self):
        dest = os.path.join(self.mk('qh'), 'mcp_config.json')
        before = _snapshot(self.root)
        code, out, err, _ = self.run_plan(dest, forbid_prepare=True, expect_remote=False)
        self.assertEqual(code, 2)
        self.assertEqual(out, '')
        self.assertIn('Quick-owned', err)
        self.assertEqual(_snapshot(self.root), before)

    def test_pl1d_safe_destination_not_detected_b4f_behaviour(self):
        self.need_posix_owner()
        self.need_safe_root()
        dest = os.path.join(self.mk('Users', USER, 'plans'), 'plan.json')
        code, out, err, _ = self.run_plan(dest)
        self.assertEqual(code, 0, err)
        self.assertEqual(stat.S_IMODE(os.stat(dest).st_mode), 0o600)
        with open(dest, encoding='utf-8') as f:
            self.assertIn(USER, f.read())  # private, unredacted file (unchanged)
        self.assertNotIn(USER, out)       # redacted stdout (unchanged)
        code, out, err, _ = self.run_plan(dest)
        self.assertEqual((code, out), (2, ''))
        self.assertEqual(err, 'ERROR: ' + cli.DARWIN_PLAN_FILE_EXISTS + '\n')

    def test_pl1e_missing_parent_keeps_b4f_write_error(self):
        dest = os.path.join(self.mk('Users', USER), 'no-such-folder', 'plan.json')
        before = _snapshot(self.root)
        code, out, err, _ = self.run_plan(dest)
        self.assertEqual(code, 1)
        self.assertEqual(err, 'ERROR: ' + cli.DARWIN_PLAN_FILE_WRITE_ERROR + '\n')
        self.assertEqual(_snapshot(self.root), before)

    def test_pl1f_symlink_final_component_not_followed(self):
        self.need_safe_root()
        d = self.mk('Users', USER, 'pl')
        victim = os.path.join(self.mk('victim'), 'v.json')
        self.symlink(victim, os.path.join(d, 'plan.json'))
        code, out, err, _ = self.run_plan(os.path.join(d, 'plan.json'))
        self.assertNotEqual(code, 0)
        self.assertEqual(out, '')
        self.assertFalse(os.path.lexists(victim))
        self.assertNotIn(self.root, err)


class PL2_PlanFilePrivateFolderWhenDriveDetected(_Plan):

    def test_pl2a_outside_designated_refused_folder_not_created(self):
        self.need_safe_root()
        self.detect_drive()
        for dest in (os.path.join(self.mk('Users', USER, 'plans'), 'plan.json'),
                     os.path.join(self.home, 'plan.json'),
                     os.path.join(self.private, 'plan.json')):  # folder missing: not created here
            with self.subTest(dest=dest.replace(self.root, '<root>')):
                self.assert_plan_refused(dest, _new(quick_reg, 'P2_PLAN_FILE_PRIVATE_DIR_ONLY'))
                self.assertFalse(os.path.lexists(os.path.join(self.home, PRIVATE_PARTS[0])))

    def test_pl2b_inside_existing_folder_written_0600_create_only(self):
        self.need_posix_owner()
        self.need_safe_root()
        self.detect_drive()
        self.assertEqual(quick_reg_ensure(self), self.private)
        for name in ('plan.json', 'plan.txt'):  # no .json forcing for plan files (decision)
            with self.subTest(name=name):
                dest = os.path.join(self.private, name)
                code, out, err, _ = self.run_plan(dest)
                self.assertEqual(code, 0, err)
                self.assertEqual(stat.S_IMODE(os.stat(dest).st_mode), 0o600)
                with open(dest, 'rb') as f:
                    body = f.read()
                code, out, err, _ = self.run_plan(dest)
                self.assertEqual((code, out), (2, ''))
                self.assertEqual(err, 'ERROR: ' + cli.DARWIN_PLAN_FILE_EXISTS + '\n')
                with open(dest, 'rb') as f:
                    self.assertEqual(f.read(), body)

    def test_pl2c_shape_and_link_variants_refused(self):
        self.need_posix_owner()
        self.need_safe_root()
        self.detect_drive()
        self.assertEqual(quick_reg_ensure(self), self.private)
        victim = os.path.join(self.mk('victim'), 'v.json')
        self.symlink(victim, os.path.join(self.private, 'link.json'))
        os.mkdir(os.path.join(self.private, 'sub'), 0o700)
        for dest, msg in ((os.path.join(self.private, 'link.json'), _new(quick_reg, 'P2_PLAN_FILE_PRIVATE_DIR_ONLY')),
                          (os.path.join(self.private, 'sub', 'p.json'), _new(quick_reg, 'P2_PLAN_FILE_PRIVATE_DIR_ONLY')),
                          (os.path.join(self.private, '..', 'private_exports', 'p.json'),
                           _new(quick_reg, 'P2_PLAN_FILE_PRIVATE_DIR_ONLY')),
                          ('~/.aq_mcp_wizard/private_exports/p.json', _new(quick_reg, 'P2_PLAN_FILE_DEST_REFUSED'))):
            with self.subTest(dest=dest.replace(self.root, '<root>')):
                self.assert_plan_refused(dest, msg)
        self.assertFalse(os.path.lexists(victim))

    def test_pl2d_unsafe_existing_folder_refused(self):
        self.need_posix_owner()
        self.need_safe_root()
        self.detect_drive()
        self.assertEqual(quick_reg_ensure(self), self.private)
        os.chmod(self.private, 0o755)
        self.assert_plan_refused(os.path.join(self.private, 'p.json'), _new(quick_reg, 'P2_PLAN_FILE_PRIVATE_DIR_ONLY'))


# ===================================================================== S: P2 sanitization
DIST_USER, DIST_HOST, DIST_HOME = 'zqu7731', 'zqh7731.example.com', 'zqhome7731'


class S_NoIdentityOrPathInAnyNewErrorText(_Plan):
    """P2: every new/changed refusal or error path, with distinctive fake user / host / home
    values: none of them (nor the temp path) appears in stdout, stderr or a dialog text."""

    def setUp(self):
        _Plan.setUp(self)
        self.home = self.mk('mac', 'Users', DIST_HOME)
        self.private = os.path.join(self.home, *PRIVATE_PARTS)
        self.dsp = spec(user=DIST_USER, host=DIST_HOST)
        self.write_manifest(self.dsp)

    def detect(self):
        self.mk('mac', 'Users', DIST_HOME, 'Library', 'Application Support', 'Google', 'DriveFS')

    def test_s1_all_new_paths(self):
        texts = []
        repo = self.mk('repo')
        os.mkdir(os.path.join(repo, '.git'))
        okdir = self.mk('mac', 'Users', DIST_HOME, 'out')
        # CLI plan: destination refusal, relative refusal, write error, existing file
        for dest in (os.path.join(repo, 'p.json'), 'rel.json', os.path.join(okdir, 'nope', 'p.json')):
            code, out, err, _ = self.run_plan(dest)
            self.assertNotEqual(code, 0)
            texts += [out, err]
        existing = os.path.join(okdir, 'exists.json')
        with open(existing, 'w') as f:
            f.write('x')
        code, out, err, _ = self.run_plan(existing)
        texts += [out, err]
        # CLI export: existing file, other OSError
        for full in (False, True):
            argv = ['export', self.manifest, '--output-file', existing] + (['--full-export', '--ack', TOKEN] if full else [])
            with platform_as('darwin'), self.drive_env():
                code, out, err, _ = run_cli(argv)
            self.assertEqual(code, 2, err)
            texts += [out, err]

        def boom(path, text, newline='\n'):
            raise OSError(13, 'Permission denied', path)
        with platform_as('darwin'), self.drive_env(), mock.patch.object(quick_reg, 'secure_write_text', boom):
            code, out, err, _ = run_cli(['export', self.manifest, '--output-file', os.path.join(okdir, 'n.json')])
        self.assertEqual(code, 1, err)
        texts += [out, err]
        # plan with Drive detected (M2)
        self.detect()
        code, out, err, _ = self.run_plan(os.path.join(okdir, 'm2.json'))
        self.assertEqual(code, 2)
        texts += [out, err]
        # Wizard: wrong token, folder unsafe, returned path refused, existing file, file error
        if WIZ is not None and POSIX_OWNER:
            dlg, mb = self.gui('', ack='nope', sp=self.dsp)
            texts.append(mb.texts())
            os.mkdir(os.path.join(self.home, PRIVATE_PARTS[0]), 0o755)
            os.chmod(os.path.join(self.home, PRIVATE_PARTS[0]), 0o755)
            dlg, mb = self.gui(os.path.join(self.private, 'x.json'), sp=self.dsp)
            texts.append(mb.texts())
            self.assertTrue(mb.texts())
            os.chmod(os.path.join(self.home, PRIVATE_PARTS[0]), 0o700)
            dlg, mb = self.gui(os.path.join(repo, 'x.json'), sp=self.dsp)
            texts.append(mb.texts())
            self.assertTrue(mb.texts())
            with open(os.path.join(self.private, 'e.json'), 'w') as f:
                f.write('x')
            dlg, mb = self.gui(os.path.join(self.private, 'e.json'), sp=self.dsp)
            texts.append(mb.texts())
            with mock.patch.object(quick_reg, 'secure_write_text', boom):
                dlg, mb = self.gui(os.path.join(self.private, 'f.json'), sp=self.dsp)
            texts.append(mb.texts())
        blob = '\n'.join(texts)
        self.assertTrue(blob.strip())
        for bad in (DIST_USER, DIST_HOST, DIST_HOME, self.root, 'Traceback', 'Errno', 'OSError',
                    'PermissionError', 'FileExistsError'):
            self.assertNotIn(bad, blob)


# ===================================================================== N: P3 offline
class N_NewPathsOfflineNoDriveReads(_Base):

    def _drive_fixture(self):
        self.detect_drive()
        fs = os.path.join(self.home, 'Library', 'Application Support', 'Google', 'DriveFS')
        with open(os.path.join(fs, 'secret.db'), 'w') as f:
            f.write('x')
        with open(os.path.join(self.drive_root('My Drive'), 'doc.txt'), 'w') as f:
            f.write('x')
        self.mk('mac', 'Volumes', 'GoogleDrive')

    def test_n1_helpers_under_tripwire_import_watch_and_drive_read_watch(self):
        self._drive_fixture()
        with platform_as('darwin'), self.drive_env(), ImportWatch() as iw, Tripwire() as tw, \
                DriveReadWatch() as fw:
            self.assertTrue(quick_reg.p2_google_drive_detected())
            quick_reg.p2_full_export_dialog_folder()
            quick_reg.p2_full_export_returned_path_refusal(os.path.join(self.private, 'x.json'), self.private)
            quick_reg.p2_full_export_returned_path_refusal(os.path.join(self.drive_root(), 'x.json'), None)
            quick_reg.p2_plan_file_destination_refusal(os.path.join(self.private, 'p.json'))
            quick_reg.p2_plan_file_destination_refusal(os.path.join(self.drive_root(), 'p.json'))
        self.assertEqual((tw.hits, iw.new, fw.hits), ([], [], []))

    def test_n2_dns_injected_into_new_path_is_caught(self):
        self._drive_fixture()
        real = getattr(quick_reg, '_p2_private_dir_prevalidate', lambda: True)

        def leaky():
            socket.getfqdn()
            return real()
        with platform_as('darwin'), self.drive_env(), Tripwire() as tw, \
                mock.patch.object(quick_reg, '_p2_private_dir_prevalidate', leaky, create=_absent(quick_reg, '_p2_private_dir_prevalidate')):
            folder, refusal = quick_reg.p2_full_export_dialog_folder()
        self.assertEqual(tw.hits, ['socket.getfqdn'])
        self.assertIsNone(folder)  # fail closed

    def test_n3_drive_read_watch_positive_control(self):
        self._drive_fixture()
        fs = os.path.join(self.home, 'Library', 'Application Support', 'Google', 'DriveFS')
        with DriveReadWatch() as fw:
            os.listdir(fs)
            os.listdir(self.drive_root('My Drive'))
        self.assertEqual(fw.hits, ['os.listdir', 'os.listdir'])
        if not fw.open_watched:
            self.skipTest('PARTIAL: builtins.open not patchable here (listdir/os.open/sqlite3 watched)')
        with DriveReadWatch() as fw:
            with open(os.path.join(fs, 'secret.db')) as f:
                f.read()
        self.assertEqual(fw.hits, ['open'])


class T_PositiveControls(unittest.TestCase):

    def test_t1_every_patched_entry_point_fires(self):
        with Tripwire() as tw:
            labels = [lab for _, _, lab in tw.targets]
            for obj, name, _ in tw.targets:
                with self.assertRaises(AssertionError):
                    getattr(obj, name)()
            with self.assertRaises(AssertionError):
                sys.modules['paramiko'].SSHClient
        self.assertEqual(len(tw.hits), len(labels) + 1, tw.hits)
        for must in ('socket.gethostbyaddr', 'socket.getnameinfo', 'socket.getfqdn', 'socket.getaddrinfo'):
            self.assertIn(must, labels)

    def test_t2_import_watch_reports_new_watched_module(self):
        probe = 'ssl.b4g_probe_watch'
        with ImportWatch() as iw:
            sys.modules[probe] = type(unittest)(probe)
        sys.modules.pop(probe, None)
        self.assertEqual(iw.new, [probe])

    def test_t3_wizard_load_mode_reported(self):
        # visible record of how wizard.py was loaded for the G tests
        if WIZ is None:
            self.skipTest('NOT RUN: ' + WIZ_MODE)
        self.assertIn(WIZ_MODE, ('real tkinter', 'stub tkinter (no Tk installed)'))


# ===================================================================== W: parity
class W_WindowsLinuxUnchanged(_Plan):

    def test_w1_non_darwin_plan_file_into_git_repo_still_written(self):
        repo = self.mk('repo')
        os.mkdir(os.path.join(repo, '.git'))
        sp = spec()
        prepared = model.plan(sp, '0' * 64)
        prepared['gateway'] = {'host': HOST, 'user': USER}
        prepared['existing_target_count'] = 0
        for plat in ('win32', 'linux'):
            with self.subTest(plat=plat):
                dest = os.path.join(repo, plat + '_plan.json')
                with platform_as(plat), mock.patch.object(cli, 'SSHG'), \
                        mock.patch.object(cli, 'ConnectorDeployer') as D, \
                        mock.patch.object(cli, '_darwin_remote', side_effect=AssertionError('darwin')), \
                        mock.patch.object(quick_reg, 'p2_plan_file_destination_refusal', _trip('off macOS'), create=_absent(quick_reg, 'p2_plan_file_destination_refusal')):
                    D.return_value.prepare.return_value = json.loads(json.dumps(prepared))
                    code, out, err, _ = run_cli(['plan', self.manifest, '--plan-file', dest])
                self.assertEqual(code, 0, err)
                self.assertTrue(os.path.isfile(dest))

    def test_w2_non_darwin_export_existing_file_legacy_error(self):
        d = self.mk('np_out')
        dest = os.path.join(d, 'x.json')
        with open(dest, 'w') as f:
            f.write('ORIGINAL')
        for plat in ('win32', 'linux'):
            with self.subTest(plat=plat):
                with platform_as(plat), mock.patch.object(cli, '_darwin_export', _trip('darwin export off macOS')):
                    code, out, err, _ = run_cli(['export', self.manifest, '--output-file', dest, '--full-export'])
                self.assertEqual(code, 1)
                self.assertEqual(err, 'ERROR: Refusing to overwrite an existing export.\n')
                self.assertNotIn(_new(cli, 'DARWIN_EXPORT_FILE_EXISTS'), err)

    def test_w3_non_darwin_full_export_into_git_repo_written(self):
        repo = self.mk('repo_w3')
        os.mkdir(os.path.join(repo, '.git'))
        for plat in ('win32', 'linux'):
            with self.subTest(plat=plat):
                dest = os.path.join(repo, plat + '.json')
                with platform_as(plat), mock.patch.object(quick_reg, '_p2_darwin_export_guard', _trip('guard')):
                    code, out, err, _ = run_cli(['export', self.manifest, '--output-file', dest, '--full-export'])
                self.assertEqual(code, 0, err)
                self.assertTrue(os.path.isfile(dest))


# ===================================================================== X: static
RUNNER_DENY_IMPORTS = frozenset(('ctypes', '_ctypes', 'multiprocessing', '_multiprocessing',
                                 'concurrent.futures.process', 'webbrowser', 'urllib.request',
                                 'http.client', 'ftplib', 'smtplib', 'imaplib', 'poplib',
                                 'xmlrpc.client'))


class X_Static(unittest.TestCase):

    def test_x1_this_file_has_no_runner_denied_import_anywhere(self):
        with open(os.path.join(TESTS_DIR, 'test_p2s1_b4g_gui_plan_errors.py'), encoding='utf-8') as f:
            tree = ast.parse(f.read())
        for n in ast.walk(tree):
            mods = []
            if isinstance(n, ast.Import):
                mods = [a.name for a in n.names]
            elif isinstance(n, ast.ImportFrom) and n.module:
                mods = [n.module] + [n.module + '.' + a.name for a in n.names]
            for m in mods:
                parts = m.split('.')
                self.assertFalse(any('.'.join(parts[:i]) in RUNNER_DENY_IMPORTS
                                     for i in range(1, len(parts) + 1)), m)

    def test_x2_changed_sources_tagged_ascii_lf(self):
        for name in ('quick_reg.py', 'cli.py', 'wizard.py'):
            with open(os.path.join(TREE_DIR, name), 'rb') as f:
                data = f.read()
            self.assertIn(b'[P2-S1 / B4g]', data, name)
            data.decode('ascii')
            self.assertNotIn(b'\r', data, name)
            self.assertTrue(data.endswith(b'\n'), name)

    def test_x3_new_quick_reg_helpers_only_called_from_darwin_call_sites(self):
        names = ('p2_full_export_dialog_folder', 'p2_full_export_returned_path_refusal',
                 'p2_plan_file_destination_refusal')
        for fname, allowed in (('wizard.py', {'_export_darwin'}), ('cli.py', {'_darwin_remote'}),
                               ('deploy_lib.py', set()), ('model.py', set()), ('native_gateway.py', set())):
            with open(os.path.join(TREE_DIR, fname), encoding='utf-8') as f:
                tree = ast.parse(f.read())
            users = set()
            for fn in ast.walk(tree):
                if isinstance(fn, ast.FunctionDef):
                    for n in ast.walk(fn):
                        if isinstance(n, ast.Name) and n.id in names:
                            users.add(fn.name)
            self.assertEqual(users, allowed, fname)


if __name__ == '__main__':
    unittest.main()
