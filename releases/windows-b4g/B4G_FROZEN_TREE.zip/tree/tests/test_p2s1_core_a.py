"""P2 Slice 1 B1a: native gateway disabled on darwin, model + quick_reg darwin rules.

Every darwin test drives the REAL function with sys.platform patched to 'darwin'
and tripwires armed. Windows-parity tests use literal constants captured from BASE.
"""
import json
import os
import shutil
import socket
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import native_gateway  # noqa: E402
import model  # noqa: E402
import quick_reg  # noqa: E402
import capability_gate  # noqa: E402
from deploy_lib import DeploymentError  # noqa: E402

MSG = 'Native gateway is not available on macOS in Slice 1; use the Linux SSH gateway'
NATIVE_SPEC = {'host': '127.0.0.1', 'user': 'local', 'transport': 'native-local',
               'kind': 'lambda', 'target': 'rtr-demo', 'display_name': 'Native RTR Demo',
               'url': 'https://abc.lambda-url.us-west-2.on.aws/mcp', 'allow': ['count_alerts']}
SSH_SPEC = {'host': 'gateway.example.com', 'user': 'fakeuser', 'transport': 'linux-ssh',
            'kind': 'lambda', 'target': 'rtr-demo', 'display_name': 'RTR Demo',
            'url': 'https://abc.lambda-url.us-west-2.on.aws/mcp', 'allow': ['count_alerts']}
ALL_OPS = ['inspect', 'bootstrap', 'discover', 'inspect_lambda_target', 'apply',
           'rollback', 'check', 'probe_existing', 'git_check', 'repair_permissions',
           'bogus', None]


def _trip(name):
    def f(*a, **k):
        raise AssertionError('TRIPWIRE: ' + name)
    return f


class Tripwires:
    """Arms subprocess/socket/sqlite/os.environ.copy/mkdir/open-write tripwires."""
    def __init__(self, tc, block_open_write=True):
        self.tc = tc
        self.block_open_write = block_open_write

    def __enter__(self):
        self.p = [
            mock.patch.object(subprocess, 'run', _trip('subprocess.run')),
            mock.patch.object(subprocess, 'Popen', _trip('subprocess.Popen')),
            mock.patch.object(subprocess, 'check_call', _trip('subprocess.check_call')),
            mock.patch.object(subprocess, 'check_output', _trip('subprocess.check_output')),
            mock.patch.object(os, 'system', _trip('os.system')),
            mock.patch.object(socket, 'socket', _trip('socket.socket')),
            mock.patch.object(socket, 'create_connection', _trip('socket.create_connection')),
            mock.patch.object(sqlite3, 'connect', _trip('sqlite3.connect')),
            mock.patch.object(Path, 'mkdir', _trip('Path.mkdir')),
            mock.patch.object(os, 'mkdir', _trip('os.mkdir')),
            mock.patch.object(os, 'makedirs', _trip('os.makedirs')),
            mock.patch.object(os, 'listdir', _trip('os.listdir')),
            mock.patch.object(tempfile, 'mkstemp', _trip('tempfile.mkstemp')),
            mock.patch.object(type(os.environ), 'copy', _trip('os.environ.copy')),
            mock.patch.object(quick_reg, 'secure_open', _trip('secure_open')),
        ]
        for x in self.p:
            x.start()
        return self

    def __exit__(self, *a):
        for x in reversed(self.p):
            x.stop()
        return False


def darwin():
    return mock.patch.object(sys, 'platform', 'darwin')


class NativeDisabledOnDarwin(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name) / 'AQ-MCP-Gateway'

    def _assert_refused(self, fn):
        with self.assertRaises(DeploymentError) as cm:
            fn()
        self.assertEqual(str(cm.exception), MSG)
        self.assertFalse(self.root.exists())

    def test_bootstrap_refused_nothing_created(self):
        gw = native_gateway.NativeGateway(self.root)
        with darwin(), Tripwires(self):
            self._assert_refused(lambda: gw.bootstrap(approved=True, install_dependencies=True))

    def test_bootstrap_refused_before_pip_even_if_root_missing_check_mocked(self):
        # Even if inspect() would report MISSING, nothing downstream is reached.
        gw = native_gateway.NativeGateway(self.root)
        calls = []
        with darwin(), Tripwires(self), \
                mock.patch.object(native_gateway.NativeGateway, 'inspect',
                                  lambda s: calls.append(1) or {'state': 'MISSING'}):
            self._assert_refused(lambda: gw.bootstrap(approved=True, install_dependencies=True))
        self.assertEqual(calls, [])  # refusal precedes even the inspect() call

    def test_run_every_op_refused(self):
        gw = native_gateway.NativeGateway(self.root)
        for op in ALL_OPS:
            req = {'op': op, 'confirm': 'CREATE_FRESH_GATEWAY', 'install_dependencies': True,
                   'entry': {'url': NATIVE_SPEC['url'], 'allow': ['count_alerts']},
                   'target': 'rtr-demo', 'receipt': {}, 'expected_sha256': '0' * 64}
            with self.subTest(op=op), darwin(), Tripwires(self):
                self._assert_refused(lambda: gw.run(req))

    def test_run_refuses_before_reading_request(self):
        gw = native_gateway.NativeGateway(self.root)
        with darwin(), Tripwires(self):
            self._assert_refused(lambda: gw.run(None))  # BASE would AttributeError

    def test_private_entry_points_refused(self):
        gw = native_gateway.NativeGateway(self.root)
        cases = {
            'inspect': lambda: gw.inspect(),
            '_load': lambda: gw._load(),
            '_probe_entry': lambda: gw._probe_entry({'url': NATIVE_SPEC['url']}),
            '_apply': lambda: gw._apply({'target': 'rtr-demo', 'entry': {}}),
            '_rollback': lambda: gw._rollback({}),
            'ensure_safe_root': lambda: native_gateway.ensure_safe_root(self.root),
            'atomic_write': lambda: native_gateway.atomic_write(self.root / 'x', b'x'),
        }
        for name, fn in cases.items():
            with self.subTest(fn=name), darwin(), Tripwires(self):
                self._assert_refused(fn)

    def test_exclusive_lock_refused(self):
        def use():
            with native_gateway.exclusive_lock(self.root):
                pass
        with darwin(), Tripwires(self):
            self._assert_refused(use)

    def test_init_does_nothing_on_darwin(self):
        with darwin(), Tripwires(self):
            gw = native_gateway.NativeGateway(self.root)
        self.assertEqual(gw.root, self.root.absolute())
        self.assertFalse(self.root.exists())

    def test_pure_helpers_unchanged_on_darwin(self):
        with darwin():
            self.assertEqual(native_gateway.local_python(Path('/r')),
                             Path('/r') / 'venv' / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python'))
            self.assertEqual(native_gateway.native_root(), Path.home() / 'AQ-MCP-Gateway')

    def test_no_darwin_tables_added(self):
        self.assertEqual(native_gateway.SUPPORTED_WINDOWS_INTERPRETERS,
                         (('CPython', (3, 13), 'win_amd64'),))
        self.assertFalse(hasattr(native_gateway, 'SUPPORTED_DARWIN_INTERPRETERS'))

    def test_refusal_is_first_statement_of_bootstrap_and_run(self):
        import ast
        tree = ast.parse(Path(native_gateway.__file__).read_text(encoding='utf-8'))
        cls = [n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'NativeGateway'][0]
        for fn in cls.body:
            if isinstance(fn, ast.FunctionDef) and fn.name in (
                    'bootstrap', 'run', 'inspect', '_load', '_probe_entry', '_apply', '_rollback'):
                first = fn.body[0]
                if isinstance(first, ast.Expr) and isinstance(getattr(first, 'value', None), ast.Constant) \
                        and isinstance(first.value.value, str):
                    first = fn.body[1]
                with self.subTest(fn=fn.name):
                    self.assertIsInstance(first, ast.Expr)
                    self.assertEqual(first.value.func.id, '_p2_refuse_native')


class ModelDarwin(unittest.TestCase):
    def test_validate_spec_rejects_native_local_on_darwin(self):
        with darwin(), Tripwires(self):
            with self.assertRaises(model.ValidationError) as cm:
                model.validate_spec(dict(NATIVE_SPEC))
        self.assertEqual(str(cm.exception), MSG)

    def test_quick_connector_native_refused_on_darwin(self):
        with darwin(), Tripwires(self):
            self.assertRaises(model.ValidationError, model.quick_connector, dict(NATIVE_SPEC))

    def test_ssh_spec_still_valid_on_darwin(self):
        with darwin(), Tripwires(self):
            self.assertEqual(model.validate_spec(dict(SSH_SPEC)), SSH_SPEC)


class QuickRegDarwin(unittest.TestCase):
    def test_find_configs_default_on_darwin_returns_empty_list_no_scan(self):
        with darwin(), Tripwires(self), \
                mock.patch.object(os.path, 'isfile', _trip('isfile')), \
                mock.patch.object(os.path, 'isdir', _trip('isdir')), \
                mock.patch.object(os.path, 'expanduser', _trip('expanduser')):
            self.assertEqual(quick_reg.find_quick_profile_configs(), [])
            self.assertEqual(quick_reg.find_quick_profile_configs(None), [])
            self.assertEqual(quick_reg.find_quick_profile_configs(''), [])

    def test_find_configs_explicit_home_reads_on_darwin(self):
        with tempfile.TemporaryDirectory() as d:
            (Path(d) / 'profiles' / 'p1').mkdir(parents=True)
            (Path(d) / 'profiles' / 'p1' / 'mcp_config.json').write_text('{}')
            (Path(d) / 'mcp_config.json').write_text('{}')
            with darwin():
                got = quick_reg.find_quick_profile_configs(d)
        self.assertEqual([os.path.relpath(p, d) for p in got],
                         ['mcp_config.json', os.path.join('profiles', 'p1', 'mcp_config.json')])

    def test_emit_import_file_refused_on_darwin_no_file(self):
        settings = {'command': 'ssh', 'args': ['-T', 'fakeuser@gateway.example.com', 'x'],
                    'name': 'rtr-demo'}
        with tempfile.TemporaryDirectory() as d:
            with darwin(), Tripwires(self):
                self.assertRaises(capability_gate.GateRefused, quick_reg.emit_quick_import_file,
                                  settings, d, allow_inside_repo=True)
            self.assertEqual(os.listdir(d), [])

    def test_dips_reader_refused_on_darwin_no_sqlite(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'x.db')
            open(p, 'wb').close()
            with darwin(), Tripwires(self):
                self.assertRaises(capability_gate.GateRefused, quick_reg.inspect_dips_read_only, p)

P2_REFUSED = ('Refusing this export destination on macOS: it is inside a Quick-owned '
              'folder or is a file named mcp_config.json. Quick configuration is never '
              'written in Slice 1 (preview only); choose a private folder elsewhere.')


class QuickRegExportGuardDarwin(unittest.TestCase):
    """User decision B (B3): the REAL quick_reg guard + write_quick_config on 'darwin',
    with HOME/USERPROFILE pointed at a temp folder holding a fake ~/.quickwork."""
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, self.tmp, True)
        self.home = os.path.join(self.tmp, 'home')
        self.qw = os.path.join(self.home, '.quickwork')
        os.makedirs(os.path.join(self.qw, 'profiles', 'p1'))
        self.out = os.path.join(self.tmp, 'out')
        os.mkdir(self.out)
        p = mock.patch.dict(os.environ, {'HOME': self.home, 'USERPROFILE': self.home})
        p.start()
        self.addCleanup(p.stop)

    def refused(self, path, homes=()):
        with darwin():
            return quick_reg.p2_export_destination_refused(path, homes)

    def _symlink(self, target, link):
        try:
            os.symlink(target, link)
        except (OSError, NotImplementedError, AttributeError):
            self.skipTest('symlinks not permitted here')

    def test_inside_default_quickwork_refused(self):
        for rel in ('.quickwork', os.path.join('.quickwork', 'x.json'),
                    os.path.join('.quickwork', 'profiles', 'p1', 'x.json')):
            with self.subTest(rel=rel):
                self.assertTrue(self.refused(os.path.join(self.home, rel)))

    def test_tilde_form_refused(self):
        self.assertTrue(self.refused(os.path.join('~', '.quickwork', 'x.json')))

    def test_dotdot_traversal_refused(self):
        self.assertTrue(self.refused(os.path.join(self.out, '..', 'home', '.quickwork', 'x.json')))
        self.assertTrue(self.refused(os.path.join(self.qw, 'profiles', '..', 'x.json')))

    def test_symlinked_folder_into_quickwork_refused(self):
        link = os.path.join(self.tmp, 'innocent-folder')
        self._symlink(self.qw, link)
        self.assertTrue(self.refused(os.path.join(link, 'x.json')))
        self.assertTrue(self.refused(os.path.join(link, 'profiles', 'p1', 'x.json')))

    def test_symlinked_file_onto_quick_config_refused(self):
        link = os.path.join(self.out, 'innocent.json')
        self._symlink(os.path.join(self.qw, 'profiles', 'p1', 'mcp_config.json'), link)
        self.assertTrue(self.refused(link))

    def test_mcp_config_json_name_refused_anywhere(self):
        for name in ('mcp_config.json', 'MCP_CONFIG.json', 'Mcp_Config.Json'):
            with self.subTest(name=name):
                self.assertTrue(self.refused(os.path.join(self.out, name)))

    def test_case_variant_of_quickwork_refused(self):
        self.assertTrue(self.refused(os.path.join(self.home, '.QuickWork', 'x.json')))

    def test_explicit_quick_home_refused(self):
        qh = os.path.join(self.tmp, 'other-quick-home')
        os.mkdir(qh)
        self.assertTrue(self.refused(os.path.join(qh, 'x.json'), (qh,)))
        self.assertFalse(self.refused(os.path.join(qh, 'x.json')))

    def test_outside_destinations_allowed(self):
        for path in (os.path.join(self.out, 'x.json'),
                     os.path.join(self.home, '.quickwork2', 'x.json'),
                     os.path.join(self.home, 'quickwork-notes', 'x.json')):
            with self.subTest(path=path):
                self.assertFalse(self.refused(path))

    def test_fail_closed_on_malformed_input(self):
        for bad in ('', None, 'a\x00b.json', 5, b'x.json'):
            with self.subTest(bad=bad):
                self.assertTrue(self.refused(bad))

    def test_write_quick_config_refuses_inside_quick_dir_before_any_write(self):
        link = os.path.join(self.tmp, 'innocent-folder')
        dests = [os.path.join(self.qw, 'x.json'),
                 os.path.join(self.out, '..', 'home', '.quickwork', 'y.json'),
                 os.path.join(self.out, 'mcp_config.json')]
        try:
            os.symlink(self.qw, link)
            dests.append(os.path.join(link, 'z.json'))
        except (OSError, NotImplementedError, AttributeError):
            pass
        for dest in dests:
            for redacted, ack in ((True, None), (False, 'EXPORT FULL')):
                with self.subTest(dest=dest, redacted=redacted), darwin(), \
                        mock.patch.object(quick_reg, 'secure_write_text', _trip('secure_write_text')):
                    with self.assertRaises(capability_gate.GateRefused) as cm:
                        quick_reg.write_quick_config(dict(SSH_SPEC), dest, redacted=redacted,
                                                     full_ack=ack)
                    self.assertEqual(str(cm.exception), P2_REFUSED)
        self.assertEqual(sorted(os.listdir(self.qw)), ['profiles'])
        self.assertEqual(os.listdir(self.out), [])

    def test_full_export_requires_token_in_code_path(self):
        dest = os.path.join(self.out, 'full.json')
        for bad in (None, '', 'export full', 'COPY FULL', 'EXPORT FULL\n', ' EXPORT FULL'):
            with self.subTest(bad=bad), darwin(), \
                    mock.patch.object(quick_reg, 'secure_write_text', _trip('secure_write_text')):
                with self.assertRaises(capability_gate.GateRefused):
                    quick_reg.write_quick_config(dict(SSH_SPEC), dest, redacted=False, full_ack=bad)
            self.assertFalse(os.path.exists(dest))

    def test_full_export_with_token_outside_allowed(self):
        dest = os.path.join(self.out, 'full.json')
        with darwin():
            self.assertEqual(quick_reg.write_quick_config(dict(SSH_SPEC), dest, redacted=False,
                                                          full_ack='EXPORT FULL'), dest)
        with open(dest, encoding='utf-8') as f:
            self.assertIn('fakeuser@gateway.example.com', f.read())

    def test_allowed_paths_reach_the_writer_with_the_right_variant(self):
        written = []
        rec = lambda p, t: written.append((p, t))
        with darwin(), mock.patch.object(quick_reg, 'secure_write_text', rec):
            quick_reg.write_quick_config(dict(SSH_SPEC), os.path.join(self.out, 'f.json'),
                                         redacted=False, full_ack='EXPORT FULL')
            quick_reg.write_quick_config(dict(SSH_SPEC), os.path.join(self.out, 'r.json'))
        self.assertEqual([os.path.basename(p) for p, t in written], ['f.json', 'r.json'])
        self.assertIn('fakeuser@gateway.example.com', written[0][1])
        self.assertNotIn('fakeuser', written[1][1])
        self.assertNotIn('gateway.example.com', written[1][1])

    def test_redacted_export_outside_allowed_without_token(self):
        dest = os.path.join(self.out, 'red.json')
        with darwin():
            quick_reg.write_quick_config(dict(SSH_SPEC), dest)
        with open(dest, encoding='utf-8') as f:
            text = f.read()
        self.assertNotIn('fakeuser', text)
        self.assertNotIn('gateway.example.com', text)


class WindowsExportParity(unittest.TestCase):
    """Decision B is darwin-only: BASE behaviour on win32 (Quick dir and FULL allowed)."""
    def test_write_quick_config_unchanged_on_win32(self):
        tmp = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, tmp, True)
        qw = os.path.join(tmp, '.quickwork')
        os.mkdir(qw)
        dest = os.path.join(qw, 'full.json')
        with mock.patch.object(sys, 'platform', 'win32'), \
                mock.patch.dict(os.environ, {'HOME': tmp, 'USERPROFILE': tmp}):
            self.assertEqual(quick_reg.write_quick_config(dict(SSH_SPEC), dest, redacted=False), dest)
        self.assertTrue(os.path.isfile(dest))

    def test_guard_helpers_inert_off_darwin(self):
        tmp = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, tmp, True)
        written = []
        with mock.patch.object(sys, 'platform', 'win32'), \
                mock.patch.object(quick_reg, 'p2_export_destination_refused', _trip('guard')), \
                mock.patch.object(quick_reg, '_p2_darwin_export_guard', _trip('guard')), \
                mock.patch.object(quick_reg, 'secure_write_text', lambda p, t: written.append((p, t))):
            dest = os.path.join(tmp, '.quickwork', 'mcp_config.json')
            self.assertEqual(quick_reg.write_quick_config(dict(SSH_SPEC), dest, redacted=False), dest)
        self.assertEqual(len(written), 1)
        self.assertIn('fakeuser@gateway.example.com', written[0][1])


class QuickRegFullCopyBuilder(unittest.TestCase):
    """A1.1 user gap fix (g)(ii): the FULL Quick text needs COPY FULL in the code path
    that builds it (macOS); off macOS it is byte-identical to quick_instructions(full)."""
    BAD = (None, '', 'copy full', 'COPY FULL ', ' COPY FULL', 'COPY  FULL', 'EXPORT FULL',
           'COPY FULL\n', b'COPY FULL', 'COPY FULL\u200b')

    def test_full_builder_requires_exact_token_on_darwin(self):
        for bad in self.BAD:
            with self.subTest(bad=bad):
                with darwin(), Tripwires(self), \
                        mock.patch.object(quick_reg, 'quick_instructions', _trip('builder reached')):
                    with self.assertRaises(capability_gate.GateRefused):
                        quick_reg.quick_instructions_full(dict(SSH_SPEC), bad)
        with darwin(), Tripwires(self):
            got = quick_reg.quick_instructions_full(dict(SSH_SPEC), 'COPY FULL')
        self.assertEqual(got, quick_reg.quick_instructions(dict(SSH_SPEC), redacted=False))
        self.assertIn('fakeuser@gateway.example.com', got)

    def test_full_builder_byte_identical_off_darwin(self):
        for p in ('win32', 'linux'):
            with self.subTest(platform=p):
                with mock.patch.object(sys, 'platform', p):
                    got = quick_reg.quick_instructions_full(dict(SSH_SPEC))
                    want = quick_reg.quick_instructions(dict(SSH_SPEC), redacted=False)
                self.assertEqual(got, want)

    def test_screen_builder_never_builds_full(self):
        calls = []
        real = quick_reg.quick_instructions

        def rec(spec, redacted=False):
            calls.append(redacted)
            return real(spec, redacted=redacted)
        with darwin(), Tripwires(self), mock.patch.object(quick_reg, 'quick_instructions', rec):
            v = quick_reg.quick_instructions_screen(dict(SSH_SPEC))
        self.assertEqual(sorted(v), ['redacted'])
        self.assertEqual(calls, [True])
        for leak in ('fakeuser', 'gateway.example.com'):
            self.assertNotIn(leak, v['redacted'])

    def test_variants_function_unchanged_for_windows(self):
        with mock.patch.object(sys, 'platform', 'win32'):
            v = quick_reg.quick_instructions_variants(dict(SSH_SPEC))
        self.assertEqual(sorted(v), ['full', 'full_labeled', 'redacted'])
        self.assertEqual(v['full'], quick_reg.quick_instructions(dict(SSH_SPEC), redacted=False))


class _RiggedStrAll(str):
    """F-T1-01: a str subclass whose __eq__ always says True."""
    def __eq__(self, other):
        return True

    def __ne__(self, other):
        return False

    __hash__ = str.__hash__


class _RiggedStrEqOnly(str):
    """A str subclass whose __eq__ always says True (str.__ne__ is kept)."""
    def __eq__(self, other):
        return True

    __hash__ = str.__hash__


class _RiggedStrNone(str):
    """A str subclass whose __eq__ always says False."""
    def __eq__(self, other):
        return False

    def __ne__(self, other):
        return True

    __hash__ = str.__hash__


class _Bomb(object):
    """Any use of this object (compare, hash, str, bool, attribute) fails the test."""
    def __eq__(self, other):
        raise AssertionError('argument was inspected')

    __ne__ = __eq__

    def __hash__(self):
        raise AssertionError('argument was inspected')

    def __str__(self):
        raise AssertionError('argument was inspected')

    def __bool__(self):
        raise AssertionError('argument was inspected')

    def __getattr__(self, name):
        raise AssertionError('argument was inspected')


class TokenExactTypeB3c(unittest.TestCase):
    """B3c / F-T1-01: typed confirmations accept only an EXACT str equal to the token."""
    VB_LABEL = 'rtr-demo'

    def _tokens(self):
        return (capability_gate.FULL_COPY_TOKEN, capability_gate.FULL_EXPORT_TOKEN,
                capability_gate.g1b_token(capability_gate.SCOPE_VERIFY_BACKEND, self.VB_LABEL))

    def test_token_matches_refuses_str_subclasses(self):
        for tok in self._tokens():
            for cls in (_RiggedStrAll, _RiggedStrEqOnly, _RiggedStrNone):
                with self.subTest(tok=tok, cls=cls.__name__):
                    self.assertFalse(capability_gate.token_matches(tok, cls(tok)))
                    self.assertFalse(capability_gate.token_matches(tok, cls('x')))
                    self.assertFalse(capability_gate.token_matches(cls(tok), tok))
                    self.assertFalse(capability_gate.token_matches(cls(tok), cls(tok)))

    def test_token_matches_genuine_and_non_str(self):
        for tok in self._tokens():
            with self.subTest(tok=tok):
                self.assertTrue(capability_gate.token_matches(tok, ''.join(list(tok))))
                for bad in (None, tok.encode('ascii'), bytearray(tok.encode('ascii')), [tok],
                            (tok,), 1, tok + ' ', tok.lower()):
                    self.assertFalse(capability_gate.token_matches(tok, bad))
        self.assertFalse(capability_gate.token_matches('', ''))

    def test_require_full_variant_refuses_str_subclasses_on_darwin(self):
        for kind, tok in (('copy', capability_gate.FULL_COPY_TOKEN),
                          ('export', capability_gate.FULL_EXPORT_TOKEN)):
            for supplied in (_RiggedStrAll('x'), _RiggedStrAll(tok), _RiggedStrEqOnly('x'),
                             _RiggedStrNone(tok), None, tok.encode('ascii'), [tok]):
                with self.subTest(kind=kind, supplied=repr(supplied)):
                    with darwin(), Tripwires(self):
                        with self.assertRaises(capability_gate.GateRefused):
                            capability_gate.require_full_variant(kind, supplied)
            with darwin(), Tripwires(self):
                self.assertIsNone(capability_gate.require_full_variant(kind, ''.join(list(tok))))

    def test_require_g1b_refuses_str_subclasses_on_darwin(self):
        scope = capability_gate.SCOPE_VERIFY_BACKEND
        tok = capability_gate.g1b_token(scope, self.VB_LABEL)
        for supplied in (_RiggedStrAll('x'), _RiggedStrAll(tok), _RiggedStrNone(tok), None):
            with self.subTest(supplied=repr(supplied)):
                with darwin(), Tripwires(self):
                    with self.assertRaises(capability_gate.GateRefused):
                        capability_gate.require_g1b(scope, self.VB_LABEL, supplied, 'inspect')
        with darwin(), Tripwires(self):
            self.assertIsNone(capability_gate.require_g1b(scope, self.VB_LABEL,
                                                          ''.join(list(tok)), 'inspect'))

    def test_off_darwin_gates_return_none_without_reading_arguments(self):
        for p in ('win32', 'linux'):
            with self.subTest(platform=p), mock.patch.object(sys, 'platform', p):
                self.assertIsNone(capability_gate.require_full_variant(_Bomb(), _Bomb()))
                self.assertIsNone(capability_gate.require_full_variant('copy', _RiggedStrAll('x')))
                self.assertIsNone(capability_gate.require_g1b(_Bomb(), _Bomb(), _Bomb(), _Bomb()))


class WindowsParity(unittest.TestCase):
    """Non-darwin results: literal constants captured from BASE v0.4 behaviour."""
    def test_native_inspect_missing(self):
        with tempfile.TemporaryDirectory() as d, mock.patch.object(sys, 'platform', 'win32'):
            gw = native_gateway.NativeGateway(Path(d) / 'gw')
            self.assertEqual(gw.inspect(), {'state': 'MISSING', 'installed': False})
            self.assertEqual(gw.run({'op': 'inspect'}), {'state': 'MISSING', 'installed': False})

    def test_native_unapproved_bootstrap_message(self):
        with tempfile.TemporaryDirectory() as d, mock.patch.object(sys, 'platform', 'win32'):
            gw = native_gateway.NativeGateway(Path(d) / 'gw')
            with self.assertRaises(DeploymentError) as cm:
                gw.bootstrap()
            self.assertEqual(str(cm.exception), 'Explicit native-local installation approval required')

    def test_native_probe_existing_message(self):
        with tempfile.TemporaryDirectory() as d, mock.patch.object(sys, 'platform', 'linux'):
            gw = native_gateway.NativeGateway(Path(d) / 'gw')
            with self.assertRaises(DeploymentError) as cm:
                gw.run({'op': 'probe_existing'})
            self.assertEqual(str(cm.exception),
                             'Native-local v0.4 supports new Lambda targets only; Git/local adapters remain Linux SSH')

    def test_validate_spec_native_ok_on_win32(self):
        with mock.patch.object(sys, 'platform', 'win32'):
            self.assertEqual(model.validate_spec(dict(NATIVE_SPEC)), NATIVE_SPEC)

    def test_find_configs_default_on_win32_scans_quickwork(self):
        with tempfile.TemporaryDirectory() as d, mock.patch.object(sys, 'platform', 'win32'), \
                mock.patch.object(os.path, 'expanduser', lambda p: d):
            (Path(d) / '.quickwork').mkdir()
            (Path(d) / '.quickwork' / 'mcp_config.json').write_text('{}')
            self.assertEqual(quick_reg.find_quick_profile_configs(),
                             [os.path.join(d, '.quickwork', 'mcp_config.json')])

    def test_emit_import_file_bytes_on_win32(self):
        settings = {'command': 'ssh', 'args': ['-T', 'fakeuser@gateway.example.com', 'x'],
                    'name': 'rtr-demo'}
        with tempfile.TemporaryDirectory() as d, mock.patch.object(sys, 'platform', 'win32'):
            r = quick_reg.emit_quick_import_file(settings, d, allow_inside_repo=True)
            self.assertEqual(r['bytes'], 164)
            self.assertEqual(open(r['path'], 'rb').read(),
                             b'{\n  "mcpServers": {\n    "rtr-demo": {\n      "command": "ssh",\n'
                             b'      "args": [\n        "-T",\n        "fakeuser@gateway.example.com",\n'
                             b'        "x"\n      ]\n    }\n  }\n}\n')


if __name__ == '__main__':
    unittest.main()
