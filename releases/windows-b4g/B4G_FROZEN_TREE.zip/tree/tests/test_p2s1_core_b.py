"""P2 Slice 1 / B1b + B3 (Amendment A1): deploy_lib + cli capability gates
(G1a / G1b two operation-bound scopes / G2) and the macOS export guard (decision B).

Stdlib unittest only. Every test drives the REAL function. macOS is simulated by
patching sys.platform (read at call time by platform_p2.is_darwin). Tripwires
(subprocess, os.system, os.exec*, socket, sqlite3.connect, import of paramiko) raise
AssertionError. A1.4 F2-F4 use a STUB paramiko object injected only inside the test
(sys.modules + import hook); the stub records host-key policies, connect kwargs and
saves. Expected values are literal constants. Placeholders only.
"""
import ast
import builtins
import contextlib
import io
import json
import os
import socket
import sqlite3
import subprocess
import sys
import shutil
import tempfile
import unittest
from unittest import mock

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

import capability_gate  # noqa: E402
import platform_p2  # noqa: E402
import quick_reg  # noqa: E402
import deploy_lib  # noqa: E402
import cli  # noqa: E402
from deploy_lib import SSHGateway, ConnectorDeployer, DeploymentError  # noqa: E402
from capability_gate import GateRefused  # noqa: E402

TARGET = 'rtr-demo'
HOST = 'gateway.example.com'
USER = 'fakeuser'
IG = 'inspect-gateway'
VB = 'verify-backend'
GOOD_ACK = 'VERIFY BACKEND rtr-demo'
GOOD_IG = 'INSPECT GATEWAY fakeuser@gateway.example.com'
SPEC = {'transport': 'linux-ssh', 'host': 'gateway.example.com', 'user': 'fakeuser',
        'kind': 'lambda', 'target': TARGET, 'display_name': 'rtr demo',
        'url': 'https://abc123.lambda-url.us-east-1.on.aws/mcp',
        'allow': ['get_rating_mappings']}
PREPARE_KEYS = sorted(['version', 'mode', 'target', 'kind', 'backend_identity_sha256',
                       'expected_registry_sha256', 'registry_entry', 'tool_count_to_expose',
                       'potentially_mutating_tools_name_only', 'warnings', 'execution_plan',
                       'quick_connector', 'registration', 'no_secrets_in_manifest',
                       'gateway', 'existing_target_count'])
SENTINEL = 'NOT READ (offline plan)'
NO_SSH_LIB = 'SSH client library not available; nothing was installed'
TRANSPORT_MSG = 'SSH/transport failed ({}). Check trusted host key, SSH agent and connectivity.'
PLAN_OFFLINE_MSG = ('plan is offline on macOS in Slice 1: use the offline plan '
                    '(prepare_offline); no SSH is opened for planning')
BAD_ACKS = ['verify backend rtr-demo', 'VERIFY BACKEND RTR-DEMO', ' VERIFY BACKEND rtr-demo',
            'VERIFY BACKEND rtr-demo ', 'VERIFY BACKEND rtr-demo\n', 'VERIFY  BACKEND rtr-demo',
            'VERIFY BACKEND\trtr-demo', 'VERIFY BACKEND other-demo', 'VERIFY BACKEND',
            'VERIFY BACKEND ', '', None, b'VERIFY BACKEND rtr-demo', 'rtr-demo',
            'VERIFY BACKEND rtr-demo\u200b', '\ufeffVERIFY BACKEND rtr-demo', GOOD_IG]
VERIFY_OPS = ['inspect', 'inspect_lambda_target', 'discover', 'probe_existing']
# A1.1: a registry entry exactly as ConnectorDeployer.discover builds it (placeholders).
VALID_ENTRY = {'url': 'https://abc123.lambda-url.us-east-1.on.aws/mcp', 'region': 'us-east-1',
               'env': 'wizard', 'note': 'Installed by AQ-MCP Connector Wizard',
               'allow': ['discovery-placeholder']}
PRE_A1_ACK_HELP = ('macOS: type exactly VERIFY BACKEND <target> to allow the SSH metadata '
                   'handshake (inspect/discover/plan with remote read). Ignored elsewhere.')
AUTH_ITEM1_TAIL = ' Every key held by the agent may be offered to the server, one after another.'
AUTH_ITEM2 = ('Default private key files in your ~/.ssh folder (id_rsa, id_ecdsa, id_ed25519, '
              'id_dsa), which this program opens and reads (look_for_keys=True). Unencrypted keys '
              'are tried; passphrase-protected keys are skipped (no passphrase is asked for) and '
              'work only through the agent.')
LEAKY_ERROR = ('connect fakeuser@internal-host.example.net failed at '
               'https://internal.example.com/x?sig=1 token=' + 'a1' * 20 +
               ' path /home/fakeuser/aq-mcp/x host gateway.example.com ip 192.0.2.7 ' + 'Z' * 40)
LEAK_PARTS = ('fakeuser', 'internal-host', 'internal.example.com', 'https://', 'a1a1a1a1',
              '/home/fakeuser', 'gateway.example.com', '192.0.2.7', 'Z' * 32)

_REAL_IMPORT = builtins.__import__


class _EqAll(str):
    """A str subclass whose == always answers True (must never authorize)."""
    def __eq__(self, other):
        return True

    def __ne__(self, other):
        return False

    def __hash__(self):
        return 0


def _sys_modules_patch(stub):
    """Inject the stub paramiko into sys.modules ONLY for the duration of one test."""
    return mock.patch.dict(sys.modules, {'paramiko': stub})


class Trip(object):
    """Arms tripwires. paramiko_mode: 'trip' -> AssertionError, 'missing' -> ImportError,
    'stub' -> the given stub object (also placed in sys.modules for the test only)."""
    def __init__(self, paramiko_mode='trip', stub=None, exc=None):
        self.paramiko_attempts = 0
        self.mode = paramiko_mode
        self.stub = stub
        self.exc = exc   # A1.1: paramiko_mode 'raise' raises this exception object
        self._stack = contextlib.ExitStack()

    def _imp(self, name, *a, **k):
        if name == 'paramiko' or name.startswith('paramiko.'):
            self.paramiko_attempts += 1
            if self.mode == 'missing':
                raise ImportError('No module named paramiko (test)')
            if self.mode == 'raise':
                raise self.exc
            if self.mode == 'stub':
                return self.stub
            raise AssertionError('TRIPWIRE: paramiko import')
        return _REAL_IMPORT(name, *a, **k)

    def __enter__(self):
        def boom(*a, **k):
            raise AssertionError('TRIPWIRE')
        s = self._stack
        for obj, attr in [(subprocess, 'run'), (subprocess, 'Popen'), (subprocess, 'call'),
                          (subprocess, 'check_call'), (subprocess, 'check_output'),
                          (os, 'system'), (os, 'execv'), (os, 'execve'), (os, 'execvp'),
                          (socket, 'socket'), (socket, 'create_connection'),
                          (sqlite3, 'connect')]:
            s.enter_context(mock.patch.object(obj, attr, boom))
        if self.mode == 'stub':
            s.enter_context(_sys_modules_patch(self.stub))
        s.enter_context(mock.patch.object(builtins, '__import__', self._imp))
        return self

    def __exit__(self, *exc):
        return self._stack.__exit__(*exc)


class _StubModule(object):
    pass


def make_stub_paramiko(behaviour, rec):
    """A stand-in for the paramiko API surface SSHGateway.run uses. `behaviour` selects
    what connect()/exec_command() do; `rec` records everything (policies, connects,
    host-key loads and saves). Never opens a socket."""
    m = _StubModule()

    class SSHException(Exception):
        pass

    class AuthenticationException(SSHException):
        pass

    class NoValidAuthMethodsException(AuthenticationException):
        pass

    class BadHostKeyException(SSHException):
        pass

    class RejectPolicy(object):
        pass

    class AutoAddPolicy(object):
        pass

    class WarningPolicy(object):
        pass

    class _Chan(object):
        def __init__(s, status):
            s.status = status

        def shutdown_write(s):
            rec['shutdown_write'] += 1

        def recv_exit_status(s):
            return s.status

    class _In(object):
        def __init__(s, chan):
            s.channel = chan

        def write(s, data):
            rec['stdin'].append(data)

        def flush(s):
            pass

    class _Out(object):
        def __init__(s, chan, data):
            s.channel = chan
            s.data = data

        def read(s, n=-1):
            return s.data

    class SSHClient(object):
        def __init__(s):
            rec['clients'].append(s)
            s.policies = []
            s.host_key_files = []
            s.system_keys = 0
            s.connects = []
            s.closed = False
            s.execs = 0

        def load_system_host_keys(s, *a):
            s.system_keys += 1

        def load_host_keys(s, path):
            s.host_key_files.append(path)

        def set_missing_host_key_policy(s, policy):
            s.policies.append(policy)

        def save_host_keys(s, *a, **k):
            rec['saved'] += 1

        def connect(s, hostname, **kw):
            s.connects.append(dict(kw, hostname=hostname))
            if behaviour == 'auth':
                raise AuthenticationException('Authentication failed for fakeuser@gateway.example.com')
            if behaviour == 'novalid':
                raise NoValidAuthMethodsException('No authentication methods available')
            if behaviour == 'sshexc':
                raise SSHException('Error reading SSH protocol banner from gateway.example.com')
            if behaviour == 'badkey':
                raise BadHostKeyException('Host key for server gateway.example.com does not match')
            if behaviour == 'unknown_host':
                if any(isinstance(p, RejectPolicy) for p in s.policies):
                    raise SSHException('Server gateway.example.com not found in known_hosts')
                rec['would_have_added_key'] = True

        def exec_command(s, cmd, timeout=None):
            s.execs += 1
            status = 1 if behaviour == 'exit1' else 0
            body = {'okfalse': b'{"ok": false, "error": "Remote operation failed"}',
                    'okfalse_leak': json.dumps({'ok': False, 'error': LEAKY_ERROR}).encode('ascii'),
                    'okfalse_noerr': b'{"ok": false}',
                    'okfalse_nonstr': b'{"ok": false, "error": {"x": 1}}',
                    'ok': b'{"ok": true, "result": {"state": "READY"}}'}.get(
                        behaviour, b'{"ok": true, "result": {}}')
            ch = _Chan(status)
            return _In(ch), _Out(ch, body), _Out(ch, b'')

        def close(s):
            s.closed = True

    rec['RejectPolicy'] = RejectPolicy
    for name, obj in (('SSHException', SSHException),
                      ('AuthenticationException', AuthenticationException),
                      ('NoValidAuthMethodsException', NoValidAuthMethodsException),
                      ('BadHostKeyException', BadHostKeyException),
                      ('RejectPolicy', RejectPolicy), ('AutoAddPolicy', AutoAddPolicy),
                      ('WarningPolicy', WarningPolicy), ('SSHClient', SSHClient)):
        setattr(m, name, obj)
    return m


def new_rec():
    return {'clients': [], 'saved': 0, 'stdin': [], 'shutdown_write': 0}


def darwin():
    return mock.patch.object(platform_p2.sys, 'platform', 'darwin')


def plat(name):
    return mock.patch.object(platform_p2.sys, 'platform', name)


class FailGateway(object):
    """Any use of the gateway fails the test."""
    def __init__(self, ack=GOOD_ACK, scope=VB, label=TARGET, host=HOST, user=USER):
        self.ack = ack
        self.scope = scope
        self.label = label
        self.host = host
        self.user = user
        self.calls = []

    def run(self, request, timeout=65):
        self.calls.append(request)
        raise AssertionError('gateway must not be used: %r' % (request,))


class FakeGateway(object):
    def __init__(self, ack=None, scope=None, label=None, host=HOST, user=USER):
        self.ack = ack
        self.scope = scope
        self.label = label
        self.host = host
        self.user = user
        self.calls = []

    def run(self, q, timeout=65):
        self.calls.append(q)
        if q['op'] == 'inspect':
            return {'state': 'READY', 'installed': True, 'sha256': 'a' * 64,
                    'target_names': [], 'kinds': {}, 'git_targets': []}
        if q['op'] == 'discover':
            return {'tools': [{'name': 'get_rating_mappings'}], 'count': 1, 'truncated': False}
        raise AssertionError(q)


def src(name):
    with open(os.path.join(ROOT, name), 'r', encoding='utf-8') as f:
        return f.read()


def run_cli(argv):
    out, err = io.StringIO(), io.StringIO()
    with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
        try:
            code = cli.main(argv)
        except SystemExit as e:
            code = e.code if isinstance(e.code, int) else 2
    return code, out.getvalue(), err.getvalue()


def vb_gw(ack=GOOD_ACK, label=TARGET, host=HOST, user=USER, known_hosts='/nonexistent/kh'):
    return SSHGateway(host, user, known_hosts, ack=ack, scope=VB, label=label)


def ig_gw(ack=GOOD_IG, host=HOST, user=USER, known_hosts='/nonexistent/kh', label=None):
    return SSHGateway(host, user, known_hosts, ack=ack, scope=IG, label=label)


# ----------------------------------------------------------------- capability_gate (pure)
class TestGateApiA1(unittest.TestCase):
    """A1.3 API, driven on the real capability_gate functions (pure; no I/O)."""
    def test_scope_constants_and_op_sets_literal(self):
        self.assertEqual(capability_gate.SCOPE_INSPECT_GATEWAY, 'inspect-gateway')
        self.assertEqual(capability_gate.SCOPE_VERIFY_BACKEND, 'verify-backend')
        self.assertEqual({k: sorted(v) for k, v in capability_gate.G1B_SCOPE_OPS.items()},
                         {'inspect-gateway': ['inspect'],
                          'verify-backend': ['discover', 'inspect', 'inspect_lambda_target',
                                             'probe_existing']})

    def test_old_single_target_api_removed(self):
        self.assertFalse(hasattr(capability_gate, 'G1B_PREFIX'))
        with self.assertRaises(TypeError):
            capability_gate.g1b_token(TARGET)
        with self.assertRaises(TypeError):
            capability_gate.require_g1b(TARGET, GOOD_ACK)

    def test_tokens_literal(self):
        self.assertEqual(capability_gate.g1b_token(IG, 'fakeuser@gateway.example.com'), GOOD_IG)
        self.assertEqual(capability_gate.g1b_token(VB, TARGET), GOOD_ACK)
        self.assertEqual(capability_gate.gateway_label(USER, HOST), 'fakeuser@gateway.example.com')
        self.assertEqual(capability_gate.g1b_token(IG, 'fakeuser@192.0.2.10'),
                         'INSPECT GATEWAY fakeuser@192.0.2.10')

    def test_invalid_labels_refused(self):
        for bad in ['', ' ', 'a b', 'x\n', 'x\x00', None, b'x', 5, 'a\u200bb', '\ufeffa',
                    'x\u00a0y', 'x\u202ey', 'x\u2060', _EqAll('rtr-demo')]:
            with self.subTest(bad=bad):
                with self.assertRaises(capability_gate.GateRefused):
                    capability_gate.g1b_token(VB, bad)
        for bad in ['fakeuser', 'a@@b', '@gateway.example.com', 'fakeuser@', 'a@b@c',
                    'fake user@gateway.example.com', 'fakeuser@gate\u200bway.example.com']:
            with self.subTest(bad=bad):
                with self.assertRaises(capability_gate.GateRefused):
                    capability_gate.g1b_token(IG, bad)
        for user, host in [('a@b', HOST), (USER, 'h@x'), ('', HOST), (USER, ''), (None, HOST),
                           (USER, None), ('fake\tuser', HOST)]:
            with self.subTest(user=user, host=host):
                with self.assertRaises(capability_gate.GateRefused):
                    capability_gate.gateway_label(user, host)

    def test_unknown_scope_refused(self):
        for scope in [None, '', 'INSPECT-GATEWAY', 'verify_backend', 'inspect', ['verify-backend'],
                      _EqAll('verify-backend')]:
            with self.subTest(scope=scope):
                with self.assertRaises(capability_gate.GateRefused):
                    capability_gate.g1b_token(scope, TARGET)
                with darwin():
                    with self.assertRaises(capability_gate.GateRefused):
                        capability_gate.require_g1b(scope, TARGET, GOOD_ACK, 'inspect')

    def test_exact_tokens_accepted_for_their_ops_only(self):
        with darwin():
            self.assertIsNone(capability_gate.require_g1b(IG, 'fakeuser@gateway.example.com',
                                                          GOOD_IG, 'inspect'))
            for op in VERIFY_OPS:
                self.assertIsNone(capability_gate.require_g1b(VB, TARGET, GOOD_ACK, op))

    def test_scope_separation_inspect_token_never_authorizes_verify(self):
        # direction 1: an INSPECT GATEWAY approval never authorizes verify-backend.
        with darwin():
            for op in VERIFY_OPS:
                for label in (TARGET, 'fakeuser@gateway.example.com'):
                    with self.subTest(op=op, label=label):
                        with self.assertRaises(capability_gate.GateRefused):
                            capability_gate.require_g1b(VB, label, GOOD_IG, op)
            for op in ['discover', 'probe_existing', 'inspect_lambda_target']:
                with self.subTest(op=op):
                    with self.assertRaises(capability_gate.GateRefused):
                        capability_gate.require_g1b(IG, 'fakeuser@gateway.example.com', GOOD_IG, op)

    def test_scope_separation_verify_token_never_authorizes_inspect(self):
        # direction 2: a VERIFY BACKEND approval never authorizes inspect-gateway.
        with darwin():
            for supplied in (GOOD_ACK, 'VERIFY BACKEND fakeuser@gateway.example.com'):
                with self.subTest(supplied=supplied):
                    with self.assertRaises(capability_gate.GateRefused):
                        capability_gate.require_g1b(IG, 'fakeuser@gateway.example.com',
                                                    supplied, 'inspect')

    def test_check_git_check_and_g2_ops_refused_under_both_scopes(self):
        with darwin():
            for scope, label, ack in ((IG, 'fakeuser@gateway.example.com', GOOD_IG),
                                      (VB, TARGET, GOOD_ACK)):
                for op in ['check', 'git_check', 'bootstrap', 'repair_permissions', 'apply',
                           'rollback', 'tools_call', '', None, 'INSPECT', 5]:
                    with self.subTest(scope=scope, op=op):
                        with self.assertRaises(capability_gate.GateRefused):
                            capability_gate.require_g1b(scope, label, ack, op)

    def test_target_mismatch_refused(self):
        with darwin():
            for label in ('other-demo', 'rtr-demo2', 'RTR-DEMO'):
                with self.subTest(label=label):
                    with self.assertRaises(capability_gate.GateRefused):
                        capability_gate.require_g1b(VB, label, GOOD_ACK, 'discover')

    def test_destination_mismatch_refused(self):
        with darwin():
            for label in ('fakeuser@192.0.2.10', 'otheruser@gateway.example.com',
                          'fakeuser@GATEWAY.example.com'):
                with self.subTest(label=label):
                    with self.assertRaises(capability_gate.GateRefused):
                        capability_gate.require_g1b(IG, label, GOOD_IG, 'inspect')

    def test_bad_ack_variants_refused(self):
        with darwin():
            for bad in BAD_ACKS + [_EqAll('x')]:
                with self.subTest(bad=bad):
                    with self.assertRaises(capability_gate.GateRefused):
                        capability_gate.require_g1b(VB, TARGET, bad, 'discover')

    def test_messages_fixed_and_never_echo_input(self):
        with darwin():
            for args in ((VB, TARGET, 'VERIFY BACKEND SENTINEL-123', 'discover'),
                         (IG, 'fakeuser@gateway.example.com', 'SENTINEL-123', 'inspect'),
                         (VB, TARGET, GOOD_ACK, 'SENTINEL-123')):
                try:
                    capability_gate.require_g1b(*args)
                except capability_gate.GateRefused as exc:
                    self.assertNotIn('SENTINEL', str(exc))
                    self.assertNotIn('rtr-demo', str(exc))
                    self.assertNotIn('fakeuser', str(exc))
                else:
                    self.fail('not refused: %r' % (args,))

    def test_non_darwin_inert(self):
        for p in ['win32', 'linux']:
            with plat(p):
                self.assertIsNone(capability_gate.require_g1b(None, None, None, None))
                self.assertIsNone(capability_gate.require_g1b(VB, 'other', 'x', 'bootstrap'))

    def test_no_module_level_unlock_flag(self):
        for name in dir(capability_gate):
            if name.startswith('__') and name.endswith('__'):
                continue   # module machinery, not gate state
            self.assertNotIsInstance(getattr(capability_gate, name), bool, name)


# ----------------------------------------------------------------- SSHGateway.run gate
class TestSSHGatewayDarwinGate(unittest.TestCase):
    def test_no_ack_refused_before_paramiko_socket_subprocess(self):
        for gw in (vb_gw(ack=None), ig_gw(ack=None)):
            with darwin(), Trip() as t:
                with self.assertRaises(GateRefused):
                    gw.run({'op': 'inspect'})
            self.assertEqual(t.paramiko_attempts, 0)

    def test_bad_ack_variants_refused(self):
        for bad in BAD_ACKS:
            gw = vb_gw(ack=bad)
            with darwin(), Trip() as t:
                with self.assertRaises(GateRefused, msg=repr(bad)):
                    gw.run({'op': 'inspect'})
            self.assertEqual(t.paramiko_attempts, 0, repr(bad))

    def test_cross_target_reuse_refused(self):
        gw = vb_gw(ack=GOOD_ACK, label='other-demo')
        with darwin(), Trip() as t:
            with self.assertRaises(GateRefused):
                gw.run({'op': 'discover'})
        self.assertEqual(t.paramiko_attempts, 0)

    def test_missing_scope_or_label_refused(self):
        for gw in (SSHGateway(HOST, USER, ack=GOOD_ACK), vb_gw(label=None),
                   SSHGateway(HOST, USER, ack=GOOD_ACK, scope='verify_backend', label=TARGET)):
            with darwin(), Trip() as t:
                with self.assertRaises(GateRefused):
                    gw.run({'op': 'inspect'})
            self.assertEqual(t.paramiko_attempts, 0)

    def test_verify_scope_reaches_import_for_its_ops_and_never_pips(self):
        # A1.1 F9: a discover request must carry a VALID entry to get past the
        # pre-connect checks (an empty entry is now refused before the import).
        reqs = [{'op': 'inspect'}, {'op': 'discover', 'entry': dict(VALID_ENTRY)},
                {'op': 'probe_existing', 'kind': 'git', 'target': TARGET},
                {'op': 'inspect_lambda_target', 'target': TARGET}]
        for req in reqs:
            with darwin(), Trip('missing') as t:
                with self.assertRaises(DeploymentError) as cm:
                    vb_gw().run(req)
            self.assertEqual(str(cm.exception), NO_SSH_LIB, req)
            self.assertEqual(t.paramiko_attempts, 1, req)

    def test_inspect_scope_reaches_import_only_for_inspect(self):
        with darwin(), Trip('missing') as t:
            with self.assertRaises(DeploymentError) as cm:
                ig_gw().run({'op': 'inspect'})
        self.assertEqual(str(cm.exception), NO_SSH_LIB)
        self.assertEqual(t.paramiko_attempts, 1)
        for req in [{'op': 'discover', 'entry': {}}, {'op': 'probe_existing', 'target': TARGET},
                    {'op': 'inspect_lambda_target', 'target': TARGET}]:
            with darwin(), Trip() as t:
                with self.assertRaises(GateRefused):
                    ig_gw().run(req)
            self.assertEqual(t.paramiko_attempts, 0, req)

    def test_scope_separation_gateway_both_directions(self):
        cases = [ig_gw(ack=GOOD_ACK),                       # verify token, inspect scope
                 vb_gw(ack=GOOD_IG),                        # inspect token, verify scope
                 vb_gw(ack=GOOD_IG, label='fakeuser@gateway.example.com')]
        for gw in cases:
            with darwin(), Trip() as t:
                with self.assertRaises(GateRefused):
                    gw.run({'op': 'inspect'})
            self.assertEqual(t.paramiko_attempts, 0)

    def test_destination_binding_label_computed_inside_gateway(self):
        # Same approval text, but the gateway object points elsewhere -> refused. A
        # caller-supplied label is ignored for inspect-gateway (rule c).
        for gw in (ig_gw(host='192.0.2.10'), ig_gw(user='otheruser'),
                   ig_gw(host='192.0.2.10', label='fakeuser@gateway.example.com')):
            with darwin(), Trip() as t:
                with self.assertRaises(GateRefused):
                    gw.run({'op': 'inspect'})
            self.assertEqual(t.paramiko_attempts, 0)
        gw = ig_gw()
        gw.host = '192.0.2.10'   # changed after the dialog: approval no longer valid
        with darwin(), Trip() as t:
            with self.assertRaises(GateRefused):
                gw.run({'op': 'inspect'})
        self.assertEqual(t.paramiko_attempts, 0)

    def test_destination_binding_connect_uses_gateway_own_host_user(self):
        rec = new_rec()
        stub = make_stub_paramiko('ok', rec)
        d = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, d, True)
        kh = os.path.join(d, 'known_hosts')
        with open(kh, 'w') as f:
            f.write('gateway.example.com ssh-ed25519 AAAAPLACEHOLDER\n')
        with darwin(), Trip('stub', stub) as t:
            res = ig_gw(known_hosts=kh).run({'op': 'inspect'})
        self.assertEqual(res, {'state': 'READY'})
        self.assertEqual(t.paramiko_attempts, 1)
        self.assertEqual(len(rec['clients']), 1)
        c = rec['clients'][0]
        self.assertEqual([(x['hostname'], x['username']) for x in c.connects], [(HOST, USER)])

    def test_request_target_must_equal_approved_target(self):
        bad = [{'op': 'inspect_lambda_target', 'target': 'other-demo'},
               {'op': 'probe_existing', 'kind': 'git', 'target': 'other-demo'},
               {'op': 'probe_existing', 'kind': 'git'},
               {'op': 'inspect_lambda_target'},
               {'op': 'discover', 'target': 'other-demo', 'entry': {}},
               {'op': 'inspect', 'target': 'other-demo'}]
        for req in bad:
            with darwin(), Trip() as t:
                with self.assertRaises(GateRefused, msg=repr(req)):
                    vb_gw().run(req)
            self.assertEqual(t.paramiko_attempts, 0, req)

    def test_inspect_scope_refuses_request_naming_a_target(self):
        with darwin(), Trip() as t:
            with self.assertRaises(GateRefused):
                ig_gw().run({'op': 'inspect', 'target': TARGET})
        self.assertEqual(t.paramiko_attempts, 0)

    def test_g2_ops_refused_even_with_valid_ack(self):
        for gw in (vb_gw(), ig_gw()):
            for op in ['bootstrap', 'repair_permissions', 'apply', 'rollback']:
                with darwin(), Trip() as t:
                    with self.assertRaises(GateRefused):
                        gw.run({'op': op, 'target': TARGET})
                self.assertEqual(t.paramiko_attempts, 0)

    def test_f6_any_other_op_refused_before_paramiko(self):
        for gw in (vb_gw(), ig_gw()):
            for req in [{'op': 'check', 'target': TARGET}, {'op': 'git_check', 'target': TARGET},
                        {'op': 'tools_call'}, {'op': None}, {}, {'op': 'INSPECT'},
                        {'op': ['inspect']}, ['inspect'], None, {'op': 'inspect '}]:
                with darwin(), Trip() as t:
                    with self.assertRaises(GateRefused, msg=repr(req)):
                        gw.run(req)
                self.assertEqual(t.paramiko_attempts, 0, req)

    def test_gate_state_is_not_sticky(self):
        gw = vb_gw()
        with darwin(), Trip('missing'):
            with self.assertRaises(DeploymentError):
                gw.run({'op': 'inspect'})
        gw.ack = None
        with darwin(), Trip() as t:
            with self.assertRaises(GateRefused):
                gw.run({'op': 'inspect'})
        self.assertEqual(t.paramiko_attempts, 0)


# ----------------------------------------------------------------- A1.4 fail-closed (stub paramiko)
class TestFailClosedStubParamiko(unittest.TestCase):
    """F1(ii)-F4 driven through the REAL SSHGateway.run with a stub paramiko object."""
    def setUp(self):
        d = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, d, True)
        self.kh = os.path.join(d, 'known_hosts')
        with open(self.kh, 'w') as f:
            f.write('gateway.example.com ssh-ed25519 AAAAPLACEHOLDER\n')

    def _run(self, behaviour, req=None, gw=None):
        rec = new_rec()
        stub = make_stub_paramiko(behaviour, rec)
        gw = gw or vb_gw(known_hosts=self.kh)
        with darwin(), Trip('stub', stub) as t:
            try:
                res = gw.run(req or {'op': 'inspect'})
                err = None
            except Exception as exc:  # recorded and asserted by the caller
                res, err = None, exc
        self.assertEqual(t.paramiko_attempts, 1)
        return rec, res, err

    def _assert_policy_and_no_save(self, rec):
        for c in rec['clients']:
            self.assertTrue(c.policies, 'no host-key policy set')
            for p in c.policies:
                self.assertIsInstance(p, rec['RejectPolicy'])
            self.assertEqual(c.host_key_files, [self.kh])
            self.assertEqual(c.system_keys, 1)
            self.assertTrue(c.closed)
        self.assertEqual(rec['saved'], 0)
        self.assertNotIn('would_have_added_key', rec)

    def test_f1_paramiko_absent_refuses_with_fixed_message(self):
        with darwin(), Trip('missing') as t:
            with self.assertRaises(DeploymentError) as cm:
                vb_gw(known_hosts=self.kh).run({'op': 'inspect'})
        self.assertEqual(str(cm.exception), NO_SSH_LIB)
        self.assertEqual(t.paramiko_attempts, 1)

    def test_f2_credentials_unavailable_no_retry_no_fallback(self):
        for behaviour, tname in (('auth', 'AuthenticationException'),
                                 ('novalid', 'NoValidAuthMethodsException'),
                                 ('sshexc', 'SSHException')):
            with self.subTest(behaviour=behaviour):
                rec, res, err = self._run(behaviour)
                self.assertIsInstance(err, DeploymentError)
                self.assertEqual(str(err), TRANSPORT_MSG.format(tname))
                self.assertNotIn('fakeuser', str(err))
                self.assertNotIn('gateway.example.com', str(err))
                self.assertEqual(len(rec['clients']), 1)
                c = rec['clients'][0]
                self.assertEqual(len(c.connects), 1, 'retried')
                self.assertEqual(c.execs, 0)
                kw = c.connects[0]
                self.assertIs(kw['allow_agent'], True)
                self.assertIs(kw['look_for_keys'], True)
                for k in ('password', 'key_filename', 'passphrase', 'pkey', 'gss_auth',
                          'gss_kex', 'sock'):
                    self.assertNotIn(k, kw)
                self._assert_policy_and_no_save(rec)

    def test_f3_unknown_host_refused_by_reject_policy(self):
        rec, res, err = self._run('unknown_host')
        self.assertIsInstance(err, DeploymentError)
        self.assertEqual(str(err), TRANSPORT_MSG.format('SSHException'))
        self._assert_policy_and_no_save(rec)

    def test_f3_changed_host_key_refused(self):
        rec, res, err = self._run('badkey')
        self.assertIsInstance(err, DeploymentError)
        self.assertEqual(str(err), TRANSPORT_MSG.format('BadHostKeyException'))
        self.assertEqual(rec['clients'][0].execs, 0)
        self._assert_policy_and_no_save(rec)

    def test_f3_known_hosts_missing_refused_before_connect(self):
        rec = new_rec()
        stub = make_stub_paramiko('ok', rec)
        with darwin(), Trip('stub', stub):
            with self.assertRaises(DeploymentError) as cm:
                vb_gw(known_hosts=self.kh + '.missing').run({'op': 'inspect'})
        self.assertTrue(str(cm.exception).startswith('Known-hosts file is missing.'))
        self.assertEqual(rec['clients'], [])

    def test_f4_nonzero_worker_exit_refused(self):
        rec, res, err = self._run('exit1')
        self.assertIsInstance(err, DeploymentError)
        self.assertEqual(str(err), 'Gateway worker exited with status 1')
        self.assertEqual(len(rec['clients'][0].connects), 1)
        self._assert_policy_and_no_save(rec)

    def test_f4_ok_false_response_refused(self):
        rec, res, err = self._run('okfalse')
        self.assertIsInstance(err, DeploymentError)
        self.assertEqual(str(err), 'Remote operation failed')
        self.assertEqual(len(rec['clients'][0].connects), 1)
        self._assert_policy_and_no_save(rec)

    def test_ok_path_returns_result_and_sends_request_on_stdin_only(self):
        rec, res, err = self._run('ok', {'op': 'inspect'})
        self.assertIsNone(err)
        self.assertEqual(res, {'state': 'READY'})
        self.assertEqual(rec['stdin'], [b'{"op": "inspect"}'])
        self._assert_policy_and_no_save(rec)

    def test_gate_refusal_precedes_stub_import(self):
        rec = new_rec()
        stub = make_stub_paramiko('ok', rec)
        with darwin(), Trip('stub', stub) as t:
            with self.assertRaises(GateRefused):
                vb_gw(ack='VERIFY BACKEND other-demo', known_hosts=self.kh).run({'op': 'inspect'})
        self.assertEqual(t.paramiko_attempts, 0)
        self.assertEqual(rec['clients'], [])


class TestWindowsParity(unittest.TestCase):
    def test_windows_import_failure_message_unchanged(self):
        gw = SSHGateway('gateway.example.com', 'fakeuser')
        for p in ['win32', 'linux']:
            with plat(p), Trip('missing') as t:
                with self.assertRaises(DeploymentError) as cm:
                    gw.run({'op': 'bootstrap'})
            self.assertEqual(str(cm.exception), 'Install Paramiko first: py -m pip install paramiko')
            self.assertEqual(t.paramiko_attempts, 1)

    def test_constructor_defaults_unchanged(self):
        gw = SSHGateway('gateway.example.com', 'fakeuser', '/tmp/kh')
        self.assertEqual((gw.host, gw.user, gw.known_hosts, gw.timeout, gw.ack, gw.scope, gw.label),
                         ('gateway.example.com', 'fakeuser', '/tmp/kh', 15, None, None, None))
        gw2 = SSHGateway('gateway.example.com', 'fakeuser', None, 15)
        self.assertEqual(gw2.timeout, 15)
        self.assertFalse(hasattr(gw2, 'target'))

    def test_windows_prepare_unchanged_keys_and_calls(self):
        g = FakeGateway()
        with plat('win32'):
            res = ConnectorDeployer(g).prepare(SPEC)
        self.assertEqual(sorted(res.keys()), PREPARE_KEYS)
        self.assertEqual([q['op'] for q in g.calls], ['inspect'])
        self.assertEqual(res['expected_registry_sha256'], 'a' * 64)
        self.assertEqual(res['existing_target_count'], 0)

    def test_windows_deployer_ignores_ack_and_scope(self):
        g = FakeGateway()  # no ack/scope/label at all
        with plat('win32'):
            self.assertEqual(ConnectorDeployer(g).inspect()['state'], 'READY')
            res = ConnectorDeployer(FakeGateway()).verify_backend(SPEC)
        self.assertEqual(res['status'], 'BACKEND_VERIFIED')

    def test_windows_ssh_run_ignores_scope_check_ops(self):
        # check/git_check stay reachable on Windows (only the darwin gate refuses them).
        for op in ['check', 'git_check', 'apply']:
            with plat('win32'), Trip('missing') as t:
                with self.assertRaises(DeploymentError) as cm:
                    SSHGateway(HOST, USER).run({'op': op})
            self.assertEqual(str(cm.exception), 'Install Paramiko first: py -m pip install paramiko')
            self.assertEqual(t.paramiko_attempts, 1)

    def test_non_darwin_branch_ast_identical_to_base(self):
        """The else-branch of run() holds the BASE try/except byte-for-byte (AST)."""
        base_try = ('try:\n    import paramiko\nexcept ImportError:\n'
                    "    raise DeploymentError('Install Paramiko first: py -m pip install paramiko')\n")
        tree = ast.parse(src('deploy_lib.py'))
        run = [n for c in tree.body if isinstance(c, ast.ClassDef) and c.name == 'SSHGateway'
               for n in c.body if isinstance(n, ast.FunctionDef) and n.name == 'run'][0]
        first = run.body[0]
        self.assertIsInstance(first, ast.If)
        self.assertEqual(ast.dump(first.orelse[0]), ast.dump(ast.parse(base_try).body[0]))


# ----------------------------------------------------------------- static / AST proofs
DARWIN_SOURCES = ('deploy_lib.py', 'cli.py', 'wizard.py', 'capability_gate.py', 'quick_reg.py')


class TestStatic(unittest.TestCase):
    def _run_fn(self):
        tree = ast.parse(src('deploy_lib.py'))
        return [n for c in tree.body if isinstance(c, ast.ClassDef) and c.name == 'SSHGateway'
                for n in c.body if isinstance(n, ast.FunctionDef) and n.name == 'run'][0]

    def test_gate_precedes_paramiko_import(self):
        first = self._run_fn().body[0]
        self.assertIsInstance(first, ast.If)
        self.assertEqual(ast.unparse(first.test) if hasattr(ast, 'unparse') else 'x',
                         'platform_p2.is_darwin()' if hasattr(ast, 'unparse') else 'x')
        body = first.body
        self.assertIsInstance(body[0], ast.Expr)
        self.assertEqual(body[0].value.func.attr, '_darwin_gate')
        # A1.1 P2-SEC-059: pre-connect checks run second, still before the import.
        self.assertIsInstance(body[1], ast.Expr)
        self.assertEqual(body[1].value.func.attr, '_darwin_preconnect_checks')
        self.assertIsInstance(body[2], ast.Try)
        self.assertEqual(body[2].body[0].names[0].name, 'paramiko')
        # A1.1 P2-SEC-058: the darwin handler catches Exception (not only ImportError).
        self.assertEqual(len(body[2].handlers), 1)
        self.assertEqual(ast.unparse(body[2].handlers[0].type), 'Exception')
        self.assertEqual(len(body), 3)

    def test_reject_policy_kept_no_weak_policy(self):
        text = src('deploy_lib.py')
        tree = ast.parse(text)
        attrs = {n.attr for n in ast.walk(tree) if isinstance(n, ast.Attribute)}
        self.assertIn('RejectPolicy', attrs)
        self.assertIn('load_system_host_keys', attrs)
        self.assertIn('load_host_keys', attrs)
        for weak in ['AutoAddPolicy', 'WarningPolicy', 'MissingHostKeyPolicy']:
            self.assertNotIn(weak, attrs)
            self.assertNotIn(weak, text)

    def test_f3_only_reject_policy_passed_and_no_host_key_writes(self):
        for name in DARWIN_SOURCES:
            tree = ast.parse(src(name))
            for n in ast.walk(tree):
                if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute):
                    if n.func.attr == 'set_missing_host_key_policy':
                        self.assertEqual(len(n.args), 1, name)
                        a = n.args[0]
                        self.assertTrue(isinstance(a, ast.Call) and isinstance(a.func, ast.Attribute)
                                        and a.func.attr == 'RejectPolicy', name)
                    self.assertNotIn(n.func.attr, ('save_host_keys', 'add', 'save_host_key'), name)
            for word in ('AutoAddPolicy', 'WarningPolicy', 'save_host_keys'):
                self.assertNotIn(word, src(name), (name, word))

    def test_f5_no_certificate_or_host_verification_bypass(self):
        for name in DARWIN_SOURCES:
            text = src(name)
            for word in ('verify=False', 'verify = False', '_create_unverified_context',
                         'CERT_NONE', 'check_hostname', 'StrictHostKeyChecking',
                         'UserKnownHostsFile', 'disabled_algorithms', 'ensurepip',
                         'pip install paramiko', "'pip'"):
                if name == 'deploy_lib.py' and word == 'pip install paramiko':
                    continue   # the Windows-only BASE message, asserted unreachable below
                self.assertNotIn(word, text, (name, word))
        # The only 'pip install' text in deploy_lib is in the non-darwin else-branch.
        run = self._run_fn()
        darwin_branch = ast.unparse(ast.Module(body=run.body[0].body, type_ignores=[]))
        self.assertNotIn('pip', darwin_branch)

    def test_connect_kwargs_unchanged_and_no_forwarding(self):
        tree = ast.parse(src('deploy_lib.py'))
        calls = [n for n in ast.walk(tree) if isinstance(n, ast.Call)
                 and isinstance(n.func, ast.Attribute) and n.func.attr == 'connect']
        self.assertEqual(len(calls), 1)
        kw = {k.arg: (k.value.value if isinstance(k.value, ast.Constant) else '<expr>')
              for k in calls[0].keywords}
        self.assertEqual(sorted(kw), ['allow_agent', 'auth_timeout', 'banner_timeout',
                                      'look_for_keys', 'timeout', 'username'])
        self.assertIs(kw['allow_agent'], True)
        self.assertIs(kw['look_for_keys'], True)
        text = src('deploy_lib.py')
        for forbidden in ['AgentRequestHandler', 'forward_agent', 'ForwardAgent',
                          'key_filename', 'password=', 'gss_auth']:
            self.assertNotIn(forbidden, text)

    def test_forbidden_mac_tool_strings_absent(self):
        for name in ['deploy_lib.py', 'cli.py', 'capability_gate.py']:
            tree = ast.parse(src(name))
            consts = [n.value for n in ast.walk(tree)
                      if isinstance(n, ast.Constant) and isinstance(n.value, str)]
            names = {n.id for n in ast.walk(tree) if isinstance(n, ast.Name)}
            for word in ['keychain', 'osascript', 'launchctl', 'sudo', 'brew', 'xattr',
                         'spctl', 'codesign', 'tccutil']:
                self.assertFalse(any(word in c.lower() for c in consts), (name, word))
                self.assertNotIn(word, names)
            self.assertFalse(any(c.strip().startswith('security ') or c == 'security'
                                 for c in consts), name)

    def test_g4_absent(self):
        for name in ['deploy_lib.py', 'cli.py', 'capability_gate.py']:
            text = src(name)
            for word in ['tools/call', 'tools_call', 'call_tool']:
                self.assertNotIn(word, text, (name, word))

    def test_op_sets_literal(self):
        self.assertEqual(sorted(deploy_lib.G1B_OPS),
                         ['discover', 'inspect', 'inspect_lambda_target', 'probe_existing'])
        self.assertEqual(sorted(deploy_lib.G2_OPS),
                         ['apply', 'bootstrap', 'repair_permissions', 'rollback'])
        union = set()
        for ops in capability_gate.G1B_SCOPE_OPS.values():
            union |= set(ops)
        self.assertEqual(sorted(union), sorted(deploy_lib.G1B_OPS))

    def test_prepare_first_statement_is_darwin_refusal(self):
        tree = ast.parse(src('deploy_lib.py'))
        fn = [n for c in tree.body if isinstance(c, ast.ClassDef) and c.name == 'ConnectorDeployer'
              for n in c.body if isinstance(n, ast.FunctionDef) and n.name == 'prepare'][0]
        first = fn.body[0]
        self.assertIsInstance(first, ast.If)
        self.assertEqual(ast.unparse(first.test), 'platform_p2.is_darwin()')
        self.assertIsInstance(first.body[-1], ast.Raise)

    def test_describe_auth_sources_states_current_behaviour(self):
        s = deploy_lib.describe_auth_sources()
        self.assertEqual(len(s), 4)
        self.assertIn('allow_agent=True', s[0])
        self.assertIn('ALL of its keys', s[0])
        self.assertIn('agent forwarding is NOT requested', s[0])
        self.assertIn('look_for_keys=True', s[1])
        self.assertIn('no password', s[2])
        self.assertIn('RejectPolicy', s[3])
        self.assertIn('nothing is added', s[3])
        # A1.1 / Security 2.2.4: exact amended items 1 and 2.
        self.assertTrue(s[0].endswith(AUTH_ITEM1_TAIL), s[0])
        self.assertEqual(s[1], AUTH_ITEM2)
        joined = ' '.join(s).lower()
        self.assertNotIn('agent only', joined)
        self.assertNotIn('look_for_keys=false', joined)

    def test_describe_auth_sources_matches_connect_kwargs(self):
        # Consistency derived from the connect() call by AST, not mirrored by hand.
        tree = ast.parse(src('deploy_lib.py'))
        call = [n for n in ast.walk(tree) if isinstance(n, ast.Call)
                and isinstance(n.func, ast.Attribute) and n.func.attr == 'connect'][0]
        kw = {k.arg: k.value.value for k in call.keywords if isinstance(k.value, ast.Constant)}
        s = deploy_lib.describe_auth_sources()
        self.assertIn('allow_agent=%s' % kw['allow_agent'], s[0])
        self.assertIn('look_for_keys=%s' % kw['look_for_keys'], s[1])


# ----------------------------------------------------------------- ConnectorDeployer
class TestDeployerDarwin(unittest.TestCase):
    def test_g2_methods_refuse_before_gateway(self):
        for call in [lambda d: d.bootstrap(approved=True),
                     lambda d: d.repair_permissions({'state': 'PERMISSIONS_NEED_REPAIR',
                                                     'mode_issues': []}, approved=True),
                     lambda d: d.deploy(SPEC, {'target': TARGET}, True),
                     lambda d: d.rollback({'target': TARGET})]:
            g = FailGateway()
            with darwin(), Trip() as t:
                with self.assertRaises(GateRefused):
                    call(ConnectorDeployer(g))
            self.assertEqual(g.calls, [])
            self.assertEqual(t.paramiko_attempts, 0)

    def test_g1b_entry_refuses_without_ack(self):
        for call in [lambda d: d.inspect(), lambda d: d.discover(SPEC),
                     lambda d: d.verify_backend(SPEC)]:
            for g in (FailGateway(ack=None), FailGateway(ack=None, scope=IG, label=None)):
                with darwin(), Trip():
                    with self.assertRaises(GateRefused):
                        call(ConnectorDeployer(g))
                self.assertEqual(g.calls, [])

    def test_prepare_refused_on_darwin_even_with_valid_ack(self):
        for g in (FailGateway(), FailGateway(ack=GOOD_IG, scope=IG, label=None), None):
            with darwin(), Trip() as t:
                with self.assertRaises(GateRefused) as cm:
                    ConnectorDeployer(g).prepare(SPEC)
            self.assertEqual(str(cm.exception), PLAN_OFFLINE_MSG)
            self.assertEqual(t.paramiko_attempts, 0)
            if g is not None:
                self.assertEqual(g.calls, [])

    def test_g1b_entry_refuses_stub_gateway_without_attrs(self):
        class Bare(object):
            def run(self, *a, **k):
                raise AssertionError('used')
        with darwin(), Trip():
            with self.assertRaises(GateRefused):
                ConnectorDeployer(Bare()).inspect()

    def test_spec_target_must_match_approved_label(self):
        g = FailGateway(ack='VERIFY BACKEND other-demo', label='other-demo')
        with darwin(), Trip():
            for call in (lambda d: d.verify_backend(SPEC), lambda d: d.discover(SPEC)):
                with self.assertRaises(GateRefused):
                    call(ConnectorDeployer(g))
        self.assertEqual(g.calls, [])

    def test_inspect_scope_cannot_verify_or_discover(self):
        g = FailGateway(ack=GOOD_IG, scope=IG, label=TARGET)
        with darwin(), Trip():
            for call in (lambda d: d.verify_backend(SPEC), lambda d: d.discover(SPEC)):
                with self.assertRaises(GateRefused):
                    call(ConnectorDeployer(g))
        self.assertEqual(g.calls, [])

    def test_verify_token_cannot_inspect_under_inspect_scope(self):
        g = FailGateway(ack=GOOD_ACK, scope=IG, label=None)
        with darwin(), Trip():
            with self.assertRaises(GateRefused):
                ConnectorDeployer(g).inspect()
        self.assertEqual(g.calls, [])

    def test_inspect_scope_destination_bound_at_entry(self):
        g = FailGateway(ack=GOOD_IG, scope=IG, label=None, host='192.0.2.10')
        with darwin(), Trip():
            with self.assertRaises(GateRefused):
                ConnectorDeployer(g).inspect()
        self.assertEqual(g.calls, [])

    def test_inspect_scope_allows_inspect(self):
        g = FakeGateway(ack=GOOD_IG, scope=IG)
        with darwin(), Trip():
            res = ConnectorDeployer(g).inspect()
        self.assertEqual(res['state'], 'READY')
        self.assertEqual([q['op'] for q in g.calls], ['inspect'])

    def test_verify_scope_allows_metadata_calls(self):
        g = FakeGateway(ack=GOOD_ACK, scope=VB, label=TARGET)
        with darwin(), Trip():
            res = ConnectorDeployer(g).verify_backend(SPEC)
        self.assertEqual([q['op'] for q in g.calls], ['inspect', 'discover'])
        self.assertEqual(res['status'], 'BACKEND_VERIFIED')
        self.assertEqual(res['tool_count'], 1)


class TestPrepareOffline(unittest.TestCase):
    def test_offline_never_touches_gateway_and_same_keys(self):
        for p in ['darwin', 'win32', 'linux']:
            g = FailGateway(ack=None, scope=None, label=None)
            with plat(p), Trip() as t:
                res = ConnectorDeployer(g).prepare_offline(SPEC)
            self.assertEqual(g.calls, [])
            self.assertEqual(t.paramiko_attempts, 0)
            self.assertEqual(sorted(k for k in res if k != 'offline'), PREPARE_KEYS)
            self.assertIs(res['offline'], True)
            self.assertEqual(res['expected_registry_sha256'], SENTINEL)
            self.assertEqual(res['existing_target_count'], SENTINEL)
            self.assertEqual(res['gateway'], {'host': 'gateway.example.com', 'user': 'fakeuser'})

    def test_offline_with_none_gateway(self):
        with darwin(), Trip():
            res = ConnectorDeployer(None).prepare_offline(SPEC)
        self.assertIs(res['offline'], True)

    def test_offline_plan_not_deployable_any_platform(self):
        with plat('win32'):
            res = ConnectorDeployer(None).prepare_offline(SPEC)
        for p in ['win32', 'linux']:
            g = FailGateway()
            with plat(p), Trip():
                with self.assertRaises(DeploymentError) as cm:
                    ConnectorDeployer(g).deploy(SPEC, res, True)
            self.assertIn('offline plan', str(cm.exception))
            self.assertEqual(g.calls, [])
        g = FailGateway()
        with darwin(), Trip():
            with self.assertRaises(GateRefused):
                ConnectorDeployer(g).deploy(SPEC, res, True)
        self.assertEqual(g.calls, [])

    def test_offline_validates_spec(self):
        with darwin(), Trip():
            with self.assertRaises(Exception):
                ConnectorDeployer(None).prepare_offline(dict(SPEC, target='BAD NAME'))


# ----------------------------------------------------------------- CLI
class CliHarness(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, self.tmp, True)
        self.manifest = os.path.join(self.tmp, 'm.json')
        with open(self.manifest, 'w', encoding='utf-8') as f:
            json.dump(SPEC, f)
        self.home = os.path.join(self.tmp, 'home')
        os.mkdir(self.home)
        os.mkdir(os.path.join(self.home, '.quickwork'))
        self.outdir = os.path.join(self.tmp, 'out')
        os.mkdir(self.outdir)
        self.built = []

        def no_build(*a, **k):
            self.built.append((a, k))
            raise AssertionError('gateway constructed')
        self.no_build = no_build

    def guarded(self, argv, ssh=None):
        with darwin(), Trip() as t, \
                mock.patch.dict(os.environ, {'HOME': self.home, 'USERPROFILE': self.home}), \
                mock.patch.object(cli, 'SSHGateway', ssh or self.no_build), \
                mock.patch.object(cli, 'SSHG', self.no_build), \
                mock.patch.object(cli, 'NativeGateway', self.no_build):
            code, out, err = run_cli(argv)
        self.assertEqual(t.paramiko_attempts, 0)
        return code, out, err


def _rec_gw_class(seen):
    class RecGW(object):
        def __init__(s, host, user, known_hosts=None, timeout=15, ack=None, scope=None, label=None):
            seen.append((host, user, ack, scope, label))
            s.host, s.user, s.ack, s.scope, s.label = host, user, ack, scope, label

        def run(s, q, timeout=65):
            if q['op'] == 'discover':
                return {'tools': [{'name': 'get_rating_mappings'}], 'count': 1, 'truncated': False}
            return {'state': 'READY', 'installed': True, 'sha256': 'a' * 64,
                    'target_names': [], 'kinds': {}, 'git_targets': []}
    return RecGW


class TestCliDarwin(CliHarness):
    def test_native_local_parser_error(self):
        for op in ['inspect', 'plan', 'bootstrap', 'rollback']:
            code, _, err = self.guarded([op, self.manifest, '--native-local', '--ack', GOOD_ACK])
            self.assertEqual(code, 2)
            self.assertIn('--native-local is not available on macOS', err)
        self.assertEqual(self.built, [])

    def test_g2_ops_refused_before_gateway(self):
        rec = os.path.join(self.tmp, 'r.json')
        with open(rec, 'w') as f:
            json.dump({'target': TARGET}, f)
        for argv in [['bootstrap', '--host', 'gateway.example.com', '--user', 'fakeuser',
                      '--approve-bootstrap', '--ack', GOOD_ACK],
                     ['repair-permissions', '--host', 'gateway.example.com', '--user',
                      'fakeuser', '--approve-repair', '--ack', GOOD_ACK],
                     ['apply', self.manifest, '--plan-file', rec, '--receipt-file',
                      os.path.join(self.tmp, 'x.json'), '--approve-target', TARGET,
                      '--approve-apply', '--ack', GOOD_ACK],
                     ['rollback', '--receipt-file', rec, '--host', 'gateway.example.com',
                      '--user', 'fakeuser', '--approve-target', TARGET, '--ack', GOOD_ACK],
                     ['import-file', self.manifest, '--out-dir', self.tmp]]:
            code, _, err = self.guarded(argv)
            self.assertEqual(code, 2, argv[0])
            self.assertIn('not available on macOS in Slice 1', err)
        self.assertEqual(self.built, [])
        self.assertEqual(sorted(os.listdir(self.tmp)), ['home', 'm.json', 'out', 'r.json'])

    def test_remote_reads_require_exact_scoped_ack(self):
        for op, wrong_scope in (('inspect', GOOD_ACK), ('discover', GOOD_IG)):
            code, _, err = self.guarded([op, self.manifest])
            self.assertEqual(code, 2)
            for bad in [b for b in BAD_ACKS if isinstance(b, str)
                        and b not in (GOOD_ACK, GOOD_IG)] + [wrong_scope]:
                code, _, _ = self.guarded([op, self.manifest, '--ack', bad])
                self.assertEqual(code, 2, (op, bad))
        self.assertEqual(self.built, [])

    def test_inspect_ack_bound_to_manifest_destination(self):
        for bad in ('INSPECT GATEWAY fakeuser@192.0.2.10', 'INSPECT GATEWAY otheruser@gateway.example.com',
                    'INSPECT GATEWAY fakeuser@gateway.example.com '):
            code, _, _ = self.guarded(['inspect', self.manifest, '--ack', bad])
            self.assertEqual(code, 2, bad)
        self.assertEqual(self.built, [])

    def test_plan_refuses_any_ack(self):
        for ack in [GOOD_ACK, GOOD_IG, 'VERIFY BACKEND other-demo', '']:
            code, _, err = self.guarded(['plan', self.manifest, '--ack', ack])
            self.assertEqual(code, 2, ack)
            self.assertIn('plan is offline on macOS', err)
        self.assertEqual(self.built, [])

    def test_plan_without_ack_is_offline(self):
        code, out, _ = self.guarded(['plan', self.manifest])
        self.assertEqual(code, 0)
        res = json.loads(out)
        self.assertIs(res['offline'], True)
        self.assertEqual(res['expected_registry_sha256'], SENTINEL)
        self.assertEqual(self.built, [])

    def test_valid_inspect_ack_builds_inspect_scoped_gateway(self):
        seen = []
        code, out, _ = self.guarded(['inspect', self.manifest, '--ack', GOOD_IG],
                                    ssh=_rec_gw_class(seen))
        self.assertEqual(code, 0)
        self.assertEqual(seen, [('gateway.example.com', 'fakeuser', GOOD_IG, IG, None)])
        self.assertEqual(json.loads(out)['state'], 'READY')

    def test_valid_discover_ack_builds_verify_scoped_gateway(self):
        seen = []
        code, out, _ = self.guarded(['discover', self.manifest, '--ack', GOOD_ACK],
                                    ssh=_rec_gw_class(seen))
        self.assertEqual(code, 0)
        self.assertEqual(seen, [('gateway.example.com', 'fakeuser', GOOD_ACK, VB, TARGET)])
        self.assertEqual(json.loads(out)['count'], 1)

    def test_import_reads_require_explicit_location(self):
        code, _, err = self.guarded(['import-check', '--name', 'aq-rtr-demo'])
        self.assertEqual(code, 2)
        self.assertIn('--profile-dir', err)
        code, _, err = self.guarded(['import-verify', self.manifest, '--name', 'aq-rtr-demo'])
        self.assertEqual(code, 2)
        self.assertIn('--config-path', err)


class TestCliDarwinExportGuard(CliHarness):
    """User decision B through the CLI (export / plan-file), HOME pointed at a temp dir."""
    def _export(self, dest, *extra):
        return self.guarded(['export', self.manifest, '--output-file', dest] + list(extra))

    def test_redacted_export_outside_quick_dir_allowed(self):
        dest = os.path.join(self.outdir, 'x.json')
        code, out, _ = self._export(dest)
        self.assertEqual(code, 0)
        self.assertTrue(os.path.isfile(dest))
        with open(dest, encoding='utf-8') as f:
            self.assertNotIn('fakeuser', f.read())

    def test_export_inside_quickwork_refused(self):
        dest = os.path.join(self.home, '.quickwork', 'x.json')
        code, _, err = self._export(dest)
        self.assertEqual(code, 2)
        self.assertFalse(os.path.exists(dest))
        self.assertEqual(os.listdir(os.path.join(self.home, '.quickwork')), [])

    def test_export_dotdot_traversal_refused(self):
        dest = os.path.join(self.outdir, '..', 'home', '.quickwork', 'x.json')
        code, _, _ = self._export(dest)
        self.assertEqual(code, 2)
        self.assertEqual(os.listdir(os.path.join(self.home, '.quickwork')), [])

    def test_export_symlink_into_quickwork_refused(self):
        link = os.path.join(self.tmp, 'innocent')
        try:
            os.symlink(os.path.join(self.home, '.quickwork'), link)
        except (OSError, NotImplementedError):
            self.skipTest('symlinks not permitted here')
        code, _, _ = self._export(os.path.join(link, 'x.json'))
        self.assertEqual(code, 2)
        self.assertEqual(os.listdir(os.path.join(self.home, '.quickwork')), [])

    def test_export_onto_mcp_config_json_refused_anywhere(self):
        for name in ('mcp_config.json', 'MCP_Config.JSON'):
            code, _, _ = self._export(os.path.join(self.outdir, name))
            self.assertEqual(code, 2, name)
        self.assertEqual(os.listdir(self.outdir), [])

    def test_full_export_requires_exact_token(self):
        dest = os.path.join(self.outdir, 'full.json')
        for extra in ([], ['--ack', 'export full'], ['--ack', 'COPY FULL'], ['--ack', 'EXPORT FULL ']):
            code, _, _ = self._export(dest, '--full-export', *extra)
            self.assertEqual(code, 2, extra)
            self.assertFalse(os.path.exists(dest))
        code, _, err = self._export(dest, '--full-export', '--ack', 'EXPORT FULL')
        self.assertEqual(code, 0)
        with open(dest, encoding='utf-8') as f:
            self.assertIn('fakeuser@gateway.example.com', f.read())
        self.assertIn('FULL variant', err)

    def test_full_export_token_reaches_writer_outside_quick_dir(self):
        written = []
        dest = os.path.join(self.outdir, 'full2.json')
        with mock.patch.object(quick_reg, 'secure_write_text', lambda p, t: written.append((p, t))):
            code, _, _ = self._export(dest, '--full-export', '--ack', 'EXPORT FULL')
            self.assertEqual(code, 0)
            code2, _, _ = self._export(dest, '--full-export', '--ack', 'export full')
            self.assertEqual(code2, 2)
        self.assertEqual(len(written), 1)
        self.assertIn('fakeuser@gateway.example.com', written[0][1])

    def test_full_export_with_token_still_refused_inside_quick_dir(self):
        dest = os.path.join(self.home, '.quickwork', 'full.json')
        code, _, _ = self._export(dest, '--full-export', '--ack', 'EXPORT FULL')
        self.assertEqual(code, 2)
        self.assertFalse(os.path.exists(dest))

    def test_plan_file_inside_quick_dir_refused(self):
        dest = os.path.join(self.home, '.quickwork', 'plan.json')
        code, _, _ = self.guarded(['plan', self.manifest, '--plan-file', dest])
        self.assertEqual(code, 2)
        self.assertFalse(os.path.exists(dest))

    def test_explicit_profile_dir_protected(self):
        qh = os.path.join(self.tmp, 'other-quick-home')
        os.mkdir(qh)
        code, _, _ = self.guarded(['export', self.manifest, '--output-file',
                                   os.path.join(qh, 'x.json'), '--profile-dir', qh])
        self.assertEqual(code, 2)
        self.assertEqual(os.listdir(qh), [])


class TestCliWindowsParity(CliHarness):
    def test_windows_inspect_uses_sshg_exact_args(self):
        seen = []

        class D(object):
            def __init__(s, gw):
                seen.append(('deployer', gw))

            def inspect(s):
                return {'state': 'READY'}

        def sshg(host, user, kh):
            seen.append(('sshg', host, user, kh))
            return 'GW'
        with plat('win32'), mock.patch.object(cli, 'SSHG', sshg), \
                mock.patch.object(cli, 'ConnectorDeployer', D):
            code, out, _ = run_cli(['inspect', self.manifest, '--known-hosts', '/tmp/kh'])
        self.assertEqual(code, 0)
        self.assertEqual(seen, [('sshg', 'gateway.example.com', 'fakeuser', '/tmp/kh'),
                                ('deployer', 'GW')])

    def test_windows_ack_ignored_and_g2_reachable(self):
        calls = []

        class D(object):
            def __init__(s, gw):
                pass

            def bootstrap(s, approved=False):
                calls.append(approved)
                return {'status': 'BOOTSTRAPPED'}
        with plat('win32'), mock.patch.object(cli, 'SSHG', lambda *a: 'GW'), \
                mock.patch.object(cli, 'ConnectorDeployer', D):
            code, _, _ = run_cli(['bootstrap', '--host', 'gateway.example.com', '--user',
                                  'fakeuser', '--approve-bootstrap', '--ack', 'whatever'])
        self.assertEqual(code, 0)
        self.assertEqual(calls, [True])


class TestCliWindowsExportParity(unittest.TestCase):
    """Decision B is darwin-only: on Windows export into ~/.quickwork and --full-export
    without any token behave exactly as BASE (written)."""
    def test_windows_export_unchanged(self):
        tmp = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, tmp, True)
        manifest = os.path.join(tmp, 'm.json')
        with open(manifest, 'w', encoding='utf-8') as f:
            json.dump(SPEC, f)
        qw = os.path.join(tmp, '.quickwork')
        os.mkdir(qw)
        dest = os.path.join(qw, 'full.json')
        with plat('win32'), mock.patch.dict(os.environ, {'HOME': tmp, 'USERPROFILE': tmp}):
            code, out, err = run_cli(['export', manifest, '--output-file', dest, '--full-export'])
        self.assertEqual(code, 0)
        self.assertTrue(os.path.isfile(dest))


# ----------------------------------------------------------------- A1.1 / B3b
class TestA11CliHelp(unittest.TestCase):
    """P2-SEC-054: --help on macOS is accurate; off macOS the pre-A1 wording is kept."""
    def _help(self, platname):
        with plat(platname):
            code, out, err = run_cli(['--help'])
        self.assertEqual(code, 0)
        return ''.join(out.split())   # whitespace-free: immune to argparse wrapping

    def test_054_darwin_help_accurate(self):
        h = self._help('darwin')
        self.assertNotIn('remoteread', h)
        for needle in ('INSPECTGATEWAY<user>@<host>', 'VERIFYBACKEND<target>', 'EXPORTFULL',
                       'alwaysofflineonmacOS(noSSH)'):
            self.assertIn(needle, h)

    def test_054_off_darwin_help_keeps_pre_a1_wording(self):
        want = ''.join(PRE_A1_ACK_HELP.split())
        for p in ('win32', 'linux'):
            with self.subTest(platform=p):
                h = self._help(p)
                self.assertIn(want, h)
                self.assertNotIn('INSPECTGATEWAY', h)


class TestA11GatewayDarwin(unittest.TestCase):
    """P2-SEC-055/058/059/060 driven through the REAL SSHGateway.run / ConnectorDeployer."""
    def setUp(self):
        d = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, d, True)
        self.kh = os.path.join(d, 'known_hosts')
        with open(self.kh, 'w') as f:
            f.write('gateway.example.com ssh-ed25519 AAAAPLACEHOLDER\n')

    def _stub_run(self, gw, req, behaviour='ok', platname='darwin'):
        rec = new_rec()
        stub = make_stub_paramiko(behaviour, rec)
        with plat(platname), Trip('stub', stub) as t:
            try:
                res, err = gw.run(req), None
            except Exception as exc:  # asserted by the caller
                res, err = None, exc
        return rec, t, res, err

    def _assert_nothing_reached(self, rec, t, req):
        self.assertEqual(t.paramiko_attempts, 0, req)
        self.assertEqual(rec['clients'], [], req)
        self.assertEqual(rec['stdin'], [], req)

    # (b) P2-SEC-055 target binding
    def test_055_request_target_str_subclass_refused_before_import(self):
        for req in ({'op': 'inspect_lambda_target', 'target': _EqAll('other-demo')},
                    {'op': 'probe_existing', 'kind': 'git', 'target': _EqAll('other-demo')},
                    {'op': 'inspect', 'target': _EqAll(TARGET)}):
            with self.subTest(req=req['op']):
                rec, t, res, err = self._stub_run(vb_gw(known_hosts=self.kh), req)
                self.assertIsInstance(err, GateRefused)
                self._assert_nothing_reached(rec, t, req)

    def test_055_entry_target_binding_both_directions(self):
        for label, tgt in (('rtr-demo', 'other-demo'), ('other-demo', 'rtr-demo')):
            spec = dict(SPEC, target=tgt)
            for name in ('discover', 'verify_backend'):
                with self.subTest(label=label, call=name):
                    gw = FailGateway(ack='VERIFY BACKEND ' + label, label=label)
                    with darwin(), Trip() as t:
                        with self.assertRaises(GateRefused):
                            getattr(ConnectorDeployer(gw), name)(spec)
                    self.assertEqual(gw.calls, [])
                    self.assertEqual(t.paramiko_attempts, 0)
        for name in ('discover', 'verify_backend'):
            gw = FailGateway()
            with darwin(), Trip():
                with self.assertRaises(GateRefused):
                    getattr(ConnectorDeployer(gw), name)(dict(SPEC, target=_EqAll('other-demo')))
            self.assertEqual(gw.calls, [])

    def test_055_every_request_on_allowed_paths_names_only_the_approved_target(self):
        class G(FakeGateway):
            def run(s, q, timeout=65):
                s.calls.append(q)
                if q['op'] == 'inspect':
                    return {'state': 'READY', 'installed': True, 'sha256': 'a' * 64,
                            'target_names': [s.label], 'kinds': {s.label: 'lambda'},
                            'git_targets': ['gitlab']}
                if q['op'] == 'inspect_lambda_target':
                    return {'url': SPEC['url'], 'allow': ['get_rating_mappings']}
                return {'tools': [{'name': 'get_rating_mappings'}], 'count': 1, 'truncated': False}
        cases = [(TARGET, dict(SPEC), 'verify_backend'), (TARGET, dict(SPEC), 'discover'),
                 ('gitlab', {'transport': 'linux-ssh', 'host': HOST, 'user': USER, 'kind': 'git',
                             'target': 'gitlab'}, 'verify_backend')]
        for label, spec, name in cases:
            with self.subTest(label=label, call=name):
                gw = G(ack='VERIFY BACKEND ' + label, scope=VB, label=label)
                with darwin(), Trip():
                    getattr(ConnectorDeployer(gw), name)(spec)
                self.assertTrue(gw.calls)
                for q in gw.calls:
                    self.assertIn(q['op'], VERIFY_OPS)
                    if 'target' in q:
                        self.assertEqual(q['target'], label)
                    self.assertTrue(set(q) <= set(deploy_lib.DARWIN_REQUEST_KEYS[q['op']]), q)

    def test_055_discover_through_real_gateway_sends_bound_request_only(self):
        rec = new_rec()
        stub = make_stub_paramiko('ok', rec)
        with darwin(), Trip('stub', stub) as t:
            ConnectorDeployer(vb_gw(known_hosts=self.kh)).discover(dict(SPEC))
        self.assertEqual(t.paramiko_attempts, 1)
        sent = json.loads(rec['stdin'][0].decode('utf-8'))
        self.assertEqual(sorted(sent), ['entry', 'op'])
        self.assertEqual(sent['op'], 'discover')
        self.assertEqual(sent['entry']['allow'], ['discovery-placeholder'])

    # (d) P2-SEC-058 any import exception
    def test_058_any_import_exception_gives_fixed_message(self):
        for exc in (OSError('dlopen /Users/fakeuser/lib/_bcrypt.so: code signature invalid'),
                    RuntimeError('boom fakeuser'), ValueError('x'), AttributeError('y'),
                    SyntaxError('z'), ImportError('No module named paramiko')):
            with self.subTest(exc=type(exc).__name__):
                with darwin(), Trip('raise', exc=exc) as t:
                    try:
                        vb_gw(known_hosts=self.kh).run({'op': 'inspect'})
                        got = None
                    except Exception as e:  # asserted below (a leak is a FAILURE, not an error)
                        got = e
                self.assertIsInstance(got, DeploymentError)
                self.assertEqual(str(got), NO_SSH_LIB)
                self.assertEqual(t.paramiko_attempts, 1)

    def test_058_windows_import_handling_unchanged(self):
        gw = SSHGateway(HOST, USER)
        for p in ('win32', 'linux'):
            with self.subTest(platform=p):
                with plat(p), Trip('raise', exc=OSError('dlopen failed')):
                    with self.assertRaises(OSError):
                        gw.run({'op': 'bootstrap'})
                with plat(p), Trip('raise', exc=ImportError('x')):
                    with self.assertRaises(DeploymentError) as cm:
                        gw.run({'op': 'bootstrap'})
                self.assertEqual(str(cm.exception), 'Install Paramiko first: py -m pip install paramiko')

    # (e) P2-SEC-059 / F9 size + validation before any connect
    def test_059_size_limit_checked_before_import_and_connect(self):
        base = len(json.dumps({'op': 'discover', 'entry': dict(VALID_ENTRY, note='')}, sort_keys=True))
        at_limit = {'op': 'discover', 'entry': dict(VALID_ENTRY, note='x' * (262144 - base))}
        over = {'op': 'discover', 'entry': dict(VALID_ENTRY, note='x' * (262145 - base))}
        rec, t, res, err = self._stub_run(vb_gw(known_hosts=self.kh), over)
        self.assertIsInstance(err, DeploymentError)
        self.assertEqual(str(err), 'Request exceeds safety size limit')
        self._assert_nothing_reached(rec, t, 'over')
        rec, t, res, err = self._stub_run(vb_gw(known_hosts=self.kh), at_limit)
        self.assertIsNone(err)
        self.assertEqual(len(rec['clients'][0].connects), 1)
        self.assertEqual(rec['clients'][0].execs, 1)

    def test_059_validation_before_import_and_connect(self):
        V = deploy_lib.ValidationError

        def gw(host=HOST, user=USER, label=TARGET):
            return SSHGateway(host, user, self.kh, ack='VERIFY BACKEND ' + label, scope=VB, label=label)
        cases = [(gw(host='bad host'), {'op': 'inspect'}, V),
                 (gw(host='-oProxyCommand=x'), {'op': 'inspect'}, V),
                 (gw(user='-oProxyCommand=x'), {'op': 'inspect'}, V),
                 (gw(host=None), {'op': 'inspect'}, V),
                 (gw(label='RTR_DEMO'), {'op': 'probe_existing', 'kind': 'git', 'target': 'RTR_DEMO'}, V),
                 (gw(), {'op': 'discover', 'entry': dict(VALID_ENTRY, url='http://abc123.lambda-url.us-east-1.on.aws')}, V),
                 (gw(), {'op': 'discover', 'entry': dict(VALID_ENTRY, allow=[])}, V),
                 (gw(), {'op': 'discover', 'entry': 'x'}, GateRefused),
                 (gw(), {'op': 'discover', 'entry': dict(VALID_ENTRY), 'target': TARGET}, GateRefused),
                 (gw(), {'op': 'inspect', 'extra': 1}, GateRefused),
                 (gw(), {'op': 'inspect', 1: 2}, GateRefused),
                 (gw(), {'op': 'probe_existing', 'kind': 'lambda', 'target': TARGET}, GateRefused),
                 (gw(), {'op': 'discover', 'entry': dict(VALID_ENTRY, note=object())}, DeploymentError)]
        for g, req, exc_type in cases:
            with self.subTest(req=repr(req)[:60], host=g.host):
                rec, t, res, err = self._stub_run(g, req)
                self.assertIsInstance(err, exc_type)
                self._assert_nothing_reached(rec, t, req)
        rec, t, res, err = self._stub_run(gw(host='192.0.2.10'), {'op': 'inspect'})
        self.assertIsNone(err)
        self.assertEqual(len(rec['clients'][0].connects), 1)

    # (f) P2-SEC-060 remote error redaction
    def test_060_remote_error_redacted_on_darwin(self):
        rec, t, res, err = self._stub_run(vb_gw(known_hosts=self.kh), {'op': 'inspect'}, 'okfalse_leak')
        self.assertIsInstance(err, DeploymentError)
        msg = str(err)
        for part in LEAK_PARTS:
            self.assertNotIn(part, msg)
        self.assertIn('<URL>', msg)
        self.assertIn('token=<REDACTED>', msg)
        self.assertTrue(msg.isascii())
        self.assertNotIn('internal-host', deploy_lib._darwin_redact_remote_error(
            'cannot resolve internal-host.example.net', USER, HOST))
        for behaviour in ('okfalse_noerr', 'okfalse_nonstr', 'okfalse'):
            with self.subTest(behaviour=behaviour):
                rec, t, res, err = self._stub_run(vb_gw(known_hosts=self.kh), {'op': 'inspect'}, behaviour)
                self.assertEqual(str(err), 'Remote operation failed')

    def test_060_redactor_caps_length_and_fails_closed(self):
        f = deploy_lib._darwin_redact_remote_error
        self.assertEqual(len(f('word ' * 200, USER, HOST)), 303)
        self.assertEqual(f('caf\u00e9 \u202e', USER, HOST), 'caf? ?')
        self.assertEqual(f('x', '', HOST), 'Remote operation failed')
        self.assertEqual(f(None, USER, HOST), 'Remote operation failed')
        self.assertEqual(f('   ', USER, HOST), 'Remote operation failed')

    def test_060_windows_remote_error_unchanged(self):
        for p in ('win32', 'linux'):
            with self.subTest(platform=p):
                rec, t, res, err = self._stub_run(SSHGateway(HOST, USER, self.kh), {'op': 'inspect'},
                                                  'okfalse_leak', platname=p)
                self.assertIsInstance(err, DeploymentError)
                self.assertEqual(str(err), LEAKY_ERROR)

    def test_060_transport_wrapper_still_type_name_only(self):
        rec, t, res, err = self._stub_run(vb_gw(known_hosts=self.kh), {'op': 'inspect'}, 'auth')
        self.assertEqual(str(err), TRANSPORT_MSG.format('AuthenticationException'))


if __name__ == '__main__':
    unittest.main()
