"""P2 Slice 1 / B2: wizard.py macOS behaviour, driven on the REAL Wizard with
is_darwin patched (wizard + capability_gate) and tripwires armed. GUI tests use
withdrawn roots. Collaborator classes (deploy_lib SSHGateway(ack=,scope=,label=),
ConnectorDeployer) are replaced by recording stubs that follow the A1.3 contract so the
wizard's own logic is isolated; deploy_lib's gate itself is tested in test_p2s1_core_b.
B3 adds: two operation-bound G1b windows (A1.3), the F1(i) SSH-library pre-check before
any typed prompt, W1 guarded grab_set, W2 visible callback failure, the export guard
(decision B) and the Step-4 provenance labels (decision C).
"""
import ast
import builtins
import os
import socket
import sqlite3
import subprocess
import sys
import threading
import time
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import capability_gate
import wizard

HAS_DISPLAY = bool(os.environ.get('DISPLAY')) or sys.platform in ('win32', 'darwin')
SRC = (ROOT / 'wizard.py').read_text(encoding='utf-8')
TOKEN = 'VERIFY BACKEND epg-demo'
IG_TOKEN = 'INSPECT GATEWAY fakeuser@gateway.example.com'
IG = 'inspect-gateway'
VB = 'verify-backend'
URL = 'https://abc123.lambda-url.us-west-2.on.aws/mcp'
HOSTKEY = ('the host must already be in your known_hosts; changed or unknown keys are '
           'REFUSED; nothing is added')
# A1.1 P2-SEC-057 golden fragments.
KH_BOTH = ('checked against BOTH the system known_hosts file and the known_hosts file selected '
           'in this wizard')
WORKER_A11 = ("It runs there as the SSH user with the gateway's python3, and its source is visible "
              "in the gateway's process list.")
VERIFY_ONLY = ("It uses the GATEWAY host's own credentials (not yours) for the backend.",
               'Git or local backend: it may START the backend MCP process on the gateway.',
               "Lambda backend: it makes a signed (SigV4) call with the gateway's AWS identity.",
               'Only MCP initialize + tools/list are sent; no application tool is executed.')
SPEC = {'transport': 'linux-ssh', 'host': 'gateway.example.com', 'user': 'fakeuser',
        'kind': 'lambda', 'target': 'epg-demo', 'display_name': 'epg demo', 'url': URL,
        'allow': ['get_rating_mappings']}


def _trip(*a, **k):
    raise AssertionError('tripwire: forbidden call on darwin path')


_real_import = builtins.__import__


def _guarded_import(name, *a, **k):
    if name == 'paramiko' or name.startswith('paramiko.'):
        raise AssertionError('tripwire: paramiko import')
    return _real_import(name, *a, **k)


class Tripwires(object):
    def __enter__(self):
        self.ps = [mock.patch.object(subprocess, 'run', _trip),
                   mock.patch.object(subprocess, 'Popen', _trip),
                   mock.patch.object(os, 'system', _trip),
                   mock.patch.object(socket, 'socket', _trip),
                   mock.patch.object(socket, 'create_connection', _trip),
                   mock.patch.object(sqlite3, 'connect', _trip),
                   mock.patch.object(builtins, '__import__', _guarded_import)]
        for p in self.ps:
            p.start()
        return self

    def __exit__(self, *exc):
        for p in reversed(self.ps):
            p.stop()
        return False


class GwStub(object):
    instances = []

    def __init__(self, host, user, known_hosts=None, timeout=15, ack=None, scope=None, label=None):
        self.host, self.user, self.ack, self.scope, self.label = host, user, ack, scope, label
        GwStub.instances.append(self)

    def run(self, request, timeout=65):
        return {'state': 'READY', 'op': request.get('op')}


class DeployerStub(object):
    calls = []

    def __init__(self, gateway):
        self.gateway = gateway
        DeployerStub.calls.append(('init', gateway))

    def inspect(self):
        DeployerStub.calls.append(('inspect', self.gateway))
        return {'state': 'READY'}

    def verify_backend(self, spec):
        DeployerStub.calls.append(('verify_backend', self.gateway))
        raise RuntimeError('stub stop')

    def prepare_offline(self, spec):
        DeployerStub.calls.append(('prepare_offline', self.gateway))
        return {'offline': True, 'backend_identity_sha256': 'x'}

    def __getattr__(self, name):
        raise AssertionError('DeployerStub: forbidden method ' + name)


# ---------------------------------------------------------------- pure (no Tk)
class PureTextTests(unittest.TestCase):
    def test_inspect_gateway_window_text(self):
        title, msg, expected = wizard.g1b_dialog(IG, 'gateway.example.com', 'fakeuser', 'epg-demo',
                                                 'abc123.lambda-url.us-west-2.on.aws', ['SRC-A', 'SRC-B'])
        self.assertEqual(title, 'Inspect gateway (SSH, read-only)')
        self.assertEqual(expected, IG_TOKEN)
        for needle in ('Destination host : gateway.example.com', 'SSH user         : fakeuser',
                       'Port             : 22', 'gateway state ONLY', 'does NOT start or contact any backend',
                       HOSTKEY, 'bundled worker program', '  - SRC-A', '  - SRC-B', '  ' + IG_TOKEN):
            self.assertIn(needle, msg)
        for absent in ('VERIFY BACKEND', 'Target           :', 'Backend host', 'initialize'):
            self.assertNotIn(absent, msg)

    def test_verify_backend_window_text(self):
        title, msg, expected = wizard.g1b_dialog(VB, 'gateway.example.com', 'fakeuser', 'epg-demo',
                                                 'abc123.lambda-url.us-west-2.on.aws', ['SRC-A'])
        self.assertEqual(title, 'Verify backend (SSH + backend metadata handshake)')
        self.assertEqual(expected, TOKEN)
        for needle in ('Destination host : gateway.example.com', 'SSH user         : fakeuser',
                       'Port             : 22', 'Target           : epg-demo',
                       'Backend host     : abc123.lambda-url.us-west-2.on.aws',
                       'initialize + tools/list', "gateway host's own credentials",
                       'No application tool is executed', HOSTKEY, 'bundled worker program',
                       '  - SRC-A', '  ' + TOKEN):
            self.assertIn(needle, msg)
        self.assertNotIn('INSPECT GATEWAY', msg)
        self.assertNotIn('/mcp', msg)

    def test_window_text_refuses_unknown_scope_and_bad_labels(self):
        for args in (('inspect', 'gateway.example.com', 'fakeuser', 'epg-demo'),
                     (None, 'gateway.example.com', 'fakeuser', 'epg-demo'),
                     (IG, 'gateway.example.com', 'fake user', 'epg-demo'),
                     (IG, 'gate@way', 'fakeuser', 'epg-demo'),
                     (VB, 'gateway.example.com', 'fakeuser', 'epg demo'),
                     (VB, 'gateway.example.com', 'fakeuser', '')):
            with self.subTest(args=args):
                with self.assertRaises(capability_gate.GateRefused):
                    wizard.g1b_dialog(args[0], args[1], args[2], args[3], 'h', ['S'])

    def test_backend_host_is_host_part_only(self):
        self.assertEqual(wizard.darwin_backend_host({'kind': 'lambda', 'url': URL}),
                         'abc123.lambda-url.us-west-2.on.aws')
        self.assertEqual(wizard.darwin_backend_host({'kind': 'git', 'url': ''}),
                         '(existing gateway-registered target; no URL)')
        self.assertEqual(wizard.darwin_backend_host({'kind': 'lambda', 'url': 'https://[::1'}),
                         '(invalid URL)')
        self.assertEqual(wizard.darwin_backend_host(None), '(unknown)')

    def test_ssh_library_precheck_uses_find_spec_only(self):
        with mock.patch('importlib.util.find_spec', return_value=None) as fs:
            self.assertFalse(wizard.darwin_ssh_library_present())
        fs.assert_called_once_with('paramiko')
        with mock.patch('importlib.util.find_spec', return_value=object()):
            self.assertTrue(wizard.darwin_ssh_library_present())
        with mock.patch('importlib.util.find_spec', side_effect=ValueError('x')):
            self.assertFalse(wizard.darwin_ssh_library_present())
        with Tripwires(), mock.patch('importlib.util.find_spec', return_value=None):
            self.assertFalse(wizard.darwin_ssh_library_present())

    def test_step4_provenance_labels(self):
        ident = lambda spec: 'ID-1'
        ver = {'backend_identity_sha256': 'ID-1', 'tool_count': 3}
        meta = {'at': '2026-10-29 10:00:00', 'identity': 'ID-1'}
        t = wizard.darwin_step4_provenance_text({'k': 1}, {'offline': True}, ver, meta, ident)
        for needle in ('never opens SSH', 'never starts a remote-access (G1b)', 'never launches a process',
                       'OFFLINE-GENERATED (no SSH, no gateway read)', 'NOT READ (offline plan)',
                       'METADATA FROM AN EARLIER AUTHORIZED VERIFICATION IN THIS SESSION',
                       'obtained 2026-10-29 10:00:00', 'offered tool count (3)', 'NOT re-read'):
            self.assertIn(needle, t)
        self.assertNotIn('WARNING', t)
        t2 = wizard.darwin_step4_provenance_text({'k': 1}, None, None, None, ident)
        self.assertIn('none held for the current backend fields', t2)
        self.assertNotIn('IN THIS SESSION', t2)
        t3 = wizard.darwin_step4_provenance_text({'k': 1}, {'offline': True}, ver,
                                                 {'at': 'T', 'identity': 'OTHER'}, ident)
        self.assertIn('obtained at an unrecorded time', t3)
        t4 = wizard.darwin_step4_provenance_text({'k': 1}, {'offline': False}, ver, meta, ident)
        self.assertIn('WARNING: the plan shown is NOT marked offline.', t4)
        t5 = wizard.darwin_step4_provenance_text({'k': 1}, None, dict(ver, backend_identity_sha256='ID-2'),
                                                 meta, ident)
        self.assertIn('none held', t5)

    def test_auth_sources_fail_closed_when_deploy_lib_has_none(self):
        # A1.1 P2-SEC-057: no hard-coded fallback text; refuse instead.
        for repl in (None, lambda: None, lambda: [], lambda: ['ok', ''], lambda: 'one string',
                     lambda: [1], _trip):
            with self.subTest(repl=repr(repl)[:30]):
                with mock.patch.object(wizard._deploy_lib_mod, 'describe_auth_sources', repl, create=True):
                    with self.assertRaises(capability_gate.GateRefused):
                        wizard.darwin_auth_sources()
        self.assertNotIn('PLACEHOLDER', SRC)

    def test_a11_dialog_sentences_inspect_gateway(self):
        title, msg, expected = wizard.g1b_dialog(IG, 'gateway.example.com', 'fakeuser', 'epg-demo',
                                                 'abc123.lambda-url.us-west-2.on.aws',
                                                 wizard.darwin_auth_sources())
        for needle in (KH_BOTH, WORKER_A11, HOSTKEY, '  ' + IG_TOKEN):
            self.assertIn(needle, msg)
        for absent in VERIFY_ONLY:
            self.assertNotIn(absent, msg)

    def test_a11_dialog_sentences_verify_backend(self):
        title, msg, expected = wizard.g1b_dialog(VB, 'gateway.example.com', 'fakeuser', 'epg-demo',
                                                 'abc123.lambda-url.us-west-2.on.aws',
                                                 wizard.darwin_auth_sources())
        for needle in (KH_BOTH, WORKER_A11, HOSTKEY, '  ' + TOKEN) + VERIFY_ONLY:
            self.assertIn(needle, msg)
        # the exact text to type is the last line
        self.assertEqual(msg.split('\n')[-1], '  ' + TOKEN)

    def test_a11_auth_lines_are_describe_auth_sources_verbatim(self):
        import deploy_lib
        src_lines = deploy_lib.describe_auth_sources()
        for scope in (IG, VB):
            with self.subTest(scope=scope):
                _, msg, _ = wizard.g1b_dialog(scope, 'gateway.example.com', 'fakeuser', 'epg-demo',
                                              'h', wizard.darwin_auth_sources())
                lines = msg.split('\n')
                i = lines.index('Authentication sources the SSH layer may use:')
                self.assertEqual(lines[i + 1:i + 1 + len(src_lines)], ['  - ' + s for s in src_lines])
                self.assertIn('Every key held by the agent may be offered', msg)
                self.assertIn('which this program opens and reads (look_for_keys=True)', msg)
        low = SRC.lower()
        self.assertNotIn('agent only', low)
        self.assertNotIn('agent-only', low)
        self.assertNotIn('look_for_keys=false', low)

    def test_a11_dialog_refuses_missing_auth_sources(self):
        for bad in (None, [], (), [''], [1], 'x'):
            with self.subTest(bad=bad):
                with self.assertRaises(capability_gate.GateRefused):
                    wizard.g1b_dialog(VB, 'gateway.example.com', 'fakeuser', 'epg-demo', 'h', bad)

    def test_a11_find_spec_import_is_inside_the_guard(self):
        tree = ast.parse(SRC)
        fn = [n for n in tree.body if isinstance(n, ast.FunctionDef)
              and n.name == 'darwin_ssh_library_present'][0]
        body = [s for s in fn.body if not (isinstance(s, ast.Expr) and isinstance(s.value, ast.Constant))]
        self.assertEqual(len(body), 1)
        self.assertIsInstance(body[0], ast.Try)
        self.assertIsInstance(body[0].body[0], ast.Import)
        self.assertEqual(ast.unparse(body[0].handlers[0].type), 'Exception')

    def test_a11_step5_darwin_branch_uses_screen_builder_only(self):
        tree = ast.parse(SRC)
        fn = [n for c in tree.body if isinstance(c, ast.ClassDef) and c.name == 'Wizard'
              for n in c.body if isinstance(n, ast.FunctionDef) and n.name == 'render_quick'][0]
        ifs = [n for n in ast.walk(fn) if isinstance(n, ast.If) and ast.unparse(n.test) == 'self._darwin'
               and 'quick_instructions_screen' in ast.unparse(n)]
        self.assertEqual(len(ifs), 1)
        body = ast.unparse(ast.Module(body=ifs[0].body, type_ignores=[]))
        orelse = ast.unparse(ast.Module(body=ifs[0].orelse, type_ignores=[]))
        self.assertIn('quick_instructions_screen(self.spec())', body)
        self.assertNotIn('full', body)
        self.assertNotIn('quick_instructions_variants', body)
        self.assertIn("msg = variants['full']", orelse)

    def test_auth_sources_wired_from_deploy_lib_when_present(self):
        with mock.patch.object(wizard._deploy_lib_mod, 'describe_auth_sources',
                               lambda: ['FROM-DEPLOY-LIB'], create=True):
            self.assertEqual(wizard.darwin_auth_sources(), ['FROM-DEPLOY-LIB'])

    def test_no_simpledialog_and_no_forbidden_strings(self):
        tree = ast.parse(SRC)
        names = set()
        for n in ast.walk(tree):
            if isinstance(n, (ast.Import, ast.ImportFrom)):
                for a in n.names:
                    names.add(a.name)
                if isinstance(n, ast.ImportFrom) and n.module:
                    names.add(n.module)
        self.assertNotIn('simpledialog', ' '.join(names))
        consts = ' '.join(n.value.lower() for n in ast.walk(tree)
                          if isinstance(n, ast.Constant) and isinstance(n.value, str))
        for bad in ('osascript', 'launchctl', 'sudo ', 'brew ', 'xattr', 'spctl',
                    'codesign', 'tccutil', 'keychain', 'tools/call'):
            self.assertNotIn(bad, consts)
        self.assertNotIn('simpledialog', SRC)

    def test_fonts_table_literal(self):
        self.assertEqual(wizard.DARWIN_FONTS, {'ui': 'Helvetica Neue', 'ui_bold': 'Helvetica Neue', 'mono': 'Menlo'})
        self.assertIn("font=('Segoe UI',10)", SRC)
        self.assertIn("font=('Consolas',10)", SRC)


# ---------------------------------------------------------------- no-Tk method tests
class _Status(object):
    def __init__(self):
        self.texts = []

    def config(self, **kw):
        self.texts.append(kw.get('text'))


class _FakeSelf(object):
    """Stands in for `self` when a REAL Wizard method is called unbound (no Tk root)."""
    def __init__(self, darwin, typed=None):
        self._darwin = darwin
        self.bootstrap_receipt = {'kind': 'wizard-bootstrap-receipt'}
        self._quick_variants = {'redacted': 'R-TEXT', 'full': 'FULL-SENTINEL'}
        self.status = _Status()
        self.copied = []
        self.armed = []
        self.typed = typed

    def spec(self):
        return dict(SPEC)

    def _typed_prompt(self, title, message, expected):
        return self.typed

    def copy_text(self, value):
        self.copied.append(value)

    def _arm_clipboard_clear(self, value):
        self.armed.append(value)


class MethodTestsNoTk(unittest.TestCase):
    """A1.1 user gap fixes (g)(i)/(g)(ii) on the REAL wizard methods (unbound, fake self)."""
    def _platform(self, name):
        import platform_p2
        return mock.patch.object(platform_p2.sys, 'platform', name)

    def _save(self, fake, path):
        writes, errors = [], []
        with mock.patch.object(wizard.filedialog, 'asksaveasfilename', lambda **k: path, create=True), \
                mock.patch.object(wizard.messagebox, 'showerror', lambda *a: errors.append(a), create=True), \
                mock.patch.object(wizard.messagebox, 'showinfo', lambda *a: None, create=True), \
                mock.patch.object(wizard, 'host_is_wizard_lambda_only', lambda r: True), \
                mock.patch.object(wizard, 'secure_write_json', lambda p, d: writes.append(p)):
            wizard.Wizard.save_bootstrap_receipt_action(fake)
        return writes, errors

    def test_g_i_bootstrap_receipt_refused_inside_quick_dir_on_darwin(self):
        import quick_reg
        quick = os.path.join(os.path.expanduser('~'), '.quickwork', 'receipt.json')
        for path in (quick, os.path.join(os.path.expanduser('~'), '.QuickWork', 'r.json'),
                     os.path.join(os.sep, 'tmp', 'p2-elsewhere', 'mcp_config.json'),
                     os.path.join(os.sep, 'tmp', 'p2-elsewhere', '..', 'x', '..', '..',
                                  os.path.expanduser('~').lstrip(os.sep), '.quickwork', 'r.json')):
            with self.subTest(path=path[-30:]):
                with self._platform('darwin'):
                    writes, errors = self._save(_FakeSelf(True), path)
                self.assertEqual(writes, [])
                self.assertEqual(errors, [('Save refused', quick_reg.P2_QUICK_DIR_REFUSED)])
        with self._platform('darwin'):
            writes, errors = self._save(_FakeSelf(True), os.path.join(os.sep, 'tmp', 'p2-elsewhere', 'r.json'))
        self.assertEqual(len(writes), 1)
        self.assertEqual(errors, [])

    def test_g_i_bootstrap_receipt_unchanged_off_darwin(self):
        quick = os.path.join(os.path.expanduser('~'), '.quickwork', 'receipt.json')
        import quick_reg
        with self._platform('win32'), mock.patch.object(quick_reg, 'p2_export_destination_refused', _trip):
            writes, errors = self._save(_FakeSelf(False), quick)
        self.assertEqual(writes, [quick])
        self.assertEqual(errors, [])

    def _copy(self, fake, gate_patch=None):
        errors = []
        ps = [mock.patch.object(wizard.messagebox, 'askyesno', lambda *a: True, create=True),
              mock.patch.object(wizard.messagebox, 'showerror', lambda *a: errors.append(a), create=True)]
        if gate_patch is not None:
            ps.append(gate_patch)
        for p in ps:
            p.start()
        try:
            with self._platform('darwin'):
                wizard.Wizard._copy_quick_full_darwin(fake)
        finally:
            for p in reversed(ps):
                p.stop()
        return errors

    def test_g_ii_full_copy_text_built_only_by_gated_builder(self):
        import quick_reg
        fake = _FakeSelf(True, typed='COPY FULL')
        errors = self._copy(fake)
        self.assertEqual(errors, [])
        with self._platform('darwin'):
            want = quick_reg.quick_instructions_full(dict(SPEC), 'COPY FULL')
        self.assertEqual(fake.copied, [want])
        self.assertEqual(fake.armed, [want])
        self.assertNotIn('FULL-SENTINEL', fake.copied)
        self.assertIn('fakeuser@gateway.example.com', want)

    def test_g_ii_bad_token_copies_nothing(self):
        for typed in (None, '', 'copy full', 'COPY FULL ', 'EXPORT FULL'):
            with self.subTest(typed=typed):
                fake = _FakeSelf(True, typed=typed)
                self._copy(fake)
                self.assertEqual(fake.copied, [])
                self.assertEqual(fake.armed, [])

    def test_g_ii_code_path_gate_holds_even_if_handler_check_bypassed(self):
        # Simulate a handler whose own token check is gone: the wizard-level
        # require_full_variant call is replaced, but quick_reg's check stays real.
        import quick_reg
        real = capability_gate.require_full_variant
        fake = _FakeSelf(True, typed='WRONG')
        calls = []

        def handler_bypass(kind, supplied, plat=None):
            calls.append(kind)
            return None
        self.assertIs(quick_reg._p2_gate.require_full_variant, real)
        with mock.patch.object(wizard, 'capability_gate', _GateView(handler_bypass)):
            self._copy(fake)
        self.assertEqual(calls, ['copy'])
        self.assertEqual(fake.copied, [])


class _GateView(object):
    """capability_gate as seen by wizard.py only, with require_full_variant replaced."""
    def __init__(self, rfv):
        self._rfv = rfv

    def __getattr__(self, name):
        if name == 'require_full_variant':
            return self._rfv
        return getattr(capability_gate, name)


# ---------------------------------------------------------------- B3c: Step 5 panel (no Tk)
class _RiggedStr(str):
    def __eq__(self, other):
        return True

    def __ne__(self, other):
        return False

    __hash__ = str.__hash__


class _FakeWidget(object):
    log = []

    def __init__(self, *a, **k):
        self.kw = dict(k)
        self.values = []
        _FakeWidget.log.append(self)

    def pack(self, *a, **k):
        return None

    def insert(self, index, value):
        self.values.append(value)

    def configure(self, **k):
        self.kw.update(k)


class _FLabel(_FakeWidget):
    pass


class _FFrame(_FakeWidget):
    pass


class _FEntry(_FakeWidget):
    pass


class _FButton(_FakeWidget):
    pass


class _FakeTtk(object):
    Label = _FLabel
    Frame = _FFrame
    Entry = _FEntry
    Button = _FButton


class _FakeParent(object):
    def __init__(self):
        self.destroyed = []

    def winfo_children(self):
        return []


class _PanelSelf(_FakeSelf):
    def __init__(self, typed=None, spec=None):
        _FakeSelf.__init__(self, True, typed=typed)
        self._spec = dict(SPEC) if spec is None else spec
        self.helped = []
        self.field_calls = []

    def spec(self):
        return dict(self._spec)

    def helper(self, parent, text):
        self.helped.append(text)

    def _copy_quick_field_full_darwin(self, key):
        self.field_calls.append(key)


class Step5PanelDarwinB3c(unittest.TestCase):
    """B3c item 2: on macOS the Step 5 Command / Arguments panel is REDACTED; the real
    values come only from darwin_full_copy_field after the typed COPY FULL token."""
    IDENT = SPEC['user'] + '@' + SPEC['host']

    def _platform(self, name):
        import platform_p2
        return mock.patch.object(platform_p2.sys, 'platform', name)

    def _no_identity(self, text):
        self.assertNotIn(SPEC['user'], text)
        self.assertNotIn(SPEC['host'], text)

    def test_redacted_fields_use_the_shared_redaction(self):
        import model
        import quick_reg
        with self._platform('darwin'):
            got = wizard.darwin_redacted_copy_fields(dict(SPEC))
            real = quick_reg.quick_copy_fields(model.quick_connector(dict(SPEC)))
            screen = quick_reg.quick_instructions_screen(dict(SPEC))['redacted']
        self.assertIn(self.IDENT, real['arguments'])
        for key in ('command', 'arguments', 'id', 'name'):
            self._no_identity(got[key])
            self.assertEqual(got[key], model.redact_identity(str(real[key]), SPEC['user'], SPEC['host']))
        self.assertEqual(got['command'], 'ssh')
        self.assertEqual(got['timeout_seconds'], real['timeout_seconds'])
        self.assertIn('Arguments       : ' + got['arguments'], screen)

    def test_redacted_fields_fail_closed_without_identity(self):
        for bad in (dict(SPEC, user=''), dict(SPEC, host=''), dict(SPEC, user='   ')):
            with self.subTest(bad=sorted(bad.items())[:2]):
                with self._platform('darwin'):
                    with self.assertRaises(Exception):
                        wizard.darwin_redacted_copy_fields(bad)

    def test_full_field_builder_needs_exact_token_before_building(self):
        bad_tokens = (None, '', 'copy full', 'COPY FULL ', 'EXPORT FULL', b'COPY FULL',
                      _RiggedStr('x'), _RiggedStr('COPY FULL'))
        for typed in bad_tokens:
            with self.subTest(typed=repr(typed)):
                with self._platform('darwin'), \
                        mock.patch.object(wizard, 'quick_connector', _trip), \
                        mock.patch.object(wizard, 'quick_copy_fields', _trip):
                    with self.assertRaises(capability_gate.GateRefused):
                        wizard.darwin_full_copy_field(dict(SPEC), 'arguments', typed)
        for p in ('darwin', 'win32'):
            with self.subTest(platform=p), self._platform(p), \
                    mock.patch.object(wizard, 'quick_connector', _trip):
                with self.assertRaises(capability_gate.GateRefused):
                    wizard.darwin_full_copy_field(dict(SPEC), 'arguments', 'WRONG')
        with self._platform('darwin'):
            self.assertIn(self.IDENT, wizard.darwin_full_copy_field(dict(SPEC), 'arguments', 'COPY FULL'))
            self.assertEqual(wizard.darwin_full_copy_field(dict(SPEC), 'command', 'COPY FULL'), 'ssh')
            with self.assertRaises(ValueError):
                wizard.darwin_full_copy_field(dict(SPEC), 'id', 'COPY FULL')

    def test_panel_shows_redacted_values_and_buttons_route_to_gate(self):
        fake = _PanelSelf()
        _FakeWidget.log = []
        with self._platform('darwin'), mock.patch.object(wizard, 'ttk', _FakeTtk):
            wizard.Wizard._show_quick_copy_fields_darwin(fake, _FakeParent())
        entries = [w for w in _FakeWidget.log if isinstance(w, _FEntry)]
        buttons = [w for w in _FakeWidget.log if isinstance(w, _FButton)]
        with self._platform('darwin'):
            want = wizard.darwin_redacted_copy_fields(dict(SPEC))
        self.assertEqual([e.values for e in entries], [[want['command']], [want['arguments']]])
        texts = [str(w.kw.get('text', '')) for w in _FakeWidget.log] + fake.helped
        texts += [v for e in entries for v in e.values]
        for t in texts:
            self._no_identity(t)
        self.assertIn(wizard.DARWIN_PANEL_REDACTED_NOTE, fake.helped)
        self.assertIn('COPY FULL', wizard.DARWIN_PANEL_REDACTED_NOTE)
        self.assertEqual(len(buttons), 2)
        for b in buttons:
            b.kw['command']()
        self.assertEqual(fake.field_calls, ['command', 'arguments'])
        self.assertEqual(fake.copied, [])
        self.assertEqual(fake.armed, [])

    def test_panel_bad_spec_shows_fixed_text_only(self):
        fake = _PanelSelf(spec=dict(SPEC, user=''))
        _FakeWidget.log = []
        with self._platform('darwin'), mock.patch.object(wizard, 'ttk', _FakeTtk):
            wizard.Wizard._show_quick_copy_fields_darwin(fake, _FakeParent())
        self.assertEqual([w.kw.get('text') for w in _FakeWidget.log],
                         ['Quick Command / Arguments appear here after plan generation.'])
        self.assertFalse([w for w in _FakeWidget.log if isinstance(w, (_FEntry, _FButton))])

    def _field_copy(self, fake, key, gate=None):
        errors = []
        ps = [mock.patch.object(wizard.messagebox, 'askyesno', lambda *a: True, create=True),
              mock.patch.object(wizard.messagebox, 'showerror', lambda *a: errors.append(a), create=True)]
        if gate is not None:
            ps.append(mock.patch.object(wizard, 'capability_gate', gate))
        for p in ps:
            p.start()
        try:
            with self._platform('darwin'):
                wizard.Wizard._copy_quick_field_full_darwin(fake, key)
        finally:
            for p in reversed(ps):
                p.stop()
        return errors

    def test_field_copy_bad_token_copies_nothing(self):
        for typed in (None, '', 'copy full', 'COPY FULL ', 'EXPORT FULL', _RiggedStr('COPY FULL')):
            for key in ('command', 'arguments'):
                with self.subTest(typed=repr(typed), key=key):
                    fake = _PanelSelf(typed=typed)
                    self._field_copy(fake, key)
                    self.assertEqual(fake.copied, [])
                    self.assertEqual(fake.armed, [])

    def test_field_copy_genuine_token_copies_real_value_and_arms_clear(self):
        import model
        import quick_reg
        real = quick_reg.quick_copy_fields(model.quick_connector(dict(SPEC)))
        for key in ('command', 'arguments'):
            with self.subTest(key=key):
                fake = _PanelSelf(typed='COPY FULL')
                self.assertEqual(self._field_copy(fake, key), [])
                self.assertEqual(fake.copied, [real[key]])
                self.assertEqual(fake.armed, [real[key]])

    def test_field_copy_second_layer_holds_if_handler_check_bypassed(self):
        calls = []

        def handler_bypass(kind, supplied, plat=None):
            calls.append(kind)
            return None
        fake = _PanelSelf(typed='WRONG')
        self._field_copy(fake, 'arguments', gate=_GateView(handler_bypass))
        self.assertEqual(calls, ['copy'])
        self.assertEqual(fake.copied, [])

    def test_render_quick_panel_darwin_branch_and_base_else(self):
        tree = ast.parse(SRC)
        fn = [n for c in tree.body if isinstance(c, ast.ClassDef) and c.name == 'Wizard'
              for n in c.body if isinstance(n, ast.FunctionDef) and n.name == 'render_quick'][0]
        ifs = [n for n in fn.body if isinstance(n, ast.If) and ast.unparse(n.test) == 'self._darwin'
               and '_show_quick_copy_fields_darwin' in ast.unparse(n)]
        self.assertEqual(len(ifs), 1)
        body = ast.unparse(ast.Module(body=ifs[0].body, type_ignores=[]))
        orelse = ast.unparse(ast.Module(body=ifs[0].orelse, type_ignores=[]))
        self.assertEqual(body, 'self._show_quick_copy_fields_darwin(self.quick_copy_area)')
        self.assertEqual(orelse, 'try:\n    self.show_quick_copy_fields(self.quick_copy_area, '
                                 'quick_connector(self.spec()))\nexcept Exception:\n'
                                 '    self.show_quick_copy_fields(self.quick_copy_area, None)')
        meth = [n for c in tree.body if isinstance(c, ast.ClassDef) and c.name == 'Wizard'
                for n in c.body if isinstance(n, ast.FunctionDef)
                and n.name == '_show_quick_copy_fields_darwin'][0]
        src = ast.unparse(meth)
        for absent in ('quick_copy_fields(', 'quick_connector(', 'copy_text', 'darwin_full_copy_field'):
            self.assertNotIn(absent, src)



# ---------------------------------------------------------------- B3d: Step 4 redaction + plan race (no Tk)
class _RecWidget(object):
    """Records every write. alive=None makes winfo_exists raise (a destroyed widget)."""
    def __init__(self, alive=True):
        self.text = ''
        self.ops = []
        self.alive = alive

    def winfo_exists(self):
        if self.alive is None:
            raise RuntimeError('widget destroyed')
        return self.alive

    def winfo_children(self):
        self.ops.append(('winfo_children',))
        return []

    def delete(self, a, b):
        self.ops.append(('delete', a, b))
        self.text = ''

    def insert(self, index, value):
        self.ops.append(('insert', index, value))
        self.text += value


class _Step4Self(_PanelSelf):
    """Fake `self` for the REAL Step 4 methods (unbound); panel builders are recorded."""
    _darwin_step4_owned = wizard.Wizard._darwin_step4_owned
    _darwin_render_step4 = wizard.Wizard._darwin_render_step4
    _darwin_wrap_plan_done = wizard.Wizard._darwin_wrap_plan_done

    def __init__(self, step=3):
        _PanelSelf.__init__(self)
        self.step = step
        self._tearing_down = False
        self.area = _RecWidget()
        self.view = _RecWidget()
        self.quick_copy_area = self.area
        self.plan_view = self.view
        self._darwin_step4_widgets = (self.area, self.view)
        self.prepared = None
        self.backend_verification = None
        self.panel_calls = []
        self.provenance = []
        self.summaries = []
        self.actions = []

    def _show_quick_copy_fields_darwin(self, parent):
        self.panel_calls.append(('darwin', parent))

    def show_quick_copy_fields(self, parent, connector):
        self.panel_calls.append(('base', parent, connector))

    def _darwin_refresh_provenance(self):
        self.provenance.append(1)

    def refresh_summary_view(self):
        self.summaries.append(1)

    def action(self, task, callback=None):
        self.actions.append((task, callback))

    def gateway(self):
        raise AssertionError('tripwire: gateway() on the darwin plan path')


class Step4DarwinB3d(unittest.TestCase):
    """B3d: on macOS the Step 4 Command / Arguments panel and plan JSON are REDACTED, and
    a late offline-plan result never writes into Step 5 (stale results are dropped)."""
    IDENT = SPEC['user'] + '@' + SPEC['host']
    OTHER_HOST = 'other.invalid'

    def _platform(self, name):
        import platform_p2
        return mock.patch.object(platform_p2.sys, 'platform', name)

    def _plan(self, spec=None):
        import deploy_lib
        with self._platform('darwin'):
            return deploy_lib.ConnectorDeployer(None).prepare_offline(dict(spec or SPEC))

    def _verification(self):
        import model
        return {'backend_identity_sha256': model.backend_identity(dict(SPEC)), 'handshake': 'h',
                'tool_count': 1, 'tools': [{'name': 'get_rating_mappings'}]}

    def _no_identity(self, text):
        self.assertNotIn(self.IDENT, text)
        self.assertNotIn(SPEC['host'], text)
        self.assertNotIn(SPEC['user'], text)

    def test_view_redacts_plan_json_and_leaves_plan_unchanged(self):
        import copy
        import json
        import model
        plan = self._plan()
        before = copy.deepcopy(plan)
        real = json.dumps(plan, indent=2)
        self.assertIn(self.IDENT, real)
        with self._platform('darwin'):
            show, text = wizard.darwin_step4_view(dict(SPEC), plan)
        self.assertTrue(show)
        self.assertEqual(plan, before)
        note = wizard.DARWIN_STEP4_REDACTED_NOTE
        self.assertIn('COPY FULL', note)
        self.assertTrue(text.startswith(note + '\n\n'))
        self.assertEqual(text[len(note) + 2:], model.redact_identity(real, SPEC['user'], SPEC['host']))
        self._no_identity(text)
        self.assertIn('"offline": true', text)

    def test_view_fails_closed(self):
        plan = self._plan()
        cases = [
            ('plan gateway host differs', dict(SPEC), dict(plan, gateway={'host': self.OTHER_HOST, 'user': SPEC['user']})),
            ('spec host differs', dict(SPEC, host=self.OTHER_HOST), plan),
            ('spec user differs', dict(SPEC, user='someoneelse'), plan),
            ('connector differs', dict(SPEC), dict(plan, quick_connector={'command': 'ssh'})),
            ('no gateway', dict(SPEC), dict(plan, gateway=None)),
            ('no spec', None, plan),
            ('not a dict', dict(SPEC), ['not', 'a', 'dict']),
            ('empty user', dict(SPEC, user=''), dict(plan, gateway={'host': SPEC['host'], 'user': ''})),
        ]
        for name, spec, prepared in cases:
            with self.subTest(case=name):
                with self._platform('darwin'):
                    self.assertEqual(wizard.darwin_step4_view(spec, prepared),
                                     (False, wizard.DARWIN_STEP4_UNAVAILABLE))
        self._no_identity(wizard.DARWIN_STEP4_UNAVAILABLE)
        for empty in (None, {}):
            with self.subTest(empty=repr(empty)):
                self.assertEqual(wizard.darwin_step4_view(dict(SPEC), empty),
                                 (False, wizard.DARWIN_STEP4_PLAN_WAITING))
        self.assertEqual(wizard.DARWIN_STEP4_PLAN_WAITING, 'Generating a deployment plan '
                         'automatically from verified backend and selected tools...')

    def test_view_residual_identity_check(self):
        import model
        plan = self._plan()
        with self._platform('darwin'), \
                mock.patch.object(model, 'redact_identity', lambda text, user, host, home_root=None: text):
            self.assertEqual(wizard.darwin_step4_view(dict(SPEC), plan),
                             (False, wizard.DARWIN_STEP4_UNAVAILABLE))

    def test_render_step4_writes_redacted_into_owned_widgets(self):
        fake = _Step4Self(step=3)
        fake.prepared = self._plan()
        with self._platform('darwin'):
            wizard.Wizard._darwin_render_step4(fake)
            want = wizard.darwin_step4_view(dict(SPEC), fake.prepared)[1]
        self.assertEqual(fake.view.text, want)
        self.assertEqual(fake.panel_calls, [('darwin', fake.area)])
        self._no_identity(fake.view.text)
        stale = _Step4Self(step=3)
        stale.prepared = dict(self._plan(), gateway={'host': self.OTHER_HOST, 'user': SPEC['user']})
        with self._platform('darwin'):
            wizard.Wizard._darwin_render_step4(stale)
        self.assertEqual(stale.view.text, wizard.DARWIN_STEP4_UNAVAILABLE)
        self.assertEqual(stale.panel_calls, [('base', stale.area, None)])
        waiting = _Step4Self(step=3)
        with self._platform('darwin'):
            wizard.Wizard._darwin_render_step4(waiting)
        self.assertEqual(waiting.view.text, wizard.DARWIN_STEP4_PLAN_WAITING)
        self.assertEqual(waiting.panel_calls, [('base', waiting.area, None)])

    def _not_current(self):
        out = []
        f = _Step4Self(step=4)
        out.append(('moved to Step 5', f))
        f = _Step4Self(step=2)
        out.append(('moved back to Step 3', f))
        f = _Step4Self(step=3)
        f._tearing_down = True
        out.append(('teardown', f))
        f = _Step4Self(step=3)
        f.quick_copy_area = _RecWidget()
        out.append(('panel area is not the owned one', f))
        f = _Step4Self(step=3)
        f.plan_view = _RecWidget()
        out.append(('plan view is not the owned one', f))
        f = _Step4Self(step=3)
        f.view.alive = False
        out.append(('owned widget destroyed', f))
        f = _Step4Self(step=3)
        f.area.alive = None
        out.append(('winfo_exists raises', f))
        f = _Step4Self(step=3)
        f._darwin_step4_widgets = None
        out.append(('no owned widgets', f))
        return out

    def test_render_step4_does_nothing_when_step4_not_current(self):
        for name, fake in self._not_current():
            with self.subTest(case=name):
                fake.prepared = self._plan()
                with self._platform('darwin'):
                    self.assertIsNone(wizard.Wizard._darwin_step4_owned(fake))
                    wizard.Wizard._darwin_render_step4(fake)
                self.assertEqual(fake.panel_calls, [])
                self.assertEqual(fake.area.ops, [])
                self.assertEqual(fake.view.ops, [])
                for w in (fake.quick_copy_area, fake.plan_view):
                    self.assertEqual(w.ops, [])

    def test_wrapped_plan_callback_drops_stale_results_silently(self):
        for name, fake in self._not_current():
            with self.subTest(case=name):
                calls = []
                wrapped = wizard.Wizard._darwin_wrap_plan_done(fake, lambda ok, r: calls.append((ok, r)))
                with self._platform('darwin'):
                    self.assertIsNone(wrapped(True, {'quick_connector': {}}))
                    self.assertIsNone(wrapped(False, 'boom'))
                self.assertEqual(calls, [])
                self.assertEqual(fake.provenance, [])
        fake = _Step4Self(step=3)
        calls = []
        wrapped = wizard.Wizard._darwin_wrap_plan_done(fake, lambda ok, r: calls.append((ok, r)))
        wrapped(True, 'R')
        self.assertEqual(calls, [(True, 'R')])
        self.assertEqual(fake.provenance, [1])

    def _start_plan(self, fake):
        fake.backend_verification = self._verification()
        with self._platform('darwin'):
            wizard.Wizard.plan_action(fake)
        self.assertEqual(len(fake.actions), 1)
        task, callback = fake.actions[0]
        with self._platform('darwin'):
            return task(), callback

    def test_real_plan_action_late_result_never_writes_step5(self):
        fake = _Step4Self(step=3)
        result, callback = self._start_plan(fake)
        self.assertEqual(result['gateway'], {'host': SPEC['host'], 'user': SPEC['user']})
        step5 = _RecWidget()
        fake.step = 4
        fake.quick_copy_area = step5
        errors = []
        with self._platform('darwin'), mock.patch.object(wizard.messagebox, 'showerror',
                                                         lambda *a: errors.append(a), create=True):
            callback(True, result)
            callback(False, 'late failure')
        self.assertEqual(step5.ops, [])
        self.assertEqual(fake.view.ops, [])
        self.assertEqual(fake.area.ops, [])
        self.assertEqual(fake.panel_calls, [])
        self.assertIsNone(fake.prepared)
        self.assertEqual(fake.provenance, [])
        self.assertEqual(fake.summaries, [])
        self.assertEqual(errors, [])

    def test_real_plan_action_current_step4_renders_redacted(self):
        fake = _Step4Self(step=3)
        result, callback = self._start_plan(fake)
        with self._platform('darwin'):
            callback(True, result)
        self.assertIs(fake.prepared, result)
        self.assertEqual(fake.panel_calls, [('darwin', fake.area)])
        self._no_identity(fake.view.text)
        self.assertIn(wizard.DARWIN_STEP4_REDACTED_NOTE, fake.view.text)
        self.assertIn('"offline": true', fake.view.text)
        self.assertIn('BACKEND_VERIFIED', fake.view.text)
        self.assertEqual(fake.provenance, [1])
        self.assertEqual(fake.summaries, [1])
        self.assertEqual(result['gateway'], {'host': SPEC['host'], 'user': SPEC['user']})

    def test_real_plan_action_rebuilt_step4_gets_result_old_widgets_untouched(self):
        fake = _Step4Self(step=3)
        result, callback = self._start_plan(fake)
        old_area, old_view = fake.area, fake.view
        fake.area, fake.view = _RecWidget(), _RecWidget()
        fake.quick_copy_area, fake.plan_view = fake.area, fake.view
        fake._darwin_step4_widgets = (fake.area, fake.view)
        with self._platform('darwin'):
            callback(True, result)
        self.assertEqual(old_area.ops, [])
        self.assertEqual(old_view.ops, [])
        self.assertEqual(fake.panel_calls, [('darwin', fake.area)])
        self._no_identity(fake.view.text)

    def test_step4_darwin_branches_keep_base_else(self):
        tree = ast.parse(SRC)
        cls = [c for c in tree.body if isinstance(c, ast.ClassDef) and c.name == 'Wizard'][0]
        fns = {n.name: n for n in cls.body if isinstance(n, ast.FunctionDef)}

        def darwin_ifs(fn, marker):
            return [n for n in ast.walk(fn) if isinstance(n, ast.If)
                    and ast.unparse(n.test) == 'self._darwin' and marker in ast.unparse(n)]

        def code(nodes):
            return ast.unparse(ast.Module(body=nodes, type_ignores=[]))
        ifs = darwin_ifs(fns['render_review'], '_darwin_step4_widgets')
        self.assertEqual(len(ifs), 2)
        self.assertEqual(code(ifs[0].body), 'self._darwin_step4_widgets = None')
        self.assertEqual(code(ifs[0].orelse), "self.show_quick_copy_fields(self.quick_copy_area, "
                         "(self.prepared or {}).get('quick_connector'))")
        self.assertEqual(code(ifs[1].body), 'self._darwin_step4_widgets = (self.quick_copy_area, '
                         'self.plan_view)\nself._darwin_render_step4()')
        self.assertEqual(code(ifs[1].orelse), "if self.prepared:\n    self.plan_view.insert('1.0', "
                         "json.dumps(self.prepared, indent=2))\nelse:\n    self.plan_view.insert('1.0', "
                         "'Generating a deployment plan automatically from verified backend and "
                         "selected tools...')")
        ifs = darwin_ifs(fns['plan_action'], '_darwin_render_step4')
        self.assertEqual(len(ifs), 1)
        self.assertEqual(code(ifs[0].body), 'self._darwin_render_step4()')
        self.assertEqual(code(ifs[0].orelse), "self.show_quick_copy_fields(self.quick_copy_area, "
                         "result.get('quick_connector'))\nself.plan_view.delete('1.0', 'end')\n"
                         "self.plan_view.insert('1.0', json.dumps(result, indent=2))")
        src = ast.unparse(fns['_darwin_render_step4'])
        for absent in ('self.quick_copy_area', 'self.plan_view', 'json.dumps', 'quick_connector(', 'copy_text'):
            self.assertNotIn(absent, src)


# ---------------------------------------------------------------- GUI (withdrawn)
@unittest.skipUnless(HAS_DISPLAY, 'Tk GUI requires an active desktop/display')
class DarwinWizardTests(unittest.TestCase):
    def setUp(self):
        GwStub.instances = []
        DeployerStub.calls = []
        self.patches = [mock.patch.object(wizard, 'is_darwin', return_value=True),
                        mock.patch.object(capability_gate, 'is_darwin', lambda plat=None: True),
                        mock.patch.object(wizard, 'SSHGateway', GwStub),
                        mock.patch.object(wizard, 'ConnectorDeployer', DeployerStub),
                        mock.patch.object(wizard, 'NativeGateway', _trip),
                        mock.patch.object(wizard, 'darwin_ssh_library_present', return_value=True)]
        for p in self.patches:
            p.start()
        self.app = wizard.Wizard()
        self.app.withdraw()
        self.app.vars['host'].set('gateway.example.com')
        self.app.vars['user'].set('fakeuser')
        self.app.vars['target'].set('epg-demo')
        self.app.vars['url'].set('https://abc123.lambda-url.us-west-2.on.aws/mcp')

    def tearDown(self):
        try:
            self.app.destroy()
        except Exception:
            pass
        for p in reversed(self.patches):
            p.stop()

    def pump(self, cond, limit=3.0):
        end = time.time() + limit
        while time.time() < end and not cond():
            self.app.update()
            time.sleep(0.01)
        return cond()

    def buttons(self, widget=None):
        out = {}
        for c in (widget or self.app).winfo_children():
            try:
                if c.winfo_class() in ('TButton', 'TRadiobutton'):
                    out.setdefault(c.cget('text'), []).append(c)
            except Exception:
                pass
            for k, v in self.buttons(c).items():
                out.setdefault(k, []).extend(v)
        return out

    # 3.1 / 3.4 step 0
    def test_step0_only_linux_ssh_and_g2_buttons_disabled(self):
        b = self.buttons()
        self.assertIn('Linux SSH jump server (existing v0.3 workflow)', b)
        self.assertNotIn('Native gateway on THIS computer (no SSH/admin)', b)
        self.assertEqual(str(b['Install missing gateway'][0].cget('state')), 'disabled')
        self.assertEqual(str(b['Repair core permissions'][0].cget('state')), 'disabled')
        self.assertEqual(self.app.vars['transport'].get(), 'linux-ssh')

    # 3.4 G2 actions refused before any gateway/deployer
    def test_g2_actions_refused_before_any_gateway(self):
        self.app.gateway_inspection = {'state': 'MISSING', 'mode_issues': []}
        self.app.prepared = {'x': 1}
        self.app.last_receipt = {'backup_name': 'b'}
        with Tripwires(), mock.patch.object(wizard.messagebox, 'showerror') as err, \
                mock.patch.object(wizard.messagebox, 'askyesno', _trip):
            for fn in (self.app.bootstrap_action, self.app.repair_action,
                       self.app.deploy_action, self.app.rollback_action, self.app.save_receipt_action):
                fn()
        self.assertEqual(err.call_count, 5)
        self.assertIn('not available on macOS in Slice 1', err.call_args_list[0][0][1])
        self.assertEqual(GwStub.instances, [])
        self.assertEqual(DeployerStub.calls, [])

    # 3.4 step 3 buttons + plan offline through the real queue path
    def test_step3_plan_only_offline_and_deploy_disabled(self):
        self.app.backend_verification = {'backend_identity_sha256': wizard.backend_identity(self.app.spec()),
                                         'handshake': 'h', 'tool_count': 0, 'tools': []}
        self.app.step = 3
        with mock.patch.object(self.app, 'after', wraps=self.app.after):
            self.app.render()
        b = self.buttons()
        self.assertEqual(str(b['Deploy approved plan'][0].cget('state')), 'disabled')
        self.assertEqual(str(b['Rollback last deployment'][0].cget('state')), 'disabled')
        with Tripwires(), mock.patch.object(wizard.messagebox, 'showerror'):
            self.app.plan_action()
            self.assertTrue(self.pump(lambda: not self.app.busy))
        self.assertIn(('prepare_offline', None), DeployerStub.calls)
        self.assertEqual(GwStub.instances, [])

    # G1b flow (A1.2 / A1.3)
    def _g1b(self, typed, action, deployer=None):
        seen = {}

        def prompt(title, message, expected):
            seen['title'] = title
            seen['message'] = message
            seen['expected'] = expected
            return typed
        with Tripwires(), mock.patch.object(self.app, '_typed_prompt', prompt), \
                mock.patch.object(wizard.messagebox, 'showerror') as err, \
                mock.patch.object(wizard.messagebox, 'showinfo'), \
                mock.patch.object(wizard.messagebox, 'showwarning'), \
                mock.patch.object(wizard, 'ConnectorDeployer', deployer or DeployerStub):
            action()
            self.pump(lambda: not self.app.busy)
        return seen, err

    def test_g1b_mismatch_variants_construct_nothing(self):
        for action, wrong in ((self.app.inspect_action, TOKEN),
                              (self.app.verify_backend_action, IG_TOKEN),
                              (self.app.discover_action, IG_TOKEN)):
            for typed in (None, '', wrong, 'verify backend epg-demo', 'VERIFY BACKEND epg-demo ',
                          ' INSPECT GATEWAY fakeuser@gateway.example.com', 'VERIFY BACKEND other',
                          'INSPECT GATEWAY fakeuser@192.0.2.10', 'VERIFY  BACKEND epg-demo'):
                seen, err = self._g1b(typed, action)
                self.assertEqual(GwStub.instances, [], repr(typed))
                self.assertEqual(DeployerStub.calls, [], repr(typed))

    def test_two_distinct_windows_and_fresh_scoped_gateway_per_action(self):
        rows = ((self.app.inspect_action, IG_TOKEN, 'inspect', IG, None,
                 'Inspect gateway (SSH, read-only)'),
                (self.app.verify_backend_action, TOKEN, 'verify_backend', VB, 'epg-demo',
                 'Verify backend (SSH + backend metadata handshake)'),
                (self.app.discover_action, TOKEN, 'verify_backend', VB, 'epg-demo',
                 'Verify backend (SSH + backend metadata handshake)'))
        for action, tok, op, scope, label, title in rows:
            before = len(GwStub.instances)
            seen, err = self._g1b(tok, action)
            self.assertEqual(len(GwStub.instances), before + 1)
            gw = GwStub.instances[-1]
            self.assertEqual((gw.host, gw.user, gw.ack, gw.scope, gw.label),
                             ('gateway.example.com', 'fakeuser', tok, scope, label))
            self.assertIn((op, gw), DeployerStub.calls)
            self.assertEqual(seen['title'], title)
            self.assertEqual(seen['expected'], tok)
            for needle in ('Destination host : gateway.example.com', 'SSH user         : fakeuser',
                           'Port             : 22', 'Authentication sources', HOSTKEY, tok):
                self.assertIn(needle, seen['message'])
        self.assertEqual(len({id(g) for g in GwStub.instances}), 3)
        for k, v in vars(self.app).items():
            self.assertNotIn(v, (TOKEN, IG_TOKEN), k)
        self.assertIsNone(self.app.last_gateway)

    def test_destination_bound_to_values_shown_in_dialog(self):
        seen = {}

        def prompt(title, message, expected):
            seen['message'] = message
            self.app.vars['host'].set('192.0.2.10')   # edited while the dialog was open
            return expected
        with Tripwires(), mock.patch.object(self.app, '_typed_prompt', prompt), \
                mock.patch.object(wizard.messagebox, 'showerror'):
            self.app.inspect_action()
            self.pump(lambda: not self.app.busy)
        gw = GwStub.instances[-1]
        self.assertEqual(gw.host, 'gateway.example.com')
        self.assertIn('Destination host : gateway.example.com', seen['message'])

    def test_f1_ssh_library_precheck_before_any_prompt(self):
        for action in (self.app.inspect_action, self.app.verify_backend_action, self.app.discover_action):
            with Tripwires(), mock.patch.object(wizard, 'darwin_ssh_library_present', return_value=False), \
                    mock.patch.object(self.app, '_typed_prompt', _trip), \
                    mock.patch.object(wizard.messagebox, 'showerror') as err:
                action()
            err.assert_called_once_with('SSH client library not installed',
                                        'SSH client library not installed; Slice 1 never installs it; '
                                        'nothing was run')
        self.assertEqual(GwStub.instances, [])
        self.assertEqual(DeployerStub.calls, [])

    def test_f1_real_precheck_function_drives_refusal(self):
        self.patches[-1].stop()
        try:
            with Tripwires(), mock.patch('importlib.util.find_spec', return_value=None), \
                    mock.patch.object(self.app, '_typed_prompt', _trip), \
                    mock.patch.object(wizard.messagebox, 'showerror') as err:
                self.app.inspect_action()
            self.assertEqual(err.call_args[0][0], 'SSH client library not installed')
        finally:
            self.patches[-1].start()
        self.assertEqual(GwStub.instances, [])

    def test_verify_records_time_of_authorized_metadata(self):
        spec_id = wizard.backend_identity(self.app.spec())

        class OkDeployer(DeployerStub):
            def verify_backend(s, spec):
                DeployerStub.calls.append(('verify_backend', s.gateway))
                return {'status': 'BACKEND_VERIFIED', 'backend_identity_sha256': spec_id,
                        'handshake': 'h', 'tool_count': 1, 'tools': [{'name': 't1'}],
                        'existing_allow': None, 'warnings': [],
                        'potentially_mutating_tools_name_only': []}
        self._g1b(TOKEN, self.app.verify_backend_action, deployer=OkDeployer)
        meta = self.app._darwin_verified_meta
        self.assertEqual(meta['identity'], spec_id)
        self.assertRegex(meta['at'], r'^\d{4}-\d\d-\d\d \d\d:\d\d:\d\d$')
        self._g1b(IG_TOKEN, self.app.inspect_action)
        self.assertEqual(self.app._darwin_verified_meta, meta)

    # 3.5 queue delivery + teardown
    def test_worker_never_touches_tk_and_late_result_dropped(self):
        main = threading.current_thread()
        release = threading.Event()
        errors = []
        old_hook = threading.excepthook
        threading.excepthook = lambda a: errors.append(a)
        try:
            for name in ('configure', 'after'):
                orig = getattr(self.app, name)

                def guard(*a, _o=orig, **k):
                    if threading.current_thread() is not main:
                        errors.append('Tk call from worker')
                    return _o(*a, **k)
                setattr(self.app, name, guard)
            self.app.busy = False
            t = self.app._darwin_start_worker(lambda: release.wait(5) and 'late', lambda ok, r: errors.append('callback ran'))
            self.assertIsNotNone(self.app._poll_id)
            self.app.destroy()
            self.assertTrue(self.app._tearing_down)
            self.assertIsNone(self.app._poll_id)
            fake_tk = mock.MagicMock()
            self.app.tk = fake_tk
            release.set()
            t.join(5)
            self.assertFalse(t.is_alive())
            self.app._poll_ui_queue()
            self.assertEqual(fake_tk.mock_calls, [])
            self.assertTrue(self.app._ui_queue.empty())
            self.assertEqual(errors, [])
        finally:
            threading.excepthook = old_hook

    def test_queue_delivers_on_main_thread(self):
        main = threading.current_thread()
        got = []
        self.app.busy = True
        self.app._darwin_start_worker(lambda: 42, lambda ok, r: got.append((ok, r, threading.current_thread() is main)))
        self.assertTrue(self.pump(lambda: got))
        self.assertEqual(got, [(True, 42, True)])
        self.assertFalse(self.app.busy)
        self.assertIsNotNone(self.app._poll_id)

    def test_action_routes_through_queue_not_after0(self):
        calls = []
        orig_after = self.app.after

        def rec(ms, *a):
            calls.append(ms)
            return orig_after(ms, *a)
        with mock.patch.object(self.app, 'after', rec):
            got = []
            self.app.action(lambda: 1, lambda ok, r: got.append(r))
            self.assertTrue(self.pump(lambda: got))
        self.assertNotIn(0, calls)

    # 3.7 export safeguards
    def _quick(self):
        # A1.1 (g)(ii): on macOS the held variants hold the redacted text only; the FULL
        # text comes from quick_reg.quick_instructions_full (patched here to a fixed text
        # behind the REAL COPY FULL check).
        import quick_reg
        self.app._quick_variants = {'redacted': 'R-TEXT'}

        def full(spec, copy_ack=None):
            capability_gate.require_full_variant('copy', copy_ack, plat='darwin')
            return 'FULL-TEXT fakeuser@gateway.example.com'
        p = mock.patch.object(quick_reg, 'quick_instructions_full', full)
        p.start()
        self.addCleanup(p.stop)

    def test_copy_full_requires_yes_and_exact_token(self):
        self._quick()
        for typed in (None, 'copy full', 'COPY FULL ', 'EXPORT FULL'):
            self.app.clipboard_clear()
            self.app.clipboard_append('PRIOR')
            with mock.patch.object(wizard.messagebox, 'askyesno', return_value=True), \
                    mock.patch.object(wizard.messagebox, 'showerror'), \
                    mock.patch.object(self.app, '_typed_prompt', return_value=typed):
                self.app.copy_quick_full()
            self.assertEqual(self.app.clipboard_get(), 'PRIOR', repr(typed))
            self.assertIsNone(self.app._clip_after)
        with mock.patch.object(wizard.messagebox, 'askyesno', return_value=False) as ask, \
                mock.patch.object(self.app, '_typed_prompt', _trip):
            self.app.copy_quick_full()
        self.assertIn('Universal Clipboard', ask.call_args[0][1])

    def test_copy_full_clears_only_if_still_ours_and_cancelled_at_teardown(self):
        self._quick()
        with mock.patch.object(wizard.messagebox, 'askyesno', return_value=True), \
                mock.patch.object(self.app, '_typed_prompt', return_value='COPY FULL'):
            self.app.copy_quick_full()
        self.assertEqual(self.app.clipboard_get(), 'FULL-TEXT fakeuser@gateway.example.com')
        self.assertIsNotNone(self.app._clip_after)
        # user copied something else -> must NOT be cleared
        self.app.clipboard_clear(); self.app.clipboard_append('USER-OTHER')
        self.app._clip_clear_if_ours()
        self.assertEqual(self.app.clipboard_get(), 'USER-OTHER')
        # still ours -> cleared
        with mock.patch.object(wizard.messagebox, 'askyesno', return_value=True), \
                mock.patch.object(self.app, '_typed_prompt', return_value='COPY FULL'):
            self.app.copy_quick_full()
        with mock.patch.object(self.app, 'clipboard_clear', wraps=self.app.clipboard_clear) as cc:
            self.app._clip_clear_if_ours()
        self.assertEqual(cc.call_count, 1)
        # teardown cancels a pending clear
        with mock.patch.object(wizard.messagebox, 'askyesno', return_value=True), \
                mock.patch.object(self.app, '_typed_prompt', return_value='COPY FULL'):
            self.app.copy_quick_full()
        pending = self.app._clip_after
        with mock.patch.object(self.app, 'after_cancel', wraps=self.app.after_cancel) as ac:
            self.app._darwin_teardown()
        self.assertIn(mock.call(pending), ac.call_args_list)
        self.assertIsNone(self.app._clip_after)

    def test_copy_redacted_ungated(self):
        self._quick()
        with mock.patch.object(wizard.messagebox, 'askyesno', _trip), \
                mock.patch.object(self.app, '_typed_prompt', _trip):
            self.app.copy_quick_redacted()
        self.assertEqual(self.app.clipboard_get(), 'R-TEXT')

    def test_export_full_requires_yes_and_exact_token(self):
        for typed in (None, 'export full', 'COPY FULL', 'EXPORT FULL\n'):
            with mock.patch.object(wizard.messagebox, 'askyesno', return_value=True), \
                    mock.patch.object(wizard.messagebox, 'showerror'), \
                    mock.patch.object(self.app, '_typed_prompt', return_value=typed), \
                    mock.patch.object(self.app, '_export_darwin') as ex:
                self.app.export_full_action()
            self.assertFalse(ex.called, repr(typed))
        with mock.patch.object(wizard.messagebox, 'askyesno', return_value=True) as ask, \
                mock.patch.object(self.app, '_typed_prompt', return_value='EXPORT FULL'), \
                mock.patch.object(self.app, '_export_darwin') as ex:
            self.app.export_full_action()
        ex.assert_called_once_with(False, 'EXPORT FULL')
        self.assertIn('Universal Clipboard', ask.call_args[0][1])

    def test_export_redacted_ungated(self):
        with mock.patch.object(self.app, '_typed_prompt', _trip), \
                mock.patch.object(wizard.messagebox, 'askyesno', _trip), \
                mock.patch.object(self.app, '_export_darwin') as ex:
            self.app.export_action()
        ex.assert_called_once_with(True, None)

    def _export_env(self):
        import shutil
        import tempfile
        tmp = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, tmp, True)
        home = os.path.join(tmp, 'home')
        os.makedirs(os.path.join(home, '.quickwork'))
        out = os.path.join(tmp, 'out')
        os.mkdir(out)
        self.app.tool_selection = ['list_genres']
        return tmp, home, out

    def test_export_into_quick_dir_refused_before_write(self):
        tmp, home, out = self._export_env()
        for dest in (os.path.join(home, '.quickwork', 'x.json'),
                     os.path.join(out, '..', 'home', '.quickwork', 'x.json'),
                     os.path.join(out, 'mcp_config.json')):
            with mock.patch.dict(os.environ, {'HOME': home, 'USERPROFILE': home}), \
                    mock.patch.object(wizard.filedialog, 'asksaveasfilename', return_value=dest), \
                    mock.patch.object(wizard, 'write_quick_config', _trip), \
                    mock.patch.object(wizard.messagebox, 'showerror') as err:
                self.app._export(redacted=True)
            self.assertEqual(err.call_args[0][0], 'Export refused', dest)
        self.assertEqual(os.listdir(os.path.join(home, '.quickwork')), [])

    def test_export_full_code_path_requires_token_even_if_wizard_bypassed(self):
        tmp, home, out = self._export_env()
        dest = os.path.join(out, 'full.json')
        with mock.patch.dict(os.environ, {'HOME': home, 'USERPROFILE': home}), \
                mock.patch.object(wizard.filedialog, 'asksaveasfilename', return_value=dest), \
                mock.patch.object(wizard.messagebox, 'showerror') as err, \
                mock.patch.object(wizard.messagebox, 'showinfo'):
            self.app._export(redacted=False)          # no typed token on this path
        self.assertEqual(err.call_args[0][0], 'Export failed')
        self.assertFalse(os.path.exists(dest))

    def test_export_full_outside_with_token_writes(self):
        tmp, home, out = self._export_env()
        dest = os.path.join(out, 'full.json')
        with mock.patch.dict(os.environ, {'HOME': home, 'USERPROFILE': home}), \
                mock.patch.object(wizard.filedialog, 'asksaveasfilename', return_value=dest), \
                mock.patch.object(wizard.messagebox, 'showerror') as err, \
                mock.patch.object(wizard.messagebox, 'showinfo') as info:
            self.app._export_darwin(False, 'EXPORT FULL')
        self.assertFalse(err.called)
        self.assertTrue(info.called)
        with open(dest, encoding='utf-8') as f:
            self.assertIn('fakeuser@gateway.example.com', f.read())

    # 3.6 DIPS disabled
    def test_dips_disabled(self):
        self.app.step = 4
        self.app.render()
        b = self.buttons()
        self.assertEqual(str(b['Inspect DIPS schema (read-only)'][0].cget('state')), 'disabled')
        with Tripwires(), mock.patch.object(wizard.filedialog, 'askopenfilename', _trip), \
                mock.patch.object(wizard.messagebox, 'showerror') as err:
            self.app.dips_action()
        self.assertTrue(err.called)

    # 3.8 typed prompt: real Toplevel, raw text returned (no strip)
    def test_typed_prompt_plain_toplevel_returns_raw(self):
        import tkinter as tk
        from tkinter import ttk

        def fill():
            tops = [w for w in self.app.winfo_children() if isinstance(w, tk.Toplevel)]
            top = tops[-1]
            for w in top.winfo_children():
                if isinstance(w, ttk.Entry):
                    w.insert(0, ' VERIFY BACKEND epg-demo')
            for btn in self.buttons(top).get('OK', []):
                btn.invoke()
        self.app.deiconify()
        self.app.after(150, fill)
        got = self.app._typed_prompt('t', 'm', TOKEN)
        self.assertEqual(got, ' VERIFY BACKEND epg-demo')
        self.assertFalse(capability_gate.token_matches(TOKEN, got))

    # A1.5 W1: guarded grab_set
    def _prompt_with_grab(self, side_effect):
        import tkinter as tk
        from tkinter import ttk
        calls = []

        def grab(widget_self):
            calls.append(1)
            eff = side_effect[len(calls) - 1] if len(calls) <= len(side_effect) else None
            if eff is not None:
                raise eff

        def fake_wait(top):
            for w in top.winfo_children():
                if isinstance(w, ttk.Entry):
                    w.insert(0, TOKEN)
            for btn in self.buttons(top).get('OK', []):
                btn.invoke()
        with mock.patch.object(tk.Misc, 'grab_set', grab), \
                mock.patch.object(self.app, 'wait_window', fake_wait):
            got = self.app._typed_prompt('t', 'm', TOKEN)
        return got, calls

    def test_w1_grab_set_failure_retried_once_then_continues(self):
        import tkinter as tk
        got, calls = self._prompt_with_grab([tk.TclError('not viewable'), tk.TclError('still not')])
        self.assertEqual(got, TOKEN)
        self.assertEqual(len(calls), 2)
        got, calls = self._prompt_with_grab([tk.TclError('not viewable'), None])
        self.assertEqual(got, TOKEN)
        self.assertEqual(len(calls), 2)
        got, calls = self._prompt_with_grab([None])
        self.assertEqual(len(calls), 1)

    # A1.5 W2: callback failure is visible, generic, once per poll
    def test_w2_raising_callback_shows_generic_failure_once(self):
        def bad():
            raise RuntimeError('/Users/fakeuser/secret-path detail')
        self.app._ui_queue.put(bad)
        self.app._ui_queue.put(bad)
        with mock.patch.object(wizard.messagebox, 'showerror') as err:
            self.app._poll_ui_queue()
        self.assertEqual(err.call_count, 1)
        title, text = err.call_args[0]
        self.assertEqual(title, 'Operation failed')
        self.assertNotIn('secret-path', text)
        self.assertNotIn('fakeuser', text)
        self.assertEqual(str(self.app.status.cget('text')), 'Operation failed')
        self.assertIsNotNone(self.app._poll_id)

    def test_w2_no_report_after_teardown(self):
        def bad():
            raise RuntimeError('x')
        self.app._ui_queue.put(bad)
        self.app._darwin_teardown()
        with mock.patch.object(wizard.messagebox, 'showerror') as err:
            self.app._poll_ui_queue()
        self.assertFalse(err.called)

    # User decision C: Step 4 renders offline and labels its inputs
    def test_step4_render_starts_no_g1b_and_labels_inputs(self):
        ident = wizard.backend_identity(self.app.spec())
        self.app.backend_verification = {'backend_identity_sha256': ident, 'handshake': 'h',
                                         'tool_count': 2, 'tools': []}
        self.app._darwin_verified_meta = {'at': '2026-10-29 10:00:00', 'identity': ident}
        self.app.step = 3
        with Tripwires(), mock.patch.object(self.app, '_darwin_g1b_action', _trip), \
                mock.patch.object(self.app, '_typed_prompt', _trip), \
                mock.patch.object(wizard, 'darwin_ssh_library_present', _trip), \
                mock.patch.object(wizard.messagebox, 'showerror'):
            self.app.render()
            self.pump(lambda: ('prepare_offline', None) in DeployerStub.calls and not self.app.busy)
        text = str(self.app._darwin_provenance.cget('text'))
        self.assertIn('OFFLINE-GENERATED', text)
        self.assertIn('METADATA FROM AN EARLIER AUTHORIZED VERIFICATION IN THIS SESSION', text)
        self.assertIn('obtained 2026-10-29 10:00:00', text)
        self.assertIn('never opens SSH', text)
        self.assertEqual(GwStub.instances, [])
        self.assertEqual([c for c in DeployerStub.calls if c[0] != 'init'], [('prepare_offline', None)])

    def test_step4_without_earlier_verification_says_so(self):
        self.app.backend_verification = None
        self.app.step = 3
        with Tripwires(), mock.patch.object(self.app, '_darwin_g1b_action', _trip), \
                mock.patch.object(wizard.messagebox, 'showerror'):
            self.app.render()
            for _ in range(10):
                self.app.update()
        self.assertIn('none held for the current backend fields',
                      str(self.app._darwin_provenance.cget('text')))
        self.assertEqual(GwStub.instances, [])

    def test_a11_step5_screen_text_redacted_and_no_full_held(self):
        with Tripwires(), mock.patch.object(self.app, 'spec', lambda: dict(SPEC)), \
                mock.patch.object(wizard.messagebox, 'showerror'):
            self.app.step = 4
            self.app.render()
        text = self.app.manual.get('1.0', 'end')
        self.assertIn('REDACTED', text)
        self.assertNotIn('fakeuser@gateway.example.com', text)
        self.assertEqual(sorted(self.app._quick_variants), ['redacted'])

    def test_b3c_step5_panel_redacted_on_darwin(self):
        # B3c item 2 (Tk): the Step 5 Command / Arguments panel shows no real login/host.
        def entries(widget):
            out = []
            for c in widget.winfo_children():
                if c.winfo_class() == 'TEntry':
                    out.append(c.get())
                out.extend(entries(c))
            return out
        with Tripwires(), mock.patch.object(self.app, 'spec', lambda: dict(SPEC)), \
                mock.patch.object(wizard.messagebox, 'showerror'):
            self.app.step = 4
            self.app.render()
        got = entries(self.app.quick_copy_area)
        self.assertEqual(len(got), 2)
        for value in got:
            self.assertNotIn(SPEC['user'], value)
            self.assertNotIn(SPEC['host'], value)
        b = self.buttons(self.app.quick_copy_area)
        self.assertIn('Copy command (FULL)', b)
        self.assertIn('Copy arguments (FULL)', b)
        self.assertNotIn('Copy command', b)

    def test_b3d_step4_redacted_and_late_plan_never_writes_step5(self):
        # B3d (Tk): Step 4 panel + plan JSON show no real login/host on darwin, and a plan
        # result arriving after the move to Step 5 leaves the redacted Step 5 panel alone.
        def entries(widget):
            out = []
            for c in widget.winfo_children():
                if c.winfo_class() == 'TEntry':
                    out.append(c.get())
                out.extend(entries(c))
            return out
        ident = SPEC['user'] + '@' + SPEC['host']
        plan = wizard._deploy_lib_mod.ConnectorDeployer(None).prepare_offline(dict(SPEC))
        captured = []
        with Tripwires(), mock.patch.object(self.app, 'spec', lambda: dict(SPEC)), \
                mock.patch.object(wizard.messagebox, 'showerror'):
            self.app.backend_verification = {
                'backend_identity_sha256': wizard.backend_identity(dict(SPEC)), 'handshake': 'h',
                'tool_count': 1, 'tools': [{'name': 'get_rating_mappings'}]}
            self.app.prepared = plan
            self.app.step = 3
            self.app.render()
            for _ in range(10):
                self.app.update()
            text = self.app.plan_view.get('1.0', 'end')
            step4 = entries(self.app.quick_copy_area)
            b4 = self.buttons(self.app.quick_copy_area)
            with mock.patch.object(self.app, 'action', lambda task, cb=None: captured.append(cb)):
                self.app.plan_action()
            self.app.step = 4
            self.app.render()
            captured[0](True, dict(plan))
            for _ in range(5):
                self.app.update()
            step5 = entries(self.app.quick_copy_area)
        self.assertIn('REDACTED', text)
        for value in [text] + step4 + step5:
            self.assertNotIn(ident, value)
            self.assertNotIn(SPEC['host'], value)
        self.assertEqual(len(step4), 2)
        self.assertEqual(len(step5), 2)
        self.assertIn('Copy command (FULL)', b4)
        self.assertNotIn('Copy command', b4)

    def test_b3e_plan_failure_shows_fixed_text_on_darwin(self):
        # B3e (Tk): a failed offline plan shows ONLY the fixed text, never the error text.
        ident = SPEC['user'] + '@' + SPEC['host']
        shown = []
        captured = []
        with Tripwires(), mock.patch.object(self.app, 'spec', lambda: dict(SPEC)), \
                mock.patch.object(wizard.messagebox, 'showerror', lambda *a: shown.append(a)):
            self.app.backend_verification = {
                'backend_identity_sha256': wizard.backend_identity(dict(SPEC)), 'handshake': 'h',
                'tool_count': 1, 'tools': [{'name': 'get_rating_mappings'}]}
            self.app.prepared = None
            self.app.step = 3
            self.app.render()
            with mock.patch.object(self.app, 'action', lambda task, cb=None: captured.append(cb)):
                self.app.plan_action()
            captured[-1](False, 'bad field ' + ident)
            text = self.app.plan_view.get('1.0', 'end').strip()
        self.assertEqual(text, wizard.DARWIN_STEP4_PLAN_FAILED)
        self.assertTrue(shown)
        for args in shown:
            for value in args:
                self.assertNotIn(SPEC['host'], value)
                self.assertNotIn(SPEC['user'], value)
        self.assertIsNone(self.app.prepared)

    # 3.9 fonts
    def test_darwin_fonts_applied(self):
        self.assertIn('Helvetica Neue', str(self.app.style.lookup('TLabel', 'font')))
        self.assertIn('Menlo', str(self.app.gateway_result.cget('font')))


class B3ePlanFailureTextTests(unittest.TestCase):
    # B3e (pure, no Tk): the macOS plan-failure text never carries the error text.
    def test_b3e_failure_text_is_fixed(self):
        secret = SPEC['user'] + '@' + SPEC['host']
        for result in ('boom ' + secret, ValueError(secret), None, ''):
            got = wizard.darwin_plan_failure_text(result)
            self.assertEqual(got, wizard.DARWIN_STEP4_PLAN_FAILED)
            self.assertNotIn(SPEC['host'], got)
            self.assertNotIn(SPEC['user'], got)
            self.assertNotIn('Plan failed:', got)

    def test_b3e_fixed_texts_carry_no_placeholder(self):
        for got in (wizard.DARWIN_STEP4_PLAN_FAILED, wizard.DARWIN_SUMMARY_UNAVAILABLE):
            self.assertTrue(got.isascii())
            self.assertNotIn('{', got)
            self.assertNotIn('%', got)

    def test_b3e_non_darwin_statements_kept(self):
        # static: the BASE Windows/Linux statements are still present after the darwin branch.
        self.assertIn("self.plan_view.insert('1.0','Plan failed: '+str(result))", SRC)
        self.assertIn("return 'Summary unavailable: '+str(e)", SRC)


class Step4LoginResidualB3f(unittest.TestCase):
    """B3f (F-T1b-01): darwin_step4_view also refuses when the bare login survives
    redaction (boundary-aware, case-insensitive). Pure function, no Tk."""

    def _platform(self, name):
        import platform_p2
        return mock.patch.object(platform_p2.sys, 'platform', name)

    def _view(self, spec, redact=None):
        import deploy_lib
        import model
        with self._platform('darwin'):
            plan = deploy_lib.ConnectorDeployer(None).prepare_offline(dict(spec))
            if redact is None:
                return wizard.darwin_step4_view(dict(spec), plan)
            with mock.patch.object(model, 'redact_identity', redact):
                return wizard.darwin_step4_view(dict(spec), plan)

    def test_b3f_whole_token_login_refused(self):
        def keep_login(text, user, host, home_root=None):
            return text.replace(user + '@' + host, 'X').replace(host, 'X')
        self.assertEqual(self._view(SPEC, keep_login), (False, wizard.DARWIN_STEP4_UNAVAILABLE))

        def upper_login(text, user, host, home_root=None):
            return keep_login(text, user, host).replace(user, user.upper())
        self.assertEqual(self._view(SPEC, upper_login), (False, wizard.DARWIN_STEP4_UNAVAILABLE))

    def test_b3f_login_inside_target_refused(self):
        spec = dict(SPEC, target=SPEC['user'] + '-epg')
        self.assertEqual(self._view(spec), (False, wizard.DARWIN_STEP4_UNAVAILABLE))

    def test_b3f_login_substring_of_longer_word_not_refused(self):
        # 'operations' does not contain 'ops' as letters in a row, so the embedded case
        # is 'devopstools' (login between letters): shown, not refused.
        for word in ('operations', 'devopstools'):
            with self.subTest(word=word):
                spec = dict(SPEC, user='ops', target=word, display_name=word)
                show, text = self._view(spec)
                self.assertTrue(show)
                self.assertIn(word, text)
                self.assertNotIn(SPEC['host'], text)

    def test_b3f_empty_or_whitespace_login_fails_closed(self):
        import deploy_lib
        with self._platform('darwin'):
            good = deploy_lib.ConnectorDeployer(None).prepare_offline(dict(SPEC))
        for u in ('', '   '):
            with self.subTest(user=repr(u)):
                prepared = dict(good, gateway={'host': SPEC['host'], 'user': u})
                with self._platform('darwin'):
                    self.assertEqual(wizard.darwin_step4_view(dict(SPEC, user=u), prepared),
                                     (False, wizard.DARWIN_STEP4_UNAVAILABLE))


@unittest.skipUnless(HAS_DISPLAY, 'Tk GUI requires an active desktop/display')
class NonDarwinParityTests(unittest.TestCase):
    def test_windows_path_unchanged(self):
        with mock.patch.object(wizard, 'is_darwin', return_value=False):
            app = wizard.Wizard()
        try:
            app.withdraw()
            self.assertFalse(app._darwin)
            self.assertIsNone(app._ui_queue)
            self.assertIsNone(app._poll_id)
            self.assertIn('Segoe UI', str(app.style.lookup('TLabel', 'font')))
            names = []
            def walk(w):
                for c in w.winfo_children():
                    try:
                        if c.winfo_class() == 'TRadiobutton':
                            names.append(c.cget('text'))
                    except Exception:
                        pass
                    walk(c)
            walk(app)
            self.assertIn('Native gateway on THIS computer (no SSH/admin)', names)
            calls = []
            orig = app.after
            with mock.patch.object(app, 'after', lambda ms, *a: calls.append(ms) or orig(ms, *a)):
                got = []
                end = time.time() + 3
                def tick():
                    if got or time.time() > end:
                        app.quit()
                    else:
                        orig(10, tick)
                orig(0, lambda: app.action(lambda: 1, lambda ok, r: got.append(r)))
                orig(10, tick)
                orig(5000, app.quit)
                app.mainloop()
            self.assertEqual(got, [1])
            self.assertIn(0, calls)
        finally:
            app.destroy()


if __name__ == '__main__':
    unittest.main()
