"""Tests for the Quick Import workflow helpers in quick_reg.py.

Stdlib unittest only. Uses temp dirs; runnable on Windows and Linux. LF endings.
Covers the Tester's 18 import-workflow cases (SECTION C of tester_wizard_v04.md)
plus emitter create-only/symlink/synced-folder rules and the no-leak guarantee.

These tests import quick_reg, which imports model; both are stdlib-only. No
network, no subprocess, no Quick UI. The emitter writes into a temp dir (never
Quick's store); the verifier/collision helpers read synthetic mcp_config.json
files built in temp dirs that mirror the REAL observed Quick shape.
"""
import json
import os
import sys
import tempfile
import unittest
from unittest import mock

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import quick_reg
from quick_reg import (emit_quick_import_file, find_quick_profile_configs,
                       check_name_collision, verify_quick_import,
                       import_instructions, ImportFileError)

# A valid settings dict as produced by quick_copy_fields / quick_connector.
GOOD = {'command': 'C:/Users/<user>/g/venv/Scripts/python.exe',
        'args': ['C:/Users/<user>/g/aq_registry.py', 'run', 'rtr-demo'],
        'name': 'rtr-demo', 'id': 'rtr-demo'}

# A synthetic sentinel that must never leak out of verify/collision/emit.
SENTINEL = 'SENTINEL-DO-NOT-LEAK-7f3a9c'


def read_json(path):
    with open(path, 'rb') as f:
        return json.loads(f.read().decode('utf-8'))


def write_config(path, servers, bom=False, raw=None):
    data = json.dumps({'mcpServers': servers}, indent=2).encode('utf-8')
    if raw is not None:
        data = raw
    if bom:
        data = b'\xef\xbb\xbf' + data
    with open(path, 'wb') as f:
        f.write(data)
    return path


def observed_entry(name, command, args, source='C:/Users/<user>/imp/x.json',
                   suffix='ebb7602a', disabled=None, env=None,
                   startup=None, startup_top=None, auto_disabled=None):
    """Build an entry in the REAL observed Quick shape: key = name-<8hex>,
    _quick {name, source, upstream_id}, no startupTimeout unless given.

    DEFECT-FIX realism (CHANGE 1): the executed read of the real profile
    mcp_config.json showed startupTimeout, name and autoDisabled living INSIDE
    the per-entry _quick object. So `startup` and `auto_disabled` are placed in
    _quick here; `startup_top` is a separate knob for the legacy/fallback case
    where a build stores startupTimeout at the entry TOP level.
    """
    entry = {'command': command, 'args': list(args),
             '_quick': {'name': name, 'source': source, 'upstream_id': name}}
    if disabled is not None:
        entry['disabled'] = disabled
    if env is not None:
        entry['env'] = env
    if startup is not None:
        entry['_quick']['startupTimeout'] = startup
    if auto_disabled is not None:
        entry['_quick']['autoDisabled'] = auto_disabled
    if startup_top is not None:
        entry['startupTimeout'] = startup_top
    return {name + '-' + suffix: entry}


class EmitShape(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp()

    def test_single_entry_shape(self):
        r = emit_quick_import_file(GOOD, self.d)
        obj = read_json(r['path'])
        self.assertEqual(list(obj.keys()), ['mcpServers'])
        self.assertEqual(len(obj['mcpServers']), 1)
        srv = obj['mcpServers']['rtr-demo']
        self.assertEqual(list(srv.keys()), ['command', 'args'])
        self.assertEqual(srv['command'], GOOD['command'])
        self.assertEqual(srv['args'], GOOD['args'])

    def test_no_env_quick_unknown_keys(self):
        r = emit_quick_import_file(GOOD, self.d)
        srv = read_json(r['path'])['mcpServers']['rtr-demo']
        self.assertNotIn('env', srv)
        self.assertNotIn('_quick', srv)
        self.assertNotIn('startupTimeout', srv)
        self.assertNotIn('timeout', srv)
        self.assertNotIn('id', srv)
        self.assertNotIn('name', srv)

    def test_bytes_lf_no_bom(self):
        r = emit_quick_import_file(GOOD, self.d)
        with open(r['path'], 'rb') as f:
            b = f.read()
        self.assertNotEqual(b[:3], b'\xef\xbb\xbf')
        self.assertNotIn(b'\r', b)
        self.assertTrue(b.endswith(b'\n'))
        self.assertEqual(r['bytes'], len(b))
        import hashlib
        self.assertEqual(r['sha256'], hashlib.sha256(b).hexdigest())

    def test_result_has_identity_warning_and_no_content(self):
        r = emit_quick_import_file(GOOD, self.d)
        self.assertTrue(r['contains_identity_warning'])
        # result must not contain file content (command/args values).
        blob = json.dumps(r)
        self.assertNotIn('aq_registry.py', blob)
        self.assertNotIn('python.exe', blob)

    def test_env_block_refused(self):
        s = dict(GOOD); s['env'] = {'AWS_PROFILE': 'x'}
        with self.assertRaises(ImportFileError):
            emit_quick_import_file(s, self.d)

    def test_quick_block_refused(self):
        s = dict(GOOD); s['_quick'] = {'name': 'x'}
        with self.assertRaises(ImportFileError):
            emit_quick_import_file(s, self.d)

    def test_unknown_key_refused(self):
        s = dict(GOOD); s['surprise'] = 1
        with self.assertRaises(ImportFileError):
            emit_quick_import_file(s, self.d)


class EmitNameValidation(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp()

    def _bad(self, nm):
        s = dict(GOOD); s['name'] = nm; s['id'] = nm
        with self.assertRaises(ImportFileError):
            emit_quick_import_file(s, self.d)

    def test_uppercase(self):
        self._bad('RtrDemo')

    def test_leading_dash(self):
        self._bad('-rtr')

    def test_empty(self):
        self._bad('')

    def test_too_long_65(self):
        self._bad('a' * 65)

    def test_len_64_ok(self):
        s = dict(GOOD); s['name'] = 'a' * 64; s['id'] = 'a' * 64
        r = emit_quick_import_file(s, self.d)
        self.assertEqual(r['name'], 'a' * 64)

    def test_reserved_names(self):
        for nm in ('con', 'prn', 'aux', 'nul', 'com1', 'lpt9'):
            self._bad(nm)

    def test_reserved_with_ext(self):
        self._bad('con.json')

    def test_trailing_dot_space(self):
        self._bad('rtr.')
        self._bad('rtr ')

    def test_separators_in_name(self):
        self._bad('a/b')
        self._bad('a\\b')

    def test_unicode(self):
        self._bad('rtr\u00e9')

    def test_underscore_rejected(self):
        self._bad('rtr_demo')


class EmitArgValidation(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp()

    def test_control_char_in_arg(self):
        s = dict(GOOD); s['args'] = ['ok', 'ba\x01d']
        with self.assertRaises(ImportFileError):
            emit_quick_import_file(s, self.d)

    def test_newline_in_arg(self):
        s = dict(GOOD); s['args'] = ['ok', 'ba\nd']
        with self.assertRaises(ImportFileError):
            emit_quick_import_file(s, self.d)

    def test_empty_string_arg(self):
        s = dict(GOOD); s['args'] = ['ok', '']
        with self.assertRaises(ImportFileError):
            emit_quick_import_file(s, self.d)

    def test_args_not_list(self):
        s = dict(GOOD); s['args'] = 'run rtr-demo'
        with self.assertRaises(ImportFileError):
            emit_quick_import_file(s, self.d)

    def test_empty_args_list(self):
        s = dict(GOOD); s['args'] = []
        with self.assertRaises(ImportFileError):
            emit_quick_import_file(s, self.d)

    def test_command_empty(self):
        s = dict(GOOD); s['command'] = '   '
        with self.assertRaises(ImportFileError):
            emit_quick_import_file(s, self.d)


class EmitCreateOnly(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp()

    def test_second_emit_new_filename_original_untouched(self):
        r1 = emit_quick_import_file(GOOD, self.d)
        with open(r1['path'], 'rb') as f:
            b1 = f.read()
        r2 = emit_quick_import_file(GOOD, self.d)
        self.assertNotEqual(r1['path'], r2['path'])
        # original untouched
        with open(r1['path'], 'rb') as f:
            self.assertEqual(f.read(), b1)
        # sha of the new file equals the old (same content, different name)
        self.assertEqual(r1['sha256'], r2['sha256'])
        self.assertTrue(os.path.basename(r2['path']).startswith('rtr-demo-1'))

    def test_filename_with_separator_refused(self):
        with self.assertRaises(ImportFileError):
            emit_quick_import_file(GOOD, self.d, filename='a/b.json')
        with self.assertRaises(ImportFileError):
            emit_quick_import_file(GOOD, self.d, filename='a\\b.json')

    def test_missing_dest_dir(self):
        with self.assertRaises(ImportFileError):
            emit_quick_import_file(GOOD, os.path.join(self.d, 'nope'))


class EmitRepoRefusal(unittest.TestCase):
    """CHANGE 2: emit_quick_import_file refuses a destination inside any git work
    tree (.git dir OR file) or inside the project's own module folder. The import
    file carries the real login/host and must never be committed/published.
    allow_inside_repo=True is a test-only override, never exposed by the CLI."""

    def test_refuses_git_dir_work_tree(self):
        root = tempfile.mkdtemp()
        os.makedirs(os.path.join(root, '.git'))
        dest = os.path.join(root, 'sub', 'cfg')
        os.makedirs(dest)
        with self.assertRaises(ImportFileError):
            emit_quick_import_file(GOOD, dest)

    def test_refuses_git_file_work_tree(self):
        # A .git FILE (worktree/submodule gitlink), not a directory.
        root = tempfile.mkdtemp()
        with open(os.path.join(root, '.git'), 'wb') as f:
            f.write(b'gitdir: /somewhere/else\n')
        dest = os.path.join(root, 'cfg')
        os.makedirs(dest)
        with self.assertRaises(ImportFileError):
            emit_quick_import_file(GOOD, dest)

    def test_refuses_dest_at_git_root_itself(self):
        root = tempfile.mkdtemp()
        os.makedirs(os.path.join(root, '.git'))
        with self.assertRaises(ImportFileError):
            emit_quick_import_file(GOOD, root)

    def test_allow_inside_repo_override_permits(self):
        root = tempfile.mkdtemp()
        os.makedirs(os.path.join(root, '.git'))
        dest = os.path.join(root, 'cfg')
        os.makedirs(dest)
        r = emit_quick_import_file(GOOD, dest, allow_inside_repo=True)
        self.assertTrue(os.path.isfile(r['path']))

    def test_non_repo_dest_allowed(self):
        # A plain temp dir with no .git anywhere up to the FS root and not under
        # the module folder should be permitted.
        dest = tempfile.mkdtemp()
        r = emit_quick_import_file(GOOD, dest)
        self.assertTrue(os.path.isfile(r['path']))

    def test_refuses_dest_inside_module_folder(self):
        # The directory containing quick_reg.py is the project/work copy. A
        # destination under it must be refused even without a .git marker there.
        module_dir = os.path.dirname(os.path.abspath(quick_reg.__file__))
        with self.assertRaises(ImportFileError):
            emit_quick_import_file(GOOD, module_dir, allow_inside_repo=False)

    def test_refuses_symlinked_ancestor_into_git_work_tree(self):
        # F-3: a destination reached through a SYMLINKED ancestor whose real path
        # is inside a git work tree must still be refused. _dest_inside_repo now
        # resolves with os.path.realpath before walking, so the symlink hop cannot
        # hide the .git ancestor. If the OS cannot create a symlink (e.g. Windows
        # without privilege), the test is SKIPPED with a clear reason (NOT RUN).
        repo = tempfile.mkdtemp()
        os.makedirs(os.path.join(repo, '.git'))
        real_dest = os.path.join(repo, 'sub', 'cfg')
        os.makedirs(real_dest)
        link_root = tempfile.mkdtemp()  # OUTSIDE the repo, no .git in its chain
        link = os.path.join(link_root, 'via_link')
        try:
            os.symlink(real_dest, link)
        except (OSError, NotImplementedError, AttributeError) as e:
            self.skipTest('cannot create symlink here: %s' % e)
        # Textually, `link` has no .git ancestor; only realpath reveals it is the
        # repo's sub/cfg. The emitter must refuse it.
        with self.assertRaises(ImportFileError):
            emit_quick_import_file(GOOD, link)


class EmitSymlink(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp()

    def test_symlink_dest_refused(self):
        # Pre-create a symlink at the target path; secure_open uses O_EXCL (and
        # O_NOFOLLOW where present), so it must refuse rather than follow it.
        target = os.path.join(self.d, 'real.json')
        with open(target, 'wb') as f:
            f.write(b'{}')
        link = os.path.join(self.d, 'rtr-demo.json')
        try:
            os.symlink(target, link)
        except (OSError, NotImplementedError, AttributeError) as e:
            self.skipTest('cannot create symlink here: %s' % e)
        # emit must NOT overwrite/follow the existing symlink at rtr-demo.json;
        # it picks a numbered new name instead, and the symlink target is unchanged.
        r = emit_quick_import_file(GOOD, self.d)
        self.assertNotEqual(os.path.basename(r['path']), 'rtr-demo.json')
        with open(target, 'rb') as f:
            self.assertEqual(f.read(), b'{}')  # target untouched


class EmitSyncedFolder(unittest.TestCase):
    def test_synced_refused_and_override(self):
        root = tempfile.mkdtemp()
        synced = os.path.join(root, 'OneDrive', 'cfg')
        os.makedirs(synced)
        with self.assertRaises(ImportFileError):
            emit_quick_import_file(GOOD, synced)
        r = emit_quick_import_file(GOOD, synced, allow_synced=True)
        self.assertTrue(os.path.isfile(r['path']))

    def test_dropbox_googledrive_icloud(self):
        for marker in ('Dropbox', 'Google Drive', 'iCloud'):
            root = tempfile.mkdtemp()
            d = os.path.join(root, marker, 'x')
            os.makedirs(d)
            with self.assertRaises(ImportFileError):
                emit_quick_import_file(GOOD, d)


class FindConfigs(unittest.TestCase):
    def test_discovery_paths_only(self):
        home = tempfile.mkdtemp()
        write_config(os.path.join(home, 'mcp_config.json'), {})
        p1 = os.path.join(home, 'profiles', 'acctA')
        p2 = os.path.join(home, 'profiles', 'acctB')
        os.makedirs(p1); os.makedirs(p2)
        write_config(os.path.join(p1, 'mcp_config.json'), {})
        write_config(os.path.join(p2, 'mcp_config.json'), {})
        found = find_quick_profile_configs(home)
        self.assertEqual(len(found), 3)
        for f in found:
            self.assertTrue(f.endswith('mcp_config.json'))

    def test_missing_home(self):
        self.assertEqual(find_quick_profile_configs(tempfile.mkdtemp()), [])


class Collision(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp()
        self.cfg = os.path.join(self.d, 'mcp_config.json')

    def test_collides_by_quick_name(self):
        write_config(self.cfg, observed_entry('rtr-demo', 'c', ['a']))
        self.assertEqual(check_name_collision('rtr-demo', self.cfg),
                         {'collides': True, 'count': 1})

    def test_collides_by_upstream_id(self):
        servers = {'weird-12345678': {'command': 'c', 'args': ['a'],
                   '_quick': {'name': 'other', 'source': 's', 'upstream_id': 'rtr-demo'}}}
        write_config(self.cfg, servers)
        self.assertEqual(check_name_collision('rtr-demo', self.cfg)['collides'], True)

    def test_collides_by_key_suffix(self):
        servers = {'rtr-demo-abcdef12': {'command': 'c', 'args': ['a']}}
        write_config(self.cfg, servers)
        self.assertEqual(check_name_collision('rtr-demo', self.cfg)['collides'], True)

    def test_no_collision(self):
        write_config(self.cfg, observed_entry('epg', 'c', ['a']))
        self.assertEqual(check_name_collision('rtr-demo', self.cfg),
                         {'collides': False, 'count': 0})

    def test_missing_file(self):
        self.assertEqual(check_name_collision('x', os.path.join(self.d, 'no.json')),
                         {'collides': False, 'count': 0})


class Verify(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp()
        self.cfg = os.path.join(self.d, 'mcp_config.json')
        self.cmd = 'C:/Users/<user>/g/venv/Scripts/python.exe'
        self.args = ['C:/Users/<user>/g/aq_registry.py', 'run', 'rtr-demo']

    def test_found_match_real_shape(self):
        # REAL observed shape: key with -8hex, _quick with name/source/upstream_id,
        # no startupTimeout, no env.
        write_config(self.cfg, observed_entry('rtr-demo', self.cmd, self.args))
        r = verify_quick_import('rtr-demo', self.cmd, self.args, self.cfg)
        self.assertEqual(r['status'], 'FOUND_MATCH')
        self.assertFalse(r['disabled'])
        self.assertFalse(r['has_env'])
        self.assertFalse(r['has_startup_timeout'])
        self.assertNotIn('startup_timeout', r)
        self.assertNotIn('startup_timeout_location', r)
        self.assertNotIn('auto_disabled', r)

    def test_not_found(self):
        write_config(self.cfg, observed_entry('epg', self.cmd, self.args))
        self.assertEqual(verify_quick_import('rtr-demo', self.cmd, self.args, self.cfg)['status'],
                         'NOT_FOUND')

    def test_mismatch_command(self):
        write_config(self.cfg, observed_entry('rtr-demo', 'wrong.exe', self.args))
        r = verify_quick_import('rtr-demo', self.cmd, self.args, self.cfg)
        self.assertEqual(r['status'], 'FOUND_MISMATCH_COMMAND')

    def test_mismatch_args_one_element(self):
        bad = ['C:/Users/<user>/g/aq_registry.py', 'run', 'epg']
        write_config(self.cfg, observed_entry('rtr-demo', self.cmd, bad))
        r = verify_quick_import('rtr-demo', self.cmd, self.args, self.cfg)
        self.assertEqual(r['status'], 'FOUND_MISMATCH_ARGS')

    def test_mismatch_args_order(self):
        bad = ['run', 'C:/Users/<user>/g/aq_registry.py', 'rtr-demo']
        write_config(self.cfg, observed_entry('rtr-demo', self.cmd, bad))
        r = verify_quick_import('rtr-demo', self.cmd, self.args, self.cfg)
        self.assertEqual(r['status'], 'FOUND_MISMATCH_ARGS')

    def test_multiple_matches(self):
        servers = {}
        servers.update(observed_entry('rtr-demo', self.cmd, self.args, suffix='aaaaaaaa'))
        servers.update(observed_entry('rtr-demo', self.cmd, self.args, suffix='bbbbbbbb'))
        write_config(self.cfg, servers)
        r = verify_quick_import('rtr-demo', self.cmd, self.args, self.cfg)
        self.assertEqual(r['status'], 'MULTIPLE_MATCHES')
        self.assertEqual(r['count'], 2)

    # ---- CHANGE 1 defect-fix: startupTimeout lives inside _quick ----

    def test_timeout_in_quick(self):
        # The REAL observed location: startupTimeout inside _quick. The old code
        # read it from the top level and reported has_startup_timeout=False here.
        servers = observed_entry('rtr-demo', self.cmd, self.args, startup=30)
        write_config(self.cfg, servers)
        r = verify_quick_import('rtr-demo', self.cmd, self.args, self.cfg)
        self.assertEqual(r['status'], 'FOUND_MATCH')
        self.assertTrue(r['has_startup_timeout'])
        self.assertEqual(r['startup_timeout'], 30)
        self.assertEqual(r['startup_timeout_location'], '_quick')

    def test_timeout_top_level_fallback(self):
        # Legacy/other build: only a top-level startupTimeout. Accepted as a
        # fallback, with the location reported as 'top-level'.
        servers = observed_entry('rtr-demo', self.cmd, self.args, startup_top=120)
        write_config(self.cfg, servers)
        r = verify_quick_import('rtr-demo', self.cmd, self.args, self.cfg)
        self.assertTrue(r['has_startup_timeout'])
        self.assertEqual(r['startup_timeout'], 120)
        self.assertEqual(r['startup_timeout_location'], 'top-level')

    def test_timeout_both_prefers_quick(self):
        # Both present: _quick wins.
        servers = observed_entry('rtr-demo', self.cmd, self.args,
                                 startup=30, startup_top=999)
        write_config(self.cfg, servers)
        r = verify_quick_import('rtr-demo', self.cmd, self.args, self.cfg)
        self.assertTrue(r['has_startup_timeout'])
        self.assertEqual(r['startup_timeout'], 30)
        self.assertEqual(r['startup_timeout_location'], '_quick')

    def test_timeout_float_ok(self):
        servers = observed_entry('rtr-demo', self.cmd, self.args, startup=12.5)
        write_config(self.cfg, servers)
        r = verify_quick_import('rtr-demo', self.cmd, self.args, self.cfg)
        self.assertTrue(r['has_startup_timeout'])
        self.assertEqual(r['startup_timeout'], 12.5)
        self.assertEqual(r['startup_timeout_location'], '_quick')

    def test_timeout_non_numeric_in_quick(self):
        servers = observed_entry('rtr-demo', self.cmd, self.args, startup='30')
        write_config(self.cfg, servers)
        r = verify_quick_import('rtr-demo', self.cmd, self.args, self.cfg)
        self.assertFalse(r['has_startup_timeout'])
        self.assertNotIn('startup_timeout', r)
        self.assertNotIn('startup_timeout_location', r)

    def test_timeout_bool_in_quick(self):
        # A JSON boolean must NOT be treated as a number.
        servers = observed_entry('rtr-demo', self.cmd, self.args, startup=True)
        write_config(self.cfg, servers)
        r = verify_quick_import('rtr-demo', self.cmd, self.args, self.cfg)
        self.assertFalse(r['has_startup_timeout'])
        self.assertNotIn('startup_timeout', r)

    def test_timeout_negative_in_quick(self):
        servers = observed_entry('rtr-demo', self.cmd, self.args, startup=-5)
        write_config(self.cfg, servers)
        r = verify_quick_import('rtr-demo', self.cmd, self.args, self.cfg)
        self.assertFalse(r['has_startup_timeout'])
        self.assertNotIn('startup_timeout', r)

    def test_timeout_zero_in_quick(self):
        servers = observed_entry('rtr-demo', self.cmd, self.args, startup=0)
        write_config(self.cfg, servers)
        r = verify_quick_import('rtr-demo', self.cmd, self.args, self.cfg)
        self.assertFalse(r['has_startup_timeout'])
        self.assertNotIn('startup_timeout', r)

    def test_timeout_bad_top_level_no_fallback_value(self):
        # A present-but-invalid _quick value does NOT fall through to top level;
        # only an absent _quick key triggers the top-level fallback.
        servers = observed_entry('rtr-demo', self.cmd, self.args,
                                 startup=0, startup_top=120)
        write_config(self.cfg, servers)
        r = verify_quick_import('rtr-demo', self.cmd, self.args, self.cfg)
        self.assertFalse(r['has_startup_timeout'])

    def test_auto_disabled_true(self):
        servers = observed_entry('rtr-demo', self.cmd, self.args, auto_disabled=True)
        write_config(self.cfg, servers)
        r = verify_quick_import('rtr-demo', self.cmd, self.args, self.cfg)
        self.assertEqual(r['status'], 'FOUND_MATCH')
        self.assertIn('auto_disabled', r)
        self.assertTrue(r['auto_disabled'])

    def test_auto_disabled_false(self):
        servers = observed_entry('rtr-demo', self.cmd, self.args, auto_disabled=False)
        write_config(self.cfg, servers)
        r = verify_quick_import('rtr-demo', self.cmd, self.args, self.cfg)
        self.assertIn('auto_disabled', r)
        self.assertFalse(r['auto_disabled'])

    def test_auto_disabled_absent(self):
        servers = observed_entry('rtr-demo', self.cmd, self.args)
        write_config(self.cfg, servers)
        r = verify_quick_import('rtr-demo', self.cmd, self.args, self.cfg)
        self.assertNotIn('auto_disabled', r)

    def test_flags_env_disabled_timeout(self):
        # disabled + env at top level, startupTimeout in _quick (the real shape).
        servers = observed_entry('rtr-demo', self.cmd, self.args,
                                 disabled=True, env={'X': '1'}, startup=45)
        write_config(self.cfg, servers)
        r = verify_quick_import('rtr-demo', self.cmd, self.args, self.cfg)
        self.assertEqual(r['status'], 'FOUND_MATCH')
        self.assertTrue(r['disabled'])
        self.assertTrue(r['has_env'])
        self.assertTrue(r['has_startup_timeout'])
        self.assertEqual(r['startup_timeout'], 45)
        self.assertEqual(r['startup_timeout_location'], '_quick')

    def test_extra_unknown_fields_tolerated(self):
        servers = observed_entry('rtr-demo', self.cmd, self.args)
        key = list(servers.keys())[0]
        servers[key]['surprise'] = {'nested': 1}
        write_config(self.cfg, servers)
        r = verify_quick_import('rtr-demo', self.cmd, self.args, self.cfg)
        self.assertEqual(r['status'], 'FOUND_MATCH')

    # UNREADABLE variants
    def test_unreadable_empty_file(self):
        with open(self.cfg, 'wb') as f:
            f.write(b'')
        self.assertEqual(verify_quick_import('x', 'c', [], self.cfg)['status'], 'UNREADABLE')

    def test_unreadable_invalid_json(self):
        with open(self.cfg, 'wb') as f:
            f.write(b'{not json')
        self.assertEqual(verify_quick_import('x', 'c', [], self.cfg)['status'], 'UNREADABLE')

    def test_unreadable_array_top_level(self):
        with open(self.cfg, 'wb') as f:
            f.write(b'[1,2,3]')
        self.assertEqual(verify_quick_import('x', 'c', [], self.cfg)['status'], 'UNREADABLE')

    def test_unreadable_missing_mcpservers(self):
        with open(self.cfg, 'wb') as f:
            f.write(json.dumps({'other': {}}).encode('utf-8'))
        self.assertEqual(verify_quick_import('x', 'c', [], self.cfg)['status'], 'UNREADABLE')

    def test_unreadable_oversize(self):
        # Write an object slightly over the 5 MB cap.
        big = b'{"mcpServers": {}, "pad": "' + b'a' * (5 * 1024 * 1024 + 10) + b'"}'
        with open(self.cfg, 'wb') as f:
            f.write(big)
        self.assertEqual(verify_quick_import('x', 'c', [], self.cfg)['status'], 'UNREADABLE')

    def test_bom_accepted(self):
        write_config(self.cfg, observed_entry('rtr-demo', self.cmd, self.args), bom=True)
        r = verify_quick_import('rtr-demo', self.cmd, self.args, self.cfg)
        self.assertEqual(r['status'], 'FOUND_MATCH')


class NoLeak(unittest.TestCase):
    """No result dict or exception text from verify/collision/emit may contain a
    synthetic sentinel placed in args, env, source path, or other entries' names."""
    def setUp(self):
        self.d = tempfile.mkdtemp()
        self.cfg = os.path.join(self.d, 'mcp_config.json')
        self.cmd = 'py.exe'
        self.args = ['aq_registry.py', 'run', 'rtr-demo']

    def _assert_no_sentinel(self, obj):
        self.assertNotIn(SENTINEL, json.dumps(obj))

    def test_verify_does_not_leak_other_entries_or_values(self):
        servers = {}
        # target entry, correct
        servers.update(observed_entry('rtr-demo', self.cmd, self.args))
        # a DIFFERENT entry whose name, args, env and source all carry the sentinel
        servers['other-99999999'] = {
            'command': SENTINEL, 'args': [SENTINEL],
            'env': {SENTINEL: SENTINEL},
            '_quick': {'name': SENTINEL, 'source': SENTINEL, 'upstream_id': SENTINEL}}
        write_config(self.cfg, servers)
        r = verify_quick_import('rtr-demo', self.cmd, self.args, self.cfg)
        self.assertEqual(r['status'], 'FOUND_MATCH')
        self._assert_no_sentinel(r)

    def test_verify_mismatch_does_not_echo_stored_values(self):
        servers = observed_entry('rtr-demo', 'py.exe', [SENTINEL, 'run', 'x'])
        write_config(self.cfg, servers)
        r = verify_quick_import('rtr-demo', self.cmd, self.args, self.cfg)
        self.assertEqual(r['status'], 'FOUND_MISMATCH_ARGS')
        self._assert_no_sentinel(r)

    def test_collision_does_not_leak_other_names(self):
        servers = observed_entry('rtr-demo', 'c', ['a'])
        servers['x-88888888'] = {'command': 'c', 'args': [SENTINEL],
                                 '_quick': {'name': SENTINEL, 'source': SENTINEL,
                                            'upstream_id': SENTINEL}}
        write_config(self.cfg, servers)
        r = check_name_collision('rtr-demo', self.cfg)
        self._assert_no_sentinel(r)

    def test_emit_exception_has_no_content(self):
        s = dict(GOOD); s['args'] = [SENTINEL + '\x01bad']
        try:
            emit_quick_import_file(s, self.d)
            self.fail('expected ImportFileError')
        except ImportFileError as e:
            self.assertNotIn(SENTINEL, str(e))


class Instructions(unittest.TestCase):
    def test_timeout_by_kind_and_no_overclaims(self):
        for kind, secs in (('lambda', 30), ('git', 120), ('local', 120)):
            txt = import_instructions(GOOD, kind, import_path='C:/Users/<user>/imp/x.json')
            self.assertIn('{} seconds'.format(secs), txt)
            self.assertIn('Import', txt)
            self.assertIn('C:/Users/<user>/imp/x.json', txt)
            # must NOT claim a confirmation dialog appears, nor a default timeout
            self.assertIn('if a confirmation prompt appears', txt.lower())
            self.assertIn('fallback', txt.lower())

    def test_windows_not_protected_clause_present(self):
        # F-1: the after-import guidance must plainly say the file is NOT
        # permission-protected on Windows and names login + gateway address.
        txt = import_instructions(GOOD, 'lambda', import_path='C:/Users/<user>/imp/x.json')
        low = txt.lower()
        self.assertIn('not', low)
        self.assertIn('permission-protected', low)
        self.assertIn('login', low)
        self.assertIn('gateway address', low)
        # must not claim ACL protection
        self.assertNotIn('acl', low)

    def test_connector_name_line_after_step_1(self):
        # G-1: the connector-name line now reads AFTER '1. Open Amazon Quick
        # Desktop.' (not before it). Assert its new position explicitly so a
        # future regression that moves it back is caught.
        lines = import_instructions(GOOD, 'lambda',
                                    import_path='C:/Users/<user>/imp/x.json').split('\n')
        name_idx = next(i for i, ln in enumerate(lines)
                        if 'The connector will be named' in ln)
        step1_idx = next(i for i, ln in enumerate(lines)
                         if ln.startswith('1. Open Amazon Quick Desktop'))
        step2_idx = next(i for i, ln in enumerate(lines)
                         if ln.startswith('2. Go to Customize'))
        self.assertGreater(name_idx, step1_idx)   # after step 1
        self.assertLess(name_idx, step2_idx)       # before step 2


class FollowupBoundedRead(unittest.TestCase):
    """Security cond B / F-7: the config read is bounded to cap+1 bytes and a
    stream longer than the cap yields UNREADABLE without returning content.

    The file is <= cap at fstat time (so the fstat gate passes), but the bytes
    actually readable exceed cap. We simulate a file that grows after the size
    check by patching quick_reg.os.fstat to report a small (under-cap) size while
    the file on disk is larger than cap+1. The bounded read + length re-check must
    then return UNREADABLE."""

    def setUp(self):
        self.d = tempfile.mkdtemp()
        self.cfg = os.path.join(self.d, 'mcp_config.json')

    def test_stream_longer_than_cap_is_unreadable_via_bounded_read(self):
        cap = quick_reg._QUICK_CONFIG_MAX_BYTES
        # Write a real file LARGER than cap+1 so the bounded read can pull cap+1.
        big = b'{"mcpServers": {}, "pad": "' + b'a' * (cap + 100) + b'"}'
        with open(self.cfg, 'wb') as f:
            f.write(big)
        self.assertGreater(len(big), cap + 1)

        real_fstat = os.fstat

        class _SmallStat:
            # Mimic a stat_result whose st_size is UNDER the cap (file "grew"
            # after this value would have been taken), to prove the cap is now
            # enforced on the bytes actually read, not only on the fstat size.
            st_size = cap - 1

        def fake_fstat(fd):
            return _SmallStat()

        with mock.patch.object(quick_reg.os, 'fstat', fake_fstat):
            servers, err = quick_reg._load_quick_config_servers(self.cfg)
        self.assertIsNone(servers)
        self.assertEqual(err, 'UNREADABLE')

    def test_under_cap_file_still_reads_normally(self):
        # A genuinely small, valid file is unaffected by the bounded read.
        write_config(self.cfg, observed_entry('rtr-demo', 'c', ['a']))
        servers, err = quick_reg._load_quick_config_servers(self.cfg)
        self.assertIsNone(err)
        self.assertIsInstance(servers, dict)


class FollowupSyncedHeuristicBlindSpots(unittest.TestCase):
    """Security cond C: import_instructions must state that the synced-folder
    check is a NAME-BASED heuristic blind to OneDrive Known Folder Move, network
    shares, mapped drives and oddly-named cloud folders, so the user must pick a
    private local folder themselves."""

    def test_blind_spots_sentence_present(self):
        txt = import_instructions(GOOD, 'lambda',
                                  import_path='C:/Users/<user>/imp/x.json')
        low = txt.lower()
        self.assertIn('name-based heuristic', low)
        self.assertIn('known folder move', low)
        self.assertIn('network shares', low)
        self.assertIn('mapped drives', low)
        # it must still tell the user to choose a private folder themselves
        self.assertIn('private local folder yourself', low)


class FollowupIsWithinFailsClosed(unittest.TestCase):
    """Security cond D / Tester D-1: when os.path.realpath raises OSError,
    _is_within fails CLOSED (returns True -> "inside"), so _dest_inside_repo
    REFUSES a normal destination rather than skipping the project-folder guard.
    The work copy has NO .git tree, so the .git walk is not a backstop."""

    def test_dest_inside_repo_refuses_when_realpath_raises(self):
        normal_dest = tempfile.mkdtemp()  # a plain dir with no .git ancestor

        def boom(_p):
            raise OSError('simulated unresolvable path')

        # Patch realpath so EVERY resolution raises. _dest_inside_repo's own first
        # realpath(dest) then fails closed to True; even if it did not, the
        # project-folder guard via _is_within must also fail closed to True.
        with mock.patch.object(quick_reg.os.path, 'realpath', boom):
            self.assertTrue(quick_reg._dest_inside_repo(normal_dest))

    def test_is_within_returns_true_on_oserror_directly(self):
        # Direct unit: patch realpath to raise and confirm _is_within fails closed.
        def boom(_p):
            raise OSError('simulated')
        with mock.patch.object(quick_reg.os.path, 'realpath', boom):
            self.assertTrue(quick_reg._is_within('/any/child', '/any/parent'))

    def test_is_within_normal_paths_unaffected(self):
        # Regression: with realpath working, a child under parent is True and a
        # sibling is False (the fail-closed change must not alter normal results).
        root = tempfile.mkdtemp()
        parent = os.path.join(root, 'p')
        child = os.path.join(parent, 'c')
        os.makedirs(child)
        sibling = os.path.join(root, 'q')
        os.makedirs(sibling)
        self.assertTrue(quick_reg._is_within(child, parent))
        self.assertFalse(quick_reg._is_within(sibling, parent))


if __name__ == '__main__':
    unittest.main(verbosity=2)
