import sys,os,tempfile,json,hashlib,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import remote_agent as remote

@unittest.skipUnless(os.name=='posix','Remote filesystem transaction requires POSIX/Linux')
class TestRemoteAgent(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.old=(remote.ROOT,remote.REG,remote.LOCK,remote.BACKUPS)
        remote.ROOT=Path(self.tmp.name)/'aq-mcp'
        remote.ROOT.mkdir()
        remote.REG=remote.ROOT/'targets.json'
        remote.LOCK=remote.ROOT/'.aq-wizard.lock'
        remote.BACKUPS=remote.ROOT/'.wizard-backups'
        for f in ['aq_registry.py','aq-run.sh','aq_mcp_stdio.py','aq_check.py']:(remote.ROOT/f).touch()
        remote.REG.write_text(json.dumps({'defaults':{},'targets':{'existing':{'url':'https://abc.lambda-url.us-west-2.on.aws','allow':['read']}}}))
        self.base=hashlib.sha256(remote.REG.read_bytes()).hexdigest()
        self.entry={'url':'https://abc.lambda-url.us-west-2.on.aws/mcp','region':'us-west-2',
                    'env':'wizard','note':'Installed by AQ-MCP Connector Wizard','allow':['read']}
    def tearDown(self):
        remote.ROOT,remote.REG,remote.LOCK,remote.BACKUPS=self.old
        self.tmp.cleanup()
    def test_apply_and_rollback(self):
        r=remote.apply({'target':'new-one','entry':self.entry,'expected_sha256':self.base})
        self.assertIn('new-one',json.loads(remote.REG.read_text())['targets'])
        self.assertEqual((remote.BACKUPS/r['backup_name']).stat().st_mode & 0o777,0o600)
        result=remote.rollback({'receipt':r})
        self.assertEqual(result['sha256'],self.base)
        self.assertNotIn('new-one',json.loads(remote.REG.read_text())['targets'])
    def test_parallel_change_is_not_overwritten(self):
        with self.assertRaisesRegex(ValueError,'CONFLICT'):
            remote.apply({'target':'new-one','entry':self.entry,'expected_sha256':'0'*64})
        self.assertEqual(hashlib.sha256(remote.REG.read_bytes()).hexdigest(),self.base)
    def test_rollback_respects_other_edits(self):
        r=remote.apply({'target':'new-one','entry':self.entry,'expected_sha256':self.base})
        remote.REG.write_text(remote.REG.read_text()+'\n')
        with self.assertRaisesRegex(ValueError,'CONFLICT'):
            remote.rollback({'receipt':r})
    def test_existing_target_not_replaced(self):
        with self.assertRaisesRegex(ValueError,'already exists'):
            remote.apply({'target':'existing','entry':self.entry,'expected_sha256':self.base})
    def test_empty_list_rejected(self):
        with self.assertRaises(ValueError):remote.check_entry('new-one',dict(self.entry,allow=[]))
    def test_non_lambda_refused(self):
        with self.assertRaises(ValueError):remote.check_entry('new-one',dict(self.entry,url='https://bad.example/mcp'))
    def test_apply_removes_orphan_backup_when_replace_fails(self):
        """S9/D6: if the atomic replace (or final concurrency re-check) fails after the
        backup file has been created, apply() must not leave an orphan backup behind."""
        import remote_agent as _ra
        def _boom(path,content):
            raise OSError('simulated replace failure')
        orig=_ra.atomic_replace
        _ra.atomic_replace=_boom
        try:
            with self.assertRaises(OSError):
                _ra.apply({'target':'new-one','entry':self.entry,'expected_sha256':self.base})
        finally:
            _ra.atomic_replace=orig
        # No backup file should remain, and the registry must be unchanged.
        leftover=list(remote.BACKUPS.glob('targets-*.json')) if remote.BACKUPS.exists() else []
        self.assertEqual(leftover,[])
        self.assertEqual(hashlib.sha256(remote.REG.read_bytes()).hexdigest(),self.base)


class TestRollbackReceiptParsing(unittest.TestCase):
    """L-1 (Security): rollback receipt parsing is explicit and fails closed. These
    exercise parse_rollback_receipt directly (no fcntl/filesystem) so they run on any
    platform, including Windows."""
    GOOD_NAME='targets-1760000000-0123456789ab-abcdef012345.json'
    def _receipt(self,**kw):
        base={'backup_name':self.GOOD_NAME,'before':'a'*64,'after':'b'*64}
        base.update(kw)
        return base
    def test_valid_receipt_parses(self):
        name,before,after=remote.parse_rollback_receipt({'receipt':self._receipt()})
        self.assertEqual(name,self.GOOD_NAME)
        self.assertEqual(before,'a'*64)
        self.assertEqual(after,'b'*64)
    def test_json_string_receipt_is_tolerated(self):
        import json as _json
        name,_,_=remote.parse_rollback_receipt({'receipt':_json.dumps(self._receipt())})
        self.assertEqual(name,self.GOOD_NAME)
    def test_non_dict_receipt_refused(self):
        with self.assertRaisesRegex(ValueError,'JSON object'):
            remote.parse_rollback_receipt({'receipt':['not','a','dict']})
    def test_bad_json_string_refused(self):
        with self.assertRaisesRegex(ValueError,'not valid JSON'):
            remote.parse_rollback_receipt({'receipt':'{not json'})
    def test_bad_backup_name_refused(self):
        with self.assertRaisesRegex(ValueError,'backup name'):
            remote.parse_rollback_receipt({'receipt':self._receipt(backup_name='../etc/passwd')})
    def test_bad_before_sha_refused(self):
        with self.assertRaisesRegex(ValueError,'before-SHA'):
            remote.parse_rollback_receipt({'receipt':self._receipt(before='xyz')})
    def test_bad_after_sha_refused(self):
        with self.assertRaisesRegex(ValueError,'after-SHA'):
            remote.parse_rollback_receipt({'receipt':self._receipt(after='b'*63)})


class TestApplyBackupNameMatchesRollback(unittest.TestCase):
    """L-1: the backup name apply() emits must satisfy rollback()'s validator, derived
    from the shared BACKUP_NAME_RE. Pure string check, no filesystem."""
    def test_apply_format_matches_backup_regex(self):
        import time as _t, secrets as _s
        sha='0'*64
        name='targets-{}-{}-{}.json'.format(int(_t.time()),_s.token_hex(6),sha[:12])
        self.assertIsNotNone(remote.BACKUP_NAME_RE.fullmatch(name))
