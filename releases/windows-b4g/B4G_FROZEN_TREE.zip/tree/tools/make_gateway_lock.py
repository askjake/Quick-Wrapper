#!/usr/bin/env python3
"""Generate the hash-pinned gateway lockfile (Security H-2) -- stdlib only, NO network.

Given the pinned requirements file (bootstrap_payload/requirements-gateway.txt) and a
directory of wheels that the user downloaded on a connected machine, this writes
bootstrap_payload/requirements-gateway.lock with one

    name==version --hash=sha256:<64 hex> [--hash=sha256:<64 hex> ...]

line per distinct distribution in the directory. It computes sha256 over the file
bytes you provide; it NEVER downloads anything.

Because the gateway installs with ``pip install --require-hashes --no-deps`` (pip does
NOT resolve dependencies at install time), the lock MUST contain the full transitive
dependency closure, not just the three top-level pins. The documented download step
therefore uses ``pip download -r requirements-gateway.txt ...`` WITHOUT --no-deps, so
pip downloads every wheel in the closure; this script turns that whole directory into
the lock.

What this script enforces:
  * every top-level requirement in requirements-gateway.txt must be present in the
    directory at EXACTLY its pinned version (else it refuses);
  * a distribution name may appear at only ONE version in the directory (two different
    versions of the same package -> refuse, since --no-deps would install an ambiguous
    set);
  * multiple files for the same name+version (e.g. two wheels) produce multiple --hash
    tokens on that package's line;
  * only wheels (*.whl) are accepted, plus an optional README; any other file -> refuse;
  * it prints the full resolved closure (names + versions, no hashes) so you can review
    exactly what will be installed.

The gateway is CPython 3.10 on Linux x86_64, so download the matching closure first, e.g.:

    pip download -r bootstrap_payload/requirements-gateway.txt \\
        -d <wheel-dir> --only-binary=:all: \\
        --python-version 3.10 --platform manylinux2014_x86_64 \\
        --implementation cp --abi cp310

Then:

    python tools/make_gateway_lock.py \\
        --requirements bootstrap_payload/requirements-gateway.txt \\
        --wheel-dir <wheel-dir> \\
        --output bootstrap_payload/requirements-gateway.lock

This script requires Python 3.10+ (it only ever runs on the connected build machine).
"""
import argparse
import hashlib
import os
import re
import sys

PIN_RE = re.compile(r'^([A-Za-z0-9][A-Za-z0-9._-]*)==(\S+)\s*$')
# A README (any case, optional extension) is tolerated alongside the wheels; anything
# else that is not a wheel causes a refusal.
README_RE = re.compile(r'^readme(\.[A-Za-z0-9]+)?$', re.IGNORECASE)


def canonical(name):
    """PEP 503-ish canonical distribution name: lowercase, runs of -_. unified to '-'."""
    return re.sub(r'[-_.]+', '-', name).lower()


def parse_pins(text):
    """Parse the simple version-pinned requirements file into {canonical: (display, version)}."""
    pins = {}
    for raw in text.replace('\r\n', '\n').replace('\r', '\n').splitlines():
        line = raw.strip()
        if not line or line.startswith('#'):
            continue
        m = PIN_RE.match(line)
        if not m:
            raise ValueError('requirements line is not a simple pin (name==version): ' + line[:80])
        pins[canonical(m.group(1))] = (m.group(1), m.group(2))
    if not pins:
        raise ValueError('no pinned requirements found')
    return pins


# Security MED-1 (belt-and-suspenders): a lock line is built as
# "<display>==<version> <hash tokens>". The remote validate_gateway_lock already
# refuses any non---hash token, but the generator must also be incapable of
# EMITTING one. A wheel name/version may therefore contain only these characters
# (no whitespace, no '-' leading an option, no '@', '#', backslash): if a filename
# produced anything else the whole file is refused as a non-wheel.
DISPLAY_RE = re.compile(r'^[A-Za-z0-9][A-Za-z0-9._]*$')
VERSION_RE = re.compile(r'^[A-Za-z0-9][A-Za-z0-9.!+_]*$')


def wheel_name_version(filename):
    """(canonical name, display name, version) from a wheel filename, or (None, None, None).

    Wheel file naming (PEP 427): {distribution}-{version}(-{build})?-{python}-{abi}-{platform}.whl
    distribution and version never contain '-', so the first two '-'-separated fields are
    the (escaped) name and the version. The name/version are charset-validated so the
    generated lock line can never contain whitespace or a pip option marker.
    """
    if not filename.endswith('.whl'):
        return None, None, None
    parts = filename[:-4].split('-')
    if len(parts) < 2 or not parts[0] or not parts[1]:
        return None, None, None
    if not DISPLAY_RE.match(parts[0]) or not VERSION_RE.match(parts[1]):
        return None, None, None
    return canonical(parts[0]), parts[0], parts[1]


def build_lock_text(pins, wheel_dir, hasher=None):
    """Return the lockfile text (LF) for the full closure of wheels in *wheel_dir*.

    Requires every top-level pin present at its exact version. Refuses a non-wheel file
    (other than an optional README) and refuses the same distribution appearing at two
    different versions. *hasher* lets tests inject a deterministic digest function; by
    default it is a real sha256 of the file bytes. Returns (text, closure) where closure
    is a sorted list of (display_name, version) for review/printing.
    """
    if hasher is None:
        def hasher(path):
            h = hashlib.sha256()
            with open(path, 'rb') as fh:
                for chunk in iter(lambda: fh.read(65536), b''):
                    h.update(chunk)
            return h.hexdigest()

    files = sorted(f for f in os.listdir(wheel_dir)
                   if os.path.isfile(os.path.join(wheel_dir, f)))

    # dists[canonical] = {'display': str, 'version': str, 'files': [filenames]}
    dists = {}
    non_wheel = []
    for f in files:
        if not f.endswith('.whl'):
            if README_RE.match(f):
                continue
            non_wheel.append(f)
            continue
        cname, display, version = wheel_name_version(f)
        if cname is None:
            non_wheel.append(f)
            continue
        if cname in dists:
            if dists[cname]['version'] != version:
                raise ValueError(
                    'Distribution {} present at two versions ({} and {}); '
                    'the wheel dir must contain exactly one version per package'.format(
                        display, dists[cname]['version'], version))
            dists[cname]['files'].append(f)
        else:
            dists[cname] = {'display': display, 'version': version, 'files': [f]}

    if non_wheel:
        raise ValueError('Non-wheel file(s) in wheel dir (only *.whl and an optional '
                         'README are allowed): ' + ', '.join(sorted(non_wheel)))
    if not dists:
        raise ValueError('wheel dir contains no wheels')

    # Every top-level pin must be present at exactly the pinned version.
    missing = []
    for cname, (display, version) in pins.items():
        got = dists.get(cname)
        if got is None:
            missing.append(display + '==' + version + ' (no wheel found)')
        elif got['version'] != version:
            missing.append('{}=={} (found version {} instead)'.format(display, version, got['version']))
    if missing:
        raise ValueError('Top-level pin(s) not satisfied by the wheel dir: ' + ', '.join(sorted(missing)))

    lines = ['# requirements-gateway.lock -- GENERATED by tools/make_gateway_lock.py. Do not edit by hand.',
             '# Full transitive closure, hash-pinned for the Linux x86_64 / CPython 3.10 gateway.',
             '# Install with: pip install --require-hashes --no-deps -r requirements-gateway.lock']
    closure = []
    for cname in sorted(dists):
        display = dists[cname]['display']
        version = dists[cname]['version']
        closure.append((display, version))
        tokens = ['--hash=sha256:' + hasher(os.path.join(wheel_dir, f))
                  for f in sorted(dists[cname]['files'])]
        lines.append(display + '==' + version + ' ' + ' '.join(tokens))
    return '\n'.join(lines) + '\n', closure


def main(argv=None):
    ap = argparse.ArgumentParser(description='Generate the hash-pinned gateway lockfile (no network).')
    ap.add_argument('--requirements', required=True, help='path to requirements-gateway.txt')
    ap.add_argument('--wheel-dir', required=True, help='directory of downloaded wheels (full closure)')
    ap.add_argument('--output', required=True, help='path to write requirements-gateway.lock')
    args = ap.parse_args(argv)

    if sys.version_info < (3, 10):
        print('make_gateway_lock.py requires Python 3.10+', file=sys.stderr)
        return 2
    if not os.path.isdir(args.wheel_dir):
        print('wheel dir not found: ' + args.wheel_dir, file=sys.stderr)
        return 2
    with open(args.requirements, 'r', encoding='utf-8') as fh:
        pins = parse_pins(fh.read())
    try:
        text, closure = build_lock_text(pins, args.wheel_dir)
    except ValueError as exc:
        print('ERROR: ' + str(exc), file=sys.stderr)
        return 1
    # Write LF, even on Windows (the gateway is Linux).
    with open(args.output, 'w', encoding='utf-8', newline='\n') as fh:
        fh.write(text)
    n_hashes = text.count('--hash=sha256:')
    print('Resolved closure ({} distribution(s)) -- review this list:'.format(len(closure)))
    for display, version in closure:
        print('  {}=={}'.format(display, version))
    print('Wrote {} ({} distribution(s), {} hash token(s)) to {}'.format(
        os.path.basename(args.output), len(closure), n_hashes, args.output))
    print('Next: install on the gateway with '
          '`pip install --require-hashes --no-deps -r requirements-gateway.lock`.')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
