"""AQ-MCP Connector Wizard v0.4, local desktop UI (tkinter).
No web listener, no Quick database mutations, no saved PATs or passwords.

MERGE NOTE (2026-10-20): this file is the v0.3.1 safety-hardened wizard (S2 Git/Local
refusal on a wizard-bootstrapped host, S4 confirmation parity, S5 plain-language plan
summary, S7 redacted-by-default Copy/Export with a FULL-variant warning, bootstrap
receipt save/load, 0600 receipts) with the v0.4 native-local feature re-applied on top
(transport selector, NativeGateway, quick_copy_fields Command/Arguments panel, native
bootstrap/inspect flow, GUI smoke hooks). Where the two sides interact the SAFER
behaviour is kept and marked inline with an [S2]/[S4]/[S5]/[S7] / [v04] tag.
"""
import json
import os
import threading
import queue
import sys
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

from deploy_lib import SSHGateway, ConnectorDeployer, DeploymentError
import deploy_lib as _deploy_lib_mod
import capability_gate
from platform_p2 import is_darwin
from native_gateway import NativeGateway
from model import (validate_gateway, validate_spec, validate_spec_for_host, ValidationError,
                   quick_connector, config_export, backend_identity, risk_tool_names,
                   host_is_wizard_lambda_only, plain_language_summary, mutating_confirm_text,
                   secure_write_json, FULL_VARIANT_WARNING, RedactionError,
                   IdentityRedactionError)
from quick_reg import (quick_instructions, quick_instructions_variants,
                       write_quick_config, inspect_dips_read_only, quick_copy_fields)

# Single source of truth for the wizard version string (shown in the title bar and
# wherever a version is referenced in the UI). Bump this one place on a release.
WIZARD_VERSION='v0.4'

BG='#101826'
PANEL='#1B2738'
FG='#EDF2FA'
SOFT='#AFC0D1'
ACCENT='#56C5E6'

# [P2-S1] macOS-only tables. Windows/Linux never read these.
DARWIN_FONTS={'ui':'Helvetica Neue','ui_bold':'Helvetica Neue','mono':'Menlo'}
DARWIN_POLL_MS=50
DARWIN_CLIPBOARD_CLEAR_MS=60000
DARWIN_SLICE1_TEXT=('macOS Slice 1: this wizard talks only to an EXISTING approved Linux SSH gateway. '
    'Native macOS gateway installation, gateway install/repair, deploy and rollback are not available. '
    'Every SSH connection needs its own typed approval: INSPECT GATEWAY <user>@<host> to read the '
    'gateway state, VERIFY BACKEND <target> for the backend metadata check.')
DARWIN_PLAN_ONLY_TEXT=('macOS Slice 1: Step 4 is PLAN ONLY. The plan is built offline (no SSH); '
    'Deploy and Rollback are disabled. Apply it from an approved Windows/Linux workstation.')
DARWIN_QUICK_TEXT=('macOS Slice 1: Quick registration is PREVIEW ONLY. Nothing is written to Quick '
    'configuration; the Quick profile location is not assumed. DIPS inspection is disabled.')
DARWIN_CLIPBOARD_NOTE=('\n\nmacOS note: Universal Clipboard and cloud-sync / clipboard-history tools may copy '
    'the clipboard to your other devices. The wizard clears the clipboard after 60 seconds '
    'if it still holds this text.')
DARWIN_G1B_OPERATION='metadata handshake only: MCP initialize + tools/list (no application tool calls)'
DARWIN_SSH_PORT='22 (SSH default; the wizard does not set a port)'
# [P2-S1 / A1.3] texts of the two operation-bound G1b windows.
DARWIN_HOSTKEY_SENTENCE=('Host key policy: the gateway host key is checked against BOTH the system '
    'known_hosts file and the known_hosts file selected in this wizard; the host must already be in '
    'your known_hosts; changed or unknown keys are REFUSED; nothing is added.')
DARWIN_WORKER_SENTENCE=('The wizard sends its own bundled worker program (a Python script) to the '
    'gateway host over this SSH connection. It runs there as the SSH user with the gateway\'s '
    'python3, and its source is visible in the gateway\'s process list.')
# [P2-S1 / A1.1 P2-SEC-057] extra facts of the verify-backend window only.
DARWIN_VERIFY_EFFECTS=('It uses the GATEWAY host\'s own credentials (not yours) for the backend.',
    'Git or local backend: it may START the backend MCP process on the gateway.',
    'Lambda backend: it makes a signed (SigV4) call with the gateway\'s AWS identity.',
    'Only MCP initialize + tools/list are sent; no application tool is executed.')
# [P2-S1 / A1.1 P2-SEC-057] the authentication lines come ONLY from
# deploy_lib.describe_auth_sources(); if that is unavailable no window is shown.
DARWIN_AUTH_UNAVAILABLE=('The SSH authentication description is unavailable; nothing was run.')
DARWIN_SCREEN_REDACTED_NOTE=('macOS: the text below is REDACTED. Use "Copy FULL" (type COPY FULL) '
    'to copy the real login/host.')
DARWIN_G1B_TITLES={capability_gate.SCOPE_INSPECT_GATEWAY:'Inspect gateway (SSH, read-only)',
                   capability_gate.SCOPE_VERIFY_BACKEND:'Verify backend (SSH + backend metadata handshake)'}
# [P2-S1 / A1.4 F1(i)] shown when the SSH library is absent, BEFORE any typed prompt.
DARWIN_NO_SSH_LIB_UI='SSH client library not installed; Slice 1 never installs it; nothing was run'
# [P2-S1 / B4g] D3 / P2: fixed export-error texts of the macOS Wizard (no path, errno or
# exception text can reach the dialog).
DARWIN_EXPORT_FILE_EXISTS_UI=('Export not written: a file with that name already exists. It was not '
    'changed. Choose a new file name.')
DARWIN_EXPORT_FAILED_UI=('Export not written: the file could not be created (file error). Check '
    'that the folder exists and is writable.')
# [P2-S1 / A1.5 W2] generic text: never contains exception text, paths or user names.
DARWIN_CALLBACK_FAILED=('Operation failed: an internal error occurred while showing the result. '
    'Nothing further was run.')
# [P2-S1, user decision C] Step 4 provenance labels.
DARWIN_STEP4_NO_REMOTE=('Rendering this step never opens SSH, never starts a remote-access (G1b) '
    'operation and never launches a process; the plan below is computed on this Mac.')
DARWIN_STEP4_OFFLINE=('OFFLINE-GENERATED (no SSH, no gateway read): the plan, registry entry, '
    'execution steps and Quick connector fields. Expected registry SHA-256 and existing-target '
    'count are "NOT READ (offline plan)".')


def darwin_auth_sources():
    """[P2-S1 / A1.1 P2-SEC-057] The authentication lines of the G1b windows, taken ONLY
    from deploy_lib.describe_auth_sources() (no hard-coded fallback text). Raises
    GateRefused if it is missing, fails or returns anything but non-empty strings."""
    fn=getattr(_deploy_lib_mod,'describe_auth_sources',None)
    got=None
    if callable(fn):
        try:
            got=fn()
        except Exception:
            got=None
    if isinstance(got,(list,tuple)) and got and all(isinstance(x,str) and x for x in got):
        return list(got)
    raise capability_gate.GateRefused(DARWIN_AUTH_UNAVAILABLE)


def darwin_ssh_library_present():
    """[P2-S1 / A1.4 F1(i)] True only if paramiko can be FOUND. importlib.util.find_spec
    locates a top-level module without importing it, installing it or starting any
    process. Any error counts as absent (fail closed)."""
    try:
        # A1.1 P2-SEC-058: the import of importlib.util is inside the guard too.
        import importlib.util
        return importlib.util.find_spec('paramiko') is not None
    except Exception:
        return False


def darwin_backend_host(spec):
    """[P2-S1 / A1.3] Host part ONLY of the backend URL for the verify-backend window."""
    if not isinstance(spec,dict):
        return '(unknown)'
    url=spec.get('url')
    if spec.get('kind')=='lambda' and isinstance(url,str) and url:
        from urllib.parse import urlsplit
        try:host=urlsplit(url).hostname
        except ValueError:host=None
        return host or '(invalid URL)'
    return '(existing gateway-registered target; no URL)'


def g1b_dialog(scope,host,user,target,backend_host,auth_sources):
    """[P2-S1 / A1.3] Pure (title, message, expected) of the two G1b windows. Raises
    GateRefused for an unknown scope or an invalid user/host/target label."""
    if scope==capability_gate.SCOPE_INSPECT_GATEWAY:
        expected=capability_gate.g1b_token(scope,capability_gate.gateway_label(user,host))
        what=['This action opens an SSH connection to the approved gateway and reads the',
              'gateway state ONLY. It does NOT start or contact any backend.']
        rows=[]
    elif scope==capability_gate.SCOPE_VERIFY_BACKEND:
        expected=capability_gate.g1b_token(scope,target)
        what=['This action opens an SSH connection to the approved gateway, reads the gateway',
              'state AND asks the gateway host to run the backend MCP initialize + tools/list',
              'against the backend host named below, using the gateway host\'s own credentials.',
              'No application tool is executed.']
        rows=['Target           : '+str(target),
              'Backend host     : '+str(backend_host),'']+list(DARWIN_VERIFY_EFFECTS)
    else:
        raise capability_gate.GateRefused('Unknown remote-access scope')
    # A1.1 P2-SEC-057: authentication lines must be the describe_auth_sources() text.
    if (not isinstance(auth_sources,(list,tuple)) or not auth_sources
            or not all(isinstance(s,str) and s for s in auth_sources)):
        raise capability_gate.GateRefused(DARWIN_AUTH_UNAVAILABLE)
    lines=list(what)+['',
           'Destination host : '+str(host),
           'SSH user         : '+str(user),
           'Port             : '+DARWIN_SSH_PORT]+rows+['',
           DARWIN_WORKER_SENTENCE,DARWIN_HOSTKEY_SENTENCE,'',
           'Authentication sources the SSH layer may use:']
    lines.extend('  - '+s for s in auth_sources)
    lines.extend(['','To authorize THIS action only, type exactly:','  '+expected])
    return DARWIN_G1B_TITLES[scope],'\n'.join(lines),expected


def darwin_step4_provenance_text(spec,prepared,verification,verified_meta,identity_fn=None):
    """[P2-S1, user decision C] Pure: label which Step-4 inputs are OFFLINE-GENERATED
    and which are METADATA from an earlier authorized verify-backend action in this
    session (with the time it was obtained). Never starts anything."""
    ident_of=identity_fn or backend_identity
    lines=[DARWIN_STEP4_NO_REMOTE,'',DARWIN_STEP4_OFFLINE]
    try:ident=ident_of(spec) if spec else None
    except Exception:ident=None
    held=(isinstance(verification,dict) and ident is not None
          and verification.get('backend_identity_sha256')==ident)
    if held:
        at=None
        if isinstance(verified_meta,dict) and verified_meta.get('identity')==ident:
            at=verified_meta.get('at')
        lines.append('METADATA FROM AN EARLIER AUTHORIZED VERIFICATION IN THIS SESSION '
                     '(verify-backend, obtained {}): handshake method, offered tool count ({}) '
                     'and the tool names your allow-list was chosen from. It was NOT re-read '
                     'for this plan.'.format(at if at else 'at an unrecorded time',
                                            verification.get('tool_count')))
    else:
        lines.append('METADATA FROM AN EARLIER AUTHORIZED VERIFICATION: none held for the '
                     'current backend fields. Return to Step 2 and verify the backend first.')
    if isinstance(prepared,dict) and prepared.get('offline') is not True:
        lines.append('WARNING: the plan shown is NOT marked offline.')
    return '\n'.join(lines)

# [P2-S1 / B3c] macOS Step 5 Command / Arguments panel. Windows/Linux never call these.
DARWIN_PANEL_REDACTED_NOTE=('macOS: Command and Arguments below are REDACTED. The full command is '
    'available only via Copy FULL (type COPY FULL).')
DARWIN_PANEL_FIELD_KEYS=('command','arguments')
# [P2-S1 / B4] Fixed macOS refusal texts for the Step 5 paths. They state the reason
# and the remedy and NEVER echo the login, host, target or exception text.
DARWIN_STEP5_IDENTITY_REFUSED=('macOS: the Quick setup text cannot be shown redacted, because the '
    'real login or host would still be readable in it (for example the connector ID / Name built '
    'from a target that contains your login). Nothing is shown, copied or written. Rename the '
    'target so it does not contain your login, or use the FULL path (type COPY FULL) to reveal '
    'the real login and host deliberately.')
DARWIN_PANEL_IDENTITY_REFUSED=('macOS: Command / Arguments are withheld, because the real login or '
    'host would still be readable after redaction. Rename the target so it does not contain your '
    'login, or use Copy FULL (type COPY FULL) deliberately.')


def darwin_redacted_copy_fields(spec):
    """[P2-S1 / B3c] Pure: the Step 5 panel values for macOS. quick_copy_fields of the
    spec's connector with the SAME redaction as the redacted Quick text
    (model.redact_identity with the spec's user and host, as quick_instructions does).
    Fails closed: redact_identity raises if the user or host is empty.
    [P2-S1 / B4] Each redacted field is additionally checked with the boundary-aware
    identity test (model.redact_identity_strict), and the JOINED record is checked
    once more because the panel renders id/name/timeout together in one helper line.
    A login surviving inside an approved target name (Quick id 'aq-<login>-epg')
    therefore WITHHOLDS the whole panel instead of displaying the real login; no
    approved target name is rewritten or truncated."""
    from model import redact_identity_strict, assert_identity_safe
    from quick_reg import _spec_identity
    values=quick_copy_fields(quick_connector(spec))
    user,host=_spec_identity(spec)
    out=dict(values)
    for key in ('command','arguments','id','name'):
        out[key]=redact_identity_strict(str(values[key]),user,host)
    assert_identity_safe('\n'.join(str(out[k]) for k in sorted(out)),user,host)
    return out


def darwin_full_copy_field(spec,key,copy_ack):
    """[P2-S1 / B3c] The REAL Command or Arguments value for one Step 5 panel Copy button.
    The exact typed COPY FULL token is checked BEFORE anything is built (always the
    macOS rule; capability_gate is imported here so this check does not depend on the
    wizard handler's own check)."""
    import capability_gate as _gate
    _gate.require_full_variant('copy',copy_ack,plat='darwin')
    if key not in DARWIN_PANEL_FIELD_KEYS:
        raise ValueError('Unknown Quick field')
    return quick_copy_fields(quick_connector(spec))[key]

# [P2-S1 / B3d] macOS Step 4 screen: REDACTED rendering of the offline plan. Windows/Linux
# never call these. The plan itself (prepare_offline) is not changed.
DARWIN_STEP4_PLAN_WAITING='Generating a deployment plan automatically from verified backend and selected tools...'
DARWIN_STEP4_REDACTED_NOTE=('macOS: the login/host in this plan and in the Command / Arguments panel '
    'are REDACTED. Real values appear only via the typed COPY FULL path (the "(FULL)" Copy buttons, '
    'or Copy FULL in Step 5).')
DARWIN_STEP4_UNAVAILABLE=('macOS: the plan cannot be shown redacted (it does not match the current '
    'gateway / connector fields, or the login or host is empty). Nothing is shown; refresh the plan.')
# [P2-S1 / B3e] macOS: fixed Step 4 failure texts. They NEVER include exception or error
# text (which can repeat the typed login/host). Windows/Linux never call these.
DARWIN_STEP4_PLAN_FAILED=('Plan could not be generated. Check the fields on the previous steps '
    'and try again. No remote operation was started.')
DARWIN_SUMMARY_UNAVAILABLE='Summary unavailable. Refresh the deployment plan.'


def darwin_plan_failure_text(result):
    """[P2-S1 / B3e] Pure: the on-screen macOS plan-failure text. `result` (the error
    text) is deliberately ignored and never recorded."""
    return DARWIN_STEP4_PLAN_FAILED


def darwin_step4_view(spec,prepared):
    """[P2-S1 / B3d] Pure: (show_panel, plan_text) for the macOS Step 4 screen.
    The plan JSON is shown through the SAME redaction as the redacted Quick text
    (model.redact_identity with the spec's user and host). It is shown only if the plan's
    own gateway user/host equal the current spec's (as deploy() requires) and its
    quick_connector equals quick_connector(spec), so the redaction covers the identity
    the plan holds. Fails closed: any problem gives (False, DARWIN_STEP4_UNAVAILABLE).
    [B3f] After redaction it also refuses if the host, user@host, or the bare login is
    still in the text. Login rule: case-insensitive, boundary-aware - the login counts
    only where it is NOT preceded or followed by an ASCII letter or digit (so a target
    '<login>' or '<login>-epg' refuses, but login 'ops' inside 'devopstools' does not). An empty or
    whitespace-only login or host refuses."""
    if not prepared:
        return False,DARWIN_STEP4_PLAN_WAITING
    try:
        from model import redact_identity
        from quick_reg import _spec_identity
        user,host=_spec_identity(spec)
        if not (isinstance(user,str) and isinstance(host,str) and (user+host).isascii()):
            raise ValueError('identity not plain ASCII text')
        if prepared.get('gateway')!={'host':host,'user':user}:
            raise ValueError('plan gateway does not match the current fields')
        if prepared.get('quick_connector')!=quick_connector(spec):
            raise ValueError('plan connector does not match the current fields')
        text=redact_identity(json.dumps(prepared,indent=2),user,host)
        low=text.lower()
        if host.strip().lower() in low or (user.strip()+'@'+host.strip()).lower() in low:
            raise ValueError('identity left after redaction')
        # [P2-S1 / B3f] F-T1b-01: also refuse if the bare login survives redaction.
        import re as _re
        login=user.strip()
        if not login or not host.strip():
            raise ValueError('login or host empty')
        if _re.search('(?<![A-Za-z0-9])'+_re.escape(login)+'(?![A-Za-z0-9])',text,_re.IGNORECASE):
            raise ValueError('login left after redaction')
    except Exception:
        return False,DARWIN_STEP4_UNAVAILABLE
    return True,DARWIN_STEP4_REDACTED_NOTE+'\n\n'+text


class Wizard(tk.Tk):
    def __init__(self):
        # [P2-S1] decided once; Windows sets False and changes nothing else.
        self._darwin=is_darwin()
        self._tearing_down=False
        self._ui_queue=None
        self._poll_id=None
        self._clip_after=None
        self._clip_value=None
        super().__init__()
        self.title('AQ-MCP Connector Wizard  \u2022  '+WIZARD_VERSION)
        self.geometry('970x710')
        self.minsize(760,620)
        self.configure(bg=BG)
        self.style=ttk.Style(self)
        self.style.theme_use('clam')
        self.style.configure('TFrame',background=BG)
        self.style.configure('TLabel',background=BG,foreground=FG,font=('Segoe UI',10))
        self.style.configure('Muted.TLabel',background=BG,foreground=SOFT,font=('Segoe UI',9))
        self.style.configure('Heading.TLabel',background=BG,foreground=FG,font=('Segoe UI Semibold',16))
        self.style.configure('TButton',padding=(13,8),font=('Segoe UI',10))
        self.style.configure('TEntry',fieldbackground='white',foreground='#101826')
        self.style.configure('TCombobox',fieldbackground='white',foreground='#101826')
        self.style.configure('TCheckbutton',background=BG,foreground=FG)
        self.step=0
        self.prepared=None
        # S2: a bootstrap receipt THIS wizard produced/loaded for the current host.
        # When it proves a wizard Lambda-only bootstrap, Git/Local are disabled & refused.
        self.bootstrap_receipt=None
        self.last_receipt=None
        self.last_gateway=None
        self.discovered=[]
        self.gateway_inspection=None
        self.backend_verification=None
        self.busy=False
        self.vars={
            'host':tk.StringVar(), 'user':tk.StringVar(),
            'known_hosts':tk.StringVar(value=os.path.expanduser('~/.ssh/known_hosts')),
            'transport':tk.StringVar(value='linux-ssh'),
            'kind':tk.StringVar(value='lambda'), 'target':tk.StringVar(value='epg-demo'),
            'display_name':tk.StringVar(value='AQ EPG Demo'),
            'url':tk.StringVar(), 'server':tk.StringVar(value='aq_build_artifacts_mcp.py')}
        # [P2-S1] macOS setup needs self.vars, so it runs only after they exist (Exec fix B2-F1).
        if self._darwin:self._darwin_setup()
        self.screens=['Gateway','Backend','Tool policy','Review & deploy','Quick registration']
        self.heading=ttk.Frame(self,padding=(24,18));self.heading.pack(fill='x')
        ttk.Label(self.heading,text='AQ-MCP  /  CONNECTOR WIZARD',style='Muted.TLabel').pack(anchor='w')
        ttk.Label(self.heading,text='Build a verified MCP connector',style='Heading.TLabel').pack(anchor='w',pady=(6,0))
        self.pill=ttk.Label(self.heading,text='PLAN FIRST  \u2022  NO QUICK DATABASE WRITES',style='Muted.TLabel')
        self.pill.pack(anchor='w',pady=(7,0))
        self.step_label=ttk.Label(self,text='',style='Muted.TLabel')
        self.step_label.pack(anchor='w',padx=25)
        self.body=ttk.Frame(self,padding=(26,18)); self.body.pack(fill='both',expand=True)
        foot=ttk.Frame(self,padding=(24,8))
        foot.pack(fill='x',side='bottom')
        self.back_btn=ttk.Button(foot,text='\u2190 Back',command=self.go_back);self.back_btn.pack(side='left')
        self.next_btn=ttk.Button(foot,text='Continue \u2192',command=self.go_next);self.next_btn.pack(side='right')
        self.status=ttk.Label(foot,text='Ready',style='Muted.TLabel')
        self.status.pack(side='right',padx=15)
        self.render()

    def field(self,parent,label,key,placeholder=None):
        ttk.Label(parent,text=label).pack(anchor='w',pady=(12,5))
        e=ttk.Entry(parent,textvariable=self.vars[key],width=90)
        e.pack(fill='x')
        return e

    def helper(self,parent,text):
        ttk.Label(parent,text=text,style='Muted.TLabel',wraplength=840,justify='left').pack(anchor='w',pady=7)

    def text_area(self,parent,height=8):
        holder=ttk.Frame(parent)
        holder.pack(fill='both',expand=True,pady=8)
        scroll=ttk.Scrollbar(holder,orient='vertical')
        scroll.pack(side='right',fill='y')
        t=tk.Text(holder,height=height,wrap='word',background=PANEL,foreground=FG,
                  insertbackground=FG,relief='flat',font=('Consolas',10),padx=12,pady=12,
                  yscrollcommand=scroll.set)
        t.pack(side='left',fill='both',expand=True)
        if self._darwin:t.configure(font=(DARWIN_FONTS['mono'],10))
        scroll.config(command=t.yview)
        return t

    def render(self):
        for item in self.body.winfo_children():item.destroy()
        self.step_label.config(text='   /   '.join(('[{}] {}'.format(i+1,n) if i==self.step else '{} {}'.format(i+1,n)) for i,n in enumerate(self.screens)))
        self.back_btn.config(state='disabled' if self.step==0 else 'normal')
        self.next_btn.config(text='Finish' if self.step==4 else 'Continue \u2192')
        if self.step==0:self.render_gateway()
        elif self.step==1:self.render_backend()
        elif self.step==2:self.render_tools()
        elif self.step==3:self.render_review()
        else:self.render_quick()

    def render_gateway(self):
        if self._darwin:return self._render_gateway_darwin()
        # [v04] transport selector: native localhost (no SSH/admin) vs the existing Linux
        # SSH jump server. [S2] install/repair approvals and the create-only inspect flow
        # from v0.3.1 are preserved below.
        ttk.Label(self.body,text='01  Select gateway location',style='Heading.TLabel').pack(anchor='w')
        self.helper(self.body,'Use native localhost on Windows with NO SSH server or admin rights, or keep your existing Linux SSH jump server. Native localhost does not open an inbound port.')
        selector=ttk.Frame(self.body);selector.pack(anchor='w',pady=6)
        for label,value in [('Linux SSH jump server (existing v0.3 workflow)','linux-ssh'),
                            ('Native gateway on THIS computer (no SSH/admin)','native-local')]:
            ttk.Radiobutton(selector,text=label,value=value,variable=self.vars['transport'],
                            command=self.transport_changed).pack(anchor='w')
        if self.vars['transport'].get()=='linux-ssh':
            self.helper(self.body,'Strict SSH host-key verification. Inspect first: a missing gateway can be installed; an existing group-writable gateway can be reviewed and repaired with explicit approval. No existing runtime is overwritten. 127.0.0.1 is valid if your own computer runs Linux SSH.')
            self.field(self.body,'Jump server hostname / IP','host')
            self.field(self.body,'Remote SSH username','user')
            self.field(self.body,'Local known_hosts path','known_hosts')
        else:
            self.helper(self.body,'Native gateway folder: ~/AQ-MCP-Gateway. Runs under your current Windows account and uses its own venv. Linux/macOS native-local is experimental. No WSL2, Docker, SSH daemon or admin rights required for Lambda targets.')
        buttons=ttk.Frame(self.body);buttons.pack(anchor='w',pady=(16,4))
        ttk.Button(buttons,text='Inspect gateway (read only)',command=self.inspect_action).pack(side='left',padx=(0,8))
        ttk.Button(buttons,text='Install missing gateway',command=self.bootstrap_action).pack(side='left',padx=(0,8))
        # [v04] permission repair is a Linux SSH-only operation; hide it in native-local.
        if self.vars['transport'].get()=='linux-ssh':
            ttk.Button(buttons,text='Repair core permissions',command=self.repair_action).pack(side='left',padx=(0,8))
            ttk.Button(buttons,text='Load bootstrap receipt',command=self.load_bootstrap_receipt_action).pack(side='left',padx=(0,8))
            ttk.Button(buttons,text='Save bootstrap receipt',command=self.save_bootstrap_receipt_action).pack(side='left')
        self.helper(self.body,'Fresh install is create-only and needs approved Python package downloads. AWS credentials are configured separately; no PATs or Quick database writes. Existing installations are never overwritten. Permission repair removes group/world write on owned core files only (may affect shared workflows).')
        self.gateway_result=self.text_area(self.body,9)
        self.gateway_result.insert('1.0','Click Inspect. A missing gateway can be installed only with approval; core permission repair is separate.')

    def render_backend(self):
        ttk.Label(self.body,text='02  Select MCP backend',style='Heading.TLabel').pack(anchor='w')
        self.helper(self.body,'Choose the approved backend. Native-local v0.4 supports SigV4 Lambda; Git and existing local servers remain Linux SSH-only.')
        group=ttk.Frame(self.body);group.pack(fill='x',pady=8)
        # S2: a host THIS wizard bootstrapped carries the Lambda lane only; disable the
        # Git and Build Artifacts options and say why. Decided only from held state
        # (self.bootstrap_receipt), never guessed from the remote.
        lambda_only=host_is_wizard_lambda_only(self.bootstrap_receipt)
        if lambda_only and self.vars['kind'].get() in ('git','local'):
            self.vars['kind'].set('lambda')
        # [v04] native-local offers the Lambda lane only (Git/local stay Linux SSH). This
        # is a superset of the S2 constraint, so when BOTH apply the result is still
        # Lambda-only; neither safety rule is weakened.
        modes=[('AWS Lambda Function URL (SigV4)','lambda')]
        if self.vars['transport'].get()=='linux-ssh':
            modes += [('Guarded Git MCP (existing)','git'),('Local approved MCP (existing)','local')]
        if self.vars['transport'].get()=='native-local' and self.vars['kind'].get() in ('git','local'):
            self.vars['kind'].set('lambda')
        for label,value in modes:
            rb=ttk.Radiobutton(group,text=label,value=value,variable=self.vars['kind'],command=self.kind_changed)
            rb.pack(anchor='w',pady=4)
            if lambda_only and value in ('git','local'):
                rb.configure(state='disabled')
        if self.vars['transport'].get()=='native-local':
            self.helper(self.body,'Native-local supports SigV4 Lambda only; Git and existing local servers are Linux SSH-only.')
        elif lambda_only:
            self.helper(self.body,'This host was bootstrapped by the wizard with the Lambda '
                        'lane only; the Git and Build Artifacts launchers are not installed.')
        self.field(self.body,'Registry / Git target name','target')
        self.field(self.body,'Quick connector display name','display_name')
        if self.vars['kind'].get()=='lambda':
            self.field(self.body,'AWS Lambda Function URL (HTTPS, IAM-authorized)','url')
            self.helper(self.body,'Example: https://EXAMPLE.lambda-url.us-west-2.on.aws/mcp. No other HTTP domains are permitted by this proxy.')
        elif self.vars['kind'].get()=='git':
            self.helper(self.body,'Choose existing gateway target github-ghes or gitlab. The wizard never edits Docker images, token stores, or branch guards.')
            ttk.Button(self.body,text='Use github-ghes',command=lambda:self.vars['target'].set('github-ghes')).pack(anchor='w')
            ttk.Button(self.body,text='Use gitlab',command=lambda:self.vars['target'].set('gitlab')).pack(anchor='w')
        else:
            self.helper(self.body,'Local mode registers an existing local target such as build-artifacts; it cannot execute arbitrary scripts.')
            ttk.Button(self.body,text='Use build-artifacts',command=lambda:self.vars['target'].set('build-artifacts')).pack(anchor='w')
        ttk.Button(self.body,text='Test / Verify Backend (MCP handshake)',command=self.verify_backend_action).pack(anchor='w',pady=(15,7))
        self.backend_result=self.text_area(self.body,7)
        v=self.backend_verification
        if v and v.get('backend_identity_sha256')==backend_identity(self.spec()):
            self.backend_result.insert('1.0',self.describe_backend(v))
        else:
            self.backend_result.insert('1.0','Not verified. Test the selected backend before continuing.\n'
                                       'The check requests MCP initialize + tools/list, but does not execute application tools.\n'
                                       'Git/local verification starts the existing approved MCP launcher.')

    def describe_backend(self,report):
        lines=['STATUS: '+report['status'],
               'Registry target: '+('EXISTING (registration-only)' if report.get('existing_target') else 'NEW (eligible for create-only install)'),
               'Handshake: '+report['handshake'],
               'Offered tools: '+str(report['tool_count']),
               'Backend identity: '+report['backend_identity_sha256'][:20]+'...',
               'Verification only: no application tool calls.']
        for warning in report.get('warnings',[]):lines.append('WARNING: '+warning)
        if report.get('potentially_mutating_tools_name_only'):
            lines.append('REVIEW potential mutators (name-based guess, NOT a safety verdict):')
            lines.extend('  - '+name for name in report['potentially_mutating_tools_name_only'])
        lines.extend('  '+t['name'] for t in report['tools'])
        return '\n'.join(lines)

    def verify_backend_action(self):
        spec=self.spec()
        # Backend verification does not require choosing tool policy yet.
        if spec['kind']=='lambda':spec['allow']=['verification-placeholder']
        def done(ok,result):
            if not ok:
                self.backend_verification=None
                messagebox.showerror('Backend verification failed',str(result))
                if self.step==1:self.backend_result.delete('1.0','end');self.backend_result.insert('1.0','FAILED: '+str(result))
                return
            if result.get('backend_identity_sha256')!=backend_identity(self.spec()):
                self.backend_verification=None
                messagebox.showwarning('Inputs changed','The selected backend changed while verification was running. Test again.');return
            self.backend_verification=result
            self.prepared=None
            if self.vars['kind'].get()=='lambda':
                self.discovered=list(result['tools'])
                self.tool_selection=list(result.get('existing_allow') or [])
            if self.step==1:
                self.backend_result.delete('1.0','end')
                self.backend_result.insert('1.0',self.describe_backend(result))
            messagebox.showinfo('Backend verification','MCP tools/list succeeded: {} tool(s).\n'
                                'Review warnings and choose the allowed tools next.'.format(result['tool_count']))
        if self._darwin:return self._darwin_g1b_action(capability_gate.SCOPE_VERIFY_BACKEND,lambda gw:ConnectorDeployer(gw).verify_backend(spec),done)
        self.action(lambda:ConnectorDeployer(self.gateway()).verify_backend(spec),done)

    def transport_changed(self):
        # [v04] switching transport resets verification/plan state; native-local forces the
        # Lambda lane (Git/local are Linux SSH-only).
        self.gateway_inspection=None
        self.backend_verification=None
        self.prepared=None
        self.discovered=[]
        self.tool_selection=[]
        if self.vars['transport'].get()=='native-local':
            self.vars['kind'].set('lambda')
        self.render()

    def kind_changed(self):
        self.prepared=None
        self.backend_verification=None
        self.discovered=[]
        self.tool_selection=[]
        k=self.vars['kind'].get()
        self.vars['target'].set({'lambda':'epg-demo','git':'github-ghes','local':'build-artifacts'}[k])
        self.render()

    def render_tools(self):
        ttk.Label(self.body,text='03  Tool discovery and allow-list',style='Heading.TLabel').pack(anchor='w')
        if self.vars['kind'].get()!='lambda':
            self.helper(self.body,'This backend is already registered on the gateway. Its existing Git guard / local tool policy is not modified.')
            return
        self.helper(self.body,'Discover tools through the chosen gateway (MCP initialize + tools/list only). Check exact tools to expose. An empty list is prohibited because the current proxy treats empty as ALL.')
        ttk.Button(self.body,text='Re-test / refresh backend tool list',command=self.discover_action).pack(anchor='w',pady=6)
        self.helper(self.body,'WARNING: Tool names and descriptions are not safety guarantees. An EPG label with Alerts/export tools may indicate the wrong Lambda URL.')
        self.tool_box=tk.Listbox(self.body,selectmode='multiple',height=12,exportselection=False,
                                 bg=PANEL,fg=FG,selectbackground='#28617D',
                                 selectforeground='white',font=('Consolas',10),relief='flat')
        self.tool_box.pack(fill='both',expand=True,pady=10)
        if self._darwin:self.tool_box.configure(font=(DARWIN_FONTS['mono'],10))
        for i,t in enumerate(self.discovered):
            self.tool_box.insert('end',t['name']+'   '+t.get('description','')[:85])
            if t['name'] in getattr(self,'tool_selection',[]): self.tool_box.selection_set(i)
        self.helper(self.body,'Select explicitly. An actual deployment will rediscover and verify every selected name before writing.')
        if self.backend_verification:
            for warning in self.backend_verification.get('warnings',[]):self.helper(self.body,'WARNING: '+warning)

    def show_quick_copy_fields(self, parent, connector):
        """[v04] Expose Quick Command and Arguments separately, with copy buttons."""
        for child in parent.winfo_children():
            child.destroy()
        if not connector:
            ttk.Label(parent, text='Quick Command / Arguments appear here after plan generation.',
                      style='Muted.TLabel').pack(anchor='w')
            return
        try:
            values=quick_copy_fields(connector)
        except ValueError as exc:
            ttk.Label(parent, text='Cannot format Quick settings: '+str(exc),
                      style='Muted.TLabel').pack(anchor='w')
            return
        ttk.Label(parent, text='COPY INTO AMAZON QUICK (Local connector)',
                  style='Muted.TLabel').pack(anchor='w', pady=(3,4))
        for label,key in [('Command','command'),('Arguments (paste entire line)','arguments')]:
            ttk.Label(parent,text=label).pack(anchor='w',pady=(5,2))
            row=ttk.Frame(parent);row.pack(fill='x')
            field=ttk.Entry(row)
            field.insert(0,values[key]);field.configure(state='readonly')
            field.pack(side='left',fill='x',expand=True)
            ttk.Button(row,text='Copy '+('command' if key=='command' else 'arguments'),
                       command=lambda value=values[key]:self.copy_text(value)).pack(side='left',padx=(8,0))
        self.helper(parent,'Quick ID: {}  |  Name: {}  |  Timeout: {} s  |  Environment: EMPTY'.format(
                    values['id'],values['name'],values['timeout_seconds']))

    def render_review(self):
        ttk.Label(self.body,text='04  Plan, deploy and verify',style='Heading.TLabel').pack(anchor='w')
        self.helper(self.body,'The verified backend and selected tools produce a plan automatically. The live registry is checked before approval; Apply is locked until planning finishes.')
        controls=ttk.Frame(self.body);controls.pack(fill='x',pady=6)
        ttk.Button(controls,text='Refresh deployment plan',command=self.plan_action).pack(side='left',padx=(0,10))
        ttk.Button(controls,text='Deploy approved plan',command=self.deploy_action).pack(side='left',padx=(0,10))
        ttk.Button(controls,text='Rollback last deployment',command=self.rollback_action).pack(side='left',padx=(0,10))
        ttk.Button(controls,text='Save receipt',command=self.save_receipt_action).pack(side='left')
        if self._darwin:
            self._disable_buttons(controls,('Deploy approved plan','Rollback last deployment','Save receipt'))
            self.helper(self.body,DARWIN_PLAN_ONLY_TEXT)
            self._darwin_provenance=ttk.Label(self.body,text=self._darwin_provenance_text(),
                                              style='Muted.TLabel',wraplength=840,justify='left')
            self._darwin_provenance.pack(anchor='w',pady=4)
        # [v04] Command / Arguments panel for the generated connector, with Copy buttons.
        self.quick_copy_area=ttk.Frame(self.body);self.quick_copy_area.pack(fill='x',pady=(6,10))
        if self._darwin:
            # [P2-S1 / B3d] macOS: the panel is filled REDACTED by _darwin_render_step4 below,
            # once the plan view exists. No Step 4 widgets are owned until then.
            self._darwin_step4_widgets=None
        else:
            self.show_quick_copy_fields(self.quick_copy_area, (self.prepared or {}).get('quick_connector'))
        # S5: plain-language summary a non-expert can read BEFORE approving a deploy.
        ttk.Label(self.body,text='Plain-language summary',style='Muted.TLabel').pack(anchor='w',pady=(4,0))
        self.summary_view=self.text_area(self.body,8)
        self.summary_view.insert('1.0',self.summary_text())
        self.summary_view.configure(state='disabled')
        self.plan_view=self.text_area(self.body,12)
        if self._darwin:
            # [P2-S1 / B3d] macOS: this Step 4 owns these two widgets; the panel and the plan
            # JSON are rendered REDACTED (darwin_step4_view).
            self._darwin_step4_widgets=(self.quick_copy_area,self.plan_view)
            self._darwin_render_step4()
        else:
            if self.prepared:self.plan_view.insert('1.0',json.dumps(self.prepared,indent=2))
            else:self.plan_view.insert('1.0','Generating a deployment plan automatically from verified backend and selected tools...')
        self.after(75,self.auto_plan)

    def summary_text(self):
        """S5: render the plain-language deploy summary from the current plan (or a wait note)."""
        if not self.prepared:
            return ('The plain-language summary will appear here once the deployment plan '
                    'has been generated from the verified backend and your selected tools.')
        discovered=None
        if self.backend_verification and self.backend_verification.get('backend_identity_sha256')==backend_identity(self.spec()):
            discovered=self.backend_verification.get('tool_count')
        # [P2-S1 / B4c] F-B4b-02: macOS takes the identity-validated path below. This is
        # a darwin-only statement; the off-darwin source is unchanged.
        if self._darwin:return self._darwin_summary_text(discovered)
        try:
            return plain_language_summary(self.spec(),self.prepared,discovered_count=discovered)
        except Exception as e:
            if self._darwin:return DARWIN_SUMMARY_UNAVAILABLE
            return 'Summary unavailable: '+str(e)

    def _darwin_summary_text(self, discovered):
        """[P2-S1 / B4c] macOS-only Step 4 summary boundary (F-B4b-02).

        Builds the summary with the BYTE-FROZEN model.plain_language_summary (which is
        not modified) and validates the COMPLETE text before it can reach the review
        screen (render_review) or a summary refresh (refresh_summary_view) - the only
        two macOS-reachable summary surfaces, because deploy_action refuses on darwin
        before its confirmation dialog is ever built.

        Unsafe text, an empty/malformed identity, or any other failure all yield the
        existing fixed DARWIN_SUMMARY_UNAVAILABLE. The unsafe text is never returned,
        echoed, logged or truncated into the fallback.
        """
        try:
            from model import assert_identity_safe
            from quick_reg import _spec_identity
            spec=self.spec()
            text=plain_language_summary(spec,self.prepared,discovered_count=discovered)
            return assert_identity_safe(text,*_spec_identity(spec))
        except Exception:
            return DARWIN_SUMMARY_UNAVAILABLE

    def render_quick(self):
        ttk.Label(self.body,text='05  Register in Amazon Quick',style='Heading.TLabel').pack(anchor='w')
        self.helper(self.body,'Gateway deployment and Quick Desktop registration are separate steps. Native-local uses direct Python (no SSH); Linux SSH uses ssh. This version NEVER writes to the DIPS database; its schema and supported registration lifecycle are unverified.')
        try:
            if self._darwin:
                # A1.1 user gap fix (g)(ii), macOS only: the on-screen text and the held copy
                # variants come from the REDACTED builder; the FULL text is produced only by
                # quick_reg.quick_instructions_full with the typed COPY FULL token.
                from quick_reg import quick_instructions_screen
                try:
                    variants=quick_instructions_screen(self.spec())
                    msg=DARWIN_SCREEN_REDACTED_NOTE+'\n\n'+variants['redacted']
                except IdentityRedactionError:
                    # [P2-S1 / B4] the redacted builder refused: hold NO variants (so
                    # 'Copy Quick settings (redacted)' has nothing to copy) and show the
                    # fixed refusal text, never the exception or the identity.
                    variants=None;msg=DARWIN_STEP5_IDENTITY_REFUSED
            else:
                variants=quick_instructions_variants(self.spec())
                # On-screen we show the FULL text because the user runs this command on their
                # own machine; the Copy buttons below choose redacted (default) vs full.
                msg=variants['full']
        except Exception as e:
            variants=None;msg='Complete prior steps: '+str(e)
        self._quick_variants=variants
        # [v04] Command / Arguments panel for the live connector (SSH or native-local).
        self.quick_copy_area=ttk.Frame(self.body);self.quick_copy_area.pack(fill='x',pady=(5,10))
        if self._darwin:
            # [P2-S1 / B3c] macOS only: the panel shows REDACTED values; the real values
            # come only from darwin_full_copy_field after the typed COPY FULL token.
            self._show_quick_copy_fields_darwin(self.quick_copy_area)
        else:
            try:self.show_quick_copy_fields(self.quick_copy_area,quick_connector(self.spec()))
            except Exception:self.show_quick_copy_fields(self.quick_copy_area,None)
        self.manual=self.text_area(self.body,12)
        self.manual.insert('1.0',msg)
        controls=ttk.Frame(self.body);controls.pack(fill='x',pady=12)
        ttk.Button(controls,text='Copy Quick settings (redacted)',command=self.copy_quick_redacted).pack(side='left',padx=(0,10))
        ttk.Button(controls,text='Copy FULL (real login/host)',command=self.copy_quick_full).pack(side='left',padx=(0,10))
        ttk.Button(controls,text='Export JSON example (redacted)',command=self.export_action).pack(side='left',padx=(0,10))
        ttk.Button(controls,text='Export FULL JSON',command=self.export_full_action).pack(side='left',padx=(0,10))
        ttk.Button(controls,text='Inspect DIPS schema (read-only)',command=self.dips_action).pack(side='left')
        if self._darwin:
            self._disable_buttons(controls,('Inspect DIPS schema (read-only)',))
            self.helper(self.body,DARWIN_QUICK_TEXT)
        self.helper(self.body,'After saving in Quick, open a NEW Quick chat, verify tools/list or a harmless read, and review per-tool permission settings. Registration status: MANUAL_REQUIRED.')

    def auto_plan(self):
        if self.step != 3 or self.busy:return
        current=self.spec()
        if self.prepared and self.prepared.get('backend_identity_sha256')==backend_identity(current):
            if current['kind']!='lambda' or self.prepared.get('registry_entry',{}).get('allow')==sorted(current.get('allow',[])):
                return
        self.plan_action()

    def spec(self):
        spec={k:v.get().strip() for k,v in self.vars.items() if k!='known_hosts'}
        # [v04] native-local pins the loopback host and a fixed local user so no SSH
        # login/hostname is ever required or stored for a native gateway.
        if spec.get('transport')=='native-local':
            spec['host']='127.0.0.1'
            spec['user']='local'
        if spec['kind']=='lambda':
            if hasattr(self,'tool_box') and self.tool_box.winfo_exists():
                spec['allow']=[self.discovered[int(i)]['name'] for i in self.tool_box.curselection()]
            elif hasattr(self,'tool_selection'):
                spec['allow']=list(self.tool_selection)
            else: spec['allow']=[]
        return spec

    def save_selection(self):
        if self.step==2 and self.vars['kind'].get()=='lambda' and hasattr(self,'tool_box'):
            self.tool_selection=[self.discovered[int(i)]['name'] for i in self.tool_box.curselection()]
        if self.step==1: self.prepared=None

    def gateway(self):
        spec=self.spec()
        validate_gateway(spec['host'],spec['user'])
        # [v04] native-local uses the user-owned local gateway (no SSH object built).
        if spec.get('transport')=='native-local':return NativeGateway()
        return SSHGateway(spec['host'],spec['user'],self.vars['known_hosts'].get().strip())

    def action(self,task,callback=None):
        if self.busy:return
        self.busy=True
        self.back_btn.config(state='disabled');self.next_btn.config(state='disabled')
        self.status.config(text='Working\u2026')
        self.configure(cursor='watch')
        if self._darwin:return self._darwin_start_worker(task,callback)
        def run():
            try:result=task();ok=True
            except Exception as e:result=str(e);ok=False
            def done():
                self.busy=False
                self.configure(cursor='');self.status.config(text='Ready' if ok else 'Operation failed')
                self.back_btn.config(state='disabled' if self.step==0 else 'normal');self.next_btn.config(state='normal')
                if callback:callback(ok,result)
                elif not ok:messagebox.showerror('Operation failed',result)
            self.after(0,done)
        threading.Thread(target=run,daemon=True).start()

    def inspect_action(self):
        def done(ok,result):
            self.gateway_result.delete('1.0','end')
            self.gateway_inspection=result if ok else None
            self.gateway_result.insert('1.0',json.dumps(result,indent=2) if ok else result)
        if self._darwin:return self._darwin_g1b_action(capability_gate.SCOPE_INSPECT_GATEWAY,lambda gw:ConnectorDeployer(gw).inspect(),done)
        self.action(lambda:ConnectorDeployer(self.gateway()).inspect(),done)

    def bootstrap_action(self):
        if self._darwin:return self._refuse_g2_ui('Install missing gateway')
        state=self.gateway_inspection
        if not state or state.get('state')!='MISSING':
            messagebox.showerror('Inspect first','Only a confirmed missing gateway can be installed. Click Inspect first.');return
        # [v04] native vs SSH install wording; both are create-only and never overwrite.
        location=('a new user-owned ~/AQ-MCP-Gateway on THIS computer' if self.vars['transport'].get()=='native-local' else 'a new PRIVATE ~/aq-mcp gateway on this Linux SSH server')
        if not messagebox.askyesno('Install new gateway',
            'Install '+location+'?\n\n'
            'This installs reviewed gateway Python sources and downloads pinned packages using the jump server configured pip index. '
            'No existing installation will be overwritten. AWS credentials are NOT created.\n\nProceed?'):
            return
        self.action(lambda:ConnectorDeployer(self.gateway()).bootstrap(approved=True),
                    lambda ok,result:self.install_done(ok,result))

    def repair_action(self):
        if self._darwin:return self._refuse_g2_ui('Repair core permissions')
        state=self.gateway_inspection
        if not state or state.get('state')!='PERMISSIONS_NEED_REPAIR':
            messagebox.showerror('Inspect first','Permission repair requires an inspected owned gateway with unsafe core-file modes.');return
        names=', '.join(x['file'] for x in state['mode_issues'])
        if not messagebox.askyesno('Change access modes',
            'Remove group/world WRITE permission from these owned gateway files:\n'+names+'\n\n'
            'This may affect other users or shared workflows. No unrelated files are changed. Continue?'):
            return
        self.action(lambda:ConnectorDeployer(self.gateway()).repair_permissions(state,approved=True),
                    lambda ok,result:self.install_done(ok,result))

    def install_done(self,ok,result):
        if not ok:
            messagebox.showerror('Gateway action failed',str(result));return
        self.gateway_inspection=None
        # S2: if this was a wizard bootstrap, remember it so Git/Local are disabled/refused.
        if host_is_wizard_lambda_only(result):
            self.bootstrap_receipt=result
        messagebox.showinfo('Gateway action',json.dumps(result,indent=2)[:2000]+'\n\nInspect again before deploying a target.')
        self.inspect_action()

    def load_bootstrap_receipt_action(self):
        """S2: let the user point the wizard at a bootstrap receipt the wizard wrote.
        Only a receipt that proves a wizard Lambda-only bootstrap takes effect; anything
        else is ignored (we never guess a host is Lambda-only)."""
        path=filedialog.askopenfilename(title='Select a wizard bootstrap receipt (JSON)',
                                        filetypes=[('JSON','*.json')])
        if not path:return
        try:
            with open(path,'r',encoding='utf-8') as fp:receipt=json.load(fp)
        except Exception as e:
            messagebox.showerror('Could not read receipt',str(e));return
        if host_is_wizard_lambda_only(receipt):
            self.bootstrap_receipt=receipt
            messagebox.showinfo('Bootstrap receipt loaded',
                'This host is marked as wizard-bootstrapped (Lambda lane only). The Git and '
                'Build Artifacts options are now disabled.')
            if self.step==1:self.render()
        else:
            messagebox.showwarning('Not a wizard Lambda-only bootstrap receipt',
                'This file is not a wizard Lambda-only bootstrap receipt; it was ignored. '
                'Git/Local options are unchanged.')

    def discover_action(self):
        sp=self.spec();sp['allow']=['discovery-placeholder']
        def done(ok,result):
            if not ok:
                self.backend_verification=None;self.discovered=[];self.tool_selection=[]
                messagebox.showerror('Discovery failed',result);return
            self.backend_verification=result
            self.prepared=None
            self.discovered=list(result['tools']);self.tool_selection=list(result.get('existing_allow') or [])
            self.render()
            messagebox.showinfo('Discovery','{} tools returned. Select exact tools, and review the potential mutators.'.format(len(self.discovered)))
        if self._darwin:return self._darwin_g1b_action(capability_gate.SCOPE_VERIFY_BACKEND,lambda gw:ConnectorDeployer(gw).verify_backend(sp),done)
        self.action(lambda:ConnectorDeployer(self.gateway()).verify_backend(sp),done)

    def plan_action(self):
        spec=self.spec()
        if not self.backend_verification or self.backend_verification.get('backend_identity_sha256')!=backend_identity(spec):
            self.prepared=None
            messagebox.showerror('Backend not verified','Return to Step 2 and test the selected backend before generating a plan.');return
        def done(ok,result):
            if not ok:
                if self._darwin:
                    # [P2-S1 / B3e] fixed text only; the error text is never shown.
                    self.prepared=None;msg=darwin_plan_failure_text(result)
                    self.plan_view.delete('1.0','end');self.plan_view.insert('1.0',msg)
                    messagebox.showerror('Plan failed',msg);return
                self.prepared=None;self.plan_view.delete('1.0','end');self.plan_view.insert('1.0','Plan failed: '+str(result))
                messagebox.showerror('Plan failed',str(result));return
            if result.get('backend_identity_sha256')!=backend_identity(self.spec()):
                self.prepared=None;messagebox.showerror('Plan stale','The backend fields changed; regenerate the plan.');return
            result['verification_summary']={'status':'BACKEND_VERIFIED',
                'handshake':self.backend_verification['handshake'],
                'offered_tool_count':self.backend_verification['tool_count'],
                'offered_name_sha256':__import__('hashlib').sha256(','.join(sorted(x['name'] for x in self.backend_verification['tools'])).encode()).hexdigest()}
            self.prepared=result
            if self._darwin:
                # [P2-S1 / B3d] macOS: REDACTED panel + plan JSON, written only into the
                # widgets the current Step 4 owns (never into Step 5).
                self._darwin_render_step4()
            else:
                # [v04] refresh the Command/Arguments panel from the freshly generated plan.
                self.show_quick_copy_fields(self.quick_copy_area,result.get('quick_connector'))
                self.plan_view.delete('1.0','end');self.plan_view.insert('1.0',json.dumps(result,indent=2))
            self.refresh_summary_view()
        if self._darwin:return self.action(lambda:ConnectorDeployer(None).prepare_offline(spec),self._darwin_wrap_plan_done(done))
        self.action(lambda:ConnectorDeployer(self.gateway()).prepare(spec),done)

    def refresh_summary_view(self):
        """S5: keep the on-screen summary in step with the latest plan."""
        view=getattr(self,'summary_view',None)
        if view is None or not view.winfo_exists():return
        view.configure(state='normal')
        view.delete('1.0','end');view.insert('1.0',self.summary_text())
        view.configure(state='disabled')

    def deploy_action(self):
        if self._darwin:return self._refuse_g2_ui('Deploy approved plan')
        if not self.prepared:messagebox.showerror('Plan first','Wait for the automatically generated deployment plan first.');return
        spec=self.spec();prepared=dict(self.prepared)
        if prepared.get('backend_identity_sha256')!=backend_identity(spec) or prepared.get('quick_connector')!=quick_connector(spec):
            messagebox.showerror('Stale plan','Backend/connector settings changed. Refresh the plan before deployment.');return
        if spec['kind']=='lambda' and (prepared.get('registry_entry') or {}).get('allow')!=sorted(spec.get('allow',[])):
            messagebox.showerror('Stale tool policy','Tool selection changed. Refresh the plan before deployment.');return
        try:
            # S2: refuse Git/Local on a host THIS wizard bootstrapped (Lambda lane only).
            validate_spec_for_host(spec,self.bootstrap_receipt)
        except Exception as exc:messagebox.showerror('Validation',str(exc));return
        risky=prepared.get('potentially_mutating_tools_name_only',[])
        # S4 parity: identical mutating-tool warning text as the CLI apply path.
        if risky and not messagebox.askyesno('Review selected tools',mutating_confirm_text(risky)):
            return
        if prepared.get('warnings') and not messagebox.askyesno('Backend warnings',
            '\n'.join(prepared['warnings'])+'\n\nConfirm this is the correct endpoint and tool set?'):
            return
        # S5: show the plain-language summary in the final approval dialog, before confirm.
        # [v04] wording covers either transport (native-local gateway or SSH jump server).
        target_phrase=('on the native gateway on this computer' if spec.get('transport')=='native-local'
                       else 'on the approved jump server')
        if not messagebox.askyesno('Approve gateway change',
             self.summary_text()+'\n\nDeploy only {} {} now?'.format(spec['target'],target_phrase)):
            return
        gw=self.gateway()
        def done(ok,result):
            if not ok:messagebox.showerror('Deployment failed',result);return
            self.last_receipt=result;self.last_gateway=gw
            # [v04] surface the live Command/Arguments for copy/paste into Quick.
            connector=result.get('quick_connector') or prepared.get('quick_connector')
            self.show_quick_copy_fields(self.quick_copy_area,connector)
            try:
                fields=quick_copy_fields(connector)
                paste='QUICK COMMAND (COPY/PASTE):\n'+fields['command']+'\n\nQUICK ARGUMENTS (PASTE ENTIRE LINE):\n'+fields['arguments']+'\n\n'
            except Exception:
                paste=''
            self.plan_view.delete('1.0','end');self.plan_view.insert('1.0',paste+json.dumps(result,indent=2))
            messagebox.showinfo('Gateway result',result['status']+'\n\nQuick Command and Arguments are available above the receipt, with separate Copy buttons.\nQuick registration remains manual.')
        self.action(lambda:ConnectorDeployer(gw).deploy(spec,prepared,True),done)

    def save_receipt_action(self):
        if self._darwin:return self._refuse_g2_ui('Save receipt')
        # [v04] native receipts use backup_file; SSH receipts use backup_name. Accept either.
        if not self.last_receipt or not (self.last_receipt.get('backup_name') or self.last_receipt.get('backup_file')):
            messagebox.showerror('No deployment receipt','Deploy a new Lambda target before saving a receipt.');return
        path=filedialog.asksaveasfilename(title='Save private rollback receipt',
                                          defaultextension='.json',filetypes=[('JSON','*.json')])
        if not path:return
        try:
            # B2b S7: owner-only (0600), create-only. The receipt holds the real gateway
            # address (needed for rollback) so it is NOT redacted, but it IS mode-locked.
            secure_write_json(path,self.last_receipt)
            messagebox.showinfo('Receipt saved','Keep this file internal: it includes the gateway/connector address. '
                'Saved with owner-only permissions (POSIX 0600; on Windows the read-only attribute only).')
        except Exception as e:messagebox.showerror('Could not save receipt',str(e))

    def save_bootstrap_receipt_action(self):
        """B2b S2 follow-up: persist the held bootstrap receipt so S2 state survives across
        sessions. Only a receipt that proves a wizard Lambda-only bootstrap is written; it is
        saved with S7 permissions and reloads through 'Load bootstrap receipt'."""
        receipt=self.bootstrap_receipt
        if not host_is_wizard_lambda_only(receipt):
            messagebox.showerror('No bootstrap receipt to save',
                'Bootstrap this host (or load a wizard bootstrap receipt) first. Only a wizard '
                'Lambda-only bootstrap receipt can be saved.');return
        path=filedialog.asksaveasfilename(title='Save wizard bootstrap receipt (JSON)',
                                          defaultextension='.json',filetypes=[('JSON','*.json')])
        if not path:return
        if self._darwin:
            # A1.1 user gap fix (g)(i), macOS only: same Quick-owned destination refusal as
            # the export guard, before anything is written.
            from quick_reg import p2_export_destination_refused,P2_QUICK_DIR_REFUSED
            if p2_export_destination_refused(path):
                messagebox.showerror('Save refused',P2_QUICK_DIR_REFUSED);return
        try:
            secure_write_json(path,receipt)
            messagebox.showinfo('Bootstrap receipt saved',
                'Saved with owner-only permissions. Load it with "Load bootstrap receipt" next '
                'session to keep Git/Local disabled on this Lambda-only host.')
        except Exception as e:messagebox.showerror('Could not save bootstrap receipt',str(e))

    def rollback_action(self):
        if self._darwin:return self._refuse_g2_ui('Rollback last deployment')
        # [v04] accept native (backup_file) or SSH (backup_name) receipts.
        if not self.last_receipt or not (self.last_receipt.get('backup_name') or self.last_receipt.get('backup_file')):
            messagebox.showerror('No rollback receipt','Only newly installed Lambda entries can be rolled back.');return
        if not messagebox.askyesno('Confirm rollback','Restore only if the registry SHA has NOT changed since deployment?'):
            return
        self.action(lambda:ConnectorDeployer(self.last_gateway).rollback(self.last_receipt),
                    lambda ok,result:messagebox.showinfo('Rollback' if ok else 'Rollback blocked',str(result)))

    def copy_text(self,value):
        self.clipboard_clear();self.clipboard_append(value);self.update()
        self.status.config(text='Copied to clipboard')

    def copy_quick_redacted(self):
        # B2b S7 DEFAULT: copy the REDACTED (shareable) Quick settings - placeholders in
        # place of the real login, host/IP and home path.
        v=getattr(self,'_quick_variants',None)
        if not v:
            messagebox.showerror('Nothing to copy','Complete the earlier steps first.');return
        self.copy_text(v['redacted'])
        self.status.config(text='Copied REDACTED Quick settings')

    def copy_quick_full(self):
        if self._darwin:return self._copy_quick_full_darwin()
        # B2b S7 explicit second action: copy the FULL text (real login/host). Warn first.
        v=getattr(self,'_quick_variants',None)
        if not v:
            messagebox.showerror('Nothing to copy','Complete the earlier steps first.');return
        if not messagebox.askyesno('Copy FULL (real login/host)',
            FULL_VARIANT_WARNING+'\n\nCopy the FULL text to the clipboard anyway?'):
            return
        self.copy_text(v['full'])
        self.status.config(text='Copied FULL Quick settings (real login/host)')

    def export_action(self):
        # B2b S7 DEFAULT: write the REDACTED (shareable) JSON example, owner-only (0600).
        self._export(redacted=True)

    def export_full_action(self):
        if self._darwin:return self._export_full_darwin()
        # B2b S7 explicit second action: write the FULL JSON (real login/host). Warn first.
        if not messagebox.askyesno('Export FULL JSON',
            FULL_VARIANT_WARNING+'\n\nWrite the FULL export anyway?'):
            return
        self._export(redacted=False)

    def _export(self,redacted=True):
        if self._darwin:return self._export_darwin(redacted,None)
        spec=self.spec()
        try:validate_spec(spec)
        except Exception as e:messagebox.showerror('Invalid form',str(e));return
        title=('Save REDACTED example (not directly importable)' if redacted
               else 'Save FULL example - contains real login/host')
        path=filedialog.asksaveasfilename(title=title,defaultextension='.json',filetypes=[('JSON','*.json')])
        if not path:return
        try:write_quick_config(spec,path,redacted=redacted)
        except Exception as exc:messagebox.showerror('Export failed',str(exc));return
        note=('Redacted export written (safe to share). This file is NOT proof that Quick can import it.'
              if redacted else
              'FULL export written. '+FULL_VARIANT_WARNING)
        messagebox.showinfo('Example saved',note)

    def dips_action(self):
        if self._darwin:
            messagebox.showerror('Not available on macOS','Inspect DIPS schema is disabled on macOS in Slice 1.');return
        path=filedialog.askopenfilename(title='Select Quick DIPS database (read only)')
        if not path:return
        if not messagebox.askyesno('Read only','Close Quick before inspecting. Continue with read-only schema inventory?'):return
        try:result=inspect_dips_read_only(path)
        except Exception as e:messagebox.showerror('Inspection failed',str(e));return
        messagebox.showinfo('Schema inventory (no writes)',json.dumps(result,indent=2)[:3000])

    # ------------------------------------------------------------------
    # [P2-S1] macOS-only helpers. Reached only when self._darwin is True.
    # ------------------------------------------------------------------
    def _darwin_setup(self):
        ui,bold,mono=DARWIN_FONTS['ui'],DARWIN_FONTS['ui_bold'],DARWIN_FONTS['mono']
        self.style.configure('TLabel',font=(ui,10))
        self.style.configure('Muted.TLabel',font=(ui,9))
        self.style.configure('Heading.TLabel',font=(bold,16))
        self.style.configure('TButton',font=(ui,10))
        self.vars['transport'].set('linux-ssh')
        self._darwin_verified_meta=None
        self._ui_queue=queue.Queue()
        self.protocol('WM_DELETE_WINDOW',self.destroy)
        self._poll_id=self.after(DARWIN_POLL_MS,self._poll_ui_queue)

    def _poll_ui_queue(self):
        # Main thread only. Never re-arms or runs callbacks once teardown began.
        self._poll_id=None
        if self._tearing_down:return
        q=self._ui_queue
        failed=False
        while q is not None and not self._tearing_down:
            try:item=q.get_nowait()
            except queue.Empty:break
            try:item()
            except Exception:failed=True
        if failed and not self._tearing_down:
            self._darwin_report_callback_failure()
        if not self._tearing_down:
            self._poll_id=self.after(DARWIN_POLL_MS,self._poll_ui_queue)

    def _darwin_report_callback_failure(self):
        # A1.5 W2: a raising callback is never silent; shown once per poll, generic text only.
        try:self.status.config(text='Operation failed')
        except Exception:pass
        try:messagebox.showerror('Operation failed',DARWIN_CALLBACK_FAILED)
        except Exception:pass

    def _darwin_start_worker(self,task,callback):
        # Worker thread touches NO Tk object: it only puts a callable on the queue.
        q=self._ui_queue
        def finish(ok,result):
            self.busy=False
            self.configure(cursor='');self.status.config(text='Ready' if ok else 'Operation failed')
            self.back_btn.config(state='disabled' if self.step==0 else 'normal');self.next_btn.config(state='normal')
            if callback:callback(ok,result)
            elif not ok:messagebox.showerror('Operation failed',result)
        def worker():
            try:result=task();ok=True
            except Exception as e:result=str(e);ok=False
            if self._tearing_down or q is None:return
            q.put(lambda:finish(ok,result))
        t=threading.Thread(target=worker,daemon=True)
        t.start()
        return t

    def _darwin_teardown(self):
        if self._tearing_down:return
        self._tearing_down=True
        for name in ('_poll_id','_clip_after'):
            ident=getattr(self,name,None)
            setattr(self,name,None)
            if ident is not None:
                try:self.after_cancel(ident)
                except Exception:pass
        self._clip_value=None
        q=self._ui_queue
        while q is not None:
            try:q.get_nowait()
            except queue.Empty:break

    def destroy(self):
        if getattr(self,'_darwin',False):self._darwin_teardown()
        super().destroy()

    def _disable_buttons(self,parent,labels):
        for child in parent.winfo_children():
            try:
                if child.cget('text') in labels:child.configure(state='disabled')
            except Exception:pass

    def _render_gateway_darwin(self):
        self.vars['transport'].set('linux-ssh')
        ttk.Label(self.body,text='01  Select gateway location',style='Heading.TLabel').pack(anchor='w')
        self.helper(self.body,DARWIN_SLICE1_TEXT)
        selector=ttk.Frame(self.body);selector.pack(anchor='w',pady=6)
        ttk.Radiobutton(selector,text='Linux SSH jump server (existing v0.3 workflow)',value='linux-ssh',
                        variable=self.vars['transport'],command=self.transport_changed).pack(anchor='w')
        self.helper(self.body,'Strict SSH host-key verification (the host must already be in known_hosts). Inspect reads the gateway state after a typed confirmation.')
        self.field(self.body,'Jump server hostname / IP','host')
        self.field(self.body,'Remote SSH username','user')
        self.field(self.body,'Local known_hosts path','known_hosts')
        buttons=ttk.Frame(self.body);buttons.pack(anchor='w',pady=(16,4))
        ttk.Button(buttons,text='Inspect gateway (read only)',command=self.inspect_action).pack(side='left',padx=(0,8))
        ttk.Button(buttons,text='Install missing gateway',command=self.bootstrap_action,state='disabled').pack(side='left',padx=(0,8))
        ttk.Button(buttons,text='Repair core permissions',command=self.repair_action,state='disabled').pack(side='left',padx=(0,8))
        ttk.Button(buttons,text='Load bootstrap receipt',command=self.load_bootstrap_receipt_action).pack(side='left')
        self.gateway_result=self.text_area(self.body,9)
        self.gateway_result.insert('1.0','Click Inspect (typed confirmation required). Install and repair are not available on macOS in Slice 1.')

    def _refuse_g2_ui(self,operation):
        try:
            capability_gate.refuse_g2(operation)
        except capability_gate.GateRefused as exc:
            messagebox.showerror('Not available on macOS',str(exc))
            return None
        messagebox.showerror('Not available on macOS','This action is disabled on macOS in Slice 1.')
        return None

    def _typed_prompt(self,title,message,expected):
        # Plain Toplevel (no Tk simple-dialog helper module; spec 3.8). Returns the raw
        # typed text or None.
        top=tk.Toplevel(self)
        top.title(title)
        top.transient(self)
        ttk.Label(top,text=message,justify='left',wraplength=640).pack(anchor='w',padx=16,pady=(14,6))
        entry=ttk.Entry(top,width=60)
        entry.pack(fill='x',padx=16,pady=6)
        result=[None]
        def ok():
            result[0]=entry.get()
            top.destroy()
        def cancel():
            result[0]=None
            top.destroy()
        row=ttk.Frame(top);row.pack(anchor='e',padx=16,pady=(6,14))
        ttk.Button(row,text='Cancel',command=cancel).pack(side='right')
        ttk.Button(row,text='OK',command=ok).pack(side='right',padx=(0,8))
        top.protocol('WM_DELETE_WINDOW',cancel)
        entry.focus_set()
        # A1.5 W1: grab_set raises TclError if the window is not yet viewable: retry once
        # after update_idletasks, then continue WITHOUT the grab (the prompt still works).
        try:
            top.grab_set()
        except tk.TclError:
            try:
                top.update_idletasks()
                top.grab_set()
            except tk.TclError:
                pass
        self.wait_window(top)
        return result[0]

    def _darwin_g1b_action(self,scope,make_task,done):
        # G1b / A1: (1) F1(i) SSH-library pre-check BEFORE any typed prompt; (2) one window
        # per scope showing destination, user, port, auth sources, host-key policy and the
        # exact text; (3) a NEW SSHGateway bound to that scope (and, for verify-backend,
        # to the target) for THIS action only. Nothing is stored on self.
        if not darwin_ssh_library_present():
            messagebox.showerror('SSH client library not installed',DARWIN_NO_SSH_LIB_UI);return None
        spec=self.spec()
        try:
            validate_gateway(spec['host'],spec['user'])
            title,message,expected=g1b_dialog(scope,spec['host'],spec['user'],spec['target'],
                                              darwin_backend_host(spec),darwin_auth_sources())
        except Exception as exc:
            messagebox.showerror('Cannot start this remote action',str(exc));return None
        typed=self._typed_prompt(title,message,expected)
        if typed is None:return None
        if not capability_gate.token_matches(expected,typed):
            messagebox.showerror('Not authorized','The typed confirmation did not match. Nothing was run.');return None
        label=None if scope==capability_gate.SCOPE_INSPECT_GATEWAY else spec['target']
        gw=SSHGateway(spec['host'],spec['user'],self.vars['known_hosts'].get().strip(),
                      ack=typed,scope=scope,label=label)
        return self.action(lambda:make_task(gw),self._darwin_wrap_done(scope,done))

    def _darwin_wrap_done(self,scope,done):
        # User decision C: remember WHEN the verify-backend metadata now held was obtained
        # (time + backend identity only; this is never an approval and unlocks nothing).
        def wrapped(ok,result):
            done(ok,result)
            if ok and scope==capability_gate.SCOPE_VERIFY_BACKEND and self.backend_verification is result:
                import time
                self._darwin_verified_meta={'at':time.strftime('%Y-%m-%d %H:%M:%S'),
                    'identity':result.get('backend_identity_sha256') if isinstance(result,dict) else None}
        return wrapped

    def _darwin_wrap_plan_done(self,done):
        # [P2-S1 / B3d] an offline-plan result is applied ONLY while Step 4 is the current
        # step and its widgets are the ones the current Step 4 owns. A stale result (the
        # user moved on, Step 4 was rebuilt away, or teardown began) is dropped silently.
        def wrapped(ok,result):
            if self._darwin_step4_owned() is None:return
            done(ok,result)
            self._darwin_refresh_provenance()
        return wrapped

    def _darwin_step4_owned(self):
        """[P2-S1 / B3d] (panel, plan view) of the CURRENT Step 4, or None. Never raises."""
        try:
            if getattr(self,'_tearing_down',False) or self.step!=3:return None
            owned=getattr(self,'_darwin_step4_widgets',None)
            if not owned:return None
            area,view=owned
            if area is not getattr(self,'quick_copy_area',None) or view is not getattr(self,'plan_view',None):
                return None
            if not (area.winfo_exists() and view.winfo_exists()):return None
            return area,view
        except Exception:
            return None

    def _darwin_render_step4(self):
        """[P2-S1 / B3d] macOS Step 4: REDACTED Command / Arguments panel and plan JSON,
        written only into the widgets the current Step 4 owns; does nothing otherwise."""
        owned=self._darwin_step4_owned()
        if owned is None:return
        area,view=owned
        try:spec=self.spec()
        except Exception:spec=None
        show_panel,text=darwin_step4_view(spec,self.prepared)
        if show_panel:self._show_quick_copy_fields_darwin(area)
        else:self.show_quick_copy_fields(area,None)
        view.delete('1.0','end');view.insert('1.0',text)

    def _darwin_provenance_text(self):
        try:spec=self.spec()
        except Exception:spec=None
        return darwin_step4_provenance_text(spec,self.prepared,self.backend_verification,
                                            getattr(self,'_darwin_verified_meta',None))

    def _darwin_refresh_provenance(self):
        lab=getattr(self,'_darwin_provenance',None)
        try:
            if lab is not None and lab.winfo_exists():lab.configure(text=self._darwin_provenance_text())
        except Exception:pass

    def _clip_clear_if_ours(self):
        self._clip_after=None
        ours=self._clip_value
        self._clip_value=None
        if self._tearing_down or ours is None:return
        try:current=self.clipboard_get()
        except Exception:return
        if current==ours:
            self.clipboard_clear()

    def _arm_clipboard_clear(self,value):
        if self._clip_after is not None:
            try:self.after_cancel(self._clip_after)
            except Exception:pass
        self._clip_value=value
        self._clip_after=self.after(DARWIN_CLIPBOARD_CLEAR_MS,self._clip_clear_if_ours)

    def _copy_quick_full_darwin(self):
        v=getattr(self,'_quick_variants',None)
        if not v:
            messagebox.showerror('Nothing to copy','Complete the earlier steps first.');return
        if not messagebox.askyesno('Copy FULL (real login/host)',
            FULL_VARIANT_WARNING+DARWIN_CLIPBOARD_NOTE+'\n\nCopy the FULL text to the clipboard anyway?'):
            return
        typed=self._typed_prompt('Confirm FULL copy','Type exactly: '+capability_gate.FULL_COPY_TOKEN,capability_gate.FULL_COPY_TOKEN)
        try:capability_gate.require_full_variant('copy',typed)
        except capability_gate.GateRefused as exc:
            messagebox.showerror('Not copied',str(exc));return
        # A1.1 user gap fix (g)(ii): the FULL text is built ONLY by the token-gated
        # builder (COPY FULL re-checked in quick_reg); the held variants never hold it.
        from quick_reg import quick_instructions_full
        try:full=quick_instructions_full(self.spec(),typed)
        except capability_gate.GateRefused as exc:
            messagebox.showerror('Not copied',str(exc));return
        except Exception:
            messagebox.showerror('Nothing to copy','Complete the earlier steps first.');return
        self.copy_text(full)
        self._arm_clipboard_clear(full)
        self.status.config(text='Copied FULL Quick settings (clears in 60 s)')

    def _show_quick_copy_fields_darwin(self, parent):
        """[P2-S1 / B3c] macOS Step 5 Command / Arguments panel: REDACTED values on screen.
        The per-field Copy buttons need the typed COPY FULL token (same as Copy FULL)."""
        for child in parent.winfo_children():
            child.destroy()
        try:
            values=darwin_redacted_copy_fields(self.spec())
        except IdentityRedactionError:
            # [P2-S1 / B4] withhold the panel entirely; fixed text, no login/host echo.
            ttk.Label(parent, text=DARWIN_PANEL_IDENTITY_REFUSED,
                      style='Muted.TLabel', wraplength=820, justify='left').pack(anchor='w')
            return
        except Exception:
            ttk.Label(parent, text='Quick Command / Arguments appear here after plan generation.',
                      style='Muted.TLabel').pack(anchor='w')
            return
        ttk.Label(parent, text='COPY INTO AMAZON QUICK (Local connector)',
                  style='Muted.TLabel').pack(anchor='w', pady=(3,4))
        self.helper(parent,DARWIN_PANEL_REDACTED_NOTE)
        for label,key in [('Command','command'),('Arguments (paste entire line)','arguments')]:
            ttk.Label(parent,text=label).pack(anchor='w',pady=(5,2))
            row=ttk.Frame(parent);row.pack(fill='x')
            field=ttk.Entry(row)
            field.insert(0,values[key]);field.configure(state='readonly')
            field.pack(side='left',fill='x',expand=True)
            ttk.Button(row,text='Copy '+key+' (FULL)',
                       command=lambda k=key:self._copy_quick_field_full_darwin(k)).pack(side='left',padx=(8,0))
        self.helper(parent,'Quick ID: {}  |  Name: {}  |  Timeout: {} s  |  Environment: EMPTY'.format(
                    values['id'],values['name'],values['timeout_seconds']))

    def _copy_quick_field_full_darwin(self,key):
        # [P2-S1 / B3c] same two-layer gate as _copy_quick_full_darwin: the handler checks
        # COPY FULL, then darwin_full_copy_field checks it again before building the value.
        if not messagebox.askyesno('Copy FULL (real login/host)',
            FULL_VARIANT_WARNING+DARWIN_CLIPBOARD_NOTE+'\n\nCopy the FULL value to the clipboard anyway?'):
            return
        typed=self._typed_prompt('Confirm FULL copy','Type exactly: '+capability_gate.FULL_COPY_TOKEN,capability_gate.FULL_COPY_TOKEN)
        try:capability_gate.require_full_variant('copy',typed)
        except capability_gate.GateRefused as exc:
            messagebox.showerror('Not copied',str(exc));return
        try:value=darwin_full_copy_field(self.spec(),key,typed)
        except capability_gate.GateRefused as exc:
            messagebox.showerror('Not copied',str(exc));return
        except Exception:
            messagebox.showerror('Nothing to copy','Complete the earlier steps first.');return
        self.copy_text(value)
        self._arm_clipboard_clear(value)
        self.status.config(text='Copied FULL value (clears in 60 s)')

    def _export_full_darwin(self):
        if not messagebox.askyesno('Export FULL JSON',
            FULL_VARIANT_WARNING+DARWIN_CLIPBOARD_NOTE+'\n\nWrite the FULL export anyway?'):
            return
        typed=self._typed_prompt('Confirm FULL export','Type exactly: '+capability_gate.FULL_EXPORT_TOKEN,capability_gate.FULL_EXPORT_TOKEN)
        try:capability_gate.require_full_variant('export',typed)
        except capability_gate.GateRefused as exc:
            messagebox.showerror('Not exported',str(exc));return
        self._export_darwin(False,typed)

    def _export_darwin(self,redacted,full_ack):
        # User decision B: refuse a destination inside a Quick-owned folder or on
        # mcp_config.json (checked here for a clear message AND again inside
        # write_quick_config, which also requires EXPORT FULL for the full variant).
        from quick_reg import p2_export_destination_refused,P2_QUICK_DIR_REFUSED
        # [P2-S1 / B4g] D1 / G1-G7: FULL file export. The EXPORT FULL token is checked FIRST
        # (before any folder work or dialog); with Google Drive for desktop detected the
        # private folder is validated, created if missing and re-verified, and the dialog
        # opens inside it; the RETURNED path is validated right after the dialog and again
        # right before the writer. Fixed texts only. Drive not detected: B4f dialog.
        from quick_reg import p2_full_export_dialog_folder,p2_full_export_returned_path_refusal
        spec=self.spec()
        try:validate_spec(spec)
        except Exception as e:messagebox.showerror('Invalid form',str(e));return
        folder=None
        if not redacted:
            try:capability_gate.require_full_variant('export',full_ack)
            except capability_gate.GateRefused as exc:
                messagebox.showerror('Export failed',str(exc));return
            folder,refusal=p2_full_export_dialog_folder()
            if refusal is not None:
                messagebox.showerror('Export refused',refusal);return
        title=('Save REDACTED example (not directly importable)' if redacted
               else 'Save FULL example - contains real login/host')
        if folder is None:
            path=filedialog.asksaveasfilename(title=title,defaultextension='.json',filetypes=[('JSON','*.json')])
        else:
            path=filedialog.asksaveasfilename(title=title,defaultextension='.json',filetypes=[('JSON','*.json')],
                                              initialdir=folder)
        if not path:return
        if not redacted:
            refusal=p2_full_export_returned_path_refusal(path,folder)
            if refusal is not None:
                messagebox.showerror('Export refused',refusal);return
        if p2_export_destination_refused(path):
            messagebox.showerror('Export refused',P2_QUICK_DIR_REFUSED);return
        if not redacted:
            refusal=p2_full_export_returned_path_refusal(path,folder)
            if refusal is not None:
                messagebox.showerror('Export refused',refusal);return
        try:write_quick_config(spec,path,redacted=redacted,full_ack=full_ack)
        except (capability_gate.GateRefused,RedactionError) as exc:
            messagebox.showerror('Export failed',str(exc));return
        except FileExistsError:
            messagebox.showerror('Export failed',DARWIN_EXPORT_FILE_EXISTS_UI);return
        except Exception:
            messagebox.showerror('Export failed',DARWIN_EXPORT_FAILED_UI);return
        note=('Redacted export written (safe to share). This file is NOT proof that Quick can import it.'
              if redacted else
              'FULL export written. '+FULL_VARIANT_WARNING)
        messagebox.showinfo('Example saved',note)

    def go_next(self):
        if self.step==4:messagebox.showinfo('Finish','Complete registration manually in Quick and verify a safe tool call.');return
        if self.step==0:
            try:
                # [v04] use spec() so native-local's pinned host/user validate correctly.
                g=self.spec()
                validate_gateway(g['host'],g['user'])
            except Exception as e:messagebox.showerror('Invalid gateway',str(e));return
        if self.step==1:
            try:
                s=self.spec();s['allow']=s.get('allow') or ['discovery-placeholder']
                # S2: refuse Git/Local on a host THIS wizard bootstrapped (Lambda lane only).
                validate_spec_for_host(s,self.bootstrap_receipt)
            except Exception as e:messagebox.showerror('Invalid backend',str(e));return
            if not self.backend_verification or self.backend_verification.get('backend_identity_sha256')!=backend_identity(self.spec()):
                messagebox.showerror('Backend verification required','Click Test / Verify Backend and wait for a successful MCP tools/list before continuing.');return
        if self.step==2:
            self.save_selection()
            if self.vars['kind'].get()=='lambda' and not self.tool_selection:
                messagebox.showerror('No tools','Discover and select at least one exact tool.');return
        self.step+=1;self.render()

    def go_back(self):
        if self.step>0:self.save_selection();self.step-=1;self.render()

if __name__=='__main__':
    Wizard().mainloop()
